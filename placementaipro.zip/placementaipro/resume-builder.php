<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="icon" type="image/svg+xml" href="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAzMiAzMiIgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIj4KICA8ZGVmcz4KICAgIDxsaW5lYXJHcmFkaWVudCBpZD0iZyIgeDE9IjAiIHkxPSIxIiB4Mj0iMSIgeTI9IjAiPgogICAgICA8c3RvcCBvZmZzZXQ9IjAlIiBzdG9wLWNvbG9yPSIjZmY0NzU3Ii8+CiAgICAgIDxzdG9wIG9mZnNldD0iMTAwJSIgc3RvcC1jb2xvcj0iI2Y1OWUwYiIvPgogICAgPC9saW5lYXJHcmFkaWVudD4KICA8L2RlZnM+CiAgPHJlY3Qgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIiByeD0iNyIgZmlsbD0iIzFlMWExMCIvPgogIDxyZWN0IHg9IjYiIHk9IjIxIiB3aWR0aD0iNSIgaGVpZ2h0PSI5IiByeD0iMS41IiBmaWxsPSIjZjU5ZTBiIiBvcGFjaXR5PSIuNSIvPgogIDxyZWN0IHg9IjEzIiB5PSIxNSIgd2lkdGg9IjUiIGhlaWdodD0iMTUiIHJ4PSIxLjUiIGZpbGw9IiNmZjZiMzUiIG9wYWNpdHk9Ii43NSIvPgogIDxyZWN0IHg9IjIwIiB5PSI4IiB3aWR0aD0iNSIgaGVpZ2h0PSIyMiIgcng9IjEuNSIgZmlsbD0idXJsKCNnKSIvPgogIDxwb2x5bGluZSBwb2ludHM9IjIzLDQgMjcsOCAyNyw1IiBmaWxsPSJub25lIiBzdHJva2U9InVybCgjZykiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIi8+CiAgPGxpbmUgeDE9IjE5IiB5MT0iNSIgeDI9IjI3IiB5Mj0iNCIgc3Ryb2tlPSJ1cmwoI2cpIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPgo8L3N2Zz4=">
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Resume Builder — PlacementAI Pro</title>
  <link rel="stylesheet" href="css/style.css?v=5">
  <style>
    /* ── Stepper ── */
    .rb-stepper { display:flex; align-items:center; background:var(--surface); border:1px solid var(--border); border-radius:var(--radius); padding:6px; margin-bottom:22px; overflow-x:auto; gap:0; }
    .rb-step { flex:1; min-width:72px; display:flex; flex-direction:column; align-items:center; gap:4px; padding:9px 4px; border-radius:8px; cursor:pointer; font-size:11px; font-weight:600; color:var(--text3); transition:all .18s; border:none; background:none; white-space:nowrap; }
    .rb-step-num { width:22px; height:22px; border-radius:50%; background:var(--bg3); border:1px solid var(--border2); display:flex; align-items:center; justify-content:center; font-size:10px; font-weight:700; transition:all .18s; }
    .rb-step.active { color:var(--text); }
    .rb-step.active .rb-step-num { background:var(--primary); border-color:var(--primary); color:#fff; }
    .rb-step.done { color:var(--emerald); }
    .rb-step.done .rb-step-num { background:rgba(16,185,129,.15); border-color:var(--emerald); color:var(--emerald); }
    .rb-step-line { flex:0 0 10px; height:1px; background:var(--border2); }

    /* ── Layout ── */
    .rb-layout { display:grid; grid-template-columns:1fr 420px; gap:20px; align-items:start; }
    @media(max-width:1100px) { .rb-layout { grid-template-columns:1fr; } }

    /* ── Cards ── */
    .rb-card { background:var(--surface); border:1px solid var(--border); border-radius:var(--radius-lg); padding:22px; margin-bottom:14px; animation:fadeUp .2s ease both; }
    .rb-card-head { display:flex; align-items:center; justify-content:space-between; margin-bottom:18px; padding-bottom:14px; border-bottom:1px solid var(--border); }
    .rb-card-title { font-size:14px; font-weight:700; color:var(--text); display:flex; align-items:center; gap:8px; }
    .rb-card-icon { width:30px; height:30px; border-radius:8px; display:flex; align-items:center; justify-content:center; font-size:14px; }

    /* ── ATS meter ── */
    .ats-meter { background:var(--surface); border:1px solid var(--border); border-radius:var(--radius-lg); padding:16px 20px; margin-bottom:20px; }
    .ats-top { display:flex; align-items:flex-start; justify-content:space-between; margin-bottom:10px; gap:12px; }
    .ats-score-num { font-family:var(--font-display); font-size:2.2rem; font-weight:900; line-height:1; }
    .ats-track { height:6px; background:var(--bg3); border-radius:99px; overflow:hidden; margin-bottom:10px; }
    .ats-fill { height:100%; border-radius:99px; transition:width .7s cubic-bezier(.4,0,.2,1); background:linear-gradient(90deg,#ef4444,#f59e0b,#10b981); }
    .ats-grid { display:grid; grid-template-columns:1fr 1fr; gap:4px 16px; }
    .ats-item { font-size:11.5px; display:flex; align-items:center; gap:5px; color:var(--text3); }
    .ats-item.ok { color:var(--emerald); }
    .ats-item::before { content:'○'; opacity:.5; font-size:10px; }
    .ats-item.ok::before { content:'✓'; font-weight:700; opacity:1; }

    /* ── Preview panel ── */
    .rb-preview { background:var(--surface); border:1px solid var(--border); border-radius:var(--radius-lg); position:sticky; top:76px; overflow:hidden; }
    .rb-preview-head { padding:12px 16px; border-bottom:1px solid var(--border); display:flex; align-items:center; justify-content:space-between; gap:10px; }
    .rb-tabs { display:flex; gap:3px; }
    .rb-tab { padding:5px 11px; border-radius:6px; border:1px solid var(--border2); background:none; cursor:pointer; font-size:11.5px; font-weight:600; color:var(--text3); transition:all .15s; }
    .rb-tab.active { background:var(--primary); border-color:var(--primary); color:#fff; }
    .rb-frame { width:100%; height:560px; border:none; background:#fff; display:block; }

    /* ── Template cards ── */
    .tpl-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:10px; }
    .tpl-card { border:2px solid var(--border); border-radius:10px; overflow:hidden; cursor:pointer; transition:border-color .15s,transform .15s; position:relative; }
    .tpl-card:hover { transform:translateY(-2px); border-color:var(--border2); }
    .tpl-card.sel { border-color:var(--primary); }
    .tpl-card.sel::after { content:'✓'; position:absolute; top:5px; right:5px; width:16px; height:16px; background:var(--primary); border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:9px; font-weight:700; color:#fff; }
    .tpl-thumb { width:100%; height:80px; padding:8px; display:flex; flex-direction:column; gap:3px; }
    .tpl-name { font-size:10px; font-weight:600; text-align:center; padding:5px; color:var(--text2); background:var(--bg2); }

    /* ── Color dots ── */
    .color-dots { display:flex; gap:8px; flex-wrap:wrap; }
    .color-dot { width:24px; height:24px; border-radius:50%; cursor:pointer; border:2px solid transparent; transition:transform .15s,border-color .15s; }
    .color-dot:hover { transform:scale(1.15); }
    .color-dot.sel { border-color:var(--text); transform:scale(1.1); }

    /* ── Skills/tags ── */
    .tag-wrap { display:flex; flex-wrap:wrap; gap:6px; padding:8px 10px; background:var(--bg3); border:1px solid var(--border2); border-radius:var(--radius-sm); cursor:text; min-height:44px; }
    .tag-wrap:focus-within { border-color:var(--primary); box-shadow:0 0 0 3px rgba(124,106,255,.12); }
    .s-chip { background:rgba(124,106,255,.12); color:var(--primary-l); border:1px solid rgba(124,106,255,.25); border-radius:99px; padding:3px 10px; font-size:12px; font-weight:600; display:flex; align-items:center; gap:5px; }
    .s-chip button { background:none; border:none; color:inherit; cursor:pointer; padding:0; font-size:13px; opacity:.6; line-height:1; }
    .s-chip button:hover { opacity:1; }
    .tag-input { border:none; background:none; color:var(--text); font-size:13px; outline:none; min-width:110px; flex:1; padding:2px 4px; }
    .q-skill { padding:4px 10px; border-radius:99px; border:1px solid var(--border2); background:var(--bg2); font-size:11.5px; font-weight:600; color:var(--text3); cursor:pointer; transition:all .15s; }
    .q-skill:hover { border-color:var(--primary); color:var(--primary-l); background:rgba(124,106,255,.08); }

    /* ── Entry cards ── */
    .entry-card { background:var(--bg2); border:1px solid var(--border); border-radius:var(--radius); padding:16px; margin-bottom:12px; }
    .entry-card:last-child { margin-bottom:0; }
    .entry-head { display:flex; align-items:center; justify-content:space-between; margin-bottom:12px; }
    .entry-label { font-size:11.5px; font-weight:700; color:var(--text3); text-transform:uppercase; letter-spacing:.07em; }

    /* ── Nav ── */
    .rb-nav { display:flex; gap:12px; margin-top:18px; padding-top:16px; border-top:1px solid var(--border); }
    .rb-nav .btn { flex:1; justify-content:center; }

    /* ── Tips ── */
    .rb-tip { display:flex; align-items:flex-start; gap:8px; background:rgba(124,106,255,.07); border:1px solid rgba(124,106,255,.2); border-radius:8px; padding:10px 12px; font-size:12px; color:var(--text2); margin-top:8px; }
    .rb-tip::before { content:'💡'; flex-shrink:0; }
    .char-hint { font-size:11px; color:var(--text3); text-align:right; margin-top:3px; }

    /* Checklist items */
    .chk-item { display:flex; align-items:center; gap:10px; padding:8px 12px; background:var(--bg2); border-radius:8px; border:1px solid var(--border); }
    .chk-item.chk-ok { border-color:rgba(16,185,129,.25); }
    .chk-dot { width:20px; height:20px; border-radius:50%; flex-shrink:0; display:flex; align-items:center; justify-content:center; font-size:10px; font-weight:700; }
    .chk-dot.ok { background:rgba(16,185,129,.15); color:var(--emerald); }
    .chk-dot.no { background:var(--bg3); color:var(--text3); }
  </style>
</head>
<body>
<script src="js/app.js?v=5"></script>
<script>
const user = Auth.requireAuth('student');
if (user) { buildShell('resume-builder'); setTimeout(initRB, 0); }

// ── State ─────────────────────────────────────────────────────
let profile = null, step = 0;
let tpl = 'modern', accent = '#2563eb';

const STEPS = [
  {icon:'👤',label:'Personal'},
  {icon:'🎓',label:'Education'},
  {icon:'💼',label:'Experience'},
  {icon:'🚀',label:'Projects'},
  {icon:'⚡',label:'Skills'},
  {icon:'✨',label:'Finalize'},
];

const COLORS = [
  {h:'#2563eb',n:'Blue'},{h:'#0891b2',n:'Teal'},{h:'#059669',n:'Emerald'},
  {h:'#7c3aed',n:'Violet'},{h:'#dc2626',n:'Red'},{h:'#d97706',n:'Amber'},
  {h:'#db2777',n:'Pink'},{h:'#1a1a1a',n:'Charcoal'},
];

let fd = {
  name:'',email:'',phone:'',city:'',linkedin:'',github:'',website:'',
  summary:'',achievements:'',skills:[],
  education:[{degree:'',institution:'',year:'',cgpa:'',board:''}],
  experience:[], projects:[],
};

// ── Init ──────────────────────────────────────────────────────
async function initRB() {
  document.getElementById('topbarTitle').textContent = 'Resume Builder';
  try {
    const p = await API.get('student_profile.php?user_id='+user.id);
    if (p?.profile) {
      profile = p.profile;
      fd.name = user.name||''; fd.email = user.email||'';
      fd.phone = profile.phone||''; fd.city = profile.city||'';
      fd.linkedin = profile.linkedin_url||''; fd.github = profile.github_url||'';
      fd.skills = (profile.skills||'').split(',').map(s=>s.trim()).filter(Boolean);
      Object.assign(fd.education[0], {
        degree: profile.branch ? 'B.Tech – '+profile.branch : '',
        institution: profile.college||'',
        year: profile.passing_year||'',
        cgpa: profile.cgpa||'',
      });
    }
  } catch(e) {}
  renderAll();
}

// ── Render ────────────────────────────────────────────────────
function renderAll() {
  const page = document.getElementById('mainPage');
  page.innerHTML = `
    <div class="page-header" style="margin-bottom:16px">
      <h1 style="font-size:1.5rem">📄 Resume Builder</h1>
      <p style="color:var(--text3);font-size:13px;margin-top:2px">Build an ATS-optimized resume with live preview & 3 professional templates</p>
    </div>

    <div class="ats-meter" id="atsMeter">
      <div class="ats-top">
        <div style="flex:1">
          <div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:var(--text3);margin-bottom:2px">ATS Score</div>
          <div style="font-size:12px;color:var(--text3)" id="atsTip">Fill in your details to start</div>
        </div>
        <div style="text-align:right">
          <div class="ats-score-num" id="atsNum" style="color:var(--primary)">0%</div>
          <div style="font-size:10.5px;color:var(--text3)" id="atsGrade">Not started</div>
        </div>
      </div>
      <div class="ats-track"><div class="ats-fill" id="atsFill" style="width:0%"></div></div>
      <div class="ats-grid" id="atsGrid"></div>
    </div>

    <div class="rb-stepper" id="rbStepper">${mkStepper()}</div>

    <div class="rb-layout">
      <div id="rbStep"></div>
      <div class="rb-preview">
        <div class="rb-preview-head">
          <div class="rb-tabs">
            <button class="rb-tab active" onclick="switchTab('preview',this)">Preview</button>
            <button class="rb-tab" onclick="switchTab('design',this)">Design</button>
          </div>
          <button onclick="dlResume()" class="btn btn-primary btn-sm" style="gap:5px">
            <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            Download PDF
          </button>
        </div>
        <div id="previewArea"><iframe id="rbFrame" class="rb-frame" title="Preview"></iframe></div>
      </div>
    </div>`;
  renderStep(); updateATS(); schedPrev();
}

function mkStepper() {
  return STEPS.map((s,i) => {
    const cls = i===step?'active':i<step?'done':'';
    const num = i<step?'✓':(i+1);
    return `<button class="rb-step ${cls}" onclick="goStep(${i})"><div class="rb-step-num">${num}</div><span>${s.icon} ${s.label}</span></button>${i<STEPS.length-1?'<div class="rb-step-line"></div>':''}`;
  }).join('');
}

// ── Step nav ──────────────────────────────────────────────────
function goStep(i) {
  if(i<0||i>=STEPS.length) return;
  save(); step=i;
  document.getElementById('rbStepper').innerHTML = mkStepper();
  renderStep(); if(i===STEPS.length-1) updatePreview(); updateATS(); schedPrev();
}

function save() {
  const g = id => document.getElementById(id)?.value?.trim()||'';
  if(step===0){
    fd.name=g('n_name');fd.email=g('n_email');fd.phone=g('n_phone');
    fd.city=g('n_city');fd.linkedin=g('n_li');fd.github=g('n_gh');fd.website=g('n_web');
  }
  if(step===1){
    document.querySelectorAll('.edu-e').forEach((c,i)=>{
      if(!fd.education[i])fd.education[i]={};
      ['degree','institution','year','cgpa','board'].forEach(k=>{
        fd.education[i][k]=c.querySelector('.e_'+k)?.value?.trim()||'';
      });
    });
  }
  if(step===2){
    document.querySelectorAll('.exp-e').forEach((c,i)=>{
      if(!fd.experience[i])fd.experience[i]={};
      ['role','company','duration','location','description'].forEach(k=>{
        fd.experience[i][k]=c.querySelector('.x_'+k)?.value?.trim()||'';
      });
    });
  }
  if(step===3){
    document.querySelectorAll('.proj-e').forEach((c,i)=>{
      if(!fd.projects[i])fd.projects[i]={};
      ['name','tech','link','description'].forEach(k=>{
        fd.projects[i][k]=c.querySelector('.p_'+k)?.value?.trim()||'';
      });
    });
  }
  if(step===4){fd.summary=g('s_sum');fd.achievements=g('s_ach');}
}

function navB(s) {
  const last = s===STEPS.length-1;
  return `<div class="rb-nav">
    ${s>0?`<button class="btn btn-ghost" onclick="goStep(${s-1})">← Back</button>`:'<div></div>'}
    ${last?`<button class="btn btn-primary" onclick="dlResume()">⬇ Download PDF</button>`
          :`<button class="btn btn-primary" onclick="goStep(${s+1})">Next →</button>`}
  </div>`;
}

function renderStep() {
  const el = document.getElementById('rbStep');
  if(!el) return;
  [sPersonal,sEdu,sExp,sProj,sSkills,sFinalize][step]?.(el);
}

// ── Step 0: Personal ──────────────────────────────────────────
function sPersonal(el) {
  el.innerHTML = `
  <div class="rb-card">
    <div class="rb-card-head">
      <div class="rb-card-title"><div class="rb-card-icon" style="background:rgba(59,130,246,.12)">👤</div>Personal Information</div>
    </div>
    <div class="form-row">
      <div class="form-group"><label class="form-label">Full Name <span style="color:var(--red)">*</span></label>
        <input id="n_name" class="form-input" value="${esc(fd.name||user.name||'')}" placeholder="Rahul Verma" oninput="fd.name=this.value;updateATS();schedPrev()"></div>
      <div class="form-group"><label class="form-label">Email <span style="color:var(--red)">*</span></label>
        <input id="n_email" class="form-input" type="email" value="${esc(fd.email||user.email||'')}" placeholder="rahul@gmail.com" oninput="fd.email=this.value;updateATS();schedPrev()"></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label class="form-label">Phone <span style="color:var(--red)">*</span></label>
        <input id="n_phone" class="form-input" value="${esc(fd.phone||'')}" placeholder="+91 9876543210" oninput="fd.phone=this.value;updateATS();schedPrev()"></div>
      <div class="form-group"><label class="form-label">City / Location</label>
        <input id="n_city" class="form-input" value="${esc(fd.city||'')}" placeholder="Nagpur, Maharashtra" oninput="fd.city=this.value;schedPrev()"></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label class="form-label">LinkedIn URL</label>
        <input id="n_li" class="form-input" value="${esc(fd.linkedin||'')}" placeholder="linkedin.com/in/rahulv" oninput="fd.linkedin=this.value;updateATS();schedPrev()"></div>
      <div class="form-group"><label class="form-label">GitHub URL</label>
        <input id="n_gh" class="form-input" value="${esc(fd.github||'')}" placeholder="github.com/rahulv" oninput="fd.github=this.value;updateATS();schedPrev()"></div>
    </div>
    <div class="form-group"><label class="form-label">Portfolio / Website</label>
      <input id="n_web" class="form-input" value="${esc(fd.website||'')}" placeholder="rahulverma.dev" oninput="fd.website=this.value;schedPrev()"></div>
    <div class="rb-tip">Add LinkedIn + GitHub to boost ATS score by 15 points. Recruiters verify profiles before shortlisting.</div>
  </div>
  ${navB(0)}`;
}

// ── Step 1: Education ─────────────────────────────────────────
function sEdu(el) {
  const rows = fd.education.map((e,i)=>`
    <div class="entry-card edu-e">
      <div class="entry-head">
        <div class="entry-label">Entry ${i+1}</div>
        ${fd.education.length>1?`<button class="btn btn-ghost btn-sm" style="color:var(--red);padding:3px 8px" onclick="rmEntry('education',${i})">✕ Remove</button>`:''}
      </div>
      <div class="form-row">
        <div class="form-group"><label class="form-label">Degree / Course <span style="color:var(--red)">*</span></label>
          <input class="form-input e_degree" value="${esc(e.degree||'')}" placeholder="B.Tech Computer Science" oninput="fd.education[${i}].degree=this.value;updateATS();schedPrev()"></div>
        <div class="form-group"><label class="form-label">Institution <span style="color:var(--red)">*</span></label>
          <input class="form-input e_institution" value="${esc(e.institution||'')}" placeholder="VNIT Nagpur" oninput="fd.education[${i}].institution=this.value;updateATS();schedPrev()"></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label class="form-label">Passing Year</label>
          <input class="form-input e_year" value="${esc(e.year||'')}" placeholder="2025 (Expected)" oninput="fd.education[${i}].year=this.value;schedPrev()"></div>
        <div class="form-group"><label class="form-label">CGPA / Percentage</label>
          <input class="form-input e_cgpa" value="${esc(e.cgpa||'')}" placeholder="8.5 CGPA or 85%" oninput="fd.education[${i}].cgpa=this.value;updateATS();schedPrev()"></div>
      </div>
      <div class="form-group"><label class="form-label">Board / University</label>
        <input class="form-input e_board" value="${esc(e.board||'')}" placeholder="RTM Nagpur University" oninput="fd.education[${i}].board=this.value;schedPrev()"></div>
    </div>`).join('');
  el.innerHTML = `
    <div class="rb-card">
      <div class="rb-card-head">
        <div class="rb-card-title"><div class="rb-card-icon" style="background:rgba(16,185,129,.1)">🎓</div>Education</div>
        <button class="btn btn-ghost btn-sm" onclick="addEntry('education')">+ Add Entry</button>
      </div>
      ${rows}
    </div>${navB(1)}`;
}

// ── Step 2: Experience ────────────────────────────────────────
function sExp(el) {
  const rows = fd.experience.length ? fd.experience.map((e,i)=>`
    <div class="entry-card exp-e">
      <div class="entry-head">
        <div class="entry-label">Experience ${i+1}</div>
        <button class="btn btn-ghost btn-sm" style="color:var(--red);padding:3px 8px" onclick="rmEntry('experience',${i})">✕ Remove</button>
      </div>
      <div class="form-row">
        <div class="form-group"><label class="form-label">Job Title <span style="color:var(--red)">*</span></label>
          <input class="form-input x_role" value="${esc(e.role||'')}" placeholder="Software Engineer Intern" oninput="fd.experience[${i}].role=this.value;updateATS();schedPrev()"></div>
        <div class="form-group"><label class="form-label">Company <span style="color:var(--red)">*</span></label>
          <input class="form-input x_company" value="${esc(e.company||'')}" placeholder="Google" oninput="fd.experience[${i}].company=this.value;updateATS();schedPrev()"></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label class="form-label">Duration</label>
          <input class="form-input x_duration" value="${esc(e.duration||'')}" placeholder="Jun 2024 – Aug 2024" oninput="fd.experience[${i}].duration=this.value;schedPrev()"></div>
        <div class="form-group"><label class="form-label">Location</label>
          <input class="form-input x_location" value="${esc(e.location||'')}" placeholder="Remote / Bangalore" oninput="fd.experience[${i}].location=this.value;schedPrev()"></div>
      </div>
      <div class="form-group"><label class="form-label">Key Achievements <span style="color:var(--text3);font-weight:400;font-size:11.5px">(Start with action verbs: Built, Led, Increased…)</span></label>
        <textarea class="form-input x_description" rows="4" style="resize:vertical" placeholder="• Built REST API handling 10K+ daily requests&#10;• Reduced load time by 40% with Redis caching&#10;• Led 3-member team delivering feature ahead of schedule" oninput="fd.experience[${i}].description=this.value;updateATS();schedPrev()">${esc(e.description||'')}</textarea>
      </div>
    </div>`).join('')
  : `<div style="text-align:center;padding:28px;color:var(--text3)">
      <div style="font-size:2.5rem;margin-bottom:8px">💼</div>
      <div style="font-size:13.5px;font-weight:600;color:var(--text2);margin-bottom:4px">No experience added yet</div>
      <div style="font-size:12px">Add internships, part-time roles, or freelance projects.</div>
    </div>`;
  el.innerHTML = `
    <div class="rb-card">
      <div class="rb-card-head">
        <div class="rb-card-title"><div class="rb-card-icon" style="background:rgba(245,158,11,.1)">💼</div>Work Experience</div>
        <button class="btn btn-ghost btn-sm" onclick="addEntry('experience')">+ Add Experience</button>
      </div>
      ${rows}
    </div>
    <div class="rb-tip">Use bullet points starting with strong verbs. Quantify impact with numbers (%, users, ms, $) — ATS and recruiters both prioritize measurable results.</div>
    ${navB(2)}`;
}

// ── Step 3: Projects ──────────────────────────────────────────
function sProj(el) {
  const rows = fd.projects.length ? fd.projects.map((p,i)=>`
    <div class="entry-card proj-e">
      <div class="entry-head">
        <div class="entry-label">Project ${i+1}</div>
        <button class="btn btn-ghost btn-sm" style="color:var(--red);padding:3px 8px" onclick="rmEntry('projects',${i})">✕ Remove</button>
      </div>
      <div class="form-row">
        <div class="form-group"><label class="form-label">Project Name <span style="color:var(--red)">*</span></label>
          <input class="form-input p_name" value="${esc(p.name||'')}" placeholder="Smart Resume Analyzer" oninput="fd.projects[${i}].name=this.value;updateATS();schedPrev()"></div>
        <div class="form-group"><label class="form-label">Tech Stack</label>
          <input class="form-input p_tech" value="${esc(p.tech||'')}" placeholder="React, Node.js, MongoDB, OpenAI API" oninput="fd.projects[${i}].tech=this.value;updateATS();schedPrev()"></div>
      </div>
      <div class="form-group"><label class="form-label">GitHub / Live Link</label>
        <input class="form-input p_link" value="${esc(p.link||'')}" placeholder="github.com/you/project" oninput="fd.projects[${i}].link=this.value;schedPrev()"></div>
      <div class="form-group"><label class="form-label">Description & Impact</label>
        <textarea class="form-input p_description" rows="3" style="resize:vertical" placeholder="• Built full-stack app with 500+ daily active users&#10;• Implemented real-time chat with WebSockets&#10;• Reduced API response time 60% with Redis caching" oninput="fd.projects[${i}].description=this.value;updateATS();schedPrev()">${esc(p.description||'')}</textarea>
      </div>
    </div>`).join('')
  : `<div style="text-align:center;padding:28px;color:var(--text3)">
      <div style="font-size:2.5rem;margin-bottom:8px">🚀</div>
      <div style="font-size:13.5px;font-weight:600;color:var(--text2);margin-bottom:4px">No projects added yet</div>
      <div style="font-size:12px">Projects are your #1 asset as a fresher — add at least 2!</div>
    </div>`;
  el.innerHTML = `
    <div class="rb-card">
      <div class="rb-card-head">
        <div class="rb-card-title"><div class="rb-card-icon" style="background:rgba(139,92,246,.1)">🚀</div>Projects</div>
        <button class="btn btn-ghost btn-sm" onclick="addEntry('projects')">+ Add Project</button>
      </div>
      ${rows}
    </div>
    <div class="rb-tip">List your 2–3 best projects. Include tech stack explicitly — ATS scans for technology keywords. Add GitHub links to prove the work exists.</div>
    ${navB(3)}`;
}

// ── Step 4: Skills ────────────────────────────────────────────
function sSkills(el) {
  const chips = fd.skills.map((s,i)=>`<span class="s-chip">${esc(s)}<button onclick="rmSkill(${i})">×</button></span>`).join('');
  const common = ['Python','Java','C++','JavaScript','TypeScript','React','Next.js','Node.js','Django',
    'SQL','PostgreSQL','MongoDB','Redis','Git','Docker','Kubernetes','AWS','GCP','Linux',
    'Machine Learning','Data Structures','Algorithms','System Design','REST API','GraphQL','Agile','Figma'];
  const quick = common.filter(s=>!fd.skills.includes(s)).slice(0,18)
    .map(s=>`<button class="q-skill" onclick="addSkill('${s}')">${s}</button>`).join('');
  el.innerHTML = `
    <div class="rb-card">
      <div class="rb-card-head">
        <div class="rb-card-title"><div class="rb-card-icon" style="background:rgba(16,185,129,.1)">⚡</div>Technical Skills</div>
        <span style="font-size:11.5px;color:var(--text3)">${fd.skills.length} skills added</span>
      </div>
      <div class="form-group">
        <label class="form-label">Skills <span style="color:var(--text3);font-weight:400">(Enter or comma to add)</span></label>
        <div class="tag-wrap" id="tagWrap" onclick="document.getElementById('tagInput').focus()">
          ${chips}
          <input id="tagInput" class="tag-input" placeholder="${fd.skills.length?'Add more…':'Python, React, SQL…'}">
        </div>
        <div class="rb-tip" style="margin-top:8px">ATS systems rank resumes by keyword match. Use exact skill names from job descriptions — "JavaScript" not "JS", "Machine Learning" not "ML".</div>
      </div>
      <div class="form-group" style="margin-top:16px">
        <label class="form-label">Quick add</label>
        <div style="display:flex;flex-wrap:wrap;gap:6px">${quick}</div>
      </div>
    </div>

    <div class="rb-card">
      <div class="rb-card-head">
        <div class="rb-card-title"><div class="rb-card-icon" style="background:rgba(59,130,246,.1)">📝</div>Professional Summary</div>
        <button onclick="genSum(this)" class="btn btn-ghost btn-sm" style="gap:5px">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
          AI Generate
        </button>
      </div>
      <div class="form-group">
        <textarea id="s_sum" class="form-input" rows="5" style="resize:vertical"
          placeholder="Motivated B.Tech CS student at VNIT with strong Python and React skills. Built 3 production apps with 500+ daily users. Completed SDE internship at XYZ reducing load time by 40%. Seeking full-time roles at product-based companies."
          oninput="fd.summary=this.value;updateATS();schedPrev()">${esc(fd.summary||'')}</textarea>
        <div style="display:flex;justify-content:space-between;margin-top:4px">
          <div style="font-size:11px;color:var(--text3)">Tip: Mention target role + top 2–3 skills in the first sentence.</div>
          <div class="char-hint" id="sumCnt">${(fd.summary||'').length} / 500</div>
        </div>
      </div>
    </div>

    <div class="rb-card">
      <div class="rb-card-head">
        <div class="rb-card-title"><div class="rb-card-icon" style="background:rgba(245,158,11,.1)">🏆</div>Achievements & Certifications</div>
      </div>
      <div class="form-group">
        <textarea id="s_ach" class="form-input" rows="3" style="resize:vertical"
          placeholder="• AWS Certified Developer – Associate (2024)&#10;• Ranked 350 in LeetCode India&#10;• Won 1st place in TechFest Hackathon 2024" oninput="fd.achievements=this.value;schedPrev()">${esc(fd.achievements||'')}</textarea>
      </div>
    </div>
    ${navB(4)}`;

  const inp = document.getElementById('tagInput');
  inp?.addEventListener('keydown', e => {
    if(e.key==='Enter'||e.key===','){
      e.preventDefault();
      const v=inp.value.replace(/,/g,'').trim();
      if(v&&!fd.skills.includes(v)){fd.skills.push(v);inp.value='';renderStep();updateATS();schedPrev();}
      else inp.value='';
    }
    if(e.key==='Backspace'&&!inp.value&&fd.skills.length){fd.skills.pop();renderStep();updateATS();schedPrev();}
  });
  document.getElementById('s_sum')?.addEventListener('input',function(){
    const el=document.getElementById('sumCnt');if(el)el.textContent=this.value.length+' / 500';
  });
  inp?.focus();
}

// ── Step 5: Finalize ──────────────────────────────────────────
function sFinalize(el) {
  const chks = [
    {ok:!!(fd.name&&fd.email&&fd.phone),l:'Contact info complete'},
    {ok:!!fd.linkedin,l:'LinkedIn linked'},
    {ok:!!fd.github,l:'GitHub linked'},
    {ok:fd.education.some(e=>e.degree&&e.institution),l:'Education details filled'},
    {ok:fd.education.some(e=>e.cgpa),l:'CGPA / marks included'},
    {ok:fd.experience.some(e=>e.role),l:'Work experience added'},
    {ok:fd.projects.filter(p=>p.name).length>=2,l:'2+ projects listed'},
    {ok:fd.projects.some(p=>p.tech),l:'Tech stacks in projects'},
    {ok:fd.skills.length>=8,l:'8+ skills (keyword coverage)'},
    {ok:(fd.summary||'').length>60,l:'Professional summary written'},
  ];
  const chkHtml = chks.map(c=>`
    <div class="chk-item ${c.ok?'chk-ok':''}">
      <div class="chk-dot ${c.ok?'ok':'no'}">${c.ok?'✓':'○'}</div>
      <span style="font-size:12.5px;color:${c.ok?'var(--text)':'var(--text3)'};font-weight:${c.ok?600:400}">${c.l}</span>
    </div>`).join('');
  const done = chks.filter(c=>c.ok).length;

  el.innerHTML = `
    <div class="rb-card">
      <div class="rb-card-head">
        <div class="rb-card-title"><div class="rb-card-icon" style="background:rgba(124,106,255,.12)">🎨</div>Template & Color</div>
      </div>
      <div style="margin-bottom:18px">
        <label class="form-label" style="display:block;margin-bottom:10px">Template</label>
        <div class="tpl-grid" id="tplGrid">${mkTplGrid()}</div>
      </div>
      <div>
        <label class="form-label" style="display:block;margin-bottom:10px">Accent Color</label>
        <div class="color-dots" id="colorDots">${mkColorDots()}</div>
      </div>
    </div>

    <div class="rb-card">
      <div class="rb-card-head">
        <div class="rb-card-title"><div class="rb-card-icon" style="background:rgba(16,185,129,.1)">✅</div>Resume Checklist</div>
        <span style="font-size:12px;font-weight:700;color:${done===chks.length?'var(--emerald)':'var(--accent2)'}">${done}/${chks.length} complete</span>
      </div>
      <div style="display:flex;flex-direction:column;gap:8px">${chkHtml}</div>
    </div>

    <div class="rb-card" style="background:rgba(124,106,255,.05);border-color:rgba(124,106,255,.2);text-align:center;padding:28px">
      <div style="font-size:2rem;margin-bottom:8px">🎉</div>
      <div style="font-family:var(--font-display);font-size:1.1rem;font-weight:800;margin-bottom:6px">Your resume is ready!</div>
      <div style="font-size:13px;color:var(--text3);margin-bottom:20px">Preview on the right. Download → Print dialog → "Save as PDF".</div>
      <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap">
        <button onclick="dlResume()" class="btn btn-primary" style="gap:6px">
          <svg width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
          Download PDF
        </button>
        <button onclick="updatePreview()" class="btn btn-ghost">↺ Refresh</button>
        <button onclick="goStep(0)" class="btn btn-ghost">✏ Edit</button>
      </div>
    </div>
    ${navB(5)}`;
}

function mkTplGrid() {
  return [
    {id:'modern',    n:'Modern',    c:['#2563eb','#f8fafc','#1e293b','#e2e8f0']},
    {id:'executive', n:'Executive', c:['#1a1a1a','#ffffff','#374151','#f3f4f6']},
    {id:'creative',  n:'Creative',  c:['#7c3aed','#faf5ff','#4c1d95','#ede9fe']},
  ].map(t=>`
    <div class="tpl-card ${tpl===t.id?'sel':''}" onclick="selTpl('${t.id}')">
      <div class="tpl-thumb" style="background:${t.c[1]}">
        <div style="height:10px;background:${t.c[0]};border-radius:2px;margin-bottom:4px"></div>
        <div style="height:4px;background:${t.c[2]};border-radius:2px;width:65%"></div>
        <div style="height:3px;background:${t.c[3]};border-radius:2px;width:90%;margin-top:3px"></div>
        <div style="height:3px;background:${t.c[3]};border-radius:2px;width:75%;margin-top:2px"></div>
        <div style="height:5px;background:${t.c[0]}22;border-radius:2px;margin-top:5px"></div>
        <div style="height:3px;background:${t.c[3]};border-radius:2px;width:85%;margin-top:3px"></div>
      </div>
      <div class="tpl-name">${t.n}</div>
    </div>`).join('');
}

function mkColorDots() {
  return COLORS.map(c=>`<div class="color-dot ${accent===c.h?'sel':''}" style="background:${c.h}" title="${c.n}" onclick="selColor('${c.h}')"></div>`).join('');
}

window.selTpl = id => { tpl=id; const g=document.getElementById('tplGrid'); if(g)g.innerHTML=mkTplGrid(); updatePreview(); };
window.selColor = h => { accent=h; const g=document.getElementById('colorDots'); if(g)g.innerHTML=mkColorDots(); updatePreview(); };

// ── CRUD ──────────────────────────────────────────────────────
const DEFAULTS = {
  education:  {degree:'',institution:'',year:'',cgpa:'',board:''},
  experience: {role:'',company:'',duration:'',location:'',description:''},
  projects:   {name:'',tech:'',link:'',description:''},
};
window.addEntry = section => { fd[section].push({...DEFAULTS[section]}); renderStep(); };
window.rmEntry  = (section,i) => { fd[section].splice(i,1); renderStep(); updateATS(); schedPrev(); };
window.addSkill = s => { if(!fd.skills.includes(s)){fd.skills.push(s);renderStep();updateATS();schedPrev();} };
window.rmSkill  = i => { fd.skills.splice(i,1); renderStep(); updateATS(); schedPrev(); };

// ── ATS ───────────────────────────────────────────────────────
function updateATS() {
  const items = [
    {ok:!!fd.name,l:'Full name',p:5},{ok:!!fd.email,l:'Email address',p:5},{ok:!!fd.phone,l:'Phone number',p:5},
    {ok:!!fd.linkedin,l:'LinkedIn profile',p:8},{ok:!!fd.github,l:'GitHub profile',p:7},
    {ok:(fd.summary||'').length>60,l:'Summary (60+ chars)',p:10},
    {ok:fd.education.some(e=>e.degree&&e.institution),l:'Education filled',p:8},
    {ok:fd.education.some(e=>e.cgpa),l:'CGPA / marks',p:5},
    {ok:fd.experience.some(e=>e.role),l:'Work experience',p:10},
    {ok:fd.experience.some(e=>(e.description||'').includes('•')),l:'Bullet points in exp.',p:5},
    {ok:fd.projects.length>=1&&fd.projects.some(p=>p.name),l:'1+ projects',p:8},
    {ok:fd.projects.filter(p=>p.name).length>=2,l:'2+ projects',p:5},
    {ok:fd.projects.some(p=>p.tech),l:'Tech stacks',p:5},
    {ok:fd.skills.length>=5,l:'5+ skills',p:8},{ok:fd.skills.length>=10,l:'10+ skills',p:6},
  ];
  const score = Math.min(100, items.reduce((s,i)=>s+(i.ok?i.p:0),0));
  const grade = score>=85?'Excellent':score>=70?'Good':score>=50?'Fair':'Needs Work';
  const numEl=document.getElementById('atsNum'),fillEl=document.getElementById('atsFill');
  const tipEl=document.getElementById('atsTip'),gradeEl=document.getElementById('atsGrade');
  const gridEl=document.getElementById('atsGrid');
  if(numEl){numEl.textContent=score+'%';numEl.style.color=score>=75?'var(--emerald)':score>=50?'var(--accent2)':'var(--primary)';}
  if(fillEl)fillEl.style.width=score+'%';
  if(gradeEl)gradeEl.textContent=grade;
  if(tipEl){const miss=items.filter(i=>!i.ok);tipEl.textContent=miss.length?'Next: '+miss[0].l:'All key items filled!';}
  if(gridEl)gridEl.innerHTML=items.slice(0,8).map(i=>`<div class="ats-item ${i.ok?'ok':''}">${i.l} (+${i.p})</div>`).join('');
}

// ── AI Summary ────────────────────────────────────────────────
window.genSum = async function(btn) {
  loading(btn,true,'Generating…');
  try {
    const r = await API.post('chatbot.php',{user_id:user.id,message:`Write a 3-sentence ATS-optimized professional summary.
Name: ${fd.name} | Skills: ${fd.skills.slice(0,8).join(', ')} | Experience: ${fd.experience.map(e=>e.role+' at '+e.company).join(', ')||'Fresher'}
Education: ${fd.education.map(e=>e.degree+(e.institution?' from '+e.institution:'')).join(', ')}
Rules: Open with name/status, mention top 3 skills, close with target role. Return ONLY the paragraph.`});
    const txt=(r.reply||r.message||'').trim();
    if(txt){
      fd.summary=txt;
      const el=document.getElementById('s_sum');
      if(el){el.value=txt;el.dispatchEvent(new Event('input'));}
      updateATS();schedPrev();showToast('Summary generated!','var(--emerald)',2500);
    }
  }catch(e){showToast('Could not generate — try again','var(--accent2)',3000);}
  loading(btn,false);
};

// ── Preview / Download ────────────────────────────────────────
let prevTimer;
function schedPrev(){clearTimeout(prevTimer);prevTimer=setTimeout(updatePreview,700);}

function updatePreview(){
  save();
  const frame=document.getElementById('rbFrame');
  if(frame)frame.srcdoc=buildHTML(fd,tpl,accent);
}

window.switchTab = function(tab,btn) {
  document.querySelectorAll('.rb-tab').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  const area=document.getElementById('previewArea');
  if(tab==='preview'){
    area.innerHTML='<iframe id="rbFrame" class="rb-frame" title="Preview"></iframe>';
    updatePreview();
  } else {
    area.innerHTML=`<div style="padding:16px">
      <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--text3);margin-bottom:10px">Template</div>
      <div class="tpl-grid" id="tplGrid">${mkTplGrid()}</div>
      <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--text3);margin:14px 0 10px">Accent Color</div>
      <div class="color-dots" id="colorDots">${mkColorDots()}</div>
    </div>`;
  }
};

function dlResume(){
  save();
  const html=buildHTML(fd,tpl,accent);
  const fname=(fd.name||user.name||'Resume').replace(/\s+/g,'_')+'_Resume';
  const win=window.open('','_blank','width=950,height=750');
  if(win){
    win.document.write(`<!DOCTYPE html><html><head><meta charset="UTF-8"><title>${fname}</title>
      <style>@media print{@page{margin:.5in;size:A4}body{print-color-adjust:exact;-webkit-print-color-adjust:exact}}</style>
    </head><body>${html.replace(/<!DOCTYPE[^>]*>|<\/?html[^>]*>|<head[\s\S]*?<\/head>|<\/?body[^>]*>/gi,'')}</body></html>`);
    win.document.close();
    setTimeout(()=>{win.print();setTimeout(()=>{try{win.close();}catch(e){}},2000);},700);
  } else showToast('Allow popups to download, then try again','#f59e0b',3000);
}

// ── Resume HTML builder ───────────────────────────────────────
function buildHTML(d, template, ac) {
  const name = d.name||'Your Name';
  const contact = [d.email,d.phone,d.city].filter(Boolean).join(' · ');
  const li = (d.linkedin||'').replace(/^https?:\/\//,'').replace(/^www\./,'');
  const gh = (d.github||'').replace(/^https?:\/\//,'').replace(/^www\./,'');
  const ws = (d.website||'').replace(/^https?:\/\//,'').replace(/^www\./,'');
  const links = [li&&`<a href="https://${li}">${li}</a>`,gh&&`<a href="https://${gh}">${gh}</a>`,ws&&`<a href="https://${ws}">${ws}</a>`].filter(Boolean).join(' · ');

  const sec = (title, body) => {
    if(!body) return '';
    if(template==='modern') return `<div style="margin-bottom:20px">
      <div style="font-size:10.5px;font-weight:700;text-transform:uppercase;letter-spacing:.14em;color:${ac};margin-bottom:7px;padding-bottom:5px;border-bottom:2px solid ${ac}33">${title}</div>${body}</div>`;
    if(template==='executive') return `<div style="margin-bottom:22px">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
        <div style="flex:1;height:1px;background:#d1d5db"></div>
        <span style="font-size:10.5px;font-weight:700;text-transform:uppercase;letter-spacing:.15em;color:#374151;white-space:nowrap">${title}</span>
        <div style="flex:1;height:1px;background:#d1d5db"></div>
      </div>${body}</div>`;
    return `<div style="margin-bottom:20px">
      <div style="display:flex;align-items:center;gap:7px;margin-bottom:8px">
        <div style="width:22px;height:3px;background:${ac};border-radius:2px"></div>
        <span style="font-size:10.5px;font-weight:800;text-transform:uppercase;letter-spacing:.12em;color:${ac}">${title}</span>
      </div>${body}</div>`;
  };

  const edu = (d.education||[]).filter(e=>e.degree||e.institution).map(e=>`
    <div style="margin-bottom:10px">
      <div style="display:flex;justify-content:space-between">
        <strong style="font-size:13.5px">${e.degree||''}</strong>
        <span style="font-size:12px;color:#6b7280">${e.year||''}</span>
      </div>
      <div style="font-size:13px;color:#374151">${e.institution||''}${e.board?' · '+e.board:''}</div>
      ${e.cgpa?`<div style="font-size:12px;color:${ac};font-weight:600;margin-top:2px">CGPA: ${e.cgpa}</div>`:''}
    </div>`).join('');

  const exp = (d.experience||[]).filter(e=>e.role||e.company).map(e=>`
    <div style="margin-bottom:14px">
      <div style="display:flex;justify-content:space-between;align-items:baseline">
        <strong style="font-size:13.5px">${e.role||''}</strong>
        <span style="font-size:12px;color:#6b7280;margin-left:8px;white-space:nowrap">${e.duration||''}</span>
      </div>
      <div style="font-size:13px;color:${ac};font-weight:600;margin-bottom:4px">${e.company||''}${e.location?' · '+e.location:''}</div>
      ${e.description?`<div style="font-size:13px;color:#374151;line-height:1.8;white-space:pre-line">${e.description}</div>`:''}
    </div>`).join('');

  const proj = (d.projects||[]).filter(p=>p.name).map(p=>`
    <div style="margin-bottom:14px">
      <div style="display:flex;justify-content:space-between;align-items:baseline">
        <strong style="font-size:13.5px">${p.name}</strong>
        ${p.link?`<a href="${p.link}" style="font-size:11px;color:${ac}">${p.link.replace(/^https?:\/\//,'').substring(0,50)}</a>`:''}
      </div>
      ${p.tech?`<div style="font-size:12px;color:${ac};font-weight:600;margin-bottom:4px">${p.tech}</div>`:''}
      ${p.description?`<div style="font-size:13px;color:#374151;line-height:1.8;white-space:pre-line">${p.description}</div>`:''}
    </div>`).join('');

  const sk = (d.skills||[]);
  const skillsHtml = sk.length ? `<div style="display:flex;flex-wrap:wrap;gap:5px">
    ${sk.map(s=>`<span style="padding:2px 10px;background:${ac}18;color:${ac};border:1px solid ${ac}33;border-radius:99px;font-size:12px;font-weight:600">${s}</span>`).join('')}
  </div>` : '';

  const hdr = template==='modern'
    ? `<div style="background:${ac};color:#fff;padding:28px 36px 20px;text-align:center">
        <h1 style="font-size:26px;font-weight:800;letter-spacing:-.3px;color:#fff;margin-bottom:5px">${name}</h1>
        ${contact?`<div style="font-size:13px;color:rgba(255,255,255,.85);margin-bottom:4px">${contact}</div>`:''}
        ${links?`<div style="font-size:12px;color:rgba(255,255,255,.8)">${links}</div>`:''}
      </div>`
    : template==='executive'
    ? `<div style="border-bottom:3px solid ${ac};padding:26px 36px 18px">
        <h1 style="font-size:26px;font-weight:800;color:#111;letter-spacing:-.3px;margin-bottom:5px">${name}</h1>
        ${contact?`<div style="font-size:13px;color:#6b7280;margin-bottom:4px">${contact}</div>`:''}
        ${links?`<div style="font-size:12.5px;color:${ac}">${links}</div>`:''}
      </div>`
    : `<div style="background:linear-gradient(135deg,${ac},${ac}cc);color:#fff;padding:28px 36px 20px;text-align:center">
        <h1 style="font-size:26px;font-weight:900;letter-spacing:-.3px;color:#fff;margin-bottom:5px">${name}</h1>
        ${contact?`<div style="font-size:13px;color:rgba(255,255,255,.85);margin-bottom:4px">${contact}</div>`:''}
        ${links?`<div style="font-size:12px;color:rgba(255,255,255,.8)">${links}</div>`:''}
      </div>`;

  return `<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>${name} — Resume</title>
<style>*{box-sizing:border-box;margin:0;padding:0}body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;font-size:14px;color:#111;background:#fff;max-width:800px;margin:0 auto;line-height:1.6}a{text-decoration:none}@media print{body{max-width:100%}@page{margin:.45in;size:A4}}</style>
</head><body>
${hdr}
<div style="padding:22px 36px">
  ${d.summary?sec('Professional Summary',`<p style="font-size:13.5px;color:#374151;line-height:1.85">${d.summary}</p>`):''}
  ${sec('Education',edu)}
  ${exp?sec('Work Experience',exp):''}
  ${proj?sec('Projects',proj):''}
  ${skillsHtml?sec('Technical Skills',skillsHtml):''}
  ${d.achievements?sec('Achievements & Certifications',`<div style="font-size:13px;color:#374151;line-height:1.8;white-space:pre-line">${d.achievements}</div>`):''}
</div>
</body></html>`;
}
</script>
</body>
</html>

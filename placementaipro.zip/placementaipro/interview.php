<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">  <link rel="icon" type="image/svg+xml" href="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAzMiAzMiIgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIj4KICA8ZGVmcz4KICAgIDxsaW5lYXJHcmFkaWVudCBpZD0iZyIgeDE9IjAiIHkxPSIxIiB4Mj0iMSIgeTI9IjAiPgogICAgICA8c3RvcCBvZmZzZXQ9IjAlIiBzdG9wLWNvbG9yPSIjZmY0NzU3Ii8+CiAgICAgIDxzdG9wIG9mZnNldD0iMTAwJSIgc3RvcC1jb2xvcj0iI2Y1OWUwYiIvPgogICAgPC9saW5lYXJHcmFkaWVudD4KICA8L2RlZnM+CiAgPHJlY3Qgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIiByeD0iNyIgZmlsbD0iIzFlMWExMCIvPgogIDxyZWN0IHg9IjYiIHk9IjIxIiB3aWR0aD0iNSIgaGVpZ2h0PSI5IiByeD0iMS41IiBmaWxsPSIjZjU5ZTBiIiBvcGFjaXR5PSIuNSIvPgogIDxyZWN0IHg9IjEzIiB5PSIxNSIgd2lkdGg9IjUiIGhlaWdodD0iMTUiIHJ4PSIxLjUiIGZpbGw9IiNmZjZiMzUiIG9wYWNpdHk9Ii43NSIvPgogIDxyZWN0IHg9IjIwIiB5PSI4IiB3aWR0aD0iNSIgaGVpZ2h0PSIyMiIgcng9IjEuNSIgZmlsbD0idXJsKCNnKSIvPgogIDxwb2x5bGluZSBwb2ludHM9IjIzLDQgMjcsOCAyNyw1IiBmaWxsPSJub25lIiBzdHJva2U9InVybCgjZykiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIi8+CiAgPGxpbmUgeDE9IjE5IiB5MT0iNSIgeDI9IjI3IiB5Mj0iNCIgc3Ryb2tlPSJ1cmwoI2cpIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPgo8L3N2Zz4=">
  <link rel="icon" type="image/x-icon" href="data:image/x-icon;base64,AAABAAEAEBAAAAAAIACgAAAAFgAAAIlQTkcNChoKAAAADUlIRFIAAAAQAAAAEAgGAAAAH/P/YQAAAGdJREFUeJxjZIACLg6R/wwkgG8/3jAyMDAwMJGjGVkPIzmakQETJZoZGBgYWNAFvn5/jVMxN6co9V1AWwOwOZkkA/CFB1EGEAOoH43IgOIwIAZQnpRhuYoc8O3HG0YmGIMczQwMDAwA+P4aS3/n/2IAAAAASUVORK5CYII=">
  <link rel="icon" type="image/png" sizes="32x32" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAoElEQVR4nO2XvQ6AIAyES+Pgz6rv/4Cyimw6kWhDxID0HLixabyPozHUUERjPx+xeqmct0bWboVaxk8grG0uvVjbXEJwqrG2DOL0V8ET6FIN275mfXgalld98AQaABwgOYQxyQHLHVSiHyTQALJmoOTOpeAJNAA4wCc/ohLBE2gAcAD8ozS2LmnJeWvgV8CBRNs4eLIsaJoTie04SHM9PwGQNi1E3UY9bQAAAABJRU5ErkJggg==">
  <link rel="icon" type="image/png" sizes="192x192" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMAAAADACAYAAABS3GwHAAADvklEQVR4nO3dQVLjVgBFUZvqASFTsv8FhmkIMzJIdRc0YCxL8pd8z1kAaPCuvmy61MfDxjzcP76OvgbW8/zydBx9DW8NvRhj53AYG8XVf7HRc8q1Y7jaLzN8prhWCKv/EsNnjrVDWO2HGz5LWiuExX+o4bOmpUO4W/KHGT9rW3pji9Rk+IywxGkw+wQwfkZZYnuzAjB+Rpu7wYsDMH62Ys4WLwrA+NmaSzc5OQDjZ6su2eakAIyfrZu60bMDMH72YspWzwrA+Nmbczf7bQDGz16ds91F/ykE7M3JANz92bvvNvxlAMbPrTi1ZY9ApH0agLs/t+arTTsBSPsQgLs/t+qzbTsBSHsXgLs/t+73jTsBSPsVgLs/FW+37gQgTQCk3R0OHn/o+bl5JwBpAiBNAKQJgLSjD8CUOQFIEwBpAiBNAKQJgDQBkPZj9AXM9c+/f4++hF3584+/Rl/CpjgBSBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYC03b8VYi0j356w1psuvBHiIycAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANKOD/ePr6MvYo61XiV+q7wi/T0nAGkCIE0ApAmANAGQJgDSBECaAEgTAGkCIE0ApAmANAGQJgDSBECaAEgTAGkCIE0ApAmANAGQ9mP0BWyVtyc0OAFIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0o4P94+voy8CRnECkCYA0gRAmgBIEwBpd88vT8fRFwEjPL88HZ0ApAmANAGQJgDS7g6H/z8MjL4QuKafm3cCkCYA0n4F4DGIirdbdwKQ9i4ApwC37veNOwFI+xCAU4Bb9dm2nQCkfRqAU4Bb89WmnQCkfRmAU4BbcWrLJ08AEbB3323YIxBp3wbgFGCvztnuWSeACNibczd79iOQCNiLKVud9BlABGzd1I1O/hAsArbqkm1e9C2QCNiaSzd58degImAr5mxx1t8BRMBoczc4+w9hImCUJba36Hj9bzNcw5I33UX/KYTTgLUtvbHVBus0YElr3VxXv2MLgTnWfqq42iOLEJjiWo/TV39mFwKnXPtz5NAPrWLgcBj75cnmvrURxW3b2jeF/wGOq9fsu4f8UQAAAABJRU5ErkJggg==">
  <link rel="apple-touch-icon" sizes="180x180" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAAC0CAYAAAA9zQYyAAADX0lEQVR4nO3cOXJaQQBFUVA58JDa+1+glVpWZgceygOS/kh/rs5ZAOrg8tRAwfl0AO/ffvw2+gys9/B4fx59hiEHEPDrMCLwq/1BEb9u14p71z8iYi7ZM+5dHljITLFH2HdbP6CYmWqPVjZ7hgiZNbZa600WWsystVVDq54VQmYPa9Z68UKLmb2saWtR0GJmb0sbmx20mLmWJa3NClrMXNvc5iYHLWZGmdPepKDFzGhTG3wxaDFzFFNa3Pyjbxjp2aCtM0fzUpNPBi1mjuq5Nl05SLkYtHXm6J5q9L+gxcytuNSqKwcpfwVtnbk1/zZroUkRNCm/g3bd4Fb92a6FJkXQpNydTq4b3L5fDVtoUgRNiqBJObs/U2KhSRE0KYImRdCkCJoUQZPyZvQBlvjy9fPoIxzWh3efRh9hKAtNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiblJr8ku4cRXy71Zd/tWWhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCl+rPEnP5zYYKFJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KT4kuxPH959Gn0ENmChSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJqU8/u3H7+NPgRsxUKTImhSBE2KoEkRNCl3D4/359GHgC08PN6fLTQpgiZF0KTcnU4/7h6jDwJr/GrYQpMiaFJ+B+3awa36s10LTYqgSfkraNcObs2/zVpoUv4L2kpzKy61enGhRc3RPdWoKwcpTwZtpTmq59p8dqFFzdG81KQrBykvBm2lOYopLU5aaFEz2tQGJ185RM0oc9qbdYcWNdc2t7nZLwpFzbUsaW3RuxyiZm9LG1v8tp2o2cuatjaJ0k/ysoUtRnKTD1asNWtt1dDmIVpr5th6DDf/6NtaM9Uerewan7Xmkj1H72prKu7X7Vr/uYdcD8T9Ooy4fh7ivivwhiO8fvoO2onGYhMioSEAAAAASUVORK5CYII=">
  <title>AI Interview — PlacementAI Pro</title>
  <link rel="stylesheet" href="css/style.css?v=5">
  <style>
    .setup-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
    @media(max-width:600px) { .setup-grid { grid-template-columns:1fr; } }

    .diff-btn {
      border: 2px solid var(--border);
      border-radius: var(--radius-sm);
      padding: 10px 12px;
      text-align: center;
      cursor: pointer;
      transition: all .18s;
      background: var(--bg3);
      flex: 1;
    }
    .diff-btn.selected { border-color: var(--primary); background: rgba(108,99,255,.12); }
    .diff-btn .d-title { font-weight: 700; font-size: 13px; color: var(--text); }
    .diff-btn .d-sub   { font-size: 11px; color: var(--text3); margin-top: 2px; }

    .ivp-layout { display: grid; grid-template-columns: 1fr 300px; gap: 20px; }
    @media(max-width:900px) { .ivp-layout { grid-template-columns:1fr; } }

    .iv-main { background: var(--bg2); border: 1px solid var(--border); border-radius: var(--radius); overflow: hidden; }

    .iv-video {
      background: #030609;
      height: 260px;
      display: flex; align-items: center; justify-content: center;
      position: relative;
    }
    .ai-orb {
      width: 110px; height: 110px;
      border-radius: 50%;
      background: radial-gradient(circle at 35% 35%, #a78bfa, #6c63ff 60%, #4338ca);
      display: flex; align-items: center; justify-content: center;
      font-size: 3rem;
      box-shadow: 0 0 60px rgba(108,99,255,.5), 0 0 120px rgba(108,99,255,.2);
      transition: transform .3s;
    }
    .ai-orb.speaking { animation: orb-speak .5s ease-in-out infinite alternate; }
    @keyframes orb-speak { from{transform:scale(1)} to{transform:scale(1.08)} }

    .wave-bars {
      position: absolute; bottom: 14px; left: 50%; transform: translateX(-50%);
      display: flex; align-items: center; gap: 4px;
    }
    .w-bar {
      width: 4px; background: var(--primary); border-radius: 99px;
      animation: wave-anim 1s ease-in-out infinite;
    }
    @keyframes wave-anim { 0%,100%{transform:scaleY(.3)} 50%{transform:scaleY(1)} }
    .w-bar:nth-child(1){height:8px;animation-delay:0s}
    .w-bar:nth-child(2){height:18px;animation-delay:.1s}
    .w-bar:nth-child(3){height:28px;animation-delay:.2s}
    .w-bar:nth-child(4){height:22px;animation-delay:.3s}
    .w-bar:nth-child(5){height:12px;animation-delay:.4s}
    .w-bar:nth-child(6){height:20px;animation-delay:.15s}
    .w-bar:nth-child(7){height:10px;animation-delay:.05s}

    .iv-q-box { padding: 16px 20px; background: var(--surface); border-bottom: 1px solid var(--border); }
    .iv-q-label { font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: .1em; color: var(--text3); margin-bottom: 7px; }
    .iv-q-text  { font-size: 15px; color: var(--text); font-weight: 500; line-height: 1.6; }

    .iv-controls {
      padding: 14px 16px;
      display: flex; align-items: center; gap: 12px;
      background: var(--surface);
    }
    .mic-circle {
      width: 48px; height: 48px; border-radius: 50%; flex-shrink: 0;
      background: linear-gradient(135deg, #6c63ff, #a78bfa);
      border: none; color: #fff; cursor: pointer;
      display: flex; align-items: center; justify-content: center;
      transition: all .2s;
      box-shadow: 0 4px 16px rgba(108,99,255,.4);
    }
    .mic-circle:hover { transform: scale(1.08); }
    .mic-circle.recording { background: linear-gradient(135deg,#ef4444,#f97316); animation: rec-pulse 1s ease infinite; }
    @keyframes rec-pulse { 0%,100%{box-shadow:0 4px 16px rgba(239,68,68,.4)} 50%{box-shadow:0 4px 24px rgba(239,68,68,.7),0 0 0 10px rgba(239,68,68,.1)} }

    .answer-box {
      flex: 1;
      background: var(--bg3);
      border: 1px solid var(--border2);
      border-radius: var(--radius-sm);
      padding: 10px 14px;
      font-size: 14px; color: var(--text2);
      min-height: 46px; max-height: 90px;
      overflow-y: auto;
      outline: none;
      transition: border-color .2s;
    }
    .answer-box:focus { border-color: var(--primary); }

    .iv-feedback { padding: 14px 20px; border-top: 1px solid var(--border); display: none; }
    .iv-fb-label { font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: .1em; color: var(--accent2); margin-bottom: 7px; }
    .iv-fb-text  { font-size: 14px; color: var(--text2); line-height: 1.65; }

    .score-item { display: flex; align-items: center; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid var(--border); font-size: 13px; }
    .score-val { font-weight: 800; font-family: var(--font-display); font-size: 15px; }
    .iv-panel-title { font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:var(--text3); margin-bottom:12px; }
    .score-item:last-child { border: none; }

    .tip-item { display: flex; gap: 8px; font-size: 12.5px; color: var(--text2); margin-bottom: 9px; line-height: 1.5; }

    .type-hint {
      font-size: 12px; color: var(--text3); text-align: center; margin-top: 8px;
      display: flex; align-items: center; justify-content: center; gap: 6px;
    }
  
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');

  /* Match the rest of the site's font */
  body, .form-label, .form-input, .form-select, button { font-family: 'Plus Jakarta Sans', var(--font-body) !important; }

  /* Page header */
  .page-header h1 { font-family: 'Plus Jakarta Sans', sans-serif !important; font-weight: 800 !important; letter-spacing: -.02em !important; }

  /* Setup card: site-standard surface with subtle top accent */
  #setupCard {
    background: var(--surface) !important;
    border: 1px solid var(--border2) !important;
    border-radius: 20px !important;
    box-shadow: 0 8px 40px rgba(0,0,0,.3) !important;
    position: relative; overflow: hidden;
  }
  #setupCard::before {
    content: '';
    position: absolute; top: 0; left: 0; right: 0; height: 3px;
    background: linear-gradient(90deg, #7c6aff, #a78bfa, #00e5b4);
    border-radius: 20px 20px 0 0;
  }
  #setupCard::after { display: none !important; }

  /* Card title */
  #setupCard .card-title, #setupCard .card-header .card-title {
    font-size: 13px !important; font-weight: 700 !important;
    color: var(--text) !important; letter-spacing: .01em !important;
    text-transform: none !important; font-family: 'Plus Jakarta Sans', sans-serif !important;
  }

  /* Labels */
  #setupCard .form-label {
    font-size: 11.5px !important; font-weight: 600 !important;
    color: var(--text2) !important; letter-spacing: .01em !important;
    text-transform: none !important; font-family: 'Plus Jakarta Sans', sans-serif !important;
  }

  /* Inputs & selects */
  #setupCard .form-input, #setupCard .form-select {
    background: var(--bg2) !important;
    border: 1px solid var(--border2) !important;
    border-radius: 10px !important;
    color: var(--text) !important;
    font-size: 14px !important; font-weight: 500 !important;
    font-family: 'Plus Jakarta Sans', sans-serif !important;
    transition: border-color .18s, box-shadow .18s !important;
  }
  #setupCard .form-input:focus, #setupCard .form-select:focus {
    border-color: var(--primary) !important;
    box-shadow: 0 0 0 3px rgba(124,106,255,.14) !important;
    outline: none !important;
  }
  #setupCard option { background: var(--surface); color: var(--text); }

  /* Difficulty buttons */
  .diff-btn {
    background: var(--bg2) !important;
    border: 1.5px solid var(--border) !important;
    border-radius: 12px !important;
    transition: all .18s !important;
  }
  .diff-btn:hover { border-color: var(--primary) !important; background: rgba(124,106,255,.06) !important; }
  .diff-btn.selected {
    border-color: var(--primary) !important;
    background: rgba(124,106,255,.1) !important;
    box-shadow: 0 0 0 3px rgba(124,106,255,.12) !important;
  }
  .diff-btn .d-title { color: var(--text) !important; font-weight: 700 !important; }
  .diff-btn.selected .d-title { color: var(--primary-l) !important; }
  .diff-btn .d-sub { color: var(--text3) !important; }

  /* Start interview button */
  #setupCard .btn-primary {
    background: linear-gradient(135deg, #6c52ff 0%, #7c6aff 60%, #a78bfa 100%) !important;
    border: none !important; border-radius: 12px !important;
    color: #fff !important; font-family: 'Plus Jakarta Sans', sans-serif !important;
    font-size: 14px !important; font-weight: 700 !important;
    letter-spacing: .02em !important;
    box-shadow: 0 4px 20px rgba(124,106,255,.35) !important;
    transition: all .2s !important;
  }
  #setupCard .btn-primary:hover {
    transform: translateY(-2px) !important;
    box-shadow: 0 8px 28px rgba(124,106,255,.5) !important;
  }

  /* AI Powered badge: site standard */
  .badge-purple {
    background: rgba(124,106,255,.12) !important;
    color: var(--primary-l) !important;
    border: 1px solid rgba(124,106,255,.25) !important;
    font-family: 'Plus Jakarta Sans', sans-serif !important;
    font-size: 11px !important; font-weight: 600 !important;
    letter-spacing: .01em !important;
    padding: 4px 10px !important; border-radius: 99px !important;
  }

  </style>
</head>
<body>
<script src="js/app.js?v=5"></script>
<script>
const user = Auth.requireAuth('student');
if (user) { buildShell('interview'); setTimeout(()=>initInterview(), 0); }

let recognition = null;
let synth = window.speechSynthesis;
let msgHistory = [];
let qNum = 0;
let scores = [];
let profile = null;
let typingMode = false;

const hasSpeech = !!( window.SpeechRecognition || window.webkitSpeechRecognition );

async function initInterview() {
  document.getElementById('topbarTitle').textContent = 'AI Interview';
  const page = document.getElementById('mainPage');

  try {
    const p = await API.get('student_profile.php?user_id=' + user.id);
    if (p?.profile) profile = p.profile;
  } catch(e) {}

  page.innerHTML = `
    <div class="page-header">
      <h1 style="font-size:1.6rem">🎙️ AI Mock Interviewer</h1>
      <p style="color:var(--text3);font-size:13px;margin-top:2px">Voice + text interviews · Real-time scoring · Company-specific rounds · Full session summary</p>
    </div>

    <!-- SETUP -->
    <div id="setupCard" class="card" style="max-width:700px;margin:0 auto">
      <div class="card-header"><div class="card-title">Configure Your Interview</div><span class="badge badge-purple">AI Powered</span></div>

      ${!hasSpeech ? `<div class="alert alert-warning mb-4">
        &#9888; Voice recognition not supported in this browser. You can still type your answers.
        Use <strong>Chrome</strong> or <strong>Edge</strong> for voice support.
      </div>` : ''}

      <div class="setup-grid">
        <div class="form-group">
          <label class="form-label">Target Company</label>
          <select id="company" class="form-select">
            <option>Google</option><option>Amazon</option><option>Microsoft</option>
            <option>Infosys</option><option>TCS</option><option>Wipro</option>
            <option>Flipkart</option><option>Accenture</option><option>Other</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Round Type</label>
          <select id="round" class="form-select">
            <option value="Technical">Technical (DSA + CS Fundamentals)</option>
            <option value="HR">HR (Behavioral / STAR)</option>
            <option value="System Design">System Design</option>
            <option value="Mixed">Mixed (HR + Technical)</option>
          </select>
        </div>
      </div>

      <div class="form-group">
        <label class="form-label">Difficulty</label>
        <div style="display:flex;gap:10px">
          <div class="diff-btn" id="d-Easy" onclick="pickDiff('Easy')">
            <div class="d-title">Easy</div>
            <div class="d-sub">5 questions</div>
          </div>
          <div class="diff-btn selected" id="d-Medium" onclick="pickDiff('Medium')">
            <div class="d-title">Medium</div>
            <div class="d-sub">8 questions</div>
          </div>
          <div class="diff-btn" id="d-Hard" onclick="pickDiff('Hard')">
            <div class="d-title">Hard</div>
            <div class="d-sub">10 questions</div>
          </div>
        </div>
      </div>

      <div id="startAlertBox"></div>
      <button id="startBtn" onclick="startInterview()" class="btn btn-primary btn-lg w-full" style="justify-content:center;margin-top:6px">
        &#127908; Start Interview
      </button>
    </div>

    <!-- INTERVIEW PANEL (hidden until started) -->
    <div id="ivPanel" style="display:none">
      <div class="ivp-layout">
        <div class="iv-main">
          <div class="iv-video">
            <div id="aiOrb" class="ai-orb">&#129302;</div>
            <div id="waveWrap" class="wave-bars" style="display:none">
              <div class="w-bar"></div><div class="w-bar"></div><div class="w-bar"></div>
              <div class="w-bar"></div><div class="w-bar"></div><div class="w-bar"></div>
              <div class="w-bar"></div>
            </div>
            <div style="position:absolute;top:12px;right:12px">
              <span class="badge badge-green">&#9679; Live</span>
            </div>
            <div id="qCount" style="position:absolute;top:12px;left:12px;background:rgba(0,0,0,.65);padding:3px 12px;border-radius:99px;font-size:11.5px;font-weight:700;color:#fff">Q 1 of ~8</div>
          </div>

          <div class="iv-q-box">
            <div class="iv-q-label">AI Question</div>
            <div id="qText" class="iv-q-text">Starting your interview…</div>
          </div>

          <div class="iv-controls">
            <button id="micBtn" class="mic-circle" onclick="toggleMic()" title="${hasSpeech ? 'Click to speak' : 'Click to type'}">
              <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/>
                <path d="M19 10v2a7 7 0 0 1-14 0v-2"/>
                <line x1="12" y1="19" x2="12" y2="23"/>
              </svg>
            </button>
            <textarea id="answerBox" class="answer-box" placeholder="Click mic to speak, or type your answer here…" rows="3" style="resize:vertical;min-height:72px;height:auto;overflow:hidden;field-sizing:content;flex:1;background:var(--bg3);border:1.5px solid var(--border2);border-radius:10px;padding:10px 13px;color:var(--text);font-family:var(--font-body);font-size:13.5px;line-height:1.6;outline:none;transition:border-color .2s" oninput="this.style.height='auto';this.style.height=this.scrollHeight+'px';document.getElementById('submitBtn').disabled=this.value.trim().length<2"></textarea>
            <button id="submitBtn" onclick="submitAnswer()" class="btn btn-secondary btn-sm" disabled style="flex-shrink:0">
              Submit
            </button>
          </div>

          <div class="type-hint">
            <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
              <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
            </svg>
            ${hasSpeech ? 'Click mic to speak. Or click in the text area to type manually.' : 'Click in the text area to type your answer, then click Submit.'}
          </div>

          <div id="feedbackBox" class="iv-feedback">
            <div class="iv-fb-label">AI Feedback</div>
            <div id="feedbackText" class="iv-fb-text"></div>
          </div>
        </div>

        <!-- RIGHT SIDEBAR -->
        <div>
          <div class="card mb-3">
            <div class="card-title" style="margin-bottom:14px">Session Scores</div>
            <div id="scoreList">
              <p style="font-size:12.5px;color:var(--text3);text-align:center;padding:8px 0">Scores appear after each answer</p>
            </div>
          </div>

          <div class="card mb-3">
            <div class="card-title" style="margin-bottom:12px">Interview Tips</div>
            <div class="tip-item"><span style="color:var(--primary);flex-shrink:0">&#8227;</span>Use STAR method for behavioral questions</div>
            <div class="tip-item"><span style="color:var(--primary);flex-shrink:0">&#8227;</span>Think aloud — interviewers want your reasoning</div>
            <div class="tip-item"><span style="color:var(--primary);flex-shrink:0">&#8227;</span>Clarify before answering coding questions</div>
            <div class="tip-item"><span style="color:var(--primary);flex-shrink:0">&#8227;</span>Always mention time &amp; space complexity</div>
          </div>

          <button id="endBtn" onclick="endInterview()" class="btn btn-danger w-full" style="justify-content:center" disabled>
            End &amp; Get Report
          </button>
        </div>
      </div>
    </div>

    <!-- REPORT (hidden until ended) -->
    <div id="reportCard" style="display:none;max-width:700px;margin:0 auto">
      <div class="card">
        <div class="card-header">
          <div><div class="card-title">Interview Report</div><div class="card-subtitle">AI performance assessment</div></div>
          <button onclick="resetInterview()" class="btn btn-secondary btn-sm">New Interview</button>
        </div>
        <div id="reportContent"></div>
      </div>
    </div>`;

  // Textarea auto-grow
  const ab = document.getElementById('answerBox');
  if (ab) {
    ab.addEventListener('focus', () => {
      document.getElementById('submitBtn').disabled = ab.value.trim().length < 2;
    });
    ab.addEventListener('input', () => {
      ab.style.height = 'auto';
      ab.style.height = ab.scrollHeight + 'px';
      document.getElementById('submitBtn').disabled = ab.value.trim().length < 2;
    });
  }
}

function pickDiff(d) {
  ['Easy','Medium','Hard'].forEach(x => {
    document.getElementById('d-'+x)?.classList.toggle('selected', x===d);
  });
}

async function startInterview() {
  const btn = document.getElementById('startBtn');
  const alertBox = document.getElementById('startAlertBox');
  clearAlert(alertBox);
  loading(btn, true, 'Starting interview…');

  try {
    const res = await API.post('mock_interview.php', {
      action: 'start',
      profile: profile || {},
      history: [],
      message: '',
      company: document.getElementById('company').value,
      round:   document.getElementById('round').value,
      difficulty: document.querySelector('.diff-btn.selected')?.id?.replace('d-','') || 'Medium'
    });

    if (!res.success) throw new Error(res.message || 'Failed to start');

    msgHistory = [{ role: 'assistant', content: res.reply }];
    qNum = 1;
    window._maxQ = res.max_questions || (document.querySelector('.diff-btn.selected')?.id?.includes('Easy')?5:document.querySelector('.diff-btn.selected')?.id?.includes('Hard')?10:8);

    document.getElementById('setupCard').style.display = 'none';
    document.getElementById('ivPanel').style.display = 'block';
    document.getElementById('endBtn').disabled = false;

    showQuestion(res.reply);
    speakText(res.reply);
  } catch(err) {
    loading(btn, false);
    showAlert(alertBox, err.message || 'Could not start interview. Check your API key in config.php.');
  }
}

function showQuestion(text) {
  document.getElementById('qText').innerHTML = md(text);
  document.getElementById('qCount').textContent = 'Q ' + qNum + ' of ' + (window._maxQ||'~8');
}

function speakText(text) {
  if (!synth) return;
  synth.cancel();
  const clean = text.replace(/\*\*/g,'').replace(/[#*_`]/g,'').trim().slice(0, 450);
  const u = new SpeechSynthesisUtterance(clean);
  u.rate = 1.0; u.pitch = 1.0; u.volume = 1;
  // Prefer a clear English voice
  const voices = synth.getVoices();
  const pick = voices.find(v => v.lang === 'en-US' && v.localService)
            || voices.find(v => v.lang.startsWith('en'));
  if (pick) u.voice = pick;
  const orb = document.getElementById('aiOrb');
  const wave = document.getElementById('waveWrap');
  orb?.classList.add('speaking');
  if (wave) wave.style.display = 'flex';
  u.onend = u.onerror = () => {
    orb?.classList.remove('speaking');
    if (wave) wave.style.display = 'none';
  };
  // Slight delay so voices list is loaded
  setTimeout(() => synth.speak(u), 200);
}

function toggleMic() {
  const micBtn = document.getElementById('micBtn');
  const ab = document.getElementById('answerBox');

  // No speech recognition — switch to typing mode
  if (!hasSpeech) {
    ab.readOnly = false;
    ab.value = ''; ab.focus();
    document.getElementById('submitBtn').disabled = false;
    return;
  }

  if (recognition) {
    recognition.stop();
    recognition = null;
    micBtn.classList.remove('recording');
    return;
  }

  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  recognition = new SR();
  recognition.continuous = true;
  recognition.interimResults = true;
  recognition.lang = 'en-IN';

  ab.value = 'Listening…'; ab.readOnly = true;

  let finalText = '';

  recognition.onresult = e => {
    let interim = '';
    for (let i = e.resultIndex; i < e.results.length; i++) {
      if (e.results[i].isFinal) finalText += e.results[i][0].transcript + ' ';
      else interim += e.results[i][0].transcript;
    }
    ab.value = finalText + interim; ab.style.height='auto'; ab.style.height=ab.scrollHeight+'px';
    document.getElementById('submitBtn').disabled = (finalText + interim).trim().length < 2;
  };

  recognition.onerror = err => {
    micBtn.classList.remove('recognition');
    recognition = null;
    if (err.error === 'not-allowed') {
      ab.value = ''; ab.readOnly = false; ab.placeholder = 'Mic denied — type your answer here';
      ab.readOnly = false;
    }
    micBtn.classList.remove('recording');
  };

  recognition.onend = () => {
    micBtn.classList.remove('recording');
    recognition = null;
    // Allow editing the transcribed text
    ab.readOnly = false;
  };

  recognition.start();
  micBtn.classList.add('recording');
}

async function submitAnswer() {
  const ab = document.getElementById('answerBox');
  const answer = ab.value.trim();
  if (!answer || answer.length < 3) return;

  const btn = document.getElementById('submitBtn');
  loading(btn, true, 'Scoring…');

  // Stop mic if running
  if (recognition) { recognition.stop(); recognition = null; }
  document.getElementById('micBtn').classList.remove('recording');

  msgHistory.push({ role: 'user', content: answer });

  try {
    const res = await API.post('mock_interview.php', {
      action:     'answer',
      profile:    profile || {},
      history:    msgHistory,
      message:    answer,
      company:    document.getElementById('company')?.value || 'Google',
      round:      document.getElementById('round')?.value   || 'Technical',
      difficulty: document.querySelector('.diff-btn.selected')?.id?.replace('d-','') || 'Medium'
    });

    if (!res.success) throw new Error(res.message);

    msgHistory.push({ role: 'assistant', content: res.reply });
    qNum++;

    // Show feedback
    const fb = document.getElementById('feedbackBox');
    document.getElementById('feedbackText').innerHTML = md(res.reply);
    // Extract score and color feedback accordingly
    const sm = res.reply.match(/Score:\s*(\d+)\s*\/\s*10/i) || res.reply.match(/(\d+)\s*\/\s*10/);
    if (sm) {
      const s = Math.min(10, parseInt(sm[1]));  // cap at 10 in case AI returns /100 scale
      scores.push(s);
      renderScores();
      fb.style.borderLeft = `3px solid ${s>=7?'var(--emerald)':s>=5?'var(--accent2)':'var(--red)'}`;
      fb.style.background = s>=7?'rgba(0,214,143,.05)':s>=5?'rgba(245,158,11,.05)':'rgba(255,71,87,.04)';
    } else {
      fb.style.borderLeft = '';
      fb.style.background = '';
    }
    fb.style.display = 'block';

    speakText(res.reply.slice(0, 220));

    loading(btn, false);
    btn.disabled = true;
    ab.value = ''; ab.style.height = '72px'; ab.focus();

    // After pause, ask next question
    setTimeout(async () => {
      fb.style.display = 'none';

      if (qNum > (window._maxQ||8) || res.reply.toLowerCase().includes('final assessment')) {
        endInterview(); return;
      }

      try {
        const next = await API.post('mock_interview.php', {
          action:     'next',
          profile:    profile || {},
          history:    msgHistory,
          message:    'Next question please.',
          company:    document.getElementById('company')?.value || 'Google',
          round:      document.getElementById('round')?.value   || 'Technical',
          difficulty: document.querySelector('.diff-btn.selected')?.id?.replace('d-','') || 'Medium'
        });
        if (next?.reply) {
          msgHistory.push({ role: 'assistant', content: next.reply });
          showQuestion(next.reply);
          speakText(next.reply);
        }
      } catch(e) {}
    }, 4500);

  } catch(err) {
    loading(btn, false);
    const fb = document.getElementById('feedbackBox');
    document.getElementById('feedbackText').innerHTML = `<span style="color:var(--red);font-weight:600">⚠ Error: ${esc(err.message || 'Could not get AI response. Check API key in config.php.')}</span>`;
    fb.style.display = 'block';
  }
}

function renderScores() {
  const avg = scores.length ? Math.min(100, Math.round(scores.reduce((a,b)=>a+b,0)/scores.length * 10)) : 0;
  document.getElementById('scoreList').innerHTML =
    scores.map((s,i) => `
      <div class="score-item">
        <span style="color:var(--text3)">Q${i+1}</span>
        <span style="font-weight:700;color:${s>=7?'var(--emerald)':s>=5?'var(--accent2)':'var(--red)'}">${s}/10</span>
      </div>`).join('') +
    `<div class="score-item" style="margin-top:4px">
      <span style="font-weight:700;color:var(--text)">Average</span>
      <span style="font-weight:800;color:var(--primary);font-family:var(--font-display)">${avg}/100</span>
    </div>`;
}

async function endInterview() {
  if (recognition) { try { recognition.stop(); } catch(e){} recognition = null; }
  if (synth) { try { synth.cancel(); } catch(e){} }

  const avg = scores.length ? Math.min(100, Math.round(scores.reduce((a,b)=>a+b,0)/scores.length * 10)) : 0;

  if (avg > 0) {
    try { await API.post('student_profile_save.php', { ...(profile||{}), user_id:user.id, interview_score:avg }); }
    catch(e) {}
  }

  const ivPanelEl  = document.getElementById('ivPanel');
  const reportEl   = document.getElementById('reportCard');
  if (!ivPanelEl || !reportEl) {
    console.error('Interview panel elements not found');
    return;
  }
  ivPanelEl.style.display  = 'none';
  reportEl.style.display   = 'block';

  const color = avg >= 75 ? '#10b981' : avg >= 50 ? '#f59e0b' : '#ef4444';
  const label = avg >= 75 ? 'Excellent performance!' : avg >= 50 ? 'Good effort!' : 'Keep practicing!';

  const noScores = scores.length === 0;
  document.getElementById('reportContent').innerHTML = `
    <div style="text-align:center;padding:28px 0 20px">
      ${noScores ? `<div style="font-size:5rem;line-height:1;margin-bottom:14px">&#127937;</div>` : scoreRing(avg, 150, color)}
      <div style="font-size:1.15rem;font-weight:700;margin-top:14px">${noScores ? 'Session Complete!' : label}</div>
      <div style="color:var(--text3);font-size:13px;margin-top:4px">${qNum-1} question${qNum-1!==1?'s':''} answered · ${scores.length} scored</div>
      ${noScores ? `<div class="alert alert-info" style="margin-top:16px;text-align:left">Set <strong>CLAUDE_API_KEY</strong> in <code>php/config.php</code> for AI scoring and real interview questions.</div>` : ''}
    </div>
    <div class="glow-line"></div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin:20px 0">
      <div style="text-align:center">
        <div style="font-family:var(--font-display);font-size:1.8rem;font-weight:900;color:var(--primary)">${avg}</div>
        <div style="font-size:11px;color:var(--text3)">Overall Score</div>
      </div>
      <div style="text-align:center">
        <div style="font-family:var(--font-display);font-size:1.8rem;font-weight:900;color:var(--emerald)">${scores.filter(s=>s>=7).length}</div>
        <div style="font-size:11px;color:var(--text3)">Strong Answers</div>
      </div>
      <div style="text-align:center">
        <div style="font-family:var(--font-display);font-size:1.8rem;font-weight:900;color:var(--accent2)">${scores.filter(s=>s<5).length}</div>
        <div style="font-size:11px;color:var(--text3)">Need Work</div>
      </div>
    </div>
    <div class="alert ${avg>=75?'alert-success':avg>=50?'alert-info':'alert-warning'}">
      ${avg>=75
        ? '&#127881; Outstanding session! Your communication and depth were impressive. Apply to companies now.'
        : avg>=50
        ? '&#128077; Solid effort. Focus on STAR method and adding more technical depth to answers.'
        : '&#128218; Keep practicing. Review core CS concepts and work on articulating your thought process clearly.'}
    </div>`;
}

function resetInterview() {
  msgHistory = []; qNum = 0; scores = [];
  document.getElementById('reportCard').style.display = 'none';
  document.getElementById('setupCard').style.display = 'block';
  document.getElementById('startBtn').textContent = '&#127908; Start Interview';
  document.getElementById('startBtn').disabled = false;
}
</script>
</body>
</html>

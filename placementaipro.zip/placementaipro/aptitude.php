<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">  <link rel="icon" type="image/svg+xml" href="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAzMiAzMiIgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIj4KICA8ZGVmcz4KICAgIDxsaW5lYXJHcmFkaWVudCBpZD0iZyIgeDE9IjAiIHkxPSIxIiB4Mj0iMSIgeTI9IjAiPgogICAgICA8c3RvcCBvZmZzZXQ9IjAlIiBzdG9wLWNvbG9yPSIjZmY0NzU3Ii8+CiAgICAgIDxzdG9wIG9mZnNldD0iMTAwJSIgc3RvcC1jb2xvcj0iI2Y1OWUwYiIvPgogICAgPC9saW5lYXJHcmFkaWVudD4KICA8L2RlZnM+CiAgPHJlY3Qgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIiByeD0iNyIgZmlsbD0iIzFlMWExMCIvPgogIDxyZWN0IHg9IjYiIHk9IjIxIiB3aWR0aD0iNSIgaGVpZ2h0PSI5IiByeD0iMS41IiBmaWxsPSIjZjU5ZTBiIiBvcGFjaXR5PSIuNSIvPgogIDxyZWN0IHg9IjEzIiB5PSIxNSIgd2lkdGg9IjUiIGhlaWdodD0iMTUiIHJ4PSIxLjUiIGZpbGw9IiNmZjZiMzUiIG9wYWNpdHk9Ii43NSIvPgogIDxyZWN0IHg9IjIwIiB5PSI4IiB3aWR0aD0iNSIgaGVpZ2h0PSIyMiIgcng9IjEuNSIgZmlsbD0idXJsKCNnKSIvPgogIDxwb2x5bGluZSBwb2ludHM9IjIzLDQgMjcsOCAyNyw1IiBmaWxsPSJub25lIiBzdHJva2U9InVybCgjZykiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIi8+CiAgPGxpbmUgeDE9IjE5IiB5MT0iNSIgeDI9IjI3IiB5Mj0iNCIgc3Ryb2tlPSJ1cmwoI2cpIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPgo8L3N2Zz4=">
  <link rel="icon" type="image/x-icon" href="data:image/x-icon;base64,AAABAAEAEBAAAAAAIACgAAAAFgAAAIlQTkcNChoKAAAADUlIRFIAAAAQAAAAEAgGAAAAH/P/YQAAAGdJREFUeJxjZIACLg6R/wwkgG8/3jAyMDAwMJGjGVkPIzmakQETJZoZGBgYWNAFvn5/jVMxN6co9V1AWwOwOZkkA/CFB1EGEAOoH43IgOIwIAZQnpRhuYoc8O3HG0YmGIMczQwMDAwA+P4aS3/n/2IAAAAASUVORK5CYII=">
  <link rel="icon" type="image/png" sizes="32x32" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAoElEQVR4nO2XvQ6AIAyES+Pgz6rv/4Cyimw6kWhDxID0HLixabyPozHUUERjPx+xeqmct0bWboVaxk8grG0uvVjbXEJwqrG2DOL0V8ET6FIN275mfXgalld98AQaABwgOYQxyQHLHVSiHyTQALJmoOTOpeAJNAA4wCc/ohLBE2gAcAD8ozS2LmnJeWvgV8CBRNs4eLIsaJoTie04SHM9PwGQNi1E3UY9bQAAAABJRU5ErkJggg==">
  <link rel="icon" type="image/png" sizes="192x192" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMAAAADACAYAAABS3GwHAAADvklEQVR4nO3dQVLjVgBFUZvqASFTsv8FhmkIMzJIdRc0YCxL8pd8z1kAaPCuvmy61MfDxjzcP76OvgbW8/zydBx9DW8NvRhj53AYG8XVf7HRc8q1Y7jaLzN8prhWCKv/EsNnjrVDWO2HGz5LWiuExX+o4bOmpUO4W/KHGT9rW3pji9Rk+IywxGkw+wQwfkZZYnuzAjB+Rpu7wYsDMH62Ys4WLwrA+NmaSzc5OQDjZ6su2eakAIyfrZu60bMDMH72YspWzwrA+Nmbczf7bQDGz16ds91F/ykE7M3JANz92bvvNvxlAMbPrTi1ZY9ApH0agLs/t+arTTsBSPsQgLs/t+qzbTsBSHsXgLs/t+73jTsBSPsVgLs/FW+37gQgTQCk3R0OHn/o+bl5JwBpAiBNAKQJgLSjD8CUOQFIEwBpAiBNAKQJgDQBkPZj9AXM9c+/f4++hF3584+/Rl/CpjgBSBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYC03b8VYi0j356w1psuvBHiIycAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANKOD/ePr6MvYo61XiV+q7wi/T0nAGkCIE0ApAmANAGQJgDSBECaAEgTAGkCIE0ApAmANAGQJgDSBECaAEgTAGkCIE0ApAmANAGQ9mP0BWyVtyc0OAFIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0o4P94+voy8CRnECkCYA0gRAmgBIEwBpd88vT8fRFwEjPL88HZ0ApAmANAGQJgDS7g6H/z8MjL4QuKafm3cCkCYA0n4F4DGIirdbdwKQ9i4ApwC37veNOwFI+xCAU4Bb9dm2nQCkfRqAU4Bb89WmnQCkfRmAU4BbcWrLJ08AEbB3323YIxBp3wbgFGCvztnuWSeACNibczd79iOQCNiLKVud9BlABGzd1I1O/hAsArbqkm1e9C2QCNiaSzd58degImAr5mxx1t8BRMBoczc4+w9hImCUJba36Hj9bzNcw5I33UX/KYTTgLUtvbHVBus0YElr3VxXv2MLgTnWfqq42iOLEJjiWo/TV39mFwKnXPtz5NAPrWLgcBj75cnmvrURxW3b2jeF/wGOq9fsu4f8UQAAAABJRU5ErkJggg==">
  <link rel="apple-touch-icon" sizes="180x180" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAAC0CAYAAAA9zQYyAAADX0lEQVR4nO3cOXJaQQBFUVA58JDa+1+glVpWZgceygOS/kh/rs5ZAOrg8tRAwfl0AO/ffvw2+gys9/B4fx59hiEHEPDrMCLwq/1BEb9u14p71z8iYi7ZM+5dHljITLFH2HdbP6CYmWqPVjZ7hgiZNbZa600WWsystVVDq54VQmYPa9Z68UKLmb2saWtR0GJmb0sbmx20mLmWJa3NClrMXNvc5iYHLWZGmdPepKDFzGhTG3wxaDFzFFNa3Pyjbxjp2aCtM0fzUpNPBi1mjuq5Nl05SLkYtHXm6J5q9L+gxcytuNSqKwcpfwVtnbk1/zZroUkRNCm/g3bd4Fb92a6FJkXQpNydTq4b3L5fDVtoUgRNiqBJObs/U2KhSRE0KYImRdCkCJoUQZPyZvQBlvjy9fPoIxzWh3efRh9hKAtNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiblJr8ku4cRXy71Zd/tWWhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCl+rPEnP5zYYKFJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KT4kuxPH959Gn0ENmChSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJqU8/u3H7+NPgRsxUKTImhSBE2KoEkRNCl3D4/359GHgC08PN6fLTQpgiZF0KTcnU4/7h6jDwJr/GrYQpMiaFJ+B+3awa36s10LTYqgSfkraNcObs2/zVpoUv4L2kpzKy61enGhRc3RPdWoKwcpTwZtpTmq59p8dqFFzdG81KQrBykvBm2lOYopLU5aaFEz2tQGJ185RM0oc9qbdYcWNdc2t7nZLwpFzbUsaW3RuxyiZm9LG1v8tp2o2cuatjaJ0k/ysoUtRnKTD1asNWtt1dDmIVpr5th6DDf/6NtaM9Uerewan7Xmkj1H72prKu7X7Vr/uYdcD8T9Ooy4fh7ivivwhiO8fvoO2onGYhMioSEAAAAASUVORK5CYII=">
  <title>Aptitude Test — PlacementAI Pro</title>
  <link rel="stylesheet" href="css/style.css?v=5">
  <style>
    .quiz-wrap { max-width: 760px; margin: 0 auto; }
    .q-card { background: var(--surface); border: 1.5px solid var(--border); border-radius: var(--radius); padding: 26px 28px; margin-bottom: 18px; animation: slideUp .3s ease both; }
    .q-number { font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: .1em; color: var(--primary); margin-bottom: 8px; }
    .q-text { font-size: 15px; font-weight: 600; color: var(--text); line-height: 1.65; margin-bottom: 18px; }
    .options { display: flex; flex-direction: column; gap: 10px; }
    .opt-btn { padding: 12px 16px; border: 1.5px solid var(--border); border-radius: 10px; background: var(--bg3); cursor: pointer; text-align: left; font-size: 13.5px; color: var(--text2); transition: all .15s; display: flex; gap: 12px; align-items: center; }
    .opt-btn:hover:not(.selected):not(.correct):not(.wrong) { border-color: var(--primary); color: var(--text); background: rgba(108,99,255,.06); }
    .opt-btn.selected { border-color: var(--primary); color: var(--primary); background: rgba(108,99,255,.1); }
    .opt-btn.correct  { border-color: var(--emerald); color: var(--emerald); background: rgba(0,214,143,.1); }
    .opt-btn.wrong    { border-color: var(--red);     color: var(--red);     background: rgba(239,68,68,.08); }
    .opt-letter { width: 24px; height: 24px; border-radius: 6px; background: var(--surface2); display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: 800; flex-shrink: 0; }
    .explanation { margin-top: 14px; padding: 12px 16px; background: rgba(108,99,255,.07); border-radius: 10px; font-size: 13px; color: var(--text2); line-height: 1.6; border-left: 3px solid var(--primary); display: none; }
    .progress-strip { height: 5px; background: var(--surface3); border-radius: 99px; overflow: hidden; margin-bottom: 20px; }
    .progress-fill { height: 100%; background: var(--primary); border-radius: 99px; transition: width .4s ease; }
    .result-card { text-align: center; padding: 40px 32px; }
    .score-circle { width: 140px; height: 140px; border-radius: 50%; margin: 0 auto 24px; display: flex; flex-direction: column; align-items: center; justify-content: center; border: 8px solid var(--emerald); background: rgba(0,214,143,.06); }
    .score-circle.mid { border-color: var(--accent2); background: rgba(245,158,11,.06); }
    .score-circle.low { border-color: var(--red); background: rgba(239,68,68,.06); }
    .timer-badge { display: inline-flex; align-items: center; gap: 6px; padding: 6px 14px; background: var(--surface2); border-radius: 99px; font-size: 12px; font-weight: 700; color: var(--text2); }
    .timer-badge.urgent { color: var(--red); background: rgba(239,68,68,.1); }
    .sect-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 24px; }
    .sect-btn { position:relative; overflow:hidden; }
    .sect-btn::after { content:"→"; position:absolute; right:14px; top:50%; transform:translateY(-50%); font-size:16px; color:var(--text3); transition:all .15s; }
    .sect-btn:hover::after { color:var(--primary); right:10px; }
    .sect-btn { background: var(--bg3); border: 1.5px solid var(--border); border-radius: 12px; padding: 16px; cursor: pointer; transition: all .15s; text-align:left; }
    .sect-btn:hover { border-color: var(--primary); background: rgba(108,99,255,.06); }
  
  @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;800;900&family=DM+Sans:wght@400;500;600&display=swap');

  /* Section cards: editorial magazine feel */
  .sect-btn {
    background: var(--surface) !important;
    border: 1px solid var(--border) !important;
    border-radius: 14px !important;
    padding: 22px 20px !important;
    transition: all .22s cubic-bezier(.4,0,.2,1) !important;
    position: relative;
    overflow: hidden;
  }
  .sect-btn::before {
    content: '';
    position: absolute; bottom: 0; left: 0; right: 0; height: 3px;
    transform: scaleX(0); transform-origin: left;
    transition: transform .25s ease;
  }
  .sect-btn:nth-child(1)::before { background: linear-gradient(90deg, #7c6aff, #a78bfa); }
  .sect-btn:nth-child(2)::before { background: linear-gradient(90deg, #00d68f, #00e5b4); }
  .sect-btn:nth-child(3)::before { background: linear-gradient(90deg, #f59e0b, #fbbf24); }
  .sect-btn:nth-child(4)::before { background: linear-gradient(90deg, #00c8ff, #38bdf8); }
  .sect-btn:hover::before { transform: scaleX(1); }
  .sect-btn:hover {
    border-color: var(--border2) !important;
    transform: translateY(-4px) !important;
    box-shadow: 0 12px 32px rgba(0,0,0,.4) !important;
    background: var(--bg2) !important;
  }

  /* Section card title: Playfair headline */
  .sect-btn div[style*="font-weight:700"] {
    font-family: 'Playfair Display', Georgia, serif !important;
    font-size: 15px !important;
    font-weight: 700 !important;
    letter-spacing: -.01em !important;
  }

  /* Intro card: make it dramatic */
  .quiz-wrap > .card {
    background: var(--surface) !important;
    border: 1px solid var(--border) !important;
    border-radius: 20px !important;
    overflow: hidden;
    position: relative;
  }
  .quiz-wrap > .card::before {
    content: '';
    position: absolute; top: 0; left: 0; right: 0; height: 180px;
    background: radial-gradient(ellipse at 50% 0%, rgba(124,106,255,.08) 0%, transparent 70%);
    pointer-events: none;
  }

  /* Big title in intro */
  .quiz-wrap h2 {
    font-family: 'Playfair Display', Georgia, serif !important;
    font-size: clamp(1.6rem, 3vw, 2rem) !important;
    font-weight: 900 !important;
    letter-spacing: -.03em !important;
  }

  /* Question card: clean exam paper feel */
  .q-card {
    border-radius: 16px !important;
    border: 1px solid var(--border) !important;
    position: relative;
    overflow: hidden;
  }
  .q-card::before {
    content: '';
    position: absolute; left: 0; top: 0; bottom: 0; width: 4px;
    background: linear-gradient(180deg, #7c6aff, #a78bfa);
  }
  .q-number {
    font-family: 'DM Sans', sans-serif !important;
    font-size: 10.5px !important;
    letter-spacing: .15em !important;
  }
  .q-text {
    font-family: 'Playfair Display', Georgia, serif !important;
    font-size: 16px !important;
    font-weight: 600 !important;
    line-height: 1.7 !important;
  }

  /* Options: newspaper-style */
  .opt-btn {
    border-radius: 10px !important;
    border: 1px solid var(--border) !important;
    background: transparent !important;
    font-family: 'DM Sans', sans-serif !important;
    transition: all .15s !important;
  }
  .opt-btn:hover:not(.selected):not(.correct):not(.wrong) {
    background: rgba(124,106,255,.05) !important;
    border-color: rgba(124,106,255,.3) !important;
    transform: translateX(4px) !important;
  }
  .opt-letter {
    background: var(--bg3) !important;
    border-radius: 6px !important;
    font-family: 'Playfair Display', serif !important;
    font-size: 12px !important;
  }

  /* Result card */
  .result-card h2 {
    font-family: 'Playfair Display', serif !important;
    font-size: 1.8rem !important;
  }

  /* Page header */
  .page-header h1 {
    font-family: 'Playfair Display', Georgia, serif !important;
    font-weight: 900 !important;
    letter-spacing: -.03em !important;
  }

  /* Timer badge */
  .timer-badge {
    font-family: 'DM Sans', sans-serif !important;
    border-radius: 10px !important;
    border: 1px solid var(--border2) !important;
    background: var(--surface2) !important;
    letter-spacing: .04em !important;
  }
  .timer-badge.urgent {
    background: rgba(239,68,68,.12) !important;
    border-color: rgba(239,68,68,.3) !important;
    box-shadow: 0 0 16px rgba(239,68,68,.15) !important;
  }

  </style>
</head>
<body>
<script src="js/app.js?v=5"></script>
<script>
const QUESTIONS = {
  quantitative: [
    { q:"A train travels 360 km in 4 hours. What is its speed in m/s?", opts:["25 m/s","30 m/s","22.5 m/s","90 m/s"], ans:0, exp:"360 km/4h = 90 km/h = 90×1000/3600 = 25 m/s" },
    { q:"A can do a work in 12 days, B in 18 days. Together they finish in?", opts:["7.2 days","7 days","6 days","8 days"], ans:0, exp:"Rate = 1/12+1/18 = 5/36. Days = 36/5 = 7.2 days" },
    { q:"If 40% of a number is 120, what is 25% of that number?", opts:["75","90","80","60"], ans:0, exp:"Number = 120/0.4 = 300. 25% of 300 = 75" },
    { q:"Compound interest on ₹8000 at 10% p.a. for 2 years (compounded annually)?", opts:["₹1680","₹1600","₹1728","₹1760"], ans:0, exp:"A = 8000×(1.1)² = 9680. CI = 9680-8000 = ₹1680" },
    { q:"If 5 men complete work in 8 days, how many men finish it in 4 days?", opts:["10","12","8","15"], ans:0, exp:"5×8 = M×4 → M = 10 men" },
    { q:"A shopkeeper gives 10% discount but still gains 20%. What's the mark-up % on cost?", opts:["33.33%","30%","25%","32%"], ans:0, exp:"Let CP=100. SP=120. MP×0.9=120 → MP=133.33. Markup=33.33%" },
    { q:"Speed of boat in still water is 15 km/h, stream 3 km/h. Time to go 36 km downstream?", opts:["2 hours","2.5 hours","3 hours","2.25 hours"], ans:0, exp:"Downstream = 15+3 = 18 km/h. Time = 36/18 = 2 hours" },
    { q:"Sum of first 20 odd numbers?", opts:["400","380","200","420"], ans:0, exp:"Sum of first n odd numbers = n². 20² = 400" },
    { q:"P sells to Q at 20% profit, Q sells to R at 25% profit. If R pays ₹900, what did P pay?", opts:["₹600","₹650","₹625","₹700"], ans:0, exp:"900 = P×1.2×1.25 = 1.5P → P = 600" },
    { q:"Two numbers are in ratio 3:5. If 9 is subtracted from each, ratio becomes 12:23. Larger number?", opts:["65","44","55","33"], ans:2, exp:"Let numbers be 3x and 5x. (3x-9)/(5x-9)=12/23 → 69x-207=60x-108 → 9x=99 → x=11. Larger number = 5×11 = 55." },
  ],
  logical: [
    { q:"Find next in series: 2, 6, 12, 20, 30, ?", opts:["42","40","36","48"], ans:0, exp:"Differences: 4,6,8,10,12. Next = 30+12 = 42" },
    { q:"A clock shows 3:15. Angle between hour and minute hands?", opts:["7.5°","15°","0°","22.5°"], ans:0, exp:"Minute hand at 90°. Hour: 3.25×30 = 97.5°. Angle = 7.5°" },
    { q:"In a row of 40 students, Riya is 16th from left. Position from right?", opts:["25th","24th","26th","23rd"], ans:0, exp:"40 - 16 + 1 = 25th from right" },
    { q:"BCDE : EFGH :: PQRS : ?", opts:["STUV","TUVW","UVWX","WXYZ"], ans:0, exp:"Each group shifts +3 letters. PQRS → STUV" },
    { q:"If MANGO is coded as NBOIP, GRAPE is coded as?", opts:["HSBQF","ISBPF","GRBQF","HSBRF"], ans:0, exp:"Each letter +1. G→H, R→S, A→B, P→Q, E→F = HSBQF" },
    { q:"Find the odd one: 13, 17, 23, 27, 31, 37", opts:["27","23","31","13"], ans:0, exp:"27 = 3³ (not prime). All others are prime numbers." },
    { q:"All men are mortal. Socrates is a man. Therefore Socrates is?", opts:["Mortal","Immortal","Maybe mortal","Cannot say"], ans:0, exp:"Classic valid syllogism — Socrates is definitely mortal." },
    { q:"A is the brother of B. B is the sister of C. C is the father of D. How is A related to D?", opts:["Uncle","Cousin","Brother","Grandfather"], ans:0, exp:"A(M)-brother-B(F)-sister-C(M)-father-D. A is uncle of D." },
    { q:"Mirror image: If FRIEND is written as DNEIRF in a mirror, how is SMILE written?", opts:["ELIMS","SLIME","MILES","ILMES"], ans:0, exp:"Mirror reverses left-right: SMILE → ELIMS" },
    { q:"Statement: Some books are pens. All pens are chairs. Conclusion: Some books are chairs.", opts:["True","False","Possibly true","Cannot determine"], ans:0, exp:"Some books = pens, all pens = chairs → some books must be chairs. True." },
  ],
  verbal: [
    { q:"Synonym of ELOQUENT:", opts:["Silent","Articulate","Confused","Awkward"], ans:1, exp:"Eloquent means fluent/persuasive. Articulate is the closest synonym." },
    { q:"Antonym of BENEVOLENT:", opts:["Generous","Kind","Malevolent","Charitable"], ans:2, exp:"Benevolent = well-meaning. Antonym: Malevolent (wishing evil)." },
    { q:"Fill in: She is good ___ swimming.", opts:["in","for","of","at"], ans:3, exp:"'Good at' is correct for skills/activities." },
    { q:"Error: 'The committee have decided to postpone the meeting.'", opts:["No error","'have' should be 'has'","'postpone' → 'postponed'","'meeting' → 'meetings'"], ans:1, exp:"'Committee' = collective noun (singular). Use 'has' not 'have'." },
    { q:"Correctly spelled word:", opts:["Accomodation","Acomodation","Accommodation","Acommodation"], ans:2, exp:"Accommodation has double 'c' and double 'm'." },
    { q:"BIRD : AVIARY :: FISH : ?", opts:["Zoo","Aquarium","Forest","Cage"], ans:1, exp:"A bird lives in an aviary; a fish lives in an aquarium." },
    { q:"Idiom: 'Bite the bullet' means?", opts:["Run from problems","Solve quickly","Ignore difficulties","Endure pain bravely"], ans:3, exp:"'Bite the bullet' means to endure difficulty with courage." },
    { q:"Grammatically correct sentence:", opts:["Neither of them was present","Neither of them were present","Neither of them are present","Neither of them have been present"], ans:0, exp:"'Neither' takes singular verb. 'Neither of them was present' is correct." },
    { q:"Synonym of GREGARIOUS:", opts:["Lonely","Hostile","Sociable","Reserved"], ans:2, exp:"Gregarious means fond of company; sociable." },
    { q:"Meaning of EPHEMERAL:", opts:["Everlasting","Short-lived","Powerful","Ancient"], ans:1, exp:"Ephemeral means lasting for a very short time." },
  ],
  data_interp: [
    { q:"A company sold 200, 250, 300 units in Jan, Feb, Mar. Average monthly sales?", opts:["250","283","300","275"], ans:0, exp:"Average = (200+250+300)/3 = 750/3 = 250 units" },
    { q:"In a pie chart, sector A = 90°. What % of total does A represent?", opts:["30%","22.5%","25%","20%"], ans:2, exp:"90/360 × 100 = 25%" },
    { q:"Sales grew from ₹4 lakh to ₹5 lakh. Percentage increase?", opts:["20%","25%","30%","15%"], ans:1, exp:"Increase = 1L. % = (1/4)×100 = 25%" },
    { q:"Ratio of boys to girls is 3:2 in class of 40 students. Number of boys?", opts:["16","20","18","24"], ans:3, exp:"Boys = (3/5)×40 = 24" },
    { q:"Bar graph: A=40, B=60, C=80, D=20. What % is category C of total?", opts:["40%","32%","35%","50%"], ans:0, exp:"Total=200. C=80. %=(80/200)×100=40%" },
    { q:"Median of: 10, 20, 30, 40, 50?", opts:["20","35","30","25"], ans:2, exp:"Middle value of 5 numbers = 30" },
    { q:"Mode of: 3, 5, 7, 5, 3, 5, 8, 9?", opts:["3","5","7","8"], ans:1, exp:"5 appears 3 times (most frequent) = mode is 5" },
    { q:"P is 40% of Q. Q is 75% of R. P is what % of R?", opts:["50%","35%","45%","30%"], ans:3, exp:"P=0.4Q=0.4×0.75R=0.3R=30% of R" },
    { q:"Profit: Q1=₹20k, Q2=₹30k, Q3=₹25k, Q4=₹45k. Growth from Q1 to Q4?", opts:["125%","100%","75%","150%"], ans:0, exp:"(45-20)/20 × 100 = 125%" },
    { q:"A student scored 85, 90, 78, 92, 80 in 5 subjects. What score in 6th subject for average of 86?", opts:["90","89","91","88"], ans:2, exp:"Total needed = 86×6=516. Current = 425. 6th = 516-425 = 91" },
  ],
};

const SECTIONS = ['quantitative','logical','verbal','data_interp'];
const SECTION_LABELS = { quantitative:'🔢 Quantitative', logical:'🧩 Logical', verbal:'📝 Verbal', data_interp:'📊 Data Interpretation' };
const SECTION_ICONS  = { quantitative:'🔢', logical:'🧩', verbal:'📝', data_interp:'📊' };

let state = { phase:'intro', section:null, questions:[], current:0, answers:[], timerVal:0, timerInterval:null, tabSwitches:0 };
const user2 = Auth.getUser();

function initAptitude() {
  document.getElementById('topbarTitle').textContent = 'Aptitude Test';
  renderIntro();
  document.addEventListener('visibilitychange', () => {
    if (document.hidden && state.phase==='test') { state.tabSwitches++; updateTimerUI(); }
  });
}

function renderIntro() {
  state.phase = 'intro';
  clearInterval(state.timerInterval);
  document.getElementById('mainPage').innerHTML = `
    <div class="page-header">
      <h1 style="font-size:1.6rem">🎯 Aptitude Test</h1>
      <p style="color:var(--text3);font-size:13px;margin-top:2px">10 questions · 18-minute timer · Instant grading with detailed explanations per question</p>
    </div>
    <div class="card" style="max-width:680px;margin:0 auto">
      <div style="text-align:center;margin-bottom:28px">
        <div style="font-size:3rem;margin-bottom:12px">📋</div>
        <h2 style="margin-bottom:6px">Placement Aptitude Test</h2>
        <p style="font-size:13.5px;color:var(--text3);margin-bottom:4px">10 questions · 18-minute timer · Instant scoring</p>
        <p style="font-size:12px;color:var(--text3)">Tab switching monitored · Detailed explanations included</p>
      </div>
      <div class="sect-grid">
        ${SECTIONS.map(s=>`
          <button class="sect-btn" onclick="startSection('${s}')">
            <div style="font-size:1.6rem;margin-bottom:8px">${SECTION_ICONS[s]}</div>
            <div style="font-weight:700;font-size:14px;color:var(--text);margin-bottom:4px">${SECTION_LABELS[s]}</div>
            <div style="font-size:12px;color:var(--text3)">10 questions · 18 min</div>
          </button>`).join('')}
      </div>
      <div style="background:rgba(108,99,255,.07);border-radius:10px;padding:14px 18px;font-size:13px;color:var(--text2)">
        <strong style="color:var(--primary)">📌 Instructions:</strong>
        Select one answer per question. Review before submitting. Tab-switching is tracked. Score saves to your profile.
      </div>
    </div>`;
}

function startSection(section) {
  state.section   = section;
  state.questions = [...QUESTIONS[section]].sort(()=>Math.random()-0.5);
  state.current   = 0;
  state.answers   = new Array(state.questions.length).fill(null);
  state.tabSwitches = 0;
  state.timerVal  = 18*60;
  state.phase     = 'test';
  clearInterval(state.timerInterval);
  state.timerInterval = setInterval(() => {
    state.timerVal--;
    updateTimerUI();
    if (state.timerVal <= 0) { clearInterval(state.timerInterval); submitTest(true); }
  }, 1000);
  renderTest();
}

function renderTest() {
  const q   = state.questions[state.current];
  const n   = state.current;
  const tot = state.questions.length;
  const answered = state.answers.filter(a=>a!==null).length;
  const mins = String(Math.floor(state.timerVal/60)).padStart(2,'0');
  const secs = String(state.timerVal%60).padStart(2,'0');
  const urgent = state.timerVal<120;
  const letters = ['A','B','C','D'];

  document.getElementById('mainPage').innerHTML = `
    <div class="page-header" style="margin-bottom:12px">
      <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px">
        <h1 style="font-size:1.2rem">${SECTION_LABELS[state.section]}</h1>
        <div style="display:flex;gap:10px;align-items:center">
          ${state.tabSwitches>0?`<div class="badge badge-amber">⚠ ${state.tabSwitches} tab switch</div>`:''}
          <div class="timer-badge${urgent?' urgent':''}" id="timerEl">⏱ ${mins}:${secs}</div>
        </div>
      </div>
    </div>
    <div class="progress-strip"><div class="progress-fill" style="width:${Math.round(answered/tot*100)}%"></div></div>
    <div class="quiz-wrap">
      <div style="display:flex;flex-wrap:wrap;gap:5px;margin-bottom:18px">
        ${state.questions.map((_,i)=>{
          const isA=state.answers[i]!==null, isC=i===n;
          return `<button onclick="jumpTo(${i})" style="width:30px;height:30px;border-radius:7px;border:1.5px solid ${isC?'var(--primary)':isA?'var(--emerald)':'var(--border)'};background:${isC?'var(--primary)':isA?'rgba(0,214,143,.12)':'var(--bg3)'};color:${isC?'#fff':isA?'var(--emerald)':'var(--text3)'};font-size:11px;font-weight:700;cursor:pointer">${i+1}</button>`;
        }).join('')}
      </div>
      <div class="q-card">
        <div class="q-number">Question ${n+1} of ${tot}</div>
        <div class="q-text">${esc(q.q)}</div>
        <div class="options">
          ${q.opts.map((opt,i)=>{
            let cls = '';
            if(state.answers[n]!==null){
              if(i===q.ans) cls=' correct';
              else if(i===state.answers[n]&&i!==q.ans) cls=' wrong';
            } else if(state.answers[n]===i) cls=' selected';
            const disabled = state.answers[n]!==null;
            return `<button class="opt-btn${cls}" onclick="${disabled?'':'selectAnswer('+i+')'}" style="${disabled?'cursor:default':''}">
              <div class="opt-letter">${letters[i]}</div><span>${esc(opt)}</span>
            </button>`;
          }).join('')}
        </div>
      </div>
      <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;max-width:760px">
        <button onclick="prevQ()" class="btn btn-ghost" ${n===0?'disabled':''}>← Prev</button>
        <div style="display:flex;gap:8px">
          <button onclick="clearAns()" class="btn btn-ghost btn-sm" style="color:var(--text3)">Clear</button>
          ${n<tot-1
            ?`<button onclick="nextQ()" class="btn btn-primary">Next →</button>`
            :`<button onclick="confirmSubmit()" class="btn btn-primary" style="background:var(--emerald);border-color:var(--emerald)">Submit ✓</button>`}
        </div>
      </div>
    </div>`;
}

function updateTimerUI() {
  const el = document.getElementById('timerEl');
  if (!el) return;
  const mins = String(Math.floor(state.timerVal/60)).padStart(2,'0');
  const secs = String(state.timerVal%60).padStart(2,'0');
  el.textContent = `⏱ ${mins}:${secs}`;
  el.className = 'timer-badge'+(state.timerVal<120?' urgent':'');
}

function selectAnswer(i){
  if(state.answers[state.current]!==null) return; // already answered
  state.answers[state.current]=i;
  renderTest(); // show correct/wrong highlight
  // Auto-advance to next question after 900ms
  if(state.current < state.questions.length-1){
    setTimeout(()=>{ state.current++; renderTest(); }, 900);
  }
}
function jumpTo(i){ state.current=i; renderTest(); }
function nextQ(){ if(state.current<state.questions.length-1){state.current++;renderTest();} }
function prevQ(){ if(state.current>0){state.current--;renderTest();} }
function clearAns(){ state.answers[state.current]=null; renderTest(); }

function confirmSubmit(){
  const unanswered = state.answers.filter(a=>a===null).length;
  if(unanswered>0 && !confirm(`${unanswered} unanswered question(s). Submit anyway?`)) return;
  submitTest(false);
}

function submitTest(timeout=false){
  clearInterval(state.timerInterval);
  state.phase = 'result';
  let correct=0, wrong=0;
  state.questions.forEach((q,i)=>{
    if(state.answers[i]===q.ans) correct++;
    else if(state.answers[i]!==null) wrong++;
  });
  const score = Math.round((correct/state.questions.length)*100);
  API.post('aptitude_save.php',{user_id:user2.id,score,tab_warnings:state.tabSwitches,section:state.section}).catch(()=>{});
  renderResult(correct,wrong,score,timeout);
}

function renderResult(correct,wrong,score,timeout){
  const unanswered = state.questions.length-correct-wrong;
  const grade = score>=80?'Excellent 🎉':score>=60?'Good 👍':score>=40?'Average 📈':'Needs More Practice 💪';
  const circleClass = score>=70?'':score>=40?' mid':' low';
  const color = score>=70?'var(--emerald)':score>=40?'var(--accent2)':'var(--red)';
  document.getElementById('mainPage').innerHTML = `
    <div class="page-header"><h1>${SECTION_LABELS[state.section]} — Result</h1></div>
    <div class="card quiz-wrap result-card" style="margin-bottom:20px">
      ${timeout?`<div class="alert alert-amber" style="margin-bottom:20px">⏰ Time up! Auto-submitted.</div>`:''}
      <div class="score-circle${circleClass}" style="border-color:${color}">
        <div style="font-size:2.2rem;font-weight:900;color:${color}">${score}</div>
        <div style="font-size:11px;color:var(--text3)">/ 100</div>
      </div>
      <h2 style="margin-bottom:8px">${grade}</h2>
      <p style="color:var(--text3);font-size:13.5px;margin-bottom:24px">${correct} correct · ${wrong} wrong · ${unanswered} skipped</p>
      <div style="display:flex;justify-content:center;gap:32px;margin-bottom:28px">
        <div style="text-align:center"><div style="font-size:1.8rem;font-weight:800;color:var(--emerald)">${correct}</div><div style="font-size:12px;color:var(--text3)">Correct</div></div>
        <div style="text-align:center"><div style="font-size:1.8rem;font-weight:800;color:var(--red)">${wrong}</div><div style="font-size:12px;color:var(--text3)">Wrong</div></div>
        <div style="text-align:center"><div style="font-size:1.8rem;font-weight:800;color:var(--text3)">${unanswered}</div><div style="font-size:12px;color:var(--text3)">Skipped</div></div>
      </div>
      ${state.tabSwitches>0?`<div class="alert alert-amber" style="margin-bottom:16px;text-align:left">⚠️ <strong>${state.tabSwitches} tab switch(es)</strong> detected.</div>`:''}
      <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap">
        <button onclick="reviewAnswers()" class="btn btn-ghost">📋 Review Answers</button>
        <button onclick="downloadResult()" class="btn btn-secondary" style="background:rgba(0,214,143,.12);color:var(--emerald);border:1px solid rgba(0,214,143,.3)">⬇ Download Report</button>
        <button onclick="renderIntro()" class="btn btn-primary">🔄 Try Another Section</button>
      </div>
    </div>`;
}

function reviewAnswers(){
  const letters=['A','B','C','D'];
  document.getElementById('mainPage').innerHTML = `
    <div class="page-header">
      <div style="display:flex;align-items:center;gap:12px">
        <button onclick="renderIntro()" class="btn btn-ghost btn-sm">← Back</button>
        <h1 style="font-size:1.2rem">${SECTION_LABELS[state.section]} — Review</h1>
      </div>
    </div>
    <div class="quiz-wrap">
      ${state.questions.map((q,i)=>{
        const ua=state.answers[i], c=q.ans, isC=ua===c, isW=ua!==null&&!isC;
        return `<div class="q-card" style="border-color:${isC?'var(--emerald)':isW?'var(--red)':'var(--border)'}">
          <div class="q-number" style="display:flex;justify-content:space-between">
            <span>Q${i+1}</span>
            <span style="color:${isC?'var(--emerald)':isW?'var(--red)':'var(--text3)'}">${isC?'✓ Correct':isW?'✗ Wrong':'— Skipped'}</span>
          </div>
          <div class="q-text">${esc(q.q)}</div>
          <div class="options" style="pointer-events:none">
            ${q.opts.map((opt,j)=>`<button class="opt-btn${j===c?' correct':j===ua&&!isC?' wrong':''}"><div class="opt-letter">${letters[j]}</div><span>${esc(opt)}</span></button>`).join('')}
          </div>
          <div class="explanation" style="display:block">💡 ${esc(q.exp)}</div>
        </div>`;
      }).join('')}
      <div style="max-width:760px"><button onclick="renderIntro()" class="btn btn-primary w-full">← Back to Sections</button></div>
    </div>`;
}


function downloadResult(){
  const correct = state.questions.filter((q,i)=>state.answers[i]===q.ans).length;
  const wrong   = state.questions.filter((q,i)=>state.answers[i]!==null&&state.answers[i]!==q.ans).length;
  const skipped = state.questions.length - correct - wrong;
  const score   = Math.round((correct/state.questions.length)*100);
  const grade   = score>=80?'Excellent':score>=60?'Good':score>=40?'Average':'Needs Practice';
  const now     = new Date().toLocaleDateString('en-IN',{day:'2-digit',month:'long',year:'numeric'});
  const userName = user?.name || 'Student';
  const letters = ['A','B','C','D'];

  const html = `<!DOCTYPE html><html><head><meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">  <link rel="icon" type="image/x-icon" href="data:image/x-icon;base64,AAABAAEAEBAAAAAAIACgAAAAFgAAAIlQTkcNChoKAAAADUlIRFIAAAAQAAAAEAgGAAAAH/P/YQAAAGdJREFUeJxjZIACLg6R/wwkgG8/3jAyMDAwMJGjGVkPIzmakQETJZoZGBgYWNAFvn5/jVMxN6co9V1AWwOwOZkkA/CFB1EGEAOoH43IgOIwIAZQnpRhuYoc8O3HG0YmGIMczQwMDAwA+P4aS3/n/2IAAAAASUVORK5CYII=">
  <link rel="icon" type="image/png" sizes="32x32" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAoElEQVR4nO2XvQ6AIAyES+Pgz6rv/4Cyimw6kWhDxID0HLixabyPozHUUERjPx+xeqmct0bWboVaxk8grG0uvVjbXEJwqrG2DOL0V8ET6FIN275mfXgalld98AQaABwgOYQxyQHLHVSiHyTQALJmoOTOpeAJNAA4wCc/ohLBE2gAcAD8ozS2LmnJeWvgV8CBRNs4eLIsaJoTie04SHM9PwGQNi1E3UY9bQAAAABJRU5ErkJggg==">
  <link rel="icon" type="image/png" sizes="192x192" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMAAAADACAYAAABS3GwHAAADvklEQVR4nO3dQVLjVgBFUZvqASFTsv8FhmkIMzJIdRc0YCxL8pd8z1kAaPCuvmy61MfDxjzcP76OvgbW8/zydBx9DW8NvRhj53AYG8XVf7HRc8q1Y7jaLzN8prhWCKv/EsNnjrVDWO2HGz5LWiuExX+o4bOmpUO4W/KHGT9rW3pji9Rk+IywxGkw+wQwfkZZYnuzAjB+Rpu7wYsDMH62Ys4WLwrA+NmaSzc5OQDjZ6su2eakAIyfrZu60bMDMH72YspWzwrA+Nmbczf7bQDGz16ds91F/ykE7M3JANz92bvvNvxlAMbPrTi1ZY9ApH0agLs/t+arTTsBSPsQgLs/t+qzbTsBSHsXgLs/t+73jTsBSPsVgLs/FW+37gQgTQCk3R0OHn/o+bl5JwBpAiBNAKQJgLSjD8CUOQFIEwBpAiBNAKQJgDQBkPZj9AXM9c+/f4++hF3584+/Rl/CpjgBSBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYC03b8VYi0j356w1psuvBHiIycAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANKOD/ePr6MvYo61XiV+q7wi/T0nAGkCIE0ApAmANAGQJgDSBECaAEgTAGkCIE0ApAmANAGQJgDSBECaAEgTAGkCIE0ApAmANAGQ9mP0BWyVtyc0OAFIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0o4P94+voy8CRnECkCYA0gRAmgBIEwBpd88vT8fRFwEjPL88HZ0ApAmANAGQJgDS7g6H/z8MjL4QuKafm3cCkCYA0n4F4DGIirdbdwKQ9i4ApwC37veNOwFI+xCAU4Bb9dm2nQCkfRqAU4Bb89WmnQCkfRmAU4BbcWrLJ08AEbB3323YIxBp3wbgFGCvztnuWSeACNibczd79iOQCNiLKVud9BlABGzd1I1O/hAsArbqkm1e9C2QCNiaSzd58degImAr5mxx1t8BRMBoczc4+w9hImCUJba36Hj9bzNcw5I33UX/KYTTgLUtvbHVBus0YElr3VxXv2MLgTnWfqq42iOLEJjiWo/TV39mFwKnXPtz5NAPrWLgcBj75cnmvrURxW3b2jeF/wGOq9fsu4f8UQAAAABJRU5ErkJggg==">
  <link rel="apple-touch-icon" sizes="180x180" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAAC0CAYAAAA9zQYyAAADX0lEQVR4nO3cOXJaQQBFUVA58JDa+1+glVpWZgceygOS/kh/rs5ZAOrg8tRAwfl0AO/ffvw2+gys9/B4fx59hiEHEPDrMCLwq/1BEb9u14p71z8iYi7ZM+5dHljITLFH2HdbP6CYmWqPVjZ7hgiZNbZa600WWsystVVDq54VQmYPa9Z68UKLmb2saWtR0GJmb0sbmx20mLmWJa3NClrMXNvc5iYHLWZGmdPepKDFzGhTG3wxaDFzFFNa3Pyjbxjp2aCtM0fzUpNPBi1mjuq5Nl05SLkYtHXm6J5q9L+gxcytuNSqKwcpfwVtnbk1/zZroUkRNCm/g3bd4Fb92a6FJkXQpNydTq4b3L5fDVtoUgRNiqBJObs/U2KhSRE0KYImRdCkCJoUQZPyZvQBlvjy9fPoIxzWh3efRh9hKAtNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiblJr8ku4cRXy71Zd/tWWhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCl+rPEnP5zYYKFJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KT4kuxPH959Gn0ENmChSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJqU8/u3H7+NPgRsxUKTImhSBE2KoEkRNCl3D4/359GHgC08PN6fLTQpgiZF0KTcnU4/7h6jDwJr/GrYQpMiaFJ+B+3awa36s10LTYqgSfkraNcObs2/zVpoUv4L2kpzKy61enGhRc3RPdWoKwcpTwZtpTmq59p8dqFFzdG81KQrBykvBm2lOYopLU5aaFEz2tQGJ185RM0oc9qbdYcWNdc2t7nZLwpFzbUsaW3RuxyiZm9LG1v8tp2o2cuatjaJ0k/ysoUtRnKTD1asNWtt1dDmIVpr5th6DDf/6NtaM9Uerewan7Xmkj1H72prKu7X7Vr/uYdcD8T9Ooy4fh7ivivwhiO8fvoO2onGYhMioSEAAAAASUVORK5CYII=">
  <title>Aptitude Report</title>
  <style>
    *{margin:0;padding:0;box-sizing:border-box;}
    body{font-family:'Segoe UI',Arial,sans-serif;background:#fff;color:#1a1a2e;padding:0;}
    .header{background:linear-gradient(135deg,#6c63ff,#a78bfa);padding:36px 48px;color:#fff;}
    .header h1{font-size:28px;font-weight:800;margin-bottom:4px;}
    .header p{font-size:13px;opacity:.85;}
    .meta{display:flex;gap:24px;margin-top:16px;flex-wrap:wrap;}
    .meta span{background:rgba(255,255,255,.2);padding:4px 14px;border-radius:99px;font-size:12px;font-weight:600;}
    .body{padding:36px 48px;}
    .score-row{display:flex;gap:20px;margin-bottom:32px;flex-wrap:wrap;}
    .score-box{flex:1;min-width:120px;background:#f8f9ff;border-radius:12px;padding:20px;text-align:center;border:2px solid #e8e9ff;}
    .score-box.main{border-color:#6c63ff;background:#f0eeff;}
    .score-num{font-size:36px;font-weight:900;color:#6c63ff;}
    .score-box.main .score-num{font-size:48px;}
    .score-num.green{color:#00d68f;}
    .score-num.red{color:#ff4d6d;}
    .score-num.amber{color:#f5a623;}
    .score-label{font-size:11px;color:#888;margin-top:4px;font-weight:600;text-transform:uppercase;letter-spacing:.05em;}
    h2{font-size:16px;font-weight:800;color:#1a1a2e;margin-bottom:16px;padding-bottom:8px;border-bottom:2px solid #e8e9ff;}
    .q-item{margin-bottom:16px;padding:16px;border-radius:10px;border:1.5px solid #e8e9ff;page-break-inside:avoid;}
    .q-item.correct{border-color:#00d68f;background:#f0fff8;}
    .q-item.wrong{border-color:#ff4d6d;background:#fff4f6;}
    .q-item.skipped{border-color:#e0e0e0;background:#fafafa;}
    .q-head{display:flex;justify-content:space-between;margin-bottom:8px;}
    .q-num{font-size:11px;font-weight:700;color:#888;text-transform:uppercase;}
    .q-status{font-size:11px;font-weight:700;}
    .q-text{font-size:13.5px;font-weight:600;margin-bottom:10px;line-height:1.5;}
    .opt{font-size:12.5px;padding:6px 10px;border-radius:6px;margin-bottom:4px;}
    .opt.correct{background:#dcfce7;color:#15803d;font-weight:600;}
    .opt.wrong{background:#fee2e2;color:#dc2626;}
    .explanation{font-size:12px;color:#555;margin-top:8px;padding:8px 12px;background:#f5f5ff;border-radius:6px;border-left:3px solid #6c63ff;}
    .footer{text-align:center;padding:20px;font-size:11px;color:#aaa;border-top:1px solid #eee;margin-top:32px;}
    @media print{.no-print{display:none;} body{padding:0;} .header{-webkit-print-color-adjust:exact;print-color-adjust:exact;}}
  </style></head><body>
  <div class="header">
    <h1>🎯 Aptitude Test Report</h1>
    <p>PlacementAI Pro — Official Score Certificate</p>
    <div class="meta">
      <span>👤 ${userName}</span>
      <span>📚 ${SECTION_LABELS[state.section]}</span>
      <span>📅 ${now}</span>
      <span>⚠ ${state.tabSwitches} Tab Switch(es)</span>
    </div>
  </div>
  <div class="body">
    <div class="score-row">
      <div class="score-box main">
        <div class="score-num">${score}</div>
        <div class="score-label">Score / 100</div>
        <div style="font-size:13px;font-weight:700;color:#6c63ff;margin-top:6px">${grade}</div>
      </div>
      <div class="score-box">
        <div class="score-num green">${correct}</div>
        <div class="score-label">Correct</div>
      </div>
      <div class="score-box">
        <div class="score-num red">${wrong}</div>
        <div class="score-label">Wrong</div>
      </div>
      <div class="score-box">
        <div class="score-num amber">${skipped}</div>
        <div class="score-label">Skipped</div>
      </div>
    </div>
    <h2>📋 Detailed Question Review</h2>
    ${state.questions.map((q,i)=>{
      const ua=state.answers[i], c=q.ans;
      const isC=ua===c, isW=ua!==null&&!isC;
      const cls=isC?'correct':isW?'wrong':'skipped';
      const statusTxt=isC?'✓ Correct':isW?'✗ Wrong':'— Skipped';
      const statusCol=isC?'#15803d':isW?'#dc2626':'#888';
      return `<div class="q-item ${cls}">
        <div class="q-head">
          <span class="q-num">Question ${i+1}</span>
          <span class="q-status" style="color:${statusCol}">${statusTxt}</span>
        </div>
        <div class="q-text">${q.q}</div>
        ${q.opts.map((opt,j)=>{
          let cls2='';
          if(j===c) cls2='correct';
          else if(j===ua&&j!==c) cls2='wrong';
          return `<div class="opt ${cls2}">${letters[j]}. ${opt}${j===c?' ✓':j===ua&&j!==c?' ✗':''}</div>`;
        }).join('')}
        <div class="explanation">💡 ${q.exp}</div>
      </div>`;
    }).join('')}
  </div>
  <div class="footer">Generated by PlacementAI Pro · ${now} · This report certifies the aptitude test performance of ${userName}</div>
  </body></html>`;

  const blob = new Blob([html], {type:'text/html'});
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href = url;
  a.download = `Aptitude_Report_${state.section}_${userName.replace(/\s+/g,'_')}.html`;
  a.click();
  URL.revokeObjectURL(url);

  // Also trigger print dialog for PDF save
  setTimeout(()=>{
    const win = window.open(url,'_blank');
    if(win) setTimeout(()=>{ win.print(); }, 800);
  }, 100);
}

// Init AFTER all functions/data are defined
const user = Auth.requireAuth('student');
if (user) { buildShell('aptitude'); setTimeout(()=>initAptitude(), 0); }
</script>
</body>
</html>

/* ============================================================
   PLACEMENT AI PRO  —  Core JS  v4
   ============================================================ */

/* ── Icons ──────────────────────────────────────────────────── */
const S = (p,vb='0 0 24 24') => `<svg width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" viewBox="${vb}">${p}</svg>`;
const iconHome       = ()=>S('<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>');
const iconMic        = ()=>S('<path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/>');
const iconDoc        = ()=>S('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/>');
const iconBrain      = ()=>S('<path d="M9.5 2A2.5 2.5 0 0 1 12 4.5v15a2.5 2.5 0 0 1-4.96-.46 2.5 2.5 0 0 1-2.96-3.08 3 3 0 0 1-.34-5.58 2.5 2.5 0 0 1 1.32-4.24 2.5 2.5 0 0 1 1.98-3A2.5 2.5 0 0 1 9.5 2z"/><path d="M14.5 2A2.5 2.5 0 0 0 12 4.5v15a2.5 2.5 0 0 0 4.96-.46 2.5 2.5 0 0 0 2.96-3.08 3 3 0 0 0 .34-5.58 2.5 2.5 0 0 0-1.32-4.24 2.5 2.5 0 0 0-1.98-3A2.5 2.5 0 0 0 14.5 2z"/>');
const iconMap        = ()=>S('<polygon points="3 6 9 3 15 6 21 3 21 18 15 21 9 18 3 21"/>');
const iconBriefcase  = ()=>S('<rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/>');
const iconChart      = ()=>S('<line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>');
const iconUser       = ()=>S('<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>');
const iconUsers      = ()=>S('<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>');
const iconPlus       = ()=>S('<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>');
const iconSearch     = ()=>S('<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>');
const iconX          = ()=>S('<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>');
const iconCheck      = ()=>S('<polyline points="20 6 9 17 4 12"/>');
const iconCode       = ()=>S('<polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/>');
const iconPlay       = ()=>S('<polygon points="5 3 19 12 5 21 5 3"/>');
const iconStar       = ()=>S('<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>');
const iconTrophy     = ()=>S('<path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"/><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"/><path d="M4 22h16"/><path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22"/><path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22"/><path d="M18 2H6v7a6 6 0 0 0 12 0V2z"/>');
const iconShield     = ()=>S('<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>');
const iconKey        = ()=>S('<path d="m21 2-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0 3 3L22 7l-3-3m-3.5 3.5L19 4"/>');
const iconLogoSvg = ()=>`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18" width="18" height="18"><defs><linearGradient id="gcl18" x1="0" y1="1" x2="1" y2="0"><stop offset="0%" stop-color="#ff4757"/><stop offset="100%" stop-color="#f59e0b"/></linearGradient></defs><rect width="18" height="18" rx="4" fill="#1e1a10"/><rect x="3" y="12" width="3" height="5" rx="1" fill="#f59e0b" opacity=".45"/><rect x="7" y="8" width="3" height="9" rx="1" fill="#ff6b35" opacity=".7"/><rect x="11" y="5" width="3" height="12" rx="1" fill="url(#gcl18)"/><polyline points="12,3 14,5 14,4" fill="none" stroke="url(#gcl18)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><line x1="11" y1="4" x2="12" y2="3" stroke="url(#gcl18)" stroke-width="1.5" stroke-linecap="round"/></svg>`;


/* ── Auth ──────────────────────────────────────────────────── */
const Auth = {
  _key: 'pai_user',
  getUser() {
    try {
      // Read from localStorage first, fall back to sessionStorage
      const raw = localStorage.getItem(this._key) || sessionStorage.getItem(this._key) || 'null';
      const u = JSON.parse(raw);
      // If found in sessionStorage but not localStorage, restore it
      if (u && !localStorage.getItem(this._key)) {
        localStorage.setItem(this._key, raw);
      }
      return u;
    } catch { return null; }
  },
  setUser(u) {
    const val = JSON.stringify(u);
    try { localStorage.setItem(this._key, val); } catch(e) {}
    try { sessionStorage.setItem(this._key, val); } catch(e) {}
  },
  logout() {
    localStorage.removeItem(this._key);
    sessionStorage.removeItem(this._key);
    location.href = 'index.php';
  },
  requireAuth(role=null) {
    const u = this.getUser();
    if (!u) { location.href='login.php'; return null; }
    if (role && u.role !== role) { location.href='index.php'; return null; }
    return u;
  }
};

/* ── API ────────────────────────────────────────────────────── */
const API = {
  BASE: 'php/',
  async call(ep, opts={}) {
    try {
      const res = await fetch(this.BASE+ep, { headers:{'Content-Type':'application/json',...(opts.headers||{})}, ...opts });
      const raw = await res.text();
      if (!raw || !raw.trim()) throw new Error('Empty server response (HTTP ' + res.status + ') from ' + ep + '. Ensure DB is running and placement_db exists.');
      let data;
      try {
        data = JSON.parse(raw);
      } catch(parseErr) {
        // Strip HTML tags to show plain PHP error text
        const phpErr = raw.replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim().substring(0,300);
        console.error('Non-JSON response from ' + ep + ':', raw.substring(0,500));
        throw new Error(phpErr || 'Invalid response from server');
      }
      if (!res.ok) throw new Error(data.message || 'Server error ' + res.status);
      if (data.success === false) throw new Error(data.message || 'Request failed');
      return data;
    } catch(e) {
      throw e;
    }
  },
  get(ep)        { return this.call(ep); },
  post(ep, data) { return this.call(ep, { method:'POST', body:JSON.stringify(data) }); },
  async postForm(ep, fd) {
    try {
      const res  = await fetch(this.BASE+ep, {method:'POST', body:fd});
      let data;
      try { data = await res.json(); } catch(e) { throw new Error('Server returned invalid JSON. Check PHP errors.'); }
      if (!res.ok) throw new Error(data?.message || 'Server error '+res.status);
      if (!data.success && data.message) throw new Error(data.message);
      return data;
    } catch(e) {
      if (e.message.includes('JSON')) throw e;
      throw e;
    }
  },
};

/* ── Helpers ─────────────────────────────────────────────────── */
function esc(s) {
  if (s==null) return '';
  return String(s).replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c]);
}
function showAlert(el, msg, type='error', raw=false) {
  if (!el) return;
  const icons = { success:'✓', error:'✕', info:'ℹ', warning:'⚠' };
  const icon = icons[type] || '✕';
  const text = raw ? msg : esc(msg);
  el.innerHTML = `<div class="alert alert-${type}"><span style="font-weight:700;font-size:15px;flex-shrink:0">${icon}</span><span>${text}</span></div>`;
  el.scrollIntoView({behavior:'smooth',block:'nearest'});
}
function clearAlert(el) { if(el) el.innerHTML=''; }
function loading(btn, state=true, text='') {
  if (!btn) return;
  if (state) {
    btn._orig = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = `<span class="spinner" style="width:14px;height:14px;border-width:2px"></span> ${text||'Loading…'}`;
  } else {
    btn.disabled = false;
    btn.innerHTML = btn._orig || btn.innerHTML;
  }
}
function fmtDate(d) { return d ? new Date(d).toLocaleDateString('en-IN',{day:'numeric',month:'short',year:'numeric'}) : '—'; }
function fmtNum(n)  { return Number(n||0).toLocaleString('en-IN'); }

/* ── Status Badge ──────────────────────────────────────────── */
function statusBadge(status) {
  const map = {
    active:   ['badge-green',  'Active'],
    inactive: ['badge-gray',   'Inactive'],
    blocked:  ['badge-red',    'Blocked'],
    verified: ['badge-green',  'Verified'],
    pending:  ['badge-amber',  'Pending'],
    hired:    ['badge-cyan',   'Hired'],
    rejected: ['badge-red',    'Rejected'],
    applied:  ['badge-purple', 'Applied'],
    shortlisted: ['badge-amber', 'Shortlisted'],
  };
  const [cls, label] = map[status] || ['badge-gray', status || '—'];
  return `<span class="badge ${cls}">${label}</span>`;
}

/* ── Markdown-lite ───────────────────────────────────────────── */
function md(text) {
  if (!text) return '';
  return String(text)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>')
    .replace(/`([^`]+)`/g,'<code>$1</code>')
    .replace(/^#{1,3}\s+(.+)$/gm,'<strong style="color:var(--text)">$1</strong>')
    .replace(/^[-*]\s+(.+)$/gm,'<li>$1</li>')
    .replace(/^(\d+)\.\s+(.+)$/gm,'<li>$1. $2</li>')
    .replace(/(<li>[\s\S]*?<\/li>)/g,'<ul style="padding-left:18px;margin:6px 0">$1</ul>')
    .replace(/\n{2,}/g,'<br><br>').replace(/\n/g,'<br>');
}

/* ── Progress bar ──────────────────────────────────────────── */
function progressBar(label, val, max=100, color='') {
  const pct = Math.min(100, Math.round((val/max)*100));
  const colors = { green:'var(--emerald)', amber:'var(--accent2)', rose:'var(--red)', purple:'var(--primary)' };
  const c = colors[color] || 'var(--primary)';
  return `<div style="margin-bottom:13px">
    <div style="display:flex;justify-content:space-between;margin-bottom:5px">
      <span style="font-size:13px;color:var(--text2)">${esc(label)}</span>
      <span style="font-size:13px;font-weight:700;color:${c}">${pct}%</span>
    </div>
    <div style="height:5px;background:var(--surface3);border-radius:99px;overflow:hidden">
      <div style="height:100%;width:${pct}%;background:${c};border-radius:99px;transition:width .6s ease"></div>
    </div>
  </div>`;
}

/* ── Score ring ──────────────────────────────────────────────── */
function scoreRing(score, size=120, color='#7c6aff') {
  const r = size/2 - 10;
  const circ = 2*Math.PI*r;
  const dash = (Math.min(100,score)/100)*circ;
  return `<div class="score-ring" style="width:${size}px;height:${size}px">
    <svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
      <circle cx="${size/2}" cy="${size/2}" r="${r}" fill="none" stroke="rgba(255,255,255,.06)" stroke-width="7"/>
      <circle cx="${size/2}" cy="${size/2}" r="${r}" fill="none" stroke="${color}" stroke-width="7"
        stroke-dasharray="${dash} ${circ}" stroke-linecap="round" style="transition:stroke-dasharray .6s ease"/>
    </svg>
    <div class="score-ring__text">
      <span class="score-ring__val">${Math.round(score)}</span>
      <span class="score-ring__sub">/ 100</span>
    </div>
  </div>`;
}

/* ── Tabs ─────────────────────────────────────────────────────── */
function initTabs(container) {
  if (!container) return;
  container.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = btn.dataset.tab;
      container.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      // Find parent, then look for tab panes
      const parent = container.closest('.card') || container.parentElement;
      parent.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
      const pane = parent.querySelector('#'+target) || document.getElementById(target);
      if (pane) pane.classList.add('active');
    });
  });
}

/* ── Sidebar / Shell builder ─────────────────────────────────── */
function buildShell(activePage) {
  const user = Auth.getUser();
  if (!user) return;

  const navStudent = [
    { id:'dashboard',       href:'dashboard.php',       icon:iconHome,      label:'Dashboard' },
    { id:'interview',       href:'interview.php',        icon:iconMic,       label:'AI Interview',     badge:'AI' },
    { id:'resume',          href:'resume.php',           icon:iconDoc,       label:'Resume Analyzer' },
    { id:'resume-builder',  href:'resume-builder.php',   icon:iconStar,      label:'Resume Builder',   badge:'NEW' },
    { id:'aptitude',        href:'aptitude.php',         icon:iconBrain,     label:'Aptitude Test' },
    { id:'roadmap',         href:'roadmap.php',          icon:iconMap,       label:'Roadmap' },
    { id:'jobs',            href:'jobs.php',             icon:iconBriefcase, label:'Job Portal' },
    { id:'leaderboard',     href:'leaderboard.php',      icon:iconTrophy,    label:'Leaderboard' },
    { id:'predict',         href:'predict.php',          icon:iconChart,     label:'Prediction AI' },
    { id:'profile',         href:'profile.php',          icon:iconUser,      label:'Profile' },
  ];
  const navOrg = [
    { id:'organization', href:'organization.php',         icon:iconHome,      label:'Dashboard' },
    { id:'org-jobs',     href:'organization.php?tab=jobs',     icon:iconBriefcase, label:'Job Posts' },
    { id:'org-students', href:'organization.php?tab=students', icon:iconUsers,     label:'Students' },
  ];
  const navAdmin = [
    { id:'admin',           href:'admin.php',            icon:iconHome,  label:'Overview' },
    { id:'admin-students',  href:'admin.php?tab=students',icon:iconUsers, label:'Students' },
    { id:'admin-orgs',      href:'admin.php?tab=orgs',   icon:iconBriefcase, label:'Organizations' },
    { id:'admin-analytics', href:'admin.php?tab=analytics',icon:iconChart, label:'Analytics' },
  ];

  const nav = user.role==='student' ? navStudent : user.role==='organization' ? navOrg : navAdmin;
  const navHTML = nav.map(n=>`
    <a href="${n.href}" class="nav-item${activePage===n.id?' active':''}" >
      ${n.icon()} ${esc(n.label)}
      ${n.badge ? `<span class="nav-badge">${n.badge}</span>` : ''}
    </a>`).join('');

  const initials = (user.name||'U').split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase();
  const roleColors = { admin:'#ff4757', organization:'#f59e0b', student:'#00d68f' };
  const roleColor = roleColors[user.role] || '#7c6aff';
  const homePage = user.role === 'admin' ? 'admin.php' : user.role === 'organization' ? 'organization.php' : 'dashboard.php';

  document.body.innerHTML = `
    <div class="app-shell">
      <div class="sidebar-overlay" id="sidebarOverlay"></div>
      <aside class="sidebar" id="sidebar">
        <a href="${homePage}" class="sidebar__logo" style="text-decoration:none;cursor:pointer;transition:opacity .15s" onmouseover="this.style.opacity='.8'" onmouseout="this.style.opacity='1'">
          <div class="logo-icon" style="background:none;padding:0;width:32px;height:32px">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" width="32" height="32"><defs><linearGradient id="gcl32" x1="0" y1="1" x2="1" y2="0"><stop offset="0%" stop-color="#ff4757"/><stop offset="100%" stop-color="#f59e0b"/></linearGradient></defs><rect width="32" height="32" rx="6" fill="#1e1a10"/><rect x="6" y="21" width="5" height="9" rx="1" fill="#f59e0b" opacity=".45"/><rect x="12" y="15" width="5" height="15" rx="1" fill="#ff6b35" opacity=".7"/><rect x="19" y="8" width="5" height="22" rx="1" fill="url(#gcl32)"/><polyline points="22,5 25,8 25,6" fill="none" stroke="url(#gcl32)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><line x1="18" y1="6" x2="22" y2="5" stroke="url(#gcl32)" stroke-width="1.5" stroke-linecap="round"/></svg>
          </div>
          <span style="white-space:nowrap">Placement<span style="color:var(--primary-l)">AI</span> Pro</span>
        </a>
        <nav class="sidebar__nav">
          <div class="sidebar__section-label">${user.role === 'student' ? 'Student Tools' : user.role === 'organization' ? 'Organization' : 'Administration'}</div>
          ${navHTML}
        </nav>
        <div class="sidebar__footer">
          <div class="user-card" style="cursor:default">
            <a href="${homePage}" style="display:flex;align-items:center;gap:10px;text-decoration:none;flex:1;min-width:0;transition:opacity .15s" onmouseover="this.style.opacity='.75'" onmouseout="this.style.opacity='1'" title="Go to dashboard">
              <div class="user-avatar">${initials}</div>
              <div class="user-info" style="min-width:0">
                <div class="name">${esc(user.name)}</div>
                <div class="role" style="color:${roleColor}">${esc(user.role)}</div>
              </div>
            </a>
            <button onclick="Auth.logout()" title="Sign out" style="flex-shrink:0;background:rgba(255,71,87,.1);border:1px solid rgba(255,71,87,.25);border-radius:8px;padding:6px 10px;cursor:pointer;color:#ff4757;font-size:11.5px;font-weight:600;transition:background .18s;white-space:nowrap" onmouseover="this.style.background='rgba(255,71,87,.22)'" onmouseout="this.style.background='rgba(255,71,87,.1)'">Sign out</button>
          </div>
        </div>
      </aside>
      <div class="main-content">
        <header class="topbar">
          <button class="nav-toggle-btn" id="navToggle" aria-label="Toggle menu">
            <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
          </button>
          <div class="topbar__title" id="topbarTitle">PlacementAI Pro</div>
          <div class="topbar__actions" id="topbarActions"></div>
        </header>
        <main class="page animate-up" id="mainPage"></main>
      </div>
    </div>`;

  document.getElementById('navToggle').addEventListener('click', ()=>{
    document.getElementById('sidebar').classList.toggle('open');
    document.getElementById('sidebarOverlay').classList.toggle('visible');
  });
  document.getElementById('sidebarOverlay').addEventListener('click', ()=>{
    document.getElementById('sidebar').classList.remove('open');
    document.getElementById('sidebarOverlay').classList.remove('visible');
  });
}

/* ── Dark/Light Mode Toggle ─────────────────────────────────── */
const ThemeManager = {
  _key: 'pai_theme',
  init() {
    const saved = localStorage.getItem(this._key) || 'dark';
    this.apply(saved);
  },
  toggle() {
    const current = document.documentElement.getAttribute('data-theme') || 'dark';
    const next = current === 'dark' ? 'light' : 'dark';
    this.apply(next);
    localStorage.setItem(this._key, next);
    // Update all toggle buttons
    document.querySelectorAll('.theme-toggle-btn').forEach(btn => {
      btn.innerHTML = next === 'dark' ? '🌙' : '☀️';
      btn.title = next === 'dark' ? 'Switch to light mode' : 'Switch to dark mode';
    });
  },
  apply(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    document.querySelectorAll('.theme-toggle-btn').forEach(btn => {
      btn.innerHTML = theme === 'dark' ? '🌙' : '☀️';
    });
  },
  current() { return document.documentElement.getAttribute('data-theme') || 'dark'; }
};
ThemeManager.init();

/* ── Notifications System ────────────────────────────────────── */
const Notifs = {
  _interval: null,
  async fetchCount(uid) {
    try {
      const r = await fetch(`php/notifications.php?action=unread_count&user_id=${uid}`);
      const d = await r.json();
      if (d.success) this.updateBadge(d.count);
    } catch(e) {}
  },
  updateBadge(count) {
    const badge = document.getElementById('notifBadge');
    if (!badge) return;
    if (count > 0) {
      badge.textContent = count > 9 ? '9+' : count;
      badge.style.display = 'flex';
    } else {
      badge.style.display = 'none';
    }
  },
  async showPanel(uid) {
    // Remove existing panel
    const existing = document.getElementById('notifPanel');
    if (existing) { existing.remove(); return; }

    const overlay = document.createElement('div');
    overlay.id = 'notifOverlay';
    overlay.style.cssText = 'position:fixed;inset:0;z-index:998;';
    overlay.onclick = () => { overlay.remove(); document.getElementById('notifPanel')?.remove(); };
    document.body.appendChild(overlay);

    const panel = document.createElement('div');
    panel.id = 'notifPanel';
    panel.innerHTML = `
      <div style="padding:14px 18px 12px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between">
        <div style="display:flex;align-items:center;gap:8px">
          <div style="width:30px;height:30px;border-radius:8px;background:rgba(108,99,255,.15);border:1px solid rgba(108,99,255,.25);display:flex;align-items:center;justify-content:center">
            <svg width="14" height="14" fill="none" stroke="var(--primary)" stroke-width="2" viewBox="0 0 24 24"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
          </div>
          <span style="font-weight:700;font-size:14px;color:var(--text)">Notifications</span>
        </div>
        <button onclick="Notifs.markAllRead(${uid})" style="font-size:11.5px;color:var(--primary);background:rgba(108,99,255,.1);border:1px solid rgba(108,99,255,.2);border-radius:6px;cursor:pointer;padding:4px 10px;font-weight:500;transition:background .15s" onmouseover="this.style.background='rgba(108,99,255,.2)'" onmouseout="this.style.background='rgba(108,99,255,.1)'">Mark all read</button>
      </div>
      <div id="notifList" style="max-height:400px;overflow-y:auto">
        <div style="text-align:center;padding:28px;color:var(--text3)"><div class="spinner" style="width:20px;height:20px;margin:0 auto 10px"></div>Loading…</div>
      </div>`;
    panel.style.cssText = `position:fixed;top:58px;right:16px;width:360px;max-width:calc(100vw - 32px);background:var(--surface);border:1px solid var(--border2);border-radius:16px;box-shadow:0 20px 60px rgba(0,0,0,.5);z-index:1001;overflow:hidden;animation:notifSlide .2s cubic-bezier(.34,1.56,.64,1)`;
    document.body.appendChild(panel);

    try {
      const r = await fetch(`php/notifications.php?action=list&user_id=${uid}&limit=20`);
      const d = await r.json();
      const list = document.getElementById('notifList');
      if (!list) return;
      if (!d.notifications?.length) {
        list.innerHTML = `<div style="text-align:center;padding:40px 20px;color:var(--text3)"><div style="font-size:2rem;margin-bottom:12px">🔔</div><div style="font-size:14px;font-weight:600;color:var(--text2);margin-bottom:4px">All caught up!</div><div style="font-size:12.5px">No notifications yet</div></div>`;
        return;
      }
      list.innerHTML = d.notifications.map(n => {
        const icons = {shortlisted:'🎉',applied:'✅',new_applicant:'📋',org_pending:'🏢',info:'ℹ️',warning:'⚠️'};
        const icon = icons[n.type] || '🔔';
        const unreadBg = n.is_read ? 'transparent' : 'rgba(108,99,255,.07)';
        return `<div onclick="Notifs.clickNotif(${uid},${n.id},'${esc(n.link||'')}')"
          style="display:flex;align-items:flex-start;gap:10px;padding:12px 16px;border-bottom:1px solid var(--border);cursor:pointer;transition:background .15s;background:${unreadBg}"
          onmouseover="this.style.background='var(--surface2)'" onmouseout="this.style.background='${unreadBg}'">
          <div style="width:8px;height:8px;border-radius:50%;background:${n.is_read?'transparent':'var(--primary)'};flex-shrink:0;margin-top:5px;transition:background .2s"></div>
          <div style="flex:1;min-width:0">
            <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:8px;margin-bottom:2px">
              <div style="font-size:13px;font-weight:${n.is_read?500:700};color:var(--text);line-height:1.3">${icon} ${esc(n.title)}</div>
              <div style="font-size:10px;color:var(--text3);white-space:nowrap;flex-shrink:0;margin-top:2px">${fmtDate(n.created_at)}</div>
            </div>
            ${n.body ? `<div style="font-size:12px;color:var(--text3);line-height:1.4;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(n.body)}</div>` : ''}
          </div>
        </div>`;}).join('');
      this.updateBadge(d.unread);
    } catch(e) {}
  },
  async clickNotif(uid, id, link) {
    await fetch('php/notifications.php', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'mark_read',user_id:uid,notification_id:id})});
    document.getElementById('notifPanel')?.remove();
    document.getElementById('notifOverlay')?.remove();
    if (link) location.href = link;
  },
  async markAllRead(uid) {
    await fetch('php/notifications.php', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'mark_read',user_id:uid})});
    const nb=document.getElementById('notifBadge'); if(nb){nb.classList.remove('has-unread');nb.textContent='';}
    document.getElementById('notifPanel')?.remove();
    document.getElementById('notifOverlay')?.remove();
  },
  startPolling(uid) {
    this.fetchCount(uid);
    this._interval = setInterval(() => this.fetchCount(uid), 30000);
  }
};

/* ── Application Status Timeline ────────────────────────────── */
function applicationTimeline(status, timeline=[]) {
  const steps = [
    { key:'applied',              icon:'📋', label:'Applied' },
    { key:'shortlisted',          icon:'⭐', label:'Shortlisted' },
    { key:'interview_scheduled',  icon:'📅', label:'Interview' },
    { key:'hired',                icon:'🏆', label:'Hired' },
  ];
  const isRejected = status === 'rejected';
  const order = ['applied','shortlisted','interview_scheduled','hired'];
  const currentIdx = isRejected ? order.indexOf('applied') : order.indexOf(status);

  return `<div style="display:flex;align-items:center;gap:0;margin:16px 0;position:relative">
    ${steps.map((s,i) => {
      const done = !isRejected && i <= currentIdx;
      const active = !isRejected && i === currentIdx;
      const color = done ? 'var(--emerald)' : 'var(--surface3)';
      const textColor = done ? 'var(--text)' : 'var(--text3)';
      return `
        <div style="flex:1;display:flex;flex-direction:column;align-items:center;position:relative">
          ${i > 0 ? `<div style="position:absolute;top:14px;left:-50%;right:50%;height:2px;background:${done?'var(--emerald)':'var(--surface3)'};z-index:0;transition:background .4s"></div>` : ''}
          <div style="width:28px;height:28px;border-radius:50%;background:${color};display:flex;align-items:center;justify-content:center;font-size:${active?'14':'12'}px;position:relative;z-index:1;border:2px solid ${active?'var(--primary)':'transparent'};transition:all .3s;${active?'box-shadow:0 0 0 3px rgba(124,106,255,.25)':''}">${s.icon}</div>
          <div style="font-size:10.5px;color:${textColor};margin-top:5px;font-weight:${active?'700':'400'};text-align:center">${s.label}</div>
        </div>`;
    }).join('')}
    ${isRejected ? `<div style="position:absolute;bottom:-20px;left:50%;transform:translateX(-50%);font-size:11px;color:var(--red);font-weight:600">❌ Not Selected</div>` : ''}
  </div>`;
}

/* ── Update buildShell to inject bell + theme toggle ─────────── */
const _origBuildShell = buildShell;
// Patch topbarActions after buildShell runs
const _patchedBuildShell = buildShell;
// Override to add notification bell + theme toggle in topbar
(function patchBuildShell() {
  const orig = buildShell;
  window._buildShellOrig = orig;
  window.buildShell = function(activePage) {
    orig(activePage);
    // Inject notification bell + theme toggle after shell is built
    const user = Auth.getUser();
    if (!user) return;
    const actions = document.getElementById('topbarActions');
    if (actions) {
      // Theme toggle button
      const themeBtn = document.createElement('button');
      themeBtn.className = 'theme-toggle-btn';
      themeBtn.style.cssText = 'background:none;border:1px solid var(--border2);border-radius:8px;width:34px;height:34px;cursor:pointer;font-size:16px;display:flex;align-items:center;justify-content:center;transition:background .2s;flex-shrink:0';
      themeBtn.innerHTML = ThemeManager.current() === 'dark' ? '🌙' : '☀️';
      themeBtn.title = 'Toggle theme';
      themeBtn.onclick = () => ThemeManager.toggle();
      actions.prepend(themeBtn);

      // Bell icon — improved with pulse animation on unread
      const bellStyle = document.createElement('style');
      bellStyle.textContent = `
        .notif-btn { position:relative; width:36px; height:36px; border-radius:10px; border:1px solid var(--border2); background:none; cursor:pointer; display:flex; align-items:center; justify-content:center; transition:background .18s,border-color .18s; flex-shrink:0; }
        .notif-btn:hover { background:var(--surface2); border-color:var(--border3); }
        .notif-btn:hover svg { stroke:var(--text); }
        .notif-btn svg { stroke:var(--text2); transition:stroke .18s; }
        #notifBadge { display:none; position:absolute; top:-6px; right:-6px; min-width:18px; height:18px; padding:0 4px; background:#ef4444; border-radius:99px; font-size:10px; font-weight:800; color:#fff; align-items:center; justify-content:center; border:2px solid var(--bg); letter-spacing:0; line-height:1; }
        #notifBadge.has-unread { display:flex !important; }
        @keyframes notifPulse { 0%,100%{box-shadow:0 0 0 0 rgba(239,68,68,.5)} 50%{box-shadow:0 0 0 5px rgba(239,68,68,0)} }
        #notifBadge.has-unread { animation:notifPulse 2s ease infinite; }
        #notifPanel { position:fixed; top:56px; right:16px; width:360px; max-width:calc(100vw - 32px); background:var(--surface); border:1px solid var(--border2); border-radius:16px; box-shadow:0 20px 60px rgba(0,0,0,.5); z-index:1001; overflow:hidden; animation:notifSlide .2s cubic-bezier(.34,1.56,.64,1); }
        @keyframes notifSlide { from{opacity:0;transform:translateY(-8px) scale(.97)} to{opacity:1;transform:translateY(0) scale(1)} }
        .notif-item { display:flex; align-items:flex-start; gap:10px; padding:12px 16px; border-bottom:1px solid var(--border); cursor:pointer; transition:background .15s; }
        .notif-item:hover { background:var(--surface2); }
        .notif-item:last-child { border-bottom:none; }
        .notif-item.unread { background:rgba(108,99,255,.06); }
        .notif-item.unread:hover { background:rgba(108,99,255,.1); }
        .notif-dot { width:8px; height:8px; border-radius:50%; background:var(--primary); flex-shrink:0; margin-top:5px; }
        .notif-dot.read { background:transparent; }
      `;
      document.head.appendChild(bellStyle);

      const bellWrap = document.createElement('div');
      bellWrap.style.cssText = 'position:relative;';
      bellWrap.innerHTML = `
        <button class="notif-btn" onclick="Notifs.showPanel(${user.id})" title="Notifications">
          <svg width="17" height="17" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24">
            <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
            <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
          </svg>
          <span id="notifBadge"></span>
        </button>`;
      actions.prepend(bellWrap);
      Notifs.startPolling(user.id);
    }
    // Add new sidebar items based on role
    const user2 = Auth.getUser();
    if (user2) {
      const nav = document.querySelector('.sidebar__nav');
      if (nav && user2.role === 'student') {
        // Add leaderboard + resume builder links if not present
        if (!document.querySelector('[href="leaderboard.php"]')) {
          const lb = document.createElement('a');
          lb.href = 'leaderboard.php';
          lb.className = `nav-item${activePage==='leaderboard'?' active':''}`;
          lb.innerHTML = `<svg width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"/><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"/><path d="M4 22h16"/><path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22"/><path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22"/><path d="M18 2H6v7a6 6 0 0 0 12 0V2z"/></svg> Leaderboard`;
          nav.appendChild(lb);
        }
        if (!document.querySelector('[href="resume-builder.php"]')) {
          const rb = document.createElement('a');
          rb.href = 'resume-builder.php';
          rb.className = `nav-item${activePage==='resume-builder'?' active':''}`;
          rb.innerHTML = `<svg width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 9h6M9 12h6M9 15h4"/></svg> Resume Builder`;
          nav.appendChild(rb);
        }
      }
      if (user2.role === 'organization') {
        if (!document.querySelector('[href="organization.php?tab=aptitude"]')) {
          const aq = document.createElement('a');
          aq.href = 'organization.php?tab=aptitude';
          aq.className = `nav-item${activePage==='org-aptitude'?' active':''}`;
          aq.innerHTML = `<svg width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9.5 2A2.5 2.5 0 0 1 12 4.5v15"/><path d="M14.5 2A2.5 2.5 0 0 0 12 4.5"/></svg> Aptitude Questions`;
          nav.appendChild(aq);
        }
      }
      if (user2.role === 'admin') {
        if (!document.querySelector('[href="admin.php?tab=import"]')) {
          const bi = document.createElement('a');
          bi.href = 'admin.php?tab=import';
          bi.className = `nav-item${activePage==='admin-import'?' active':''}`;
          bi.innerHTML = `<svg width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg> Bulk Import`;
          nav.appendChild(bi);
        }
      }
    }
  };
})();

/* ── Slide-down animation for notification panel ─────────────── */
const _style = document.createElement('style');
_style.textContent = `@keyframes slideDown{from{opacity:0;transform:translateY(-8px)}to{opacity:1;transform:translateY(0)}}`;
document.head.appendChild(_style);

/* ── Modal helpers (required for Jobs page) ─────────────────── */
function openModal(id) {
  const el = document.getElementById(id);
  if (!el) return;
  el.classList.add('active');
  document.body.style.overflow = 'hidden';
  // Close on backdrop click
  el.onclick = (e) => { if (e.target === el) closeModal(id); };
}
function closeModal(id) {
  const el = document.getElementById(id);
  if (!el) return;
  el.classList.remove('active');
  document.body.style.overflow = '';
}
// Close modals on ESC key
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal-overlay.active').forEach(m => {
      m.classList.remove('active');
      document.body.style.overflow = '';
    });
  }
});

/* ═══════════════════════════════════════════════════════════════
   CUSTOM SELECT DROPDOWN — replaces all .form-select elements
   Injected globally, auto-initializes on DOM mutations
   ═══════════════════════════════════════════════════════════════ */
(function initCustomSelects() {

  /* ── Inject styles once ────────────────────────────────────── */
  if (!document.getElementById('cs-style')) {
    const s = document.createElement('style');
    s.id = 'cs-style';
    s.textContent = `
      /* Hide native select but keep it functional */
      .cs-wrap { position: relative; width: 100%; }
      .cs-wrap select.form-select { position: absolute; opacity: 0; pointer-events: none; width: 100%; height: 100%; top: 0; left: 0; }

      /* Custom trigger button */
      .cs-btn {
        width: 100%;
        display: flex; align-items: center; justify-content: space-between; gap: 10px;
        padding: 9px 13px;
        background: var(--bg3);
        border: 1px solid var(--border2);
        border-radius: var(--radius-sm);
        color: var(--text);
        font-size: 13.5px;
        font-family: var(--font-body);
        cursor: pointer;
        transition: border-color .15s, box-shadow .15s;
        text-align: left;
        user-select: none;
        position: relative;
        z-index: 1;
      }
      .cs-btn:hover { border-color: var(--border3); }
      .cs-btn.open, .cs-btn:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px rgba(124,106,255,.15);
        outline: none;
      }
      .cs-btn-text { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
      .cs-arrow {
        flex-shrink: 0;
        width: 16px; height: 16px;
        display: flex; align-items: center; justify-content: center;
        transition: transform .2s cubic-bezier(.4,0,.2,1);
        color: var(--text3);
      }
      .cs-btn.open .cs-arrow { transform: rotate(180deg); }

      /* Dropdown panel */
      .cs-panel {
        position: absolute; top: calc(100% + 6px); left: 0; right: 0;
        background: var(--surface);
        border: 1px solid var(--border2);
        border-radius: 12px;
        box-shadow: 0 16px 48px rgba(0,0,0,.55), 0 4px 12px rgba(0,0,0,.3);
        z-index: 9999;
        overflow: hidden;
        opacity: 0; transform: translateY(-8px) scale(.98);
        transition: opacity .18s cubic-bezier(.4,0,.2,1), transform .18s cubic-bezier(.4,0,.2,1);
        pointer-events: none;
        max-height: 280px;
        overflow-y: auto;
      }
      .cs-panel.open {
        opacity: 1; transform: translateY(0) scale(1);
        pointer-events: all;
      }
      .cs-panel::-webkit-scrollbar { width: 4px; }
      .cs-panel::-webkit-scrollbar-track { background: transparent; }
      .cs-panel::-webkit-scrollbar-thumb { background: var(--surface3); border-radius: 99px; }

      /* Option items */
      .cs-opt {
        display: flex; align-items: center; gap: 10px;
        padding: 10px 14px;
        font-size: 13.5px;
        color: var(--text2);
        cursor: pointer;
        transition: background .12s, color .12s;
        border-radius: 0;
        position: relative;
      }
      .cs-opt:first-child { border-radius: 12px 12px 0 0; }
      .cs-opt:last-child  { border-radius: 0 0 12px 12px; }
      .cs-opt:only-child  { border-radius: 12px; }
      .cs-opt:hover { background: var(--surface2); color: var(--text); }
      .cs-opt.selected {
        background: rgba(124,106,255,.1);
        color: var(--primary-l);
        font-weight: 600;
      }
      .cs-opt.selected::after {
        content: '';
        position: absolute; right: 14px; top: 50%; transform: translateY(-50%);
        width: 6px; height: 6px;
        background: var(--primary);
        border-radius: 50%;
      }
      .cs-opt + .cs-opt { border-top: 1px solid var(--border); }

      /* Smooth scroll fix for panels that open near bottom */
      .cs-panel.open-up {
        top: auto; bottom: calc(100% + 6px);
        transform: translateY(8px) scale(.98);
      }
      .cs-panel.open-up.open { transform: translateY(0) scale(1); }
    `;
    document.head.appendChild(s);
  }

  /* ── Build custom dropdown from a <select> ─────────────────── */
  function buildCustomSelect(sel) {
    if (sel.dataset.csInit) return;
    sel.dataset.csInit = '1';

    const wrap = document.createElement('div');
    wrap.className = 'cs-wrap';
    sel.parentNode.insertBefore(wrap, sel);
    wrap.appendChild(sel);

    /* Trigger button */
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'cs-btn';
    btn.tabIndex = 0;
    btn.innerHTML = `<span class="cs-btn-text"></span><span class="cs-arrow"><svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><polyline points="6 9 12 15 18 9"/></svg></span>`;
    wrap.appendChild(btn);

    /* Panel */
    const panel = document.createElement('div');
    panel.className = 'cs-panel';
    wrap.appendChild(panel);

    function syncDisplay() {
      const chosen = sel.options[sel.selectedIndex];
      btn.querySelector('.cs-btn-text').textContent = chosen ? chosen.text : '';
    }

    function buildOptions() {
      panel.innerHTML = '';
      Array.from(sel.options).forEach((opt, i) => {
        const item = document.createElement('div');
        item.className = 'cs-opt' + (i === sel.selectedIndex ? ' selected' : '');
        item.textContent = opt.text;
        item.dataset.val = opt.value;
        item.addEventListener('mousedown', e => {
          e.preventDefault();
          sel.value = opt.value;
          sel.selectedIndex = i;
          sel.dispatchEvent(new Event('change', { bubbles: true }));
          syncDisplay();
          close();
        });
        panel.appendChild(item);
      });
    }

    function open() {
      buildOptions();
      btn.classList.add('open');
      panel.classList.add('open');
      /* Flip up if near viewport bottom */
      const rect = panel.getBoundingClientRect();
      if (rect.bottom > window.innerHeight - 20) panel.classList.add('open-up');
      else panel.classList.remove('open-up');
    }

    function close() {
      btn.classList.remove('open');
      panel.classList.remove('open');
    }

    function toggle() { btn.classList.contains('open') ? close() : open(); }

    btn.addEventListener('click', e => { e.stopPropagation(); toggle(); });
    btn.addEventListener('keydown', e => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); }
      if (e.key === 'Escape') close();
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        if (!btn.classList.contains('open')) open();
        const opts = panel.querySelectorAll('.cs-opt');
        const cur = panel.querySelector('.cs-opt.selected');
        const idx = Array.from(opts).indexOf(cur);
        if (idx < opts.length - 1) opts[idx + 1]?.dispatchEvent(new MouseEvent('mousedown'));
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        const opts = panel.querySelectorAll('.cs-opt');
        const cur = panel.querySelector('.cs-opt.selected');
        const idx = Array.from(opts).indexOf(cur);
        if (idx > 0) opts[idx - 1]?.dispatchEvent(new MouseEvent('mousedown'));
      }
    });

    /* Close when clicking outside */
    document.addEventListener('click', e => {
      if (!wrap.contains(e.target)) close();
    }, true);

    /* Keep in sync if native select changes programmatically */
    sel.addEventListener('change', syncDisplay);

    syncDisplay();
  }

  /* ── Scan & init all current selects ───────────────────────── */
  function initAll() {
    document.querySelectorAll('select.form-select:not([data-cs-init])').forEach(buildCustomSelect);
  }

  /* ── Watch for dynamically added selects (JS-rendered pages) ── */
  const observer = new MutationObserver(() => initAll());
  observer.observe(document.body, { childList: true, subtree: true });

  /* Initial pass — wait a tick for JS pages to render */
  setTimeout(initAll, 0);
  document.addEventListener('DOMContentLoaded', initAll);

})();

/* ============================================================
   PLACEMENTAI PRO — Mock API (No-PHP Standalone Mode)
   Intercepts all API.post/get calls and responds from localStorage
   ============================================================ */

// ── Seed Data ────────────────────────────────────────────────
const SEED = {
  users: [
    { id:1, name:'Rahul Verma',    email:'rahul@student.com',    role:'student',      password:'password123', is_active:1 },
    { id:2, name:'Priya Shah',     email:'priya@student.com',    role:'student',      password:'password123', is_active:1 },
    { id:3, name:'Arjun Mehta',    email:'arjun@student.com',    role:'student',      password:'password123', is_active:1 },
    { id:4, name:'Google HR',      email:'hr@google.com',        role:'organization', password:'password123', is_active:1 },
    { id:5, name:'Amazon HR',      email:'hr@amazon.com',        role:'organization', password:'password123', is_active:1 },
    { id:6, name:'Infosys HR',     email:'hr@infosys.com',       role:'organization', password:'password123', is_active:1 },
    { id:7, name:'Admin User',     email:'admin@placementai.com',role:'admin',        password:'password123', is_active:1 },
  ],
  orgs: [
    { id:1, user_id:4, company_name:'Google',  description:'Search & cloud leader.', industry:'Technology', verified:1, website:'https://google.com', logo_url:'' },
    { id:2, user_id:5, company_name:'Amazon',  description:'E-commerce & AWS cloud.', industry:'Technology', verified:1, website:'https://amazon.com', logo_url:'' },
    { id:3, user_id:6, company_name:'Infosys', description:'IT services giant.', industry:'IT Services', verified:0, website:'https://infosys.com', logo_url:'' },
  ],
  student_profiles: [
    { user_id:1, branch:'Computer Science', cgpa:8.70, skills:'Python, Machine Learning, React, SQL, TensorFlow, Docker, Git, REST API', projects:4, internships:1, aptitude_score:85, communication_rating:8.0, resume_score:76, ats_score:82, interview_score:78, github_url:'https://github.com', linkedin_url:'https://linkedin.com', resume_text:'' },
    { user_id:2, branch:'Information Technology', cgpa:9.10, skills:'Java, Spring Boot, MySQL, Angular, Redis, AWS, Docker', projects:5, internships:2, aptitude_score:92, communication_rating:9.0, resume_score:88, ats_score:90, interview_score:91, github_url:'', linkedin_url:'', resume_text:'' },
    { user_id:3, branch:'Electronics', cgpa:7.20, skills:'C++, Embedded C, MATLAB, Python', projects:2, internships:0, aptitude_score:68, communication_rating:6.5, resume_score:null, ats_score:null, interview_score:null, github_url:'', linkedin_url:'', resume_text:'' },
  ],
  jobs: [
    { id:1, org_id:1, title:'Software Engineer',   description:'Build planet-scale systems. Work on search infrastructure, distributed storage, and developer tools used by billions worldwide.', required_skills:'Python, C++, System Design, DSA, Algorithms', min_cgpa:8.5, max_cgpa:10, experience_level:'Entry', location:'Bangalore / Remote', salary_range:'18-25 LPA', is_active:1, created_at:'2025-01-15', company_name:'Google' },
    { id:2, org_id:1, title:'ML Engineer',         description:'Work on Google AI products. Design and train ML models at scale, improve AI accuracy across Google Search and Ads.', required_skills:'Python, TensorFlow, ML, PyTorch, SQL', min_cgpa:8.0, max_cgpa:10, experience_level:'Entry', location:'Hyderabad', salary_range:'20-28 LPA', is_active:1, created_at:'2025-01-20', company_name:'Google' },
    { id:3, org_id:2, title:'Data Scientist',      description:'AWS ML services team. Analyze massive datasets, build recommendation systems, and create predictive models for AWS customers.', required_skills:'Python, ML, SQL, AWS, Cloud', min_cgpa:8.0, max_cgpa:10, experience_level:'Entry', location:'Hyderabad', salary_range:'15-22 LPA', is_active:1, created_at:'2025-01-22', company_name:'Amazon' },
    { id:4, org_id:3, title:'Systems Engineer',    description:'Support & deploy enterprise applications. Manage large-scale ERP deployments for Fortune 500 clients across industries.', required_skills:'Java, SQL, Spring, Linux', min_cgpa:6.5, max_cgpa:10, experience_level:'Entry', location:'Pune / Chennai', salary_range:'4-7 LPA', is_active:1, created_at:'2025-01-25', company_name:'Infosys' },
    { id:5, org_id:2, title:'Backend Engineer',    description:'Core Amazon Shopping services. Build APIs that handle millions of requests/second for the worlds largest e-commerce platform.', required_skills:'Java, Node.js, DynamoDB, AWS Lambda, Microservices', min_cgpa:7.5, max_cgpa:10, experience_level:'Entry', location:'Bangalore', salary_range:'16-22 LPA', is_active:1, created_at:'2025-02-01', company_name:'Amazon' },
  ],
  applications: [
    { id:1, student_id:1, job_id:1, status:'applied',               org_notes:'', applied_at:'2025-02-01' },
    { id:2, student_id:1, job_id:3, status:'shortlisted',           org_notes:'Strong profile', applied_at:'2025-02-02' },
    { id:3, student_id:2, job_id:1, status:'interview_scheduled',   org_notes:'', applied_at:'2025-02-03' },
    { id:4, student_id:2, job_id:2, status:'applied',               org_notes:'', applied_at:'2025-02-04' },
    { id:5, student_id:3, job_id:4, status:'applied',               org_notes:'', applied_at:'2025-02-05' },
  ],
  streak_data: [
    { user_id:1, current_streak:5, longest_streak:12, total_xp:2340, last_checkin: new Date(Date.now()-86400000).toISOString().split('T')[0], badges:['🔥','⭐','🏆'], level:4, level_progress:64 },
    { user_id:2, current_streak:12, longest_streak:20, total_xp:5100, last_checkin: new Date().toISOString().split('T')[0], badges:['🔥','⭐','🏆','💎'], level:7, level_progress:30 },
    { user_id:3, current_streak:1, longest_streak:3, total_xp:430, last_checkin: new Date(Date.now()-172800000).toISOString().split('T')[0], badges:['⭐'], level:1, level_progress:20 },
  ],
  notifications: [],
  aptitude_results: [
    { id:1, user_id:1, score:85, tab_warnings:0, taken_at:'2025-01-10' },
    { id:2, user_id:2, score:92, tab_warnings:0, taken_at:'2025-01-12' },
  ],
  org_aptitude: [],
  interview_schedules: [],
};

// ── LocalStorage DB ─────────────────────────────────────────
const DB = {
  _inited: false,
  init() {
    if (this._inited) return;
    this._inited = true;
    if (!localStorage.getItem('pai_db_seeded')) {
      Object.keys(SEED).forEach(k => localStorage.setItem('pai_db_' + k, JSON.stringify(SEED[k])));
      localStorage.setItem('pai_db_seeded', '1');
    }
  },
  get(table) {
    this.init();
    try { return JSON.parse(localStorage.getItem('pai_db_' + table) || '[]'); } catch { return []; }
  },
  set(table, data) {
    localStorage.setItem('pai_db_' + table, JSON.stringify(data));
  },
  nextId(table) {
    const rows = this.get(table);
    return rows.length ? Math.max(...rows.map(r => r.id || 0)) + 1 : 1;
  },
  insert(table, row) {
    const rows = this.get(table);
    const newRow = { id: this.nextId(table), ...row };
    rows.push(newRow);
    this.set(table, rows);
    return newRow;
  },
  update(table, id, updates) {
    const rows = this.get(table);
    const i = rows.findIndex(r => r.id == id);
    if (i >= 0) { rows[i] = { ...rows[i], ...updates }; this.set(table, rows); return rows[i]; }
    return null;
  },
  upsert(table, keyField, keyVal, data) {
    const rows = this.get(table);
    const i = rows.findIndex(r => r[keyField] == keyVal);
    if (i >= 0) { rows[i] = { ...rows[i], ...data }; this.set(table, rows); return rows[i]; }
    else { const row = { id: this.nextId(table), ...data }; rows.push(row); this.set(table, rows); return row; }
  },
  findOne(table, fn) { return this.get(table).find(fn) || null; },
  find(table, fn) { return this.get(table).filter(fn); },
};
DB.init();

// ── Delay helper ──────────────────────────────────────────────
function delay(ms=300) { return new Promise(r => setTimeout(r, ms)); }

// ── Mock endpoint handlers ───────────────────────────────────
const MOCK_HANDLERS = {

  // ── AUTH ────────────────────────────────────────────────────
  'auth_login.php': async (body) => {
    await delay(400);
    const users = DB.get('users');
    const user = users.find(u => u.email === body.email);
    if (!user || user.password !== body.password) throw new Error('Invalid email or password');
    if (!user.is_active) throw new Error('Your account has been suspended. Contact admin.');
    if (user.role === 'organization') {
      const org = DB.findOne('orgs', o => o.user_id == user.id);
      if (!org || !org.verified) throw new Error('Your organization is pending admin verification.');
    }
    const { password: _, ...safeUser } = user;
    return { success: true, user: safeUser };
  },

  'auth_register.php': async (body) => {
    await delay(400);
    const { name, email, password, branch } = body;
    if (!name || !email || !password) throw new Error('All fields are required');
    if (!/\S+@\S+\.\S+/.test(email)) throw new Error('Invalid email address');
    if (password.length < 6) throw new Error('Password must be at least 6 characters');
    const existing = DB.findOne('users', u => u.email === email);
    if (existing) throw new Error('An account with this email already exists');
    const newUser = DB.insert('users', { name, email, password, role: 'student', is_active: 1, created_at: new Date().toISOString() });
    DB.insert('student_profiles', { user_id: newUser.id, branch: branch||'CSE', cgpa:0, skills:'', projects:0, internships:0, aptitude_score:0, communication_rating:5.0, resume_score:null, ats_score:null, interview_score:null, github_url:'', linkedin_url:'', resume_text:'' });
    return { success: true, userId: newUser.id, message: 'Account created! Please sign in.' };
  },

  'auth_register_org.php': async (body) => {
    await delay(400);
    const { name, email, password, company_name, industry, description } = body;
    if (!name || !email || !password || !company_name) throw new Error('All fields are required');
    if (password.length < 6) throw new Error('Password must be at least 6 characters');
    const existing = DB.findOne('users', u => u.email === email);
    if (existing) throw new Error('An account with this email already exists');
    const newUser = DB.insert('users', { name, email, password, role: 'organization', is_active: 1, created_at: new Date().toISOString() });
    DB.insert('orgs', { user_id: newUser.id, company_name, description: description||'', industry: industry||'Technology', verified: 0, website: '', logo_url: '' });
    return { success: true, message: 'Registration submitted! Admin will verify your account.' };
  },

  // ── STUDENT PROFILE ─────────────────────────────────────────
  'student_profile.php': async (params) => {
    await delay(200);
    const uid = parseInt(params.user_id);
    const p = DB.findOne('student_profiles', p => p.user_id == uid);
    return { success: true, profile: p || null };
  },

  'student_profile_save.php': async (body) => {
    await delay(300);
    const uid = body.user_id;
    DB.upsert('student_profiles', 'user_id', uid, { ...body });
    return { success: true, message: 'Profile saved!' };
  },

  // ── JOBS ────────────────────────────────────────────────────
  'jobs.php': async (params, body) => {
    await delay(250);
    const action = params.action || body?.action;
    if (action === 'list') {
      let jobs = DB.get('jobs').filter(j => j.is_active);
      const orgs = DB.get('orgs');
      jobs = jobs.map(j => {
        const org = orgs.find(o => o.id == j.org_id);
        return { ...j, company_name: org?.company_name || 'Company' };
      });
      if (params.limit) jobs = jobs.slice(0, parseInt(params.limit));
      return { success: true, jobs };
    }
    if (action === 'my_applications') {
      const uid = parseInt(params.user_id || body?.user_id);
      const apps = DB.find('applications', a => a.student_id == uid);
      const jobs = DB.get('jobs');
      const orgs = DB.get('orgs');
      const result = apps.map(app => {
        const job = jobs.find(j => j.id == app.job_id) || {};
        const org = orgs.find(o => o.id == job.org_id) || {};
        return { ...app, job_title: job.title, company_name: org.company_name, location: job.location, salary_range: job.salary_range };
      });
      return { success: true, applications: result };
    }
    return { success: true, jobs: [] };
  },

  'apply_job.php': async (body) => {
    await delay(300);
    const { user_id, job_id } = body;
    const existing = DB.findOne('applications', a => a.student_id == user_id && a.job_id == job_id);
    if (existing) throw new Error('Already applied');
    const job = DB.findOne('jobs', j => j.id == job_id && j.is_active);
    if (!job) throw new Error('Job not found or inactive');
    DB.insert('applications', { student_id: parseInt(user_id), job_id: parseInt(job_id), status: 'applied', org_notes: '', applied_at: new Date().toISOString() });
    return { success: true, message: 'Application submitted successfully!' };
  },

  'job_recommendations.php': async (params) => {
    await delay(300);
    const uid = parseInt(params.user_id);
    const profile = DB.findOne('student_profiles', p => p.user_id == uid);
    let jobs = DB.get('jobs').filter(j => j.is_active);
    const orgs = DB.get('orgs');
    if (profile) {
      jobs = jobs.filter(j => j.min_cgpa <= (profile.cgpa || 0));
      const skills = (profile.skills || '').toLowerCase();
      jobs = jobs.map(j => {
        const jSkills = (j.required_skills || '').toLowerCase().split(',').map(s => s.trim());
        const matched = jSkills.filter(s => skills.includes(s)).length;
        const score = Math.round((matched / Math.max(jSkills.length, 1)) * 100);
        const org = orgs.find(o => o.id == j.org_id);
        return { ...j, match_score: score, company_name: org?.company_name };
      }).sort((a, b) => b.match_score - a.match_score);
    }
    return { success: true, jobs: jobs.slice(0, 6) };
  },

  // ── ORG PANEL ───────────────────────────────────────────────
  'org_panel.php': async (body) => {
    await delay(300);
    const action = body.action;
    const uid = parseInt(body.user_id);
    const org = DB.findOne('orgs', o => o.user_id == uid);
    if (!org) throw new Error('Organization not found');

    if (action === 'overview') {
      const jobs = DB.find('jobs', j => j.org_id == org.id);
      const jobIds = jobs.map(j => j.id);
      const apps = DB.find('applications', a => jobIds.includes(a.job_id));
      const hired = apps.filter(a => a.status === 'hired');
      const ovData = {
        total_jobs: jobs.length, active_jobs: jobs.filter(j=>j.is_active).length,
        total_apps: apps.length, hired: hired.length,
        shortlisted: apps.filter(a=>a.status==='shortlisted').length,
        company_name: org.company_name, industry: org.industry,
      };
      return { success: true, stats: ovData, overview: ovData };
    }
    if (action === 'jobs') {
      const jobs = DB.find('jobs', j => j.org_id == org.id);
      const allApps = DB.get('applications');
      return { success: true, jobs: jobs.map(j => ({
        ...j,
        applicant_count: allApps.filter(a => a.job_id == j.id).length,
        hired_count: allApps.filter(a => a.job_id == j.id && a.status === 'hired').length
      })) };
    }
    if (action === 'students') {
      const users = DB.get('users').filter(u => u.role === 'student');
      const profiles = DB.get('student_profiles');
      const apps = DB.get('applications');
      const jobIds = DB.find('jobs', j => j.org_id == org.id).map(j => j.id);
      return { success: true, students: users.map(u => {
        const p = profiles.find(p => p.user_id == u.id) || {};
        const hasApplied = apps.some(a => a.student_id == u.id && jobIds.includes(a.job_id));
        return { id: u.id, name: u.name, email: u.email, branch: p.branch, cgpa: p.cgpa, skills: p.skills, aptitude_score: p.aptitude_score, has_applied: hasApplied };
      })};
    }
    if (action === 'toggle_job') {
      const job = DB.findOne('jobs', j => j.id == body.job_id && j.org_id == org.id);
      if (!job) throw new Error('Job not found');
      DB.update('jobs', job.id, { is_active: job.is_active ? 0 : 1 });
      return { success: true };
    }
    if (action === 'update_application') {
      DB.update('applications', body.app_id, { status: body.status, org_notes: body.notes || '' });
      return { success: true };
    }
    return { success: true };
  },

  'org_job_create.php': async (body) => {
    await delay(400);
    const uid = parseInt(body.user_id);
    const org = DB.findOne('orgs', o => o.user_id == uid);
    if (!org) throw new Error('Organization not found');
    const newJob = DB.insert('jobs', {
      org_id: org.id, title: body.title, description: body.description,
      required_skills: body.required_skills || '', min_cgpa: parseFloat(body.min_cgpa) || 6,
      max_cgpa: 10, experience_level: body.experience_level || 'Entry',
      location: body.location || '', salary_range: body.salary_range || '',
      is_active: 1, created_at: new Date().toISOString(), company_name: org.company_name
    });
    return { success: true, job_id: newJob.id, message: 'Job posted successfully!' };
  },

  'org_students.php': async (params) => {
    await delay(250);
    const uid = parseInt(params.user_id);
    const org = DB.findOne('orgs', o => o.user_id == uid);
    if (!org) return { success: true, students: [] };
    const jobIds = DB.find('jobs', j => j.org_id == org.id).map(j => j.id);
    const apps = DB.find('applications', a => jobIds.includes(a.job_id));
    const jobs = DB.get('jobs');
    const users = DB.get('users');
    const profiles = DB.get('student_profiles');
    const result = apps.map(app => {
      const u = users.find(u => u.id == app.student_id) || {};
      const p = profiles.find(p => p.user_id == app.student_id) || {};
      const j = jobs.find(j => j.id == app.job_id) || {};
      return { app_id: app.id, student_id: u.id, name: u.name, email: u.email, branch: p.branch, cgpa: p.cgpa, skills: p.skills, aptitude_score: p.aptitude_score, interview_score: p.interview_score, job_title: j.title, status: app.status, org_notes: app.org_notes, applied_at: app.applied_at };
    });
    return { success: true, students: result };
  },

  'org_aptitude.php': async (body) => {
    await delay(250);
    const action = body.action;
    const uid = parseInt(body.user_id);
    if (action === 'list') {
      const qs = DB.find('org_aptitude', q => q.user_id == uid);
      return { success: true, questions: qs };
    }
    if (action === 'add') {
      const q = DB.insert('org_aptitude', { user_id: uid, question: body.question, option_a: body.option_a, option_b: body.option_b, option_c: body.option_c, option_d: body.option_d, correct: body.correct, difficulty: body.difficulty || 'Medium', category: body.category || 'General', job_id: body.job_id || null });
      return { success: true, question: q };
    }
    if (action === 'delete') {
      const qs = DB.get('org_aptitude').filter(q => q.id != body.question_id);
      DB.set('org_aptitude', qs);
      return { success: true };
    }
    return { success: true };
  },

  // ── ADMIN PANEL ─────────────────────────────────────────────
  'admin_panel.php': async (body) => {
    await delay(350);
    const action = body.action;

    if (action === 'stats') {
      const users = DB.get('users');
      const jobs = DB.get('jobs');
      const apps = DB.get('applications');
      const orgs = DB.get('orgs');
      const profiles = DB.get('student_profiles');
      const students = users.filter(u => u.role === 'student');
      const hired = apps.filter(a => a.status === 'hired').length;
      const placementRate = students.length ? Math.round((hired / students.length) * 100) : 0;
      const branchCounts = {};
      profiles.forEach(p => { branchCounts[p.branch||'Other'] = (branchCounts[p.branch||'Other']||0)+1; });
      const by_branch = Object.entries(branchCounts).map(([branch,cnt]) => ({branch,cnt}));
      const recent = users.sort((a,b) => b.id-a.id).slice(0,5);
      return { success: true, stats: {
        students: students.length,
        total_students: students.length,
        jobs_active: jobs.filter(j => j.is_active).length,
        total_jobs: jobs.length,
        placement_rate: placementRate,
        applications: apps.length,
        total_applications: apps.length,
        hired,
        orgs_total: orgs.length,
        orgs_verified: orgs.filter(o => o.verified).length,
        orgs_pending: orgs.filter(o => !o.verified).length,
        pending_orgs: orgs.filter(o => !o.verified).length,
        total_orgs: orgs.length,
        by_branch,
        recent,
      }};
    }
    if (action === 'students') {
      const users = DB.get('users').filter(u => u.role === 'student');
      const profiles = DB.get('student_profiles');
      const q = (body.q || '').toLowerCase();
      return { success: true, students: users
        .filter(u => !q || u.name.toLowerCase().includes(q) || u.email.toLowerCase().includes(q))
        .map(u => {
          const p = profiles.find(p => p.user_id == u.id) || {};
          return { id: u.id, name: u.name, email: u.email, role: u.role, is_active: u.is_active, branch: p.branch, cgpa: p.cgpa, skills: p.skills, created_at: u.created_at };
        })
      };
    }
    if (action === 'orgs') {
      const orgs = DB.get('orgs');
      const users = DB.get('users');
      const jobs = DB.get('jobs');
      return { success: true, orgs: orgs.map(o => {
        const u = users.find(u => u.id == o.user_id) || {};
        const jobCount = jobs.filter(j => j.org_id == o.id).length;
        return { ...o, contact_email: u.email, contact_name: u.name, is_active: u.is_active, job_count: jobCount };
      })};
    }
    if (action === 'approve_org') {
      const org = DB.findOne('orgs', o => o.id == body.org_id);
      if (!org) throw new Error('Org not found');
      DB.update('orgs', org.id, { verified: body.approve ? 1 : 0 });
      // Also activate the user
      if (body.approve) DB.update('users', org.user_id, { is_active: 1 });
      return { success: true };
    }
    if (action === 'toggle_user') {
      const users = DB.get('users');
      const u = users.find(u => u.id == body.user_id);
      if (!u) throw new Error('User not found');
      DB.update('users', u.id, { is_active: u.is_active ? 0 : 1 });
      return { success: true };
    }
    if (action === 'analytics') {
      const apps = DB.get('applications');
      const users = DB.get('users');
      const profiles = DB.get('student_profiles');
      const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
      const placed = [2,3,5,8,12,18,22,28,31,25,18,10];
      const registered = [10,15,25,30,45,60,72,85,90,75,60,40];
      return { success: true, analytics: {
        placement_trend: months.map((m,i) => ({ month: m, placed: placed[i], registered: registered[i] })),
        branch_stats: [
          { branch:'CSE', count:42, placed:38 },
          { branch:'IT', count:28, placed:22 },
          { branch:'ECE', count:20, placed:14 },
          { branch:'EEE', count:15, placed:9 },
          { branch:'Mech', count:12, placed:6 },
        ],
        avg_cgpa: 7.8,
        avg_salary: '12.4 LPA',
        top_companies: ['Google','Amazon','Infosys','TCS','Wipro'],
      }};
    }
    return { success: true };
  },

  // ── STREAK ──────────────────────────────────────────────────
  'streak.php': async (params, body) => {
    await delay(200);
    const uid = parseInt((params || {}).user_id || (body || {}).user_id);
    const action = (params || {}).action || (body || {}).action || 'get';
    let streak = DB.findOne('streak_data', s => s.user_id == uid);
    if (!streak) {
      streak = { user_id: uid, current_streak: 0, longest_streak: 0, total_xp: 0, last_checkin: null, badges: [], level: 1, level_progress: 0 };
      DB.get('streak_data').push(streak);
      DB.set('streak_data', DB.get('streak_data'));
    }
    if (action === 'get') {
      const today = new Date().toISOString().split('T')[0];
      const can_checkin = streak.last_checkin !== today;
      return { success: true, ...streak, can_checkin, daily_challenges: [
        { id:1, title:'Complete an aptitude test', xp:50, done: false },
        { id:2, title:'Practice mock interview', xp:75, done: false },
        { id:3, title:'Update your profile', xp:30, done: false },
      ]};
    }
    if (action === 'checkin') {
      const today = new Date().toISOString().split('T')[0];
      if (streak.last_checkin === today) return { success: false, message: 'Already checked in today' };
      const yesterday = new Date(Date.now()-86400000).toISOString().split('T')[0];
      const newStreak = streak.last_checkin === yesterday ? streak.current_streak + 1 : 1;
      const xp = streak.total_xp + 50;
      const updated = { ...streak, current_streak: newStreak, longest_streak: Math.max(streak.longest_streak, newStreak), total_xp: xp, last_checkin: today, level: Math.floor(xp / 500) + 1, level_progress: (xp % 500) / 5 };
      DB.upsert('streak_data', 'user_id', uid, updated);
      return { success: true, xp_gained: 50, new_streak: newStreak, total_xp: xp, ...updated };
    }
    if (action === 'solve_problem') {
      const xp = streak.total_xp + (parseInt((body||{}).xp) || 75);
      const updated = { ...streak, total_xp: xp, level: Math.floor(xp / 500) + 1, level_progress: (xp % 500) / 5 };
      DB.upsert('streak_data', 'user_id', uid, updated);
      return { success: true, xp_gained: parseInt((body||{}).xp) || 75, total_xp: xp };
    }
    return { success: true, ...streak };
  },

  // ── APTITUDE ─────────────────────────────────────────────────
  'aptitude_save.php': async (body) => {
    await delay(300);
    const uid = parseInt(body.user_id);
    const score = parseFloat(body.score) || 0;
    DB.insert('aptitude_results', { user_id: uid, score, tab_warnings: body.tab_warnings || 0, taken_at: new Date().toISOString() });
    DB.upsert('student_profiles', 'user_id', uid, { aptitude_score: score });
    return { success: true, score, message: 'Score saved!' };
  },

  // ── LEADERBOARD ──────────────────────────────────────────────
  'leaderboard.php': async (params) => {
    await delay(250);
    const uid = parseInt(params.user_id);
    const users = DB.get('users').filter(u => u.role === 'student');
    const profiles = DB.get('student_profiles');
    const streaks = DB.get('streak_data');
    let board = users.map(u => {
      const p = profiles.find(p => p.user_id == u.id) || {};
      const s = streaks.find(s => s.user_id == u.id) || { total_xp: 0, current_streak: 0 };
      const score = Math.round(
        (parseFloat(p.cgpa)||0) * 5 +
        (parseFloat(p.aptitude_score)||0) * 0.4 +
        (parseFloat(p.resume_score)||0) * 0.2 +
        (parseFloat(p.interview_score)||0) * 0.2 +
        (s.total_xp||0) * 0.01
      );
      return { id: u.id, name: u.name, branch: p.branch || 'Unknown', cgpa: p.cgpa, aptitude_score: p.aptitude_score, interview_score: p.interview_score, total_xp: s.total_xp, streak: s.current_streak, placement_score: score };
    }).sort((a, b) => b.placement_score - a.placement_score)
      .map((r, i) => ({ ...r, rank: i + 1 }));
    const me = board.find(r => r.id == uid);
    const branch = params.branch;
    if (branch && branch !== 'all') board = board.filter(r => r.branch === branch);
    return { success: true, leaderboard: board.slice(0, 50), my_rank: me?.rank || null, total: board.length };
  },

  // ── PREDICT ──────────────────────────────────────────────────
  'predict.php': async (body) => {
    await delay(600);
    const cgpa = parseFloat(body.cgpa) || 0;
    const apt = parseFloat(body.aptitude_score) || 0;
    const comm = parseFloat(body.communication_rating) || 5;
    const internships = parseInt(body.internships) || 0;
    const projects = parseInt(body.projects) || 0;
    const skillsList = (body.skills || '').split(',').filter(Boolean);

    let prob = 0;
    prob += Math.min(cgpa * 8, 35);
    prob += Math.min(apt * 0.25, 20);
    prob += Math.min(comm * 2, 15);
    prob += Math.min(internships * 8, 15);
    prob += Math.min(projects * 3, 10);
    prob += Math.min(skillsList.length * 1.5, 15);
    prob = Math.min(Math.round(prob), 97);

    const tier = prob >= 80 ? 'Excellent' : prob >= 60 ? 'Good' : prob >= 40 ? 'Fair' : 'Needs Work';
    const tips = [];
    if (cgpa < 7.5) tips.push('Improve CGPA — target 7.5+ for top companies');
    if (apt < 75) tips.push('Practice aptitude tests — aim for 80+ score');
    if (internships === 0) tips.push('Get at least one internship to boost chances significantly');
    if (projects < 3) tips.push('Add 2-3 portfolio projects relevant to your target role');
    if (skillsList.length < 5) tips.push('Expand technical skills — learn in-demand tools');
    if (comm < 7) tips.push('Work on communication skills — they matter for HR rounds');

    return { success: true, probability: prob, tier, confidence: 0.82, tips,
      breakdown: { cgpa_score: Math.round(cgpa*8), aptitude_score: Math.round(apt*0.25), communication: Math.round(comm*2), experience: Math.round(internships*8), projects: Math.round(projects*3), skills: Math.round(skillsList.length*1.5) }
    };
  },

  // ── RESUME ANALYZE ───────────────────────────────────────────
  'resume_analyze.php': async (body) => {
    await delay(1200);
    const uid = parseInt(body.user_id || 0);
    // Simulate analysis
    const score = 65 + Math.floor(Math.random() * 25);
    const ats = score + Math.floor(Math.random() * 10) - 5;
    if (uid) {
      DB.upsert('student_profiles', 'user_id', uid, { resume_score: score, ats_score: Math.min(100, ats) });
    }
    return { success: true,
      score, ats_score: Math.min(100, ats),
      feedback: `**Overall Score: ${score}/100**\n\n**Strengths:**\n- Good structure and formatting\n- Technical skills clearly listed\n- Quantified achievements included\n\n**Improvements Needed:**\n- Add more action verbs (e.g., "Built", "Optimized", "Led")\n- Include links to GitHub/portfolio\n- Tailor skills section to job descriptions\n- Add a brief professional summary at top\n\n**ATS Compatibility: ${ats}%**\n- Use standard section headers\n- Avoid tables and graphics\n- Include keywords from job descriptions`,
      keywords: ['Python','SQL','JavaScript','REST API','Git','Agile'],
      missing_keywords: ['Docker','Kubernetes','Cloud','CI/CD'],
    };
  },

  // ── CHATBOT (Aptitude, Resume Builder) ───────────────────────
  'chatbot.php': async (body) => {
    await delay(800);
    const type = body.type || 'general';

    if (type === 'aptitude_explain') {
      const q = body.question || '';
      return { success: true, answer: `**Explanation:**\n\nFor this problem, here's the step-by-step approach:\n\n1. **Identify** the key values in the question\n2. **Apply** the relevant formula or logical rule\n3. **Calculate** systematically, avoiding shortcuts\n4. **Verify** your answer with a quick sanity check\n\nThe correct answer is **${body.correct_answer || 'C'}** because this approach gives the optimal solution. Practice similar problems to build intuition.` };
    }

    if (type === 'resume_section') {
      const section = body.section || 'summary';
      const responses = {
        summary: `**Professional Summary:**\n\nResults-driven software engineer with 2+ years of academic experience building scalable web applications. Proficient in Python, Java, and cloud technologies. Passionate about solving complex problems and delivering high-quality solutions. Seeking a challenging role to apply technical skills and grow professionally.`,
        experience: `**Work Experience Entry:**\n\n**Software Development Intern** | TechCorp | May 2024 – Aug 2024\n- Developed RESTful APIs serving 10K+ requests/day using Node.js and Express\n- Reduced page load time by 40% through database query optimization\n- Collaborated with 5-person team using Agile/Scrum methodology\n- Implemented automated testing suite covering 85% code coverage`,
        skills: `**Technical Skills Section:**\n\n**Languages:** Python, Java, JavaScript, C++, SQL\n**Frameworks:** React, Node.js, Spring Boot, Django\n**Databases:** MySQL, PostgreSQL, MongoDB, Redis\n**Tools:** Git, Docker, Jenkins, AWS, Linux\n**Concepts:** Data Structures, Algorithms, System Design, REST APIs`,
        education: `**Education Entry:**\n\n**B.Tech in Computer Science & Engineering**\nUniversity Name | 2021 – 2025 | CGPA: 8.5/10\n\n*Relevant Coursework:* Data Structures, Algorithms, DBMS, OS, CN, Software Engineering\n*Achievements:* Department rank 3, Hackathon winner 2023`,
      };
      return { success: true, content: responses[section] || responses.summary };
    }

    return { success: true, answer: `That's a great question! Here's what I can tell you:\n\n${body.message || 'Based on your query'}, the key points to remember are:\n\n1. Focus on fundamentals first\n2. Practice consistently with real problems\n3. Time management is crucial in aptitude tests\n4. Review your mistakes to avoid repeating them\n\nWould you like me to elaborate on any specific aspect?` };
  },

  // ── ROADMAP ──────────────────────────────────────────────────
  'roadmap.php': async (body) => {
    await delay(800);
    const focus = body.focus || 'Full Stack Development';
    return { success: true, roadmap: [
      { week:'Week 1-2', title:'DSA Foundations', tasks:['Arrays & Strings — master sliding window, two-pointer patterns','Linked Lists — insertion, deletion, reversal, cycle detection','Stacks & Queues — monotonic stacks, queue applications','Practice: 2 LeetCode Easy problems daily (minimum)'], resources:'LeetCode, GeeksforGeeks, CS50' },
      { week:'Week 3-4', title:'Core Algorithms', tasks:['Trees & Graphs — BFS, DFS, shortest path (Dijkstra)','Dynamic Programming — top-down vs bottom-up, common patterns','Sorting & Searching — merge sort, quicksort, binary search','Practice: 1 Medium + 1 Easy problem daily'], resources:'Striver A-Z DSA Sheet, NeetCode 150' },
      { week:'Week 5-6', title:`${focus} Deep-Dive`, tasks:[`Master core frameworks for ${focus}`,'Build 2 portfolio projects to demonstrate skills','Contribute to 1 open-source GitHub repository','Write technical blog post documenting a project'], resources:'Official documentation, YouTube tutorials' },
      { week:'Week 7', title:'Interview Simulation', tasks:['Complete 5+ AI Mock Interviews (use PlacementAI tool)','Prepare 10+ behavioral answers using STAR method','ATS-optimize resume using PlacementAI Resume Analyzer','Research top 5 target companies in depth'], resources:'PlacementAI Interview Tool, Glassdoor' },
      { week:'Week 8', title:'Final Sprint', tasks:['Company-specific problem sets (filter by company on LeetCode)','Weak areas revision — focus on topics scoring below 70%','Mock HR + Technical rounds with friends or mentors','Mindset prep: confidence building, interview day logistics'], resources:'Blind 75, Company-tagged problems' },
    ]};
  },

  // ── MOCK INTERVIEW ───────────────────────────────────────────
  'mock_interview.php': async (body) => {
    await delay(1200);
    const action = body.action || 'start';
    const company = body.company || 'TCS';
    const role = body.role || 'Software Engineer';
    const round = body.round || 'Technical';

    const questionBank = {
      Technical: [
        `Explain the difference between a stack and a queue with real-world examples.`,
        `What is time complexity? Explain with an example of O(n²) vs O(n log n).`,
        `How does a HashMap work internally? What happens during hash collision?`,
        `Write a function to check if a string is a palindrome.`,
        `Explain polymorphism in OOP with a practical example.`,
        `What is the difference between SQL and NoSQL databases?`,
        `Describe the MVC architecture pattern and its benefits.`,
        `How would you optimize a slow database query?`,
      ],
      HR: [
        `Tell me about yourself and your background.`,
        `Why do you want to join ${company}?`,
        `Describe a challenging project and how you handled it.`,
        `Where do you see yourself in 5 years?`,
        `What are your greatest strengths and areas of improvement?`,
        `Tell me about a time you worked in a team and faced conflict.`,
        `How do you handle tight deadlines and pressure?`,
      ],
      'System Design': [
        `Design a URL shortening service like bit.ly.`,
        `How would you design a real-time notification system?`,
        `Design a scalable file storage system like Dropbox.`,
        `How would you architect a chat application for millions of users?`,
        `Design a recommendation system for an e-commerce platform.`,
      ],
    };

    const questions = questionBank[round] || questionBank['Technical'];

    if (action === 'start') {
      return { success: true, session_id: 'sess_' + Date.now(),
        reply: `**Welcome to your ${round} interview at ${company}!**\n\nI'll ask you ${5} questions to assess your ${role} readiness. Take your time and think aloud.\n\n**Question 1 of 5:**\n${questions[0]}`,
        max_questions: 5,
        company, role, round };
    }

    if (action === 'answer' || action === 'next') {
      const answer = body.message || body.answer || '';
      const qNum = (body.history || []).filter(m => m.role === 'user').length;
      const score = answer.length > 50 ? 6 + Math.floor(Math.random() * 4) : 3 + Math.floor(Math.random() * 3);

      const feedbackPhrases = score >= 8
        ? ['Excellent answer!', 'Outstanding response!', 'Very well articulated!']
        : score >= 6
        ? ['Good attempt!', 'Solid understanding!', 'Nice work!']
        : ['Needs more depth.', 'Try to elaborate more.', 'Good start, expand on it.'];
      const fb = feedbackPhrases[Math.floor(Math.random() * feedbackPhrases.length)];

      if (action === 'next' || qNum === 0) {
        return { success: true, reply: `**Question ${Math.min(qNum+1,5)} of 5:**\n${questions[qNum % questions.length]}` };
      }

      if (qNum >= 5) {
        const finalScore = 65 + Math.floor(Math.random() * 25);
        return { success: true, done: true, score: finalScore,
          reply: `**${fb}** Score: ${score}/10\n\n**Final Assessment — Interview Complete!**\n\nOverall Score: **${finalScore}/100**\n\nYou demonstrated solid understanding of ${round} concepts. Key areas to improve: practice more edge cases, structure answers using STAR method, and elaborate on trade-offs.\n\n**Final Assessment complete.**` };
      }

      return { success: true, score,
        reply: `**${fb}** Score: ${score}/10\n\n${score >= 7 ? '✅' : score >= 5 ? '👍' : '💡'} ${score >= 7 ? 'You covered the key points well. Good use of examples.' : score >= 5 ? 'You got the concept right. Add more technical depth next time.' : 'The answer was brief. Explain the concept fully with an example.'}\n\n**Question ${Math.min(qNum+1,5)} of 5:**\n${questions[qNum % questions.length]}` };
    }

    return { success: true };
  },

  // ── INTERVIEW SCHEDULE ───────────────────────────────────────
  'interview_schedule.php': async (body) => {
    await delay(300);
    const action = body.action;
    const uid = parseInt(body.user_id);

    if (action === 'schedule') {
      const schedule = DB.insert('interview_schedules', { org_user_id: uid, application_id: body.application_id, datetime: body.datetime, notes: body.notes || '', status: 'scheduled', created_at: new Date().toISOString() });
      DB.update('applications', body.application_id, { status: 'interview_scheduled' });
      return { success: true, schedule };
    }
    if (action === 'org_list') {
      const org = DB.findOne('orgs', o => o.user_id == uid);
      if (!org) return { success: true, schedules: [] };
      const jobIds = DB.find('jobs', j => j.org_id == org.id).map(j => j.id);
      const apps = DB.find('applications', a => jobIds.includes(a.job_id) && a.status === 'interview_scheduled');
      const users = DB.get('users');
      const schedules_data = DB.get('interview_schedules');
      return { success: true, schedules: apps.map(app => {
        const u = users.find(u => u.id == app.student_id) || {};
        const sched = schedules_data.find(s => s.application_id == app.id) || {};
        const job = DB.findOne('jobs', j => j.id == app.job_id) || {};
        return { app_id: app.id, student_name: u.name, student_email: u.email, job_title: job.title, datetime: sched.datetime, notes: sched.notes, status: sched.status };
      })};
    }
    return { success: true };
  },

  // ── NOTIFICATIONS ────────────────────────────────────────────
  'notifications.php': async (params, body) => {
    await delay(150);
    const action = (params || {}).action || (body || {}).action;
    const uid = parseInt((params || {}).user_id || (body || {}).user_id);
    if (action === 'unread_count') {
      const notifs = DB.find('notifications', n => n.user_id == uid && !n.is_read);
      return { success: true, count: notifs.length };
    }
    if (action === 'list') {
      const notifs = DB.find('notifications', n => n.user_id == uid).sort((a,b) => b.id - a.id).slice(0, 20);
      return { success: true, notifications: notifs, unread: notifs.filter(n => !n.is_read).length };
    }
    if (action === 'mark_read') {
      const notifs = DB.get('notifications').map(n => n.user_id == uid ? { ...n, is_read: 1 } : n);
      DB.set('notifications', notifs);
      return { success: true };
    }
    return { success: true };
  },

  // ── PHOTO UPLOAD ─────────────────────────────────────────────
  'photo_upload.php': async (body) => {
    await delay(300);
    return { success: true, message: 'Photo uploaded (demo mode)', url: '' };
  },

  // ── BULK IMPORT ──────────────────────────────────────────────
  'bulk_import.php': async (body) => {
    await delay(500);
    return { success: true, imported: 0, message: 'Bulk import simulated in demo mode' };
  },

  'benchmarks.php': async (params) => {
    await delay(200);
    return { success: true, benchmarks: { avg_cgpa: 7.8, avg_aptitude: 72, avg_resume_score: 68, avg_interview_score: 71 } };
  },
};

// ── URL parser for GET params ──────────────────────────────
function parseEndpoint(ep) {
  const [path, qs] = ep.split('?');
  const params = {};
  if (qs) qs.split('&').forEach(p => { const [k,v] = p.split('='); params[decodeURIComponent(k)] = decodeURIComponent(v||''); });
  return { path, params };
}

// ── Intercept the global API object ──────────────────────────
(function interceptAPI() {
  // Override API methods to use mock
  const origCall = API.call.bind(API);

  API.call = async function(ep, opts = {}) {
    const { path, params } = parseEndpoint(ep);
    const handler = MOCK_HANDLERS[path];
    if (!handler) {
      console.warn('[MockAPI] No handler for:', path, '— returning empty success');
      return { success: true };
    }
    let body = {};
    if (opts.body) {
      try { body = JSON.parse(opts.body); } catch {}
    }
    try {
      const result = await handler(params, body);
      return result;
    } catch (err) {
      throw new Error(err.message || 'Mock API error');
    }
  };

  // Override get/post for cleanliness
  API.get = function(ep) {
    const { path, params } = parseEndpoint(ep);
    const handler = MOCK_HANDLERS[path];
    if (!handler) return Promise.resolve({ success: true });
    return handler(params, {}).catch(e => { throw new Error(e.message); });
  };

  API.post = function(ep, data) {
    const { path, params } = parseEndpoint(ep);
    const handler = MOCK_HANDLERS[path];
    if (!handler) return Promise.resolve({ success: true });
    return handler(params, data || {}).catch(e => { throw new Error(e.message); });
  };

  API.postForm = function(ep, fd) {
    // Convert FormData to object for mock
    const data = {};
    if (fd && fd.forEach) fd.forEach((v, k) => { data[k] = v; });
    return API.post(ep, data);
  };

  console.log('[PlacementAI] 🚀 Mock API loaded — all PHP calls intercepted');
})();

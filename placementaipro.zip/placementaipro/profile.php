<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">  <link rel="icon" type="image/svg+xml" href="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAzMiAzMiIgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIj4KICA8ZGVmcz4KICAgIDxsaW5lYXJHcmFkaWVudCBpZD0iZyIgeDE9IjAiIHkxPSIxIiB4Mj0iMSIgeTI9IjAiPgogICAgICA8c3RvcCBvZmZzZXQ9IjAlIiBzdG9wLWNvbG9yPSIjZmY0NzU3Ii8+CiAgICAgIDxzdG9wIG9mZnNldD0iMTAwJSIgc3RvcC1jb2xvcj0iI2Y1OWUwYiIvPgogICAgPC9saW5lYXJHcmFkaWVudD4KICA8L2RlZnM+CiAgPHJlY3Qgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIiByeD0iNyIgZmlsbD0iIzFlMWExMCIvPgogIDxyZWN0IHg9IjYiIHk9IjIxIiB3aWR0aD0iNSIgaGVpZ2h0PSI5IiByeD0iMS41IiBmaWxsPSIjZjU5ZTBiIiBvcGFjaXR5PSIuNSIvPgogIDxyZWN0IHg9IjEzIiB5PSIxNSIgd2lkdGg9IjUiIGhlaWdodD0iMTUiIHJ4PSIxLjUiIGZpbGw9IiNmZjZiMzUiIG9wYWNpdHk9Ii43NSIvPgogIDxyZWN0IHg9IjIwIiB5PSI4IiB3aWR0aD0iNSIgaGVpZ2h0PSIyMiIgcng9IjEuNSIgZmlsbD0idXJsKCNnKSIvPgogIDxwb2x5bGluZSBwb2ludHM9IjIzLDQgMjcsOCAyNyw1IiBmaWxsPSJub25lIiBzdHJva2U9InVybCgjZykiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIi8+CiAgPGxpbmUgeDE9IjE5IiB5MT0iNSIgeDI9IjI3IiB5Mj0iNCIgc3Ryb2tlPSJ1cmwoI2cpIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPgo8L3N2Zz4=">
  <link rel="icon" type="image/x-icon" href="data:image/x-icon;base64,AAABAAEAEBAAAAAAIACgAAAAFgAAAIlQTkcNChoKAAAADUlIRFIAAAAQAAAAEAgGAAAAH/P/YQAAAGdJREFUeJxjZIACLg6R/wwkgG8/3jAyMDAwMJGjGVkPIzmakQETJZoZGBgYWNAFvn5/jVMxN6co9V1AWwOwOZkkA/CFB1EGEAOoH43IgOIwIAZQnpRhuYoc8O3HG0YmGIMczQwMDAwA+P4aS3/n/2IAAAAASUVORK5CYII=">
  <link rel="icon" type="image/png" sizes="32x32" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAoElEQVR4nO2XvQ6AIAyES+Pgz6rv/4Cyimw6kWhDxID0HLixabyPozHUUERjPx+xeqmct0bWboVaxk8grG0uvVjbXEJwqrG2DOL0V8ET6FIN275mfXgalld98AQaABwgOYQxyQHLHVSiHyTQALJmoOTOpeAJNAA4wCc/ohLBE2gAcAD8ozS2LmnJeWvgV8CBRNs4eLIsaJoTie04SHM9PwGQNi1E3UY9bQAAAABJRU5ErkJggg==">
  <link rel="icon" type="image/png" sizes="192x192" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMAAAADACAYAAABS3GwHAAADvklEQVR4nO3dQVLjVgBFUZvqASFTsv8FhmkIMzJIdRc0YCxL8pd8z1kAaPCuvmy61MfDxjzcP76OvgbW8/zydBx9DW8NvRhj53AYG8XVf7HRc8q1Y7jaLzN8prhWCKv/EsNnjrVDWO2HGz5LWiuExX+o4bOmpUO4W/KHGT9rW3pji9Rk+IywxGkw+wQwfkZZYnuzAjB+Rpu7wYsDMH62Ys4WLwrA+NmaSzc5OQDjZ6su2eakAIyfrZu60bMDMH72YspWzwrA+Nmbczf7bQDGz16ds91F/ykE7M3JANz92bvvNvxlAMbPrTi1ZY9ApH0agLs/t+arTTsBSPsQgLs/t+qzbTsBSHsXgLs/t+73jTsBSPsVgLs/FW+37gQgTQCk3R0OHn/o+bl5JwBpAiBNAKQJgLSjD8CUOQFIEwBpAiBNAKQJgDQBkPZj9AXM9c+/f4++hF3584+/Rl/CpjgBSBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYC03b8VYi0j356w1psuvBHiIycAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANKOD/ePr6MvYo61XiV+q7wi/T0nAGkCIE0ApAmANAGQJgDSBECaAEgTAGkCIE0ApAmANAGQJgDSBECaAEgTAGkCIE0ApAmANAGQ9mP0BWyVtyc0OAFIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0o4P94+voy8CRnECkCYA0gRAmgBIEwBpd88vT8fRFwEjPL88HZ0ApAmANAGQJgDS7g6H/z8MjL4QuKafm3cCkCYA0n4F4DGIirdbdwKQ9i4ApwC37veNOwFI+xCAU4Bb9dm2nQCkfRqAU4Bb89WmnQCkfRmAU4BbcWrLJ08AEbB3323YIxBp3wbgFGCvztnuWSeACNibczd79iOQCNiLKVud9BlABGzd1I1O/hAsArbqkm1e9C2QCNiaSzd58degImAr5mxx1t8BRMBoczc4+w9hImCUJba36Hj9bzNcw5I33UX/KYTTgLUtvbHVBus0YElr3VxXv2MLgTnWfqq42iOLEJjiWo/TV39mFwKnXPtz5NAPrWLgcBj75cnmvrURxW3b2jeF/wGOq9fsu4f8UQAAAABJRU5ErkJggg==">
  <link rel="apple-touch-icon" sizes="180x180" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAAC0CAYAAAA9zQYyAAADX0lEQVR4nO3cOXJaQQBFUVA58JDa+1+glVpWZgceygOS/kh/rs5ZAOrg8tRAwfl0AO/ffvw2+gys9/B4fx59hiEHEPDrMCLwq/1BEb9u14p71z8iYi7ZM+5dHljITLFH2HdbP6CYmWqPVjZ7hgiZNbZa600WWsystVVDq54VQmYPa9Z68UKLmb2saWtR0GJmb0sbmx20mLmWJa3NClrMXNvc5iYHLWZGmdPepKDFzGhTG3wxaDFzFFNa3Pyjbxjp2aCtM0fzUpNPBi1mjuq5Nl05SLkYtHXm6J5q9L+gxcytuNSqKwcpfwVtnbk1/zZroUkRNCm/g3bd4Fb92a6FJkXQpNydTq4b3L5fDVtoUgRNiqBJObs/U2KhSRE0KYImRdCkCJoUQZPyZvQBlvjy9fPoIxzWh3efRh9hKAtNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiblJr8ku4cRXy71Zd/tWWhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCl+rPEnP5zYYKFJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KT4kuxPH959Gn0ENmChSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJqU8/u3H7+NPgRsxUKTImhSBE2KoEkRNCl3D4/359GHgC08PN6fLTQpgiZF0KTcnU4/7h6jDwJr/GrYQpMiaFJ+B+3awa36s10LTYqgSfkraNcObs2/zVpoUv4L2kpzKy61enGhRc3RPdWoKwcpTwZtpTmq59p8dqFFzdG81KQrBykvBm2lOYopLU5aaFEz2tQGJ185RM0oc9qbdYcWNdc2t7nZLwpFzbUsaW3RuxyiZm9LG1v8tp2o2cuatjaJ0k/ysoUtRnKTD1asNWtt1dDmIVpr5th6DDf/6NtaM9Uerewan7Xmkj1H72prKu7X7Vr/uYdcD8T9Ooy4fh7ivivwhiO8fvoO2onGYhMioSEAAAAASUVORK5CYII=">
  <title>Profile — PlacementAI Pro</title>
  <link rel="stylesheet" href="css/style.css?v=5">
  <style>
  @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@500;600;700&family=DM+Sans:wght@400;500;600&display=swap');

  /* Avatar: gold ring */
  .grid-2 > div:first-child > .card:first-child {
    background: var(--surface) !important;
    border: 1px solid var(--border) !important;
    border-radius: 20px !important;
    position: relative; overflow: hidden;
  }
  .grid-2 > div:first-child > .card:first-child::before {
    content: '';
    position: absolute; top: 0; left: 0; right: 0; height: 120px;
    background: linear-gradient(180deg, rgba(245,158,11,.06) 0%, transparent 100%);
    pointer-events: none;
  }

  /* Edit Profile card */
  .grid-2 > div:first-child > .card:nth-child(2) {
    background: var(--surface) !important; border: 1px solid var(--border) !important; border-radius: 20px !important;
  }

  /* Form labels */
  .grid-2 > div:first-child .form-label {
    font-family: 'DM Sans', sans-serif !important;
    font-size: 11px !important; letter-spacing: .08em !important; text-transform: uppercase !important;
    color: var(--text3) !important; font-weight: 600 !important;
  }

  /* Form inputs */
  .grid-2 > div:first-child .form-input,
  .grid-2 > div:first-child .form-select {
    background: var(--bg2) !important; border: 1px solid var(--border) !important;
    border-radius: 10px !important; font-family: 'DM Sans', sans-serif !important;
    font-size: 14px !important; transition: all .18s !important;
  }
  .grid-2 > div:first-child .form-input:focus,
  .grid-2 > div:first-child .form-select:focus {
    border-color: #f59e0b !important; box-shadow: 0 0 0 3px rgba(245,158,11,.1) !important;
  }

  /* Save button: gold */
  #saveBtn {
    background: linear-gradient(135deg, #92400e, #d97706) !important;
    border: none !important; border-radius: 10px !important;
    font-family: 'DM Sans', sans-serif !important; font-weight: 600 !important;
    box-shadow: 0 4px 20px rgba(245,158,11,.25) !important; transition: all .2s !important;
  }
  #saveBtn:hover {
    background: linear-gradient(135deg, #b45309, #f59e0b) !important;
    box-shadow: 0 6px 28px rgba(245,158,11,.4) !important; transform: translateY(-1px) !important;
  }

  /* Completeness bar: gold */
  #complBar {
    background: linear-gradient(90deg, #92400e, #d97706, #f59e0b, #fcd34d) !important;
    box-shadow: 0 0 12px rgba(245,158,11,.25);
  }

  /* Applications panel */
  .grid-2 > div:last-child > .card {
    background: var(--surface) !important; border: 1px solid var(--border) !important; border-radius: 20px !important;
  }

  /* Page header */
  .page-header h1 {
    font-family: 'Cormorant Garamond', Georgia, serif !important;
    font-size: 2rem !important; font-weight: 700 !important;
  }

  /* Badge tweaks */
  .badge-cyan { background: rgba(245,158,11,.12) !important; color: #f59e0b !important; border: 1px solid rgba(245,158,11,.25) !important; }
  .badge-green { background: rgba(16,185,129,.12) !important; color: var(--emerald) !important; border: 1px solid rgba(16,185,129,.25) !important; font-weight: 700 !important; }
</style>
</head>
<body>
<script src="js/app.js?v=5"></script>
<script>
const user = Auth.requireAuth('student');
if (user) { buildShell('profile'); setTimeout(()=>initProfile(), 0); }

async function initProfile() {
  document.getElementById('topbarTitle').textContent = 'My Profile';
  const page = document.getElementById('mainPage');
  page.innerHTML = `<div class="loading-center"><div class="spinner"></div></div>`;

  let profile = null;
  try { const p = await API.get(`student_profile.php?user_id=${user.id}`); profile = p.profile; } catch(e){}
  setTimeout(() => {
    const chk = [profile?.branch, profile?.cgpa, profile?.skills, profile?.github_url, profile?.linkedin_url, profile?.aptitude_score, profile?.interview_score, profile?.resume_score];
    const pct = Math.round((chk.filter(Boolean).length / chk.length) * 100);
    const bar = document.getElementById('complBar'), el = document.getElementById('complPct');
    if (bar) bar.style.width = pct + '%';
    if (el) { el.textContent = pct + '%'; el.style.color = pct >= 80 ? 'var(--emerald)' : pct >= 50 ? 'var(--accent2)' : 'var(--primary)'; }
  }, 300);

  page.innerHTML = `
    <div class="page-header">
      <h1 style="font-size:1.6rem">My Profile</h1>
      <p style="color:var(--text3);font-size:13px;margin-top:2px">Complete your profile to unlock better AI analysis, job matching & higher leaderboard score</p>
    </div>
    <div class="grid-2" style="align-items:start">
      <div>
        <div class="card mb-4">
          <div class="card-header">
            <div><div class="card-title">Basic Information</div></div>
          </div>
          <div style="display:flex;align-items:center;gap:14px;margin-bottom:20px">
            <div style="width:72px;height:72px;background:var(--primary-g);border-radius:18px;display:flex;align-items:center;justify-content:center;font-family:var(--font-display);font-size:1.6rem;font-weight:800;color:#fff;box-shadow:0 4px 16px rgba(108,99,255,.3)">${(user.name||'U').split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase()}</div>
            <div>
              <div style="font-family:var(--font-display);font-size:1.1rem;font-weight:700;color:var(--text)">${esc(user.name)}</div>
              <div style="font-size:13px;color:var(--text3)">${esc(user.email)}</div>
              <span class="badge badge-cyan mt-1">${esc(profile?.branch||'Student')}</span>
            </div>
          </div>
          <div style="margin-top:14px">
            <div style="display:flex;justify-content:space-between;margin-bottom:4px">
              <span style="font-size:11px;color:var(--text3);font-weight:700;text-transform:uppercase;letter-spacing:.07em">Profile completeness</span>
              <span id="complPct" style="font-size:11.5px;font-weight:700;color:var(--primary)">0%</span>
            </div>
            <div style="height:5px;background:var(--bg3);border-radius:99px;overflow:hidden"><div id="complBar" style="height:100%;width:0%;background:linear-gradient(90deg,var(--primary),var(--accent));border-radius:99px;transition:width .6s ease"></div></div>
          </div>
        </div>

        <div class="card mb-4">
          <div class="card-header"><div class="card-title">Edit Profile</div></div>
          <div id="alertBox"></div>
          <form id="profileForm" novalidate>
            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Branch</label>
                <select id="branch" class="form-select">
                  ${['Computer Science','Information Technology','Electronics','Mechanical','Civil','Chemical','Other'].map(b=>`<option ${profile?.branch===b?'selected':''}>${b}</option>`).join('')}
                </select>
              </div>
              <div class="form-group">
                <label class="form-label">CGPA (out of 10)</label>
                <input type="number" id="cgpa" class="form-input" value="${profile?.cgpa||''}" min="0" max="10" step="0.01" placeholder="8.5">
              </div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Projects Count</label>
                <input type="number" id="projects" class="form-input" value="${profile?.projects||0}" min="0">
              </div>
              <div class="form-group">
                <label class="form-label">Internships</label>
                <input type="number" id="internships" class="form-input" value="${profile?.internships||0}" min="0">
              </div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Aptitude Score (%)</label>
                <input type="number" id="aptitude_score" class="form-input" value="${profile?.aptitude_score||''}" min="0" max="100" step="0.1" placeholder="e.g. 75">
              </div>
              <div class="form-group">
                <label class="form-label">Communication (1-10)</label>
                <input type="number" id="communication_rating" class="form-input" value="${profile?.communication_rating||5}" min="1" max="10" step="0.5">
              </div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Interview Score (0-100)</label>
                <input type="number" id="interview_score" class="form-input" value="${profile?.interview_score||''}" min="0" max="100" step="1" placeholder="Do AI Interview to get score">
              </div>
              <div class="form-group">
                <label class="form-label">Resume Score (0-100)</label>
                <input type="number" id="resume_score" class="form-input" value="${profile?.resume_score||''}" min="0" max="100" step="1" placeholder="Analyze resume to get score">
              </div>
            </div>
            <div class="form-group">
              <label class="form-label">Skills (comma separated)</label>
              <input type="text" id="skills" class="form-input" value="${esc(profile?.skills||'')}" placeholder="Python, React, SQL, AWS, Docker…">
            </div>
            <div class="form-row">
              <div class="form-group">
                <label class="form-label">GitHub URL</label>
                <input type="url" id="github_url" class="form-input" value="${esc(profile?.github_url||'')}" placeholder="https://github.com/username">
              </div>
              <div class="form-group">
                <label class="form-label">LinkedIn URL</label>
                <input type="url" id="linkedin_url" class="form-input" value="${esc(profile?.linkedin_url||'')}" placeholder="https://linkedin.com/in/username">
              </div>
            </div>
            <button type="submit" id="saveBtn" class="btn btn-primary w-full">Save Profile</button>
          </form>
        </div>
      </div>

      <!-- My Applications -->
      <div class="card" style="position:sticky;top:72px">
        <div class="card-header"><div class="card-title">My Applications</div></div>
        <div id="applications"><div class="loading-center" style="padding:24px"><div class="spinner"></div></div></div>
      </div>
    </div>`;

  document.getElementById('profileForm').addEventListener('submit', async e=>{
    e.preventDefault();
    const btn = document.getElementById('saveBtn');
    loading(btn, true, 'Saving…');
    clearAlert(document.getElementById('alertBox'));
    try {
      const res = await API.post('student_profile_save.php', {
        user_id:user.id,
        branch:document.getElementById('branch').value,
        cgpa:parseFloat(document.getElementById('cgpa').value)||0,
        skills:document.getElementById('skills').value,
        projects:parseInt(document.getElementById('projects').value)||0,
        internships:parseInt(document.getElementById('internships').value)||0,
        aptitude_score:parseFloat(document.getElementById('aptitude_score').value)||0,
        communication_rating:parseFloat(document.getElementById('communication_rating').value)||5,
        interview_score:parseFloat(document.getElementById('interview_score').value)||0,
        resume_score:parseFloat(document.getElementById('resume_score').value)||0,
        github_url:document.getElementById('github_url').value,
        linkedin_url:document.getElementById('linkedin_url').value
      });
      loading(btn, false);
      // Update branch badge live using the saved profile returned from server
      if (res.profile) {
        const branchBadge = document.querySelector('.badge-cyan');
        if (branchBadge) branchBadge.textContent = res.profile.branch || 'Student';
      }
      showAlert(document.getElementById('alertBox'),
        'Profile saved! <a href="dashboard.php" style="color:inherit;font-weight:700;text-decoration:underline">View on Dashboard \u2192</a>',
        'success', true);
    } catch(err) {
      loading(btn, false);
      showAlert(document.getElementById('alertBox'), err.message);
    }
  });

  // Load applications
  try {
    const apps = await API.get(`jobs.php?action=my_applications&user_id=${user.id}`);
    const list = apps.applications||[];
    document.getElementById('applications').innerHTML = list.length ?
      list.map(a=>`<div style="padding:12px;border-bottom:1px solid var(--border);last-child:border-none">
        <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:8px">
          <div>
            <div style="font-weight:600;font-size:13.5px;color:var(--text)">${esc(a.title)}</div>
            <div style="font-size:12px;color:var(--primary)">${esc(a.company_name)}</div>
            <div style="font-size:11px;color:var(--text3);margin-top:2px">${fmtDate(a.applied_at)}</div>
          </div>
          ${statusBadge(a.status)}
        </div>
      </div>`).join('') :
      '<div class="empty-state" style="padding:24px"><h4 style="font-size:14px">No applications yet</h4><p>Apply to jobs from the portal</p></div>';
  } catch(e) {
    document.getElementById('applications').innerHTML='<div class="text-muted text-sm" style="padding:12px">Could not load applications.</div>';
  }
}

async function uploadPhoto(input) {
  const file = input.files[0];
  if (!file) return;
  const fd = new FormData();
  fd.append('photo', file);
  fd.append('user_id', user.id);
  try {
    const r = await fetch('php/photo_upload.php', {method:'POST', body:fd});
    const d = await r.json();
    if (d.success) { location.reload(); }
    else { alert(d.message || 'Upload failed'); }
  } catch(e) { alert('Upload failed'); }
}
</script>
</body>
</html>

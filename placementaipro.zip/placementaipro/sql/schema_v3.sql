-- ============================================================
-- PlacementAI Pro – Complete MySQL Schema
-- Run once: mysql -u root -p < sql/schema_v3.sql
-- ============================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';

CREATE DATABASE IF NOT EXISTS `placement_db`
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `placement_db`;

-- 1. users
CREATE TABLE IF NOT EXISTS `users` (
  `id`            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `name`          VARCHAR(120) NOT NULL,
  `email`         VARCHAR(255) NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `role`          ENUM('student','organization','admin') NOT NULL DEFAULT 'student',
  `is_active`     TINYINT(1) NOT NULL DEFAULT 1,
  `created_at`    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. student_profiles
CREATE TABLE IF NOT EXISTS `student_profiles` (
  `id`                   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id`              INT UNSIGNED NOT NULL,
  `branch`               VARCHAR(80) NOT NULL DEFAULT 'Computer Science',
  `cgpa`                 DECIMAL(4,2) NOT NULL DEFAULT 0.00,
  `skills`               TEXT,
  `projects`             TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `internships`          TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `aptitude_score`       DECIMAL(5,2) NOT NULL DEFAULT 0.00,
  `communication_rating` DECIMAL(3,1) NOT NULL DEFAULT 5.0,
  `resume_text`          MEDIUMTEXT,
  `resume_score`         DECIMAL(5,2) DEFAULT NULL,
  `ats_score`            DECIMAL(5,2) DEFAULT NULL,
  `interview_score`      DECIMAL(5,2) DEFAULT NULL,
  `github_url`           VARCHAR(300),
  `linkedin_url`         VARCHAR(300),
  `updated_at`           TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_user` (`user_id`),
  CONSTRAINT `fk_sp_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. organizations (with verified flag)
CREATE TABLE IF NOT EXISTS `organizations` (
  `id`           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id`      INT UNSIGNED NOT NULL,
  `company_name` VARCHAR(200) NOT NULL,
  `description`  TEXT,
  `website`      VARCHAR(300),
  `industry`     VARCHAR(100),
  `logo_url`     VARCHAR(300),
  `verified`     TINYINT(1) NOT NULL DEFAULT 0,
  `admin_notes`  TEXT,
  `created_at`   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_org_user` (`user_id`),
  CONSTRAINT `fk_org_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. job_posts
CREATE TABLE IF NOT EXISTS `job_posts` (
  `id`               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `org_id`           INT UNSIGNED NOT NULL,
  `title`            VARCHAR(200) NOT NULL,
  `description`      TEXT NOT NULL,
  `required_skills`  TEXT,
  `min_cgpa`         DECIMAL(4,2) NOT NULL DEFAULT 0.00,
  `max_cgpa`         DECIMAL(4,2) NOT NULL DEFAULT 10.00,
  `experience_level` ENUM('Entry','Mid','Senior') NOT NULL DEFAULT 'Entry',
  `location`         VARCHAR(150),
  `salary_range`     VARCHAR(100),
  `is_active`        TINYINT(1) NOT NULL DEFAULT 1,
  `created_at`       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_org` (`org_id`),
  CONSTRAINT `fk_jp_org` FOREIGN KEY (`org_id`) REFERENCES `organizations`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. applications (student → job)
CREATE TABLE IF NOT EXISTS `applications` (
  `id`           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `student_id`   INT UNSIGNED NOT NULL,
  `job_id`       INT UNSIGNED NOT NULL,
  `status`       ENUM('applied','shortlisted','interview_scheduled','rejected','hired') NOT NULL DEFAULT 'applied',
  `org_notes`    TEXT,
  `applied_at`   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_application` (`student_id`,`job_id`),
  CONSTRAINT `fk_app_student` FOREIGN KEY (`student_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_app_job`     FOREIGN KEY (`job_id`)     REFERENCES `job_posts`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. aptitude_results
CREATE TABLE IF NOT EXISTS `aptitude_results` (
  `id`           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id`      INT UNSIGNED NOT NULL,
  `score`        DECIMAL(5,2) NOT NULL DEFAULT 0.00,
  `tab_warnings` TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `taken_at`     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_ar_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. streak_data
CREATE TABLE IF NOT EXISTS `streak_data` (
  `user_id`        INT UNSIGNED PRIMARY KEY,
  `current_streak` INT UNSIGNED NOT NULL DEFAULT 0,
  `longest_streak` INT UNSIGNED NOT NULL DEFAULT 0,
  `total_xp`       INT UNSIGNED NOT NULL DEFAULT 0,
  `last_checkin`   DATE,
  `badges`         TEXT,
  CONSTRAINT `fk_streak_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- SEED DATA  (password = "password123" for all)
-- ============================================================
INSERT IGNORE INTO `users` (`id`,`name`,`email`,`password_hash`,`role`,`is_active`) VALUES
(1, 'Rahul Verma',    'rahul@student.com',    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student',      1),
(2, 'Priya Shah',     'priya@student.com',    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student',      1),
(3, 'Arjun Mehta',   'arjun@student.com',    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student',      1),
(4, 'Google HR',      'hr@google.com',        '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'organization', 1),
(5, 'Amazon HR',      'hr@amazon.com',        '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'organization', 1),
(6, 'Infosys HR',     'hr@infosys.com',       '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'organization', 1),
(7, 'Admin User',     'admin@placementai.com','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin',        1);

INSERT IGNORE INTO `organizations` (`id`,`user_id`,`company_name`,`description`,`industry`,`verified`) VALUES
(1, 4, 'Google',  'Search & cloud leader.', 'Technology', 1),
(2, 5, 'Amazon',  'E-commerce & AWS cloud.', 'Technology', 1),
(3, 6, 'Infosys', 'IT services giant.', 'IT Services', 0);

INSERT IGNORE INTO `student_profiles`
  (`user_id`,`branch`,`cgpa`,`skills`,`projects`,`internships`,`aptitude_score`,`communication_rating`,`resume_score`,`ats_score`) VALUES
(1, 'Computer Science',      8.70, 'Python, Machine Learning, React, SQL, TensorFlow, Docker, Git, REST API', 4, 1, 85.00, 8.0, 76, 82),
(2, 'Information Technology',9.10, 'Java, Spring Boot, MySQL, Angular, Redis, AWS, Docker',                  5, 2, 92.00, 9.0, 88, 90),
(3, 'Electronics',           7.20, 'C++, Embedded C, MATLAB, Python',                                       2, 0, 68.00, 6.5, NULL, NULL);

INSERT IGNORE INTO `job_posts` (`id`,`org_id`,`title`,`description`,`required_skills`,`min_cgpa`,`experience_level`,`location`,`salary_range`) VALUES
(1, 1, 'Software Engineer',    'Build planet-scale systems.', 'Python, C++, System Design, DSA, Algorithms', 8.5, 'Entry', 'Bangalore / Remote', '18-25 LPA'),
(2, 1, 'ML Engineer',          'Work on Google AI products.', 'Python, TensorFlow, ML, PyTorch, SQL',         8.0, 'Entry', 'Hyderabad',           '20-28 LPA'),
(3, 2, 'Data Scientist',       'AWS ML services.', 'Python, ML, SQL, AWS, Cloud',                            8.0, 'Entry', 'Hyderabad',           '15-22 LPA'),
(4, 3, 'Systems Engineer',     'Support & deploy enterprise apps.', 'Java, SQL, Spring, Linux',               6.5, 'Entry', 'Pune / Chennai',      '4-7 LPA');

INSERT IGNORE INTO `applications` (`student_id`,`job_id`,`status`) VALUES
(1,1,'applied'),(1,3,'shortlisted'),(2,1,'interview_scheduled'),(2,2,'applied'),(3,4,'applied');

SET FOREIGN_KEY_CHECKS = 1;

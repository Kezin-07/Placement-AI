-- ============================================================
-- PlacementAI Pro – Feature Extensions (v4)
-- Run after schema_v3.sql:  mysql -u root -p placement_db < sql/schema_v4_features.sql
-- ============================================================

USE `placement_db`;

-- ── Feature 1: Notifications ────────────────────────────────
CREATE TABLE IF NOT EXISTS `notifications` (
  `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id`    INT UNSIGNED NOT NULL,
  `type`       VARCHAR(60) NOT NULL DEFAULT 'info',
  `title`      VARCHAR(200) NOT NULL,
  `body`       TEXT,
  `link`       VARCHAR(300),
  `is_read`    TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_notif_user` (`user_id`),
  KEY `idx_notif_read` (`is_read`),
  CONSTRAINT `fk_notif_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── Feature 2: Application Status Timeline ──────────────────
ALTER TABLE `applications`
  ADD COLUMN IF NOT EXISTS `timeline` JSON,
  ADD COLUMN IF NOT EXISTS `interview_datetime` DATETIME DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `interview_notes` TEXT DEFAULT NULL;

-- ── Feature 3: Student Photos ────────────────────────────────
ALTER TABLE `student_profiles`
  ADD COLUMN IF NOT EXISTS `photo_url` VARCHAR(400) DEFAULT NULL;

-- ── Feature 4: Org Aptitude Questions ───────────────────────
CREATE TABLE IF NOT EXISTS `org_aptitude_questions` (
  `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `org_id`      INT UNSIGNED NOT NULL,
  `job_id`      INT UNSIGNED DEFAULT NULL COMMENT 'NULL = applies to all org jobs',
  `question`    TEXT NOT NULL,
  `option_a`    VARCHAR(400) NOT NULL,
  `option_b`    VARCHAR(400) NOT NULL,
  `option_c`    VARCHAR(400) DEFAULT NULL,
  `option_d`    VARCHAR(400) DEFAULT NULL,
  `correct`     CHAR(1) NOT NULL COMMENT 'a/b/c/d',
  `difficulty`  ENUM('easy','medium','hard') NOT NULL DEFAULT 'medium',
  `category`    VARCHAR(80) DEFAULT 'General',
  `created_at`  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_oaq_org` (`org_id`),
  KEY `idx_oaq_job` (`job_id`),
  CONSTRAINT `fk_oaq_org` FOREIGN KEY (`org_id`) REFERENCES `organizations`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_oaq_job` FOREIGN KEY (`job_id`) REFERENCES `job_posts`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── Feature 9: Bulk import tracking ─────────────────────────
CREATE TABLE IF NOT EXISTS `bulk_import_log` (
  `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `admin_id`   INT UNSIGNED NOT NULL,
  `filename`   VARCHAR(200),
  `total`      INT UNSIGNED DEFAULT 0,
  `imported`   INT UNSIGNED DEFAULT 0,
  `skipped`    INT UNSIGNED DEFAULT 0,
  `errors`     TEXT,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Seed a few notifications for demo
INSERT IGNORE INTO `notifications` (`user_id`,`type`,`title`,`body`,`link`) VALUES
(1,'shortlisted','🎉 You have been shortlisted!','Amazon shortlisted you for Data Scientist role.','jobs.html'),
(1,'applied','✅ Application Received','Your application to Google - Software Engineer was received.','jobs.html'),
(4,'new_applicant','📋 New Applicant','Rahul Verma applied to Software Engineer.','organization.html?tab=students'),
(7,'org_pending','🏢 New Org Awaiting Approval','Infosys has registered and is pending verification.','admin.html?tab=orgs');


-- ── Enhancement 1: Auto-create streak on register ────────────
-- (Handled in auth_register.php via INSERT IGNORE)

-- ── Enhancement 2 & 3: XP tracking column ───────────────────
ALTER TABLE `streak_data`
  ADD COLUMN IF NOT EXISTS `profile_xp_awarded` TINYINT(1) NOT NULL DEFAULT 0;

-- ── Enhancement 4: Application limit enforced in apply_job.php ──
-- (No schema change needed — enforced at PHP level)

-- ── Enhancement 5: Notification bell badge ───────────────────
-- (Already in notifications table above)

-- ── Enhancement 6: Skill-match % in job_recommendations.php ─
-- (Computed at query time — no schema change needed)

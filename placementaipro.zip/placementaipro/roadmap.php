<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">  <link rel="icon" type="image/svg+xml" href="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAzMiAzMiIgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIj4KICA8ZGVmcz4KICAgIDxsaW5lYXJHcmFkaWVudCBpZD0iZyIgeDE9IjAiIHkxPSIxIiB4Mj0iMSIgeTI9IjAiPgogICAgICA8c3RvcCBvZmZzZXQ9IjAlIiBzdG9wLWNvbG9yPSIjZmY0NzU3Ii8+CiAgICAgIDxzdG9wIG9mZnNldD0iMTAwJSIgc3RvcC1jb2xvcj0iI2Y1OWUwYiIvPgogICAgPC9saW5lYXJHcmFkaWVudD4KICA8L2RlZnM+CiAgPHJlY3Qgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIiByeD0iNyIgZmlsbD0iIzFlMWExMCIvPgogIDxyZWN0IHg9IjYiIHk9IjIxIiB3aWR0aD0iNSIgaGVpZ2h0PSI5IiByeD0iMS41IiBmaWxsPSIjZjU5ZTBiIiBvcGFjaXR5PSIuNSIvPgogIDxyZWN0IHg9IjEzIiB5PSIxNSIgd2lkdGg9IjUiIGhlaWdodD0iMTUiIHJ4PSIxLjUiIGZpbGw9IiNmZjZiMzUiIG9wYWNpdHk9Ii43NSIvPgogIDxyZWN0IHg9IjIwIiB5PSI4IiB3aWR0aD0iNSIgaGVpZ2h0PSIyMiIgcng9IjEuNSIgZmlsbD0idXJsKCNnKSIvPgogIDxwb2x5bGluZSBwb2ludHM9IjIzLDQgMjcsOCAyNyw1IiBmaWxsPSJub25lIiBzdHJva2U9InVybCgjZykiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIi8+CiAgPGxpbmUgeDE9IjE5IiB5MT0iNSIgeDI9IjI3IiB5Mj0iNCIgc3Ryb2tlPSJ1cmwoI2cpIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPgo8L3N2Zz4=">
  <link rel="icon" type="image/x-icon" href="data:image/x-icon;base64,AAABAAEAEBAAAAAAIACgAAAAFgAAAIlQTkcNChoKAAAADUlIRFIAAAAQAAAAEAgGAAAAH/P/YQAAAGdJREFUeJxjZIACLg6R/wwkgG8/3jAyMDAwMJGjGVkPIzmakQETJZoZGBgYWNAFvn5/jVMxN6co9V1AWwOwOZkkA/CFB1EGEAOoH43IgOIwIAZQnpRhuYoc8O3HG0YmGIMczQwMDAwA+P4aS3/n/2IAAAAASUVORK5CYII=">
  <link rel="icon" type="image/png" sizes="32x32" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAoElEQVR4nO2XvQ6AIAyES+Pgz6rv/4Cyimw6kWhDxID0HLixabyPozHUUERjPx+xeqmct0bWboVaxk8grG0uvVjbXEJwqrG2DOL0V8ET6FIN275mfXgalld98AQaABwgOYQxyQHLHVSiHyTQALJmoOTOpeAJNAA4wCc/ohLBE2gAcAD8ozS2LmnJeWvgV8CBRNs4eLIsaJoTie04SHM9PwGQNi1E3UY9bQAAAABJRU5ErkJggg==">
  <link rel="icon" type="image/png" sizes="192x192" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMAAAADACAYAAABS3GwHAAADvklEQVR4nO3dQVLjVgBFUZvqASFTsv8FhmkIMzJIdRc0YCxL8pd8z1kAaPCuvmy61MfDxjzcP76OvgbW8/zydBx9DW8NvRhj53AYG8XVf7HRc8q1Y7jaLzN8prhWCKv/EsNnjrVDWO2HGz5LWiuExX+o4bOmpUO4W/KHGT9rW3pji9Rk+IywxGkw+wQwfkZZYnuzAjB+Rpu7wYsDMH62Ys4WLwrA+NmaSzc5OQDjZ6su2eakAIyfrZu60bMDMH72YspWzwrA+Nmbczf7bQDGz16ds91F/ykE7M3JANz92bvvNvxlAMbPrTi1ZY9ApH0agLs/t+arTTsBSPsQgLs/t+qzbTsBSHsXgLs/t+73jTsBSPsVgLs/FW+37gQgTQCk3R0OHn/o+bl5JwBpAiBNAKQJgLSjD8CUOQFIEwBpAiBNAKQJgDQBkPZj9AXM9c+/f4++hF3584+/Rl/CpjgBSBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYC03b8VYi0j356w1psuvBHiIycAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANKOD/ePr6MvYo61XiV+q7wi/T0nAGkCIE0ApAmANAGQJgDSBECaAEgTAGkCIE0ApAmANAGQJgDSBECaAEgTAGkCIE0ApAmANAGQ9mP0BWyVtyc0OAFIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0o4P94+voy8CRnECkCYA0gRAmgBIEwBpd88vT8fRFwEjPL88HZ0ApAmANAGQJgDS7g6H/z8MjL4QuKafm3cCkCYA0n4F4DGIirdbdwKQ9i4ApwC37veNOwFI+xCAU4Bb9dm2nQCkfRqAU4Bb89WmnQCkfRmAU4BbcWrLJ08AEbB3323YIxBp3wbgFGCvztnuWSeACNibczd79iOQCNiLKVud9BlABGzd1I1O/hAsArbqkm1e9C2QCNiaSzd58degImAr5mxx1t8BRMBoczc4+w9hImCUJba36Hj9bzNcw5I33UX/KYTTgLUtvbHVBus0YElr3VxXv2MLgTnWfqq42iOLEJjiWo/TV39mFwKnXPtz5NAPrWLgcBj75cnmvrURxW3b2jeF/wGOq9fsu4f8UQAAAABJRU5ErkJggg==">
  <link rel="apple-touch-icon" sizes="180x180" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAAC0CAYAAAA9zQYyAAADX0lEQVR4nO3cOXJaQQBFUVA58JDa+1+glVpWZgceygOS/kh/rs5ZAOrg8tRAwfl0AO/ffvw2+gys9/B4fx59hiEHEPDrMCLwq/1BEb9u14p71z8iYi7ZM+5dHljITLFH2HdbP6CYmWqPVjZ7hgiZNbZa600WWsystVVDq54VQmYPa9Z68UKLmb2saWtR0GJmb0sbmx20mLmWJa3NClrMXNvc5iYHLWZGmdPepKDFzGhTG3wxaDFzFFNa3Pyjbxjp2aCtM0fzUpNPBi1mjuq5Nl05SLkYtHXm6J5q9L+gxcytuNSqKwcpfwVtnbk1/zZroUkRNCm/g3bd4Fb92a6FJkXQpNydTq4b3L5fDVtoUgRNiqBJObs/U2KhSRE0KYImRdCkCJoUQZPyZvQBlvjy9fPoIxzWh3efRh9hKAtNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiblJr8ku4cRXy71Zd/tWWhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCl+rPEnP5zYYKFJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KT4kuxPH959Gn0ENmChSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJqU8/u3H7+NPgRsxUKTImhSBE2KoEkRNCl3D4/359GHgC08PN6fLTQpgiZF0KTcnU4/7h6jDwJr/GrYQpMiaFJ+B+3awa36s10LTYqgSfkraNcObs2/zVpoUv4L2kpzKy61enGhRc3RPdWoKwcpTwZtpTmq59p8dqFFzdG81KQrBykvBm2lOYopLU5aaFEz2tQGJ185RM0oc9qbdYcWNdc2t7nZLwpFzbUsaW3RuxyiZm9LG1v8tp2o2cuatjaJ0k/ysoUtRnKTD1asNWtt1dDmIVpr5th6DDf/6NtaM9Uerewan7Xmkj1H72prKu7X7Vr/uYdcD8T9Ooy4fh7ivivwhiO8fvoO2onGYhMioSEAAAAASUVORK5CYII=">
  <title>Roadmap — PlacementAI Pro</title>
  <link rel="stylesheet" href="css/style.css?v=5">
  <style>
    .roadmap-timeline { position: relative; }
    .week-node { display: flex; gap: 20px; margin-bottom: 28px; animation: slideUp .4s ease both; }
    .week-connector { display: flex; flex-direction: column; align-items: center; flex-shrink: 0; }
    .week-circle {
      width: 46px; height: 46px;
      background: linear-gradient(135deg,#6c63ff,#a78bfa);
      border-radius: 50%; display: flex; align-items: center; justify-content: center;
      font-family: var(--font-display); font-weight: 800; font-size: 13px; color: #fff;
      box-shadow: 0 0 0 4px rgba(108,99,255,.2), 0 4px 12px rgba(108,99,255,.35);
      z-index: 1; flex-shrink: 0;
    }
    .week-line { width: 2px; flex: 1; background: linear-gradient(180deg,rgba(108,99,255,.4),transparent); margin-top: 4px; min-height: 40px; }
    .week-card { flex: 1; background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 18px 22px; transition: border-color .2s, transform .2s; }
    .week-card:hover { border-color: rgba(108,99,255,.4); transform: translateX(4px); box-shadow: -3px 0 0 var(--primary); }
    .week-label { font-size: 10px; color: var(--primary); font-weight: 700; text-transform: uppercase; letter-spacing: .1em; margin-bottom: 5px; }
    .week-title { font-size: 1rem; font-weight: 700; color: var(--text); margin-bottom: 12px; }
    .week-tasks { list-style: none; display: flex; flex-direction: column; gap: 7px; }
    .week-tasks li { display: flex; gap: 9px; align-items: flex-start; font-size: 13.5px; color: var(--text2); line-height: 1.5; }
    .week-resources { font-size:12px; color:var(--primary-l); margin-top:10px; padding-top:10px; border-top:1px solid var(--border); display:flex; align-items:center; gap:6px; font-weight:500; }
    .week-resources::before { content:"📚"; }
    .task-dot { width: 6px; height: 6px; background: var(--primary); border-radius: 50%; margin-top: 6px; flex-shrink: 0; }

    .job-input-card { background: linear-gradient(135deg, rgba(108,99,255,.08), rgba(167,139,250,.05)); border: 1.5px solid rgba(108,99,255,.25); border-radius: var(--radius); padding: 24px; margin-bottom: 24px; }
    .job-textarea {
      width: 100%; min-height: 120px; background: var(--bg3); border: 1.5px solid var(--border);
      border-radius: 10px; padding: 14px; color: var(--text); font-size: 14px; resize: vertical;
      outline: none; transition: border-color .2s; line-height: 1.6;
      font-family: var(--font-body);
    }
    .job-textarea:focus { border-color: var(--primary); }
    .job-textarea::placeholder { color: var(--text3); }

    .focus-chips { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 16px; }
    .focus-chip {
      padding: 7px 14px; border: 1.5px solid var(--border); border-radius: 99px;
      font-size: 12.5px; color: var(--text2); cursor: pointer; background: var(--bg3);
      transition: all .18s; font-weight: 500;
    }
    .focus-chip:hover { border-color: var(--primary); color: var(--primary); }
    .focus-chip.active { border-color: var(--primary); background: rgba(108,99,255,.12); color: var(--primary); font-weight: 700; }
  </style>
</head>
<body>
<script src="js/app.js?v=5"></script>
<script>
const user = Auth.requireAuth('student');
if (user) { buildShell('roadmap'); setTimeout(()=>initRoadmap(), 0); }

let activeFocus = '';

async function initRoadmap() {
  document.getElementById('topbarTitle').textContent = 'Placement Roadmap';
  const page = document.getElementById('mainPage');
  page.innerHTML = `
    <div class="page-header">
      <h1 style="font-size:1.6rem">🗺️ AI Placement Roadmap</h1>
      <p style="color:var(--text3);font-size:13px;margin-top:2px">8-week personalized plan built from your profile + target job description</p>
    </div>

    <div class="job-input-card">
      <div style="display:flex;align-items:flex-start;gap:14px;margin-bottom:16px">
        <div style="width:40px;height:40px;background:linear-gradient(135deg,#6c63ff,#a78bfa);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:1.2rem;flex-shrink:0">🎯</div>
        <div>
          <div style="font-size:15px;font-weight:700;color:var(--text);margin-bottom:3px">Enter Target Job Post</div>
          <div style="font-size:13px;color:var(--text3)">Paste a job description or role — AI will tailor your roadmap to match it exactly</div>
        </div>
      </div>
      <textarea id="jobPostInput" class="job-textarea" placeholder="e.g. Software Engineer at Google — Requirements: Python, DSA, System Design, 2+ years experience. Responsibilities include building scalable backend systems..."></textarea>
      <div style="margin-top:16px">
        <div style="font-size:12px;font-weight:600;color:var(--text3);margin-bottom:10px;text-transform:uppercase;letter-spacing:.05em">Or choose a focus area:</div>
        <div class="focus-chips">
          <div class="focus-chip active" onclick="setFocus('')" id="chip-general">🌐 General Placement</div>
          <div class="focus-chip" onclick="setFocus('dsa')" id="chip-dsa">💻 DSA & Algorithms</div>
          <div class="focus-chip" onclick="setFocus('system_design')" id="chip-system_design">🏗 System Design</div>
          <div class="focus-chip" onclick="setFocus('hr')" id="chip-hr">🗣 HR & Soft Skills</div>
          <div class="focus-chip" onclick="setFocus('data_science')" id="chip-data_science">📊 Data Science / ML</div>
          <div class="focus-chip" onclick="setFocus('fullstack')" id="chip-fullstack">⚡ Full Stack Dev</div>
        </div>
      </div>
      <button id="genBtn" onclick="generateRoadmap()" class="btn btn-primary" style="margin-top:4px">
        <svg width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><polygon points="3 6 9 3 15 6 21 3 21 18 15 21 9 18 3 21"/></svg>
        Generate My Roadmap
      </button>
    </div>

    <div id="roadmapContent">
      <div style="text-align:center;padding:60px;color:var(--text3)">
        <div style="font-size:3rem;margin-bottom:16px">🗺</div>
        <h3 style="margin-bottom:8px;color:var(--text2)">Your Personalized Roadmap Awaits</h3>
        <p style="font-size:13.5px">Paste a job description and click Generate — AI analyzes your profile to build a custom prep plan</p>
      </div>
    </div>`;
}

function setFocus(f) {
  activeFocus = f;
  document.querySelectorAll('.focus-chip').forEach(c => c.classList.remove('active'));
  const id = 'chip-' + (f || 'general');
  document.getElementById(id)?.classList.add('active');
}

async function generateRoadmap() {
  const btn = document.getElementById('genBtn');
  const jobPost = document.getElementById('jobPostInput')?.value?.trim() || '';
  loading(btn, true, 'AI is building your roadmap…');

  document.getElementById('roadmapContent').innerHTML = `
    <div style="display:flex;flex-direction:column;align-items:center;padding:60px;gap:16px">
      <div class="spinner" style="width:40px;height:40px;border-width:3px"></div>
      <div style="color:var(--text2);font-size:14px">AI is analyzing your profile &amp; crafting your roadmap…</div>
    </div>`;

  try {
    const data = await API.post('roadmap.php', { user_id: user.id, focus: activeFocus, job_post: jobPost });
    const roadmap = data.roadmap || [];
    if (!roadmap.length) throw new Error('No roadmap generated');

    const jobTag = jobPost ? `<div style="margin-bottom:20px;padding:12px 16px;background:rgba(108,99,255,.08);border:1px solid rgba(108,99,255,.2);border-radius:10px;font-size:13px;color:var(--text2)">
      <span style="color:var(--primary);font-weight:700">🎯 Tailored for:</span> ${esc(jobPost.slice(0,120))}${jobPost.length>120?'…':''}
    </div>` : '';

    document.getElementById('roadmapContent').innerHTML = `
      ${jobTag}
      <div class="roadmap-timeline">
        ${roadmap.map((week, i) => `
          <div class="week-node" style="animation-delay:${i*0.07}s">
            <div class="week-connector">
              <div class="week-circle">${i+1}</div>
              ${i < roadmap.length - 1 ? '<div class="week-line"></div>' : ''}
            </div>
            <div class="week-card">
              <div class="week-label">${esc(week.week)}</div>
              <div class="week-title">${esc(week.title)}</div>
              <ul class="week-tasks">
                ${(week.tasks||[]).map(task => `<li><div class="task-dot"></div><span>${esc(task)}</span></li>`).join('')}
              </ul>
              ${week.resources ? `<div style="margin-top:12px;padding-top:12px;border-top:1px solid var(--border);font-size:12px;color:var(--text3)">
                📚 ${esc(week.resources)}</div>` : ''}
            </div>
          </div>`).join('')}
      </div>`;
  } catch(e) {
    const errMsg = e.message || 'Failed to generate roadmap.';
    const isApiKey = errMsg.toLowerCase().includes('api key') || errMsg.toLowerCase().includes('not configured');
    document.getElementById('roadmapContent').innerHTML = `<div class="alert alert-error">
      ❌ ${esc(errMsg)}
      ${isApiKey ? '<br><br><strong>To fix:</strong> Open <code>php/config.php</code> and replace <code>sk-ant-api03-REPLACE_WITH_YOUR_KEY_HERE</code> with your real Claude API key from <a href="https://console.anthropic.com" target="_blank">console.anthropic.com</a>' : ''}
    </div>`;
  }
  loading(btn, false);
}
</script>
</body>
</html>

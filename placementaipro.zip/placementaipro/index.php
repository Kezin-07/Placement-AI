<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="icon" type="image/svg+xml" href="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAzMiAzMiIgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIj4KICA8ZGVmcz4KICAgIDxsaW5lYXJHcmFkaWVudCBpZD0iZyIgeDE9IjAiIHkxPSIxIiB4Mj0iMSIgeTI9IjAiPgogICAgICA8c3RvcCBvZmZzZXQ9IjAlIiBzdG9wLWNvbG9yPSIjZmY0NzU3Ii8+CiAgICAgIDxzdG9wIG9mZnNldD0iMTAwJSIgc3RvcC1jb2xvcj0iI2Y1OWUwYiIvPgogICAgPC9saW5lYXJHcmFkaWVudD4KICA8L2RlZnM+CiAgPHJlY3Qgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIiByeD0iNyIgZmlsbD0iIzFlMWExMCIvPgogIDxyZWN0IHg9IjYiIHk9IjIxIiB3aWR0aD0iNSIgaGVpZ2h0PSI5IiByeD0iMS41IiBmaWxsPSIjZjU5ZTBiIiBvcGFjaXR5PSIuNSIvPgogIDxyZWN0IHg9IjEzIiB5PSIxNSIgd2lkdGg9IjUiIGhlaWdodD0iMTUiIHJ4PSIxLjUiIGZpbGw9IiNmZjZiMzUiIG9wYWNpdHk9Ii43NSIvPgogIDxyZWN0IHg9IjIwIiB5PSI4IiB3aWR0aD0iNSIgaGVpZ2h0PSIyMiIgcng9IjEuNSIgZmlsbD0idXJsKCNnKSIvPgogIDxwb2x5bGluZSBwb2ludHM9IjIzLDQgMjcsOCAyNyw1IiBmaWxsPSJub25lIiBzdHJva2U9InVybCgjZykiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIi8+CiAgPGxpbmUgeDE9IjE5IiB5MT0iNSIgeDI9IjI3IiB5Mj0iNCIgc3Ryb2tlPSJ1cmwoI2cpIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPgo8L3N2Zz4=">
  <link rel="icon" type="image/x-icon" href="data:image/x-icon;base64,AAABAAEAEBAAAAAAIACgAAAAFgAAAIlQTkcNChoKAAAADUlIRFIAAAAQAAAAEAgGAAAAH/P/YQAAAGdJREFUeJxjZIACLg6R/wwkgG8/3jAyMDAwMJGjGVkPIzmakQETJZoZGBgYWNAFvn5/jVMxN6co9V1AWwOwOZkkA/CFB1EGEAOoH43IgOIwIAZQnpRhuYoc8O3HG0YmGIMczQwMDAwA+P4aS3/n/2IAAAAASUVORK5CYII=">
  <title>PlacementAI Pro — Land Your Dream Job with AI</title>
  <link rel="stylesheet" href="css/style.css?v=5">
  <style>
    /* ── Landing-specific extras ── */
    .section-label { font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:.12em; color:var(--text3); margin-bottom:14px; }
    .hero-cta-note { font-size:12px; color:var(--text3); margin-top:14px; }

    /* Stats row */
    .stat-row { display:flex; gap:40px; justify-content:center; flex-wrap:wrap; }
    .stat-item { text-align:center; }
    .stat-item strong { display:block; font-size:1.8rem; font-weight:900; letter-spacing:-.04em; color:var(--text); font-family:var(--font-display); }
    .stat-item span { font-size:12px; color:var(--text3); }
    .stat-divider { width:1px; background:var(--border2); align-self:stretch; }

    /* Feature cards */
    .features-title { text-align:center; font-size:clamp(1.6rem,3vw,2.4rem); font-weight:900; letter-spacing:-.04em; margin-bottom:14px; }
    .features-sub { text-align:center; color:var(--text2); font-size:14.5px; max-width:520px; margin:0 auto 48px; line-height:1.65; }
    .fc-icon { width:48px; height:48px; border-radius:13px; display:flex; align-items:center; justify-content:center; font-size:1.5rem; margin-bottom:18px; flex-shrink:0; }
    .fc-icon.p { background:rgba(124,106,255,.14); border:1px solid rgba(124,106,255,.2); }
    .fc-icon.g { background:rgba(0,214,143,.1); border:1px solid rgba(0,214,143,.18); }
    .fc-icon.c { background:rgba(0,200,255,.1); border:1px solid rgba(0,200,255,.18); }
    .fc-icon.a { background:rgba(245,158,11,.1); border:1px solid rgba(245,158,11,.18); }
    .fc-icon.r { background:rgba(255,71,87,.1); border:1px solid rgba(255,71,87,.18); }
    .fc-icon.v { background:rgba(167,139,250,.12); border:1px solid rgba(167,139,250,.2); }
    .feature-card h3 { font-size:1rem; font-weight:700; margin-bottom:8px; color:var(--text); }
    .feature-card p  { font-size:13.5px; color:var(--text3); line-height:1.65; }
    .feature-card .fc-tag { display:inline-block; font-size:10px; font-weight:700; text-transform:uppercase; letter-spacing:.07em; padding:2px 8px; border-radius:99px; margin-bottom:10px; }

    /* How it works */
    .steps-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:24px; }
    @media(max-width:768px) { .steps-grid { grid-template-columns:1fr; } }
    .step-card { background:var(--surface); border:1px solid var(--border); border-radius:var(--radius-lg); padding:28px; position:relative; overflow:hidden; transition:border-color .2s,transform .2s; }
    .step-card:hover { border-color:var(--border2); transform:translateY(-3px); }
    .step-num { font-family:var(--font-display); font-size:3rem; font-weight:900; color:var(--border2); line-height:1; margin-bottom:14px; }
    .step-card h3 { font-size:.95rem; font-weight:700; margin-bottom:8px; }
    .step-card p { font-size:13px; color:var(--text3); line-height:1.6; }

    /* CTA section */
    .cta-section { text-align:center; padding:100px 24px; position:relative; overflow:hidden; }
    .cta-section h2 { font-size:clamp(1.6rem,3vw,2.4rem); font-weight:900; letter-spacing:-.04em; margin-bottom:14px; position:relative; z-index:1; }
    .cta-section > p  { color:var(--text2); font-size:15px; margin-bottom:36px; position:relative; z-index:1; }
    .cta-section a { position:relative; z-index:1; }
    .cta-trust { font-size:12px; color:var(--text3); margin-top:20px; position:relative; z-index:1; display:flex; align-items:center; justify-content:center; gap:16px; flex-wrap:wrap; }
    .cta-trust span { display:flex; align-items:center; gap:5px; }
    .cta-trust span::before { content:'✓'; color:var(--emerald); font-weight:700; }

    /* Footer */
    footer { border-top:1px solid var(--border); padding:28px 40px; display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:14px; }
    footer .f-brand { display:flex; align-items:center; gap:9px; font-family:var(--font-display); font-weight:700; font-size:.9rem; color:var(--text2); }
    footer span { font-size:12px; color:var(--text3); }
    footer .f-links { display:flex; gap:20px; }
    footer .f-links a { font-size:12px; color:var(--text3); text-decoration:none; transition:color .15s; }
    footer .f-links a:hover { color:var(--text2); }

    /* Logo SVG (shared) */
    .logo-svg { display:block; }

    /* Gradient divider */
    .grad-divider { height:1px; background:linear-gradient(90deg,transparent,rgba(124,106,255,.4),rgba(0,229,180,.3),transparent); margin:0 5%; }

    /* Responsive */
    @media(max-width:600px) {
      .stat-row { gap:24px; }
      .stat-divider { display:none; }
      footer { padding:20px 20px; }
      footer .f-links { display:none; }
    }
  </style>
</head>
<body class="landing">

<!-- ── Navbar ──────────────────────────────────────── -->
<nav class="nav-landing">
  <a href="index.php" style="display:flex;align-items:center;gap:9px;font-family:var(--font-display);font-size:.95rem;font-weight:700;color:var(--text);text-decoration:none">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30" width="30" height="30"><defs><linearGradient id="gcl30" x1="0" y1="1" x2="1" y2="0"><stop offset="0%" stop-color="#ff4757"/><stop offset="100%" stop-color="#f59e0b"/></linearGradient></defs><rect width="30" height="30" rx="5" fill="#1e1a10"/><rect x="5" y="20" width="5" height="8" rx="1" fill="#f59e0b" opacity=".45"/><rect x="11" y="14" width="5" height="14" rx="1" fill="#ff6b35" opacity=".7"/><rect x="18" y="7" width="5" height="21" rx="1" fill="url(#gcl30)"/><polyline points="20,4 23,7 23,5" fill="none" stroke="url(#gcl30)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><line x1="17" y1="5" x2="20" y2="4" stroke="url(#gcl30)" stroke-width="1.5" stroke-linecap="round"/></svg>
    <span style="white-space:nowrap;letter-spacing:-.02em">PlacementAI<span style="color:var(--primary-l)"> Pro</span></span>
  </a>
  <div style="display:flex;align-items:center;gap:10px">
    <a href="login.php" style="color:var(--text2);font-size:13.5px;font-weight:500;padding:7px 16px;border-radius:8px;transition:background .15s;text-decoration:none" onmouseover="this.style.background='var(--surface2)'" onmouseout="this.style.background='transparent'">Sign in</a>
    <a href="register.php" class="btn btn-primary btn-sm">Get started free</a>
  </div>
</nav>

<!-- ── Hero ────────────────────────────────────────── -->
<section class="hero-section">
  <div class="hero-badge">✨ AI-Powered Placement Platform</div>
  <h1 class="hero-title">The smartest way to<br><span class="gradient">land your dream job</span></h1>
  <p class="hero-sub">AI mock interviews, resume analyzer, prediction engine, and personalized roadmaps — everything you need to ace campus placements.</p>
  <div class="hero-actions">
    <a href="register.php" class="btn btn-primary btn-lg">Start for free →</a>
    <a href="login.php" class="btn btn-ghost btn-lg">Sign in</a>
  </div>
  <p class="hero-cta-note">No credit card required · Free for students</p>

  <!-- Mock UI preview card -->
  <div style="margin-top:56px;width:100%;max-width:740px;position:relative;z-index:1;animation:fadeUp .9s cubic-bezier(.4,0,.2,1) .6s both">
    <div style="background:var(--surface);border:1px solid var(--border2);border-radius:20px;padding:22px;box-shadow:0 40px 100px rgba(0,0,0,.7),0 0 0 1px rgba(124,106,255,.1);overflow:hidden;position:relative">
      <!-- Inner glow -->
      <div style="position:absolute;top:-80px;left:50%;transform:translateX(-50%);width:500px;height:300px;background:radial-gradient(ellipse,rgba(124,106,255,.12) 0%,transparent 70%);pointer-events:none"></div>
      <!-- Titlebar dots -->
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:18px;padding-bottom:14px;border-bottom:1px solid var(--border)">
        <div style="display:flex;align-items:center;gap:10px">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><defs><linearGradient id="gcl24" x1="0" y1="1" x2="1" y2="0"><stop offset="0%" stop-color="#ff4757"/><stop offset="100%" stop-color="#f59e0b"/></linearGradient></defs><rect width="24" height="24" rx="4" fill="#1e1a10"/><rect x="4" y="15" width="4" height="7" rx="1" fill="#f59e0b" opacity=".45"/><rect x="9" y="10" width="4" height="12" rx="1" fill="#ff6b35" opacity=".7"/><rect x="14" y="5" width="4" height="17" rx="1" fill="url(#gcl24)"/><polyline points="16,3 18,5 18,4" fill="none" stroke="url(#gcl24)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><line x1="14" y1="4" x2="16" y2="3" stroke="url(#gcl24)" stroke-width="1.5" stroke-linecap="round"/></svg>
          <span style="font-weight:700;font-size:13px;color:var(--text)">Dashboard — PlacementAI Pro</span>
        </div>
        <div style="display:flex;gap:6px">
          <div style="width:10px;height:10px;border-radius:50%;background:#ff5f57"></div>
          <div style="width:10px;height:10px;border-radius:50%;background:#febc2e"></div>
          <div style="width:10px;height:10px;border-radius:50%;background:#28c840"></div>
        </div>
      </div>
      <!-- Score tiles -->
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:14px">
        <?php foreach([['CGPA','8.4','#a78bfa','↑ Excellent'],['Resume','87%','#00d68f','ATS Ready'],['Aptitude','92%','#f59e0b','Top Performer'],['Interview','78%','#00c8ff','Interview-Ready']] as [$l,$v,$c,$s]): ?>
        <div style="background:var(--bg2);border:1px solid var(--border);border-radius:10px;padding:12px 8px;text-align:center">
          <div style="font-size:1.15rem;font-weight:900;color:<?= $c ?>;font-family:var(--font-display)"><?= $v ?></div>
          <div style="font-size:10px;color:var(--text3);margin-top:2px"><?= $l ?></div>
          <div style="font-size:9.5px;color:<?= $c ?>;margin-top:3px;font-weight:600;opacity:.8"><?= $s ?></div>
        </div>
        <?php endforeach; ?>
      </div>
      <!-- AI interview progress row -->
      <div style="background:var(--bg2);border:1px solid rgba(124,106,255,.25);border-radius:12px;padding:14px 16px;display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-bottom:10px">
        <div style="display:flex;align-items:center;gap:10px">
          <div style="width:36px;height:36px;border-radius:10px;background:rgba(124,106,255,.12);border:1px solid rgba(124,106,255,.25);display:flex;align-items:center;justify-content:center;font-size:1.1rem;flex-shrink:0">🎙️</div>
          <div>
            <div style="font-size:13px;font-weight:700;color:var(--text)">AI Mock Interview</div>
            <div style="font-size:11px;color:var(--text3)">Google SDE · 7 of 12 questions done</div>
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:10px">
          <div style="width:100px;height:5px;background:var(--bg3);border-radius:99px;overflow:hidden">
            <div style="width:58%;height:100%;background:linear-gradient(90deg,#7c6aff,#a78bfa);border-radius:99px"></div>
          </div>
          <span style="font-size:11px;color:var(--primary-l);font-weight:700">58%</span>
        </div>
      </div>
      <!-- Resume ATS row -->
      <div style="background:var(--bg2);border:1px solid rgba(0,214,143,.2);border-radius:12px;padding:12px 16px;display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap">
        <div style="display:flex;align-items:center;gap:10px">
          <div style="width:36px;height:36px;border-radius:10px;background:rgba(0,214,143,.1);border:1px solid rgba(0,214,143,.2);display:flex;align-items:center;justify-content:center;font-size:1.1rem;flex-shrink:0">📄</div>
          <div>
            <div style="font-size:13px;font-weight:700;color:var(--text)">Resume ATS Score</div>
            <div style="font-size:11px;color:var(--text3)">3 keywords missing · 2 improvements suggested</div>
          </div>
        </div>
        <span style="font-size:13px;font-weight:800;color:#00d68f">87/100</span>
      </div>
    </div>
    <!-- Floating shadow gradient under card -->
    <div style="position:absolute;bottom:-30px;left:10%;right:10%;height:40px;background:radial-gradient(ellipse,rgba(124,106,255,.3) 0%,transparent 70%);filter:blur(20px);pointer-events:none"></div>
  </div>

<?php
$statsData = ['students'=>0,'placed'=>0,'companies'=>0,'jobs'=>0];
try {
  $pdo2 = new PDO('mysql:host=localhost;dbname=placement_db;charset=utf8mb4','root','',[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
  $statsData['students']  = $pdo2->query("SELECT COUNT(*) FROM users WHERE role='student' AND is_active=1")->fetchColumn();
  $statsData['placed']    = $pdo2->query("SELECT COUNT(DISTINCT student_id) FROM applications WHERE status='hired'")->fetchColumn();
  $statsData['companies'] = $pdo2->query("SELECT COUNT(*) FROM organizations WHERE verified=1")->fetchColumn();
  $statsData['jobs']      = $pdo2->query("SELECT COUNT(*) FROM job_posts WHERE is_active=1")->fetchColumn();
} catch(Exception $e) {}
function fmtStat($n) { if($n>=1000)return round($n/1000,1).'K+'; return $n>0?$n.'+':'—'; }
?>
  <!-- Stats strip -->
  <div class="stat-row" style="margin-top:60px">
    <div class="stat-item"><strong><?= fmtStat($statsData['students']) ?></strong><span>Registered students</span></div>
    <div class="stat-divider"></div>
    <div class="stat-item"><strong><?= fmtStat($statsData['placed']) ?></strong><span>Students hired</span></div>
    <div class="stat-divider"></div>
    <div class="stat-item"><strong><?= fmtStat($statsData['companies']) ?></strong><span>Verified companies</span></div>
    <div class="stat-divider"></div>
    <div class="stat-item"><strong><?= fmtStat($statsData['jobs']) ?></strong><span>Active jobs</span></div>
  </div>
</section>

<!-- ── Gradient divider ─────────────────────────────── -->
<div class="grad-divider"></div>

<!-- ── Features ────────────────────────────────────── -->
<section style="padding:90px 40px;max-width:1120px;margin:0 auto">
  <div class="section-label" style="text-align:center">Everything you need</div>
  <h2 class="features-title">Built for placement success</h2>
  <p class="features-sub">Every tool from resume to offer letter — powered by state-of-the-art AI and built specifically for campus placements.</p>
  <div class="features-grid">
    <div class="feature-card">
      <div class="fc-icon p">🎙️</div>
      <span class="fc-tag" style="background:rgba(124,106,255,.12);color:var(--primary-l)">Most Used</span>
      <h3>AI Mock Interviews</h3>
      <p>Company-specific questions with no repeats. Technical, HR, and system design rounds with real-time voice feedback and scoring.</p>
    </div>
    <div class="feature-card">
      <div class="fc-icon g">📄</div>
      <span class="fc-tag" style="background:rgba(0,214,143,.1);color:var(--emerald)">ATS Powered</span>
      <h3>Resume Analyzer</h3>
      <p>ATS score, keyword gap analysis, and AI-generated line-by-line suggestions to help your resume land more interviews.</p>
    </div>
    <div class="feature-card">
      <div class="fc-icon c">🗺️</div>
      <span class="fc-tag" style="background:rgba(0,200,255,.1);color:var(--cyan)">Personalized</span>
      <h3>Learning Roadmap</h3>
      <p>Paste any job description and get a custom 8-week preparation plan tailored to your current skill profile.</p>
    </div>
    <div class="feature-card">
      <div class="fc-icon a">📊</div>
      <span class="fc-tag" style="background:rgba(245,158,11,.1);color:var(--accent2)">ML Model</span>
      <h3>Placement Prediction</h3>
      <p>ML-based engine analyzes CGPA, skills, projects, and experience to predict your placement probability and suggest improvements.</p>
    </div>
    <div class="feature-card">
      <div class="fc-icon r">🧠</div>
      <span class="fc-tag" style="background:rgba(255,71,87,.1);color:var(--red)">AI Generated</span>
      <h3>Aptitude Test</h3>
      <p>AI-generated questions across quantitative, logical, and verbal reasoning — with instant scoring and detailed solution walkthroughs.</p>
    </div>
    <div class="feature-card">
      <div class="fc-icon v">🏢</div>
      <span class="fc-tag" style="background:rgba(167,139,250,.12);color:var(--primary-l)">Direct Apply</span>
      <h3>Job Portal</h3>
      <p>Browse curated openings from verified companies and apply directly — no third-party middlemen, no redirect loops.</p>
    </div>
  </div>
</section>

<!-- ── Gradient divider ─────────────────────────────── -->
<div class="grad-divider"></div>

<!-- ── How it works ─────────────────────────────────── -->
<section style="padding:90px 40px;max-width:1000px;margin:0 auto">
  <div class="section-label" style="text-align:center">Simple process</div>
  <h2 class="features-title">From signup to offer in 3 steps</h2>
  <p class="features-sub">Get started in minutes, not hours. No complex setup required.</p>
  <div class="steps-grid">
    <div class="step-card">
      <div style="position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,#7c6aff,#a78bfa);border-radius:var(--radius-lg) var(--radius-lg) 0 0"></div>
      <div class="step-num">01</div>
      <h3>Create your profile</h3>
      <p>Sign up in 30 seconds. Add your CGPA, skills, branch, and upload your resume. We'll build your placement readiness score instantly.</p>
    </div>
    <div class="step-card">
      <div style="position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,#00d68f,#00e5b4);border-radius:var(--radius-lg) var(--radius-lg) 0 0"></div>
      <div class="step-num">02</div>
      <h3>Practice with AI</h3>
      <p>Run mock interviews, take aptitude tests, analyze your resume, and follow your personalized roadmap — all powered by AI.</p>
    </div>
    <div class="step-card">
      <div style="position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,#f59e0b,#fbbf24);border-radius:var(--radius-lg) var(--radius-lg) 0 0"></div>
      <div class="step-num">03</div>
      <h3>Apply & get hired</h3>
      <p>Browse real job listings from verified companies, apply directly, and track your application status in real time.</p>
    </div>
  </div>
</section>

<!-- ── CTA ──────────────────────────────────────────── -->
<section class="cta-section">
  <div style="position:absolute;inset:0;background:radial-gradient(ellipse at center,rgba(124,106,255,.09) 0%,transparent 65%);pointer-events:none"></div>
  <div style="position:absolute;inset:0;background:radial-gradient(ellipse at 60% 60%,rgba(0,229,180,.05) 0%,transparent 60%);pointer-events:none"></div>
  <h2>Ready to ace your placement?</h2>
  <p>Join thousands of students who landed their dream jobs with PlacementAI Pro.</p>
  <a href="register.php" class="btn btn-primary btn-lg">Create free account →</a>
  <div class="cta-trust">
    <span>Free forever for students</span>
    <span>No credit card</span>
    <span>Setup in 2 minutes</span>
  </div>
</section>

<!-- ── Footer ───────────────────────────────────────── -->
<footer>
  <div class="f-brand">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 26 26" width="26" height="26"><defs><linearGradient id="gcl26" x1="0" y1="1" x2="1" y2="0"><stop offset="0%" stop-color="#ff4757"/><stop offset="100%" stop-color="#f59e0b"/></linearGradient></defs><rect width="26" height="26" rx="4" fill="#1e1a10"/><rect x="4" y="17" width="4" height="7" rx="1" fill="#f59e0b" opacity=".45"/><rect x="10" y="11" width="4" height="13" rx="1" fill="#ff6b35" opacity=".7"/><rect x="15" y="6" width="4" height="18" rx="1" fill="url(#gcl26)"/><polyline points="17,4 19,7 19,6" fill="none" stroke="url(#gcl26)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><line x1="15" y1="5" x2="17" y2="4" stroke="url(#gcl26)" stroke-width="1.5" stroke-linecap="round"/></svg>
    PlacementAI Pro
  </div>
  <div class="f-links">
    <a href="register.php">Register</a>
    <a href="login.php">Login</a>
    <a href="register-org.php">For Organizations</a>
  </div>
  <span>© <?= date('Y') ?> PlacementAI Pro · Built for campus placements</span>
</footer>

<script src="js/app.js?v=5"></script>
<script>
// ── Redirect already-logged-in users ─────────────────────────
(function() {
  try {
    const raw = localStorage.getItem('pai_user') || sessionStorage.getItem('pai_user');
    const u = raw ? JSON.parse(raw) : null;
    if (u && u.id) {
      const dest = u.role==='admin' ? 'admin.php' : u.role==='organization' ? 'organization.php' : 'dashboard.php';
      location.replace(dest);
    }
  } catch(e) {}
})();

// ── Floating particles ────────────────────────────────────────
(function() {
  const hero = document.querySelector('.hero-section');
  if (!hero) return;
  const colors = ['#7c6aff','#a78bfa','#00e5b4','#00c8ff','#f59e0b','#ff6b81'];
  for (let i = 0; i < 22; i++) {
    const p = document.createElement('div');
    p.className = 'particle';
    const size = 2 + Math.random() * 3;
    p.style.cssText = [
      `left:${Math.random()*100}%`,
      `bottom:${5 + Math.random()*60}%`,
      `background:${colors[Math.floor(Math.random()*colors.length)]}`,
      `width:${size}px`,
      `height:${size}px`,
      `border-radius:50%`,
      `--dur:${2.5+Math.random()*4}s`,
      `--delay:${Math.random()*5}s`
    ].join(';');
    hero.appendChild(p);
  }
})();

// ── Scroll reveal ─────────────────────────────────────────────
(function() {
  const obs = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      if (entry.target.classList.contains('feature-card')) {
        const all = document.querySelectorAll('.feature-card');
        const i = Array.from(all).indexOf(entry.target);
        setTimeout(() => entry.target.classList.add('visible'), i * 90);
      } else if (entry.target.classList.contains('step-card')) {
        const all = document.querySelectorAll('.step-card');
        const i = Array.from(all).indexOf(entry.target);
        setTimeout(() => entry.target.style.cssText += ';opacity:1;transform:translateY(0)', i * 120);
      } else {
        entry.target.classList.add('visible');
      }
      obs.unobserve(entry.target);
    });
  }, { threshold: 0.1 });

  document.querySelectorAll('.feature-card').forEach(el => obs.observe(el));
  document.querySelectorAll('.step-card').forEach(el => {
    el.style.cssText += ';opacity:0;transform:translateY(20px);transition:opacity .6s ease,transform .6s cubic-bezier(.4,0,.2,1)';
    obs.observe(el);
  });
  const cta = document.querySelector('.cta-section');
  if (cta) obs.observe(cta);

  // Fallback after 1s
  setTimeout(() => {
    document.querySelectorAll('.feature-card:not(.visible)').forEach(el => el.classList.add('visible'));
    document.querySelectorAll('.step-card').forEach(el => el.style.cssText += ';opacity:1;transform:translateY(0)');
    cta?.classList.add('visible');
  }, 1000);
})();

// ── Navbar scroll effect ──────────────────────────────────────
const nav = document.querySelector('.nav-landing');
if (nav) {
  window.addEventListener('scroll', () => {
    const scrolled = window.scrollY > 50;
    nav.style.background = scrolled ? 'rgba(10,10,10,.97)' : 'rgba(10,10,10,.8)';
    nav.style.boxShadow = scrolled ? '0 1px 0 rgba(255,255,255,.07)' : 'none';
  }, { passive: true });
}

// ── Smooth anchor scroll ──────────────────────────────────────
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const t = document.querySelector(a.getAttribute('href'));
    if (t) { e.preventDefault(); t.scrollIntoView({ behavior: 'smooth' }); }
  });
});
</script>
</body>
</html>

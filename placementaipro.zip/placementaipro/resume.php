<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">  <link rel="icon" type="image/svg+xml" href="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAzMiAzMiIgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIj4KICA8ZGVmcz4KICAgIDxsaW5lYXJHcmFkaWVudCBpZD0iZyIgeDE9IjAiIHkxPSIxIiB4Mj0iMSIgeTI9IjAiPgogICAgICA8c3RvcCBvZmZzZXQ9IjAlIiBzdG9wLWNvbG9yPSIjZmY0NzU3Ii8+CiAgICAgIDxzdG9wIG9mZnNldD0iMTAwJSIgc3RvcC1jb2xvcj0iI2Y1OWUwYiIvPgogICAgPC9saW5lYXJHcmFkaWVudD4KICA8L2RlZnM+CiAgPHJlY3Qgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIiByeD0iNyIgZmlsbD0iIzFlMWExMCIvPgogIDxyZWN0IHg9IjYiIHk9IjIxIiB3aWR0aD0iNSIgaGVpZ2h0PSI5IiByeD0iMS41IiBmaWxsPSIjZjU5ZTBiIiBvcGFjaXR5PSIuNSIvPgogIDxyZWN0IHg9IjEzIiB5PSIxNSIgd2lkdGg9IjUiIGhlaWdodD0iMTUiIHJ4PSIxLjUiIGZpbGw9IiNmZjZiMzUiIG9wYWNpdHk9Ii43NSIvPgogIDxyZWN0IHg9IjIwIiB5PSI4IiB3aWR0aD0iNSIgaGVpZ2h0PSIyMiIgcng9IjEuNSIgZmlsbD0idXJsKCNnKSIvPgogIDxwb2x5bGluZSBwb2ludHM9IjIzLDQgMjcsOCAyNyw1IiBmaWxsPSJub25lIiBzdHJva2U9InVybCgjZykiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIi8+CiAgPGxpbmUgeDE9IjE5IiB5MT0iNSIgeDI9IjI3IiB5Mj0iNCIgc3Ryb2tlPSJ1cmwoI2cpIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPgo8L3N2Zz4=">
  <link rel="icon" type="image/x-icon" href="data:image/x-icon;base64,AAABAAEAEBAAAAAAIACgAAAAFgAAAIlQTkcNChoKAAAADUlIRFIAAAAQAAAAEAgGAAAAH/P/YQAAAGdJREFUeJxjZIACLg6R/wwkgG8/3jAyMDAwMJGjGVkPIzmakQETJZoZGBgYWNAFvn5/jVMxN6co9V1AWwOwOZkkA/CFB1EGEAOoH43IgOIwIAZQnpRhuYoc8O3HG0YmGIMczQwMDAwA+P4aS3/n/2IAAAAASUVORK5CYII=">
  <link rel="icon" type="image/png" sizes="32x32" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAoElEQVR4nO2XvQ6AIAyES+Pgz6rv/4Cyimw6kWhDxID0HLixabyPozHUUERjPx+xeqmct0bWboVaxk8grG0uvVjbXEJwqrG2DOL0V8ET6FIN275mfXgalld98AQaABwgOYQxyQHLHVSiHyTQALJmoOTOpeAJNAA4wCc/ohLBE2gAcAD8ozS2LmnJeWvgV8CBRNs4eLIsaJoTie04SHM9PwGQNi1E3UY9bQAAAABJRU5ErkJggg==">
  <link rel="icon" type="image/png" sizes="192x192" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMAAAADACAYAAABS3GwHAAADvklEQVR4nO3dQVLjVgBFUZvqASFTsv8FhmkIMzJIdRc0YCxL8pd8z1kAaPCuvmy61MfDxjzcP76OvgbW8/zydBx9DW8NvRhj53AYG8XVf7HRc8q1Y7jaLzN8prhWCKv/EsNnjrVDWO2HGz5LWiuExX+o4bOmpUO4W/KHGT9rW3pji9Rk+IywxGkw+wQwfkZZYnuzAjB+Rpu7wYsDMH62Ys4WLwrA+NmaSzc5OQDjZ6su2eakAIyfrZu60bMDMH72YspWzwrA+Nmbczf7bQDGz16ds91F/ykE7M3JANz92bvvNvxlAMbPrTi1ZY9ApH0agLs/t+arTTsBSPsQgLs/t+qzbTsBSHsXgLs/t+73jTsBSPsVgLs/FW+37gQgTQCk3R0OHn/o+bl5JwBpAiBNAKQJgLSjD8CUOQFIEwBpAiBNAKQJgDQBkPZj9AXM9c+/f4++hF3584+/Rl/CpjgBSBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYC03b8VYi0j356w1psuvBHiIycAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANKOD/ePr6MvYo61XiV+q7wi/T0nAGkCIE0ApAmANAGQJgDSBECaAEgTAGkCIE0ApAmANAGQJgDSBECaAEgTAGkCIE0ApAmANAGQ9mP0BWyVtyc0OAFIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0o4P94+voy8CRnECkCYA0gRAmgBIEwBpd88vT8fRFwEjPL88HZ0ApAmANAGQJgDS7g6H/z8MjL4QuKafm3cCkCYA0n4F4DGIirdbdwKQ9i4ApwC37veNOwFI+xCAU4Bb9dm2nQCkfRqAU4Bb89WmnQCkfRmAU4BbcWrLJ08AEbB3323YIxBp3wbgFGCvztnuWSeACNibczd79iOQCNiLKVud9BlABGzd1I1O/hAsArbqkm1e9C2QCNiaSzd58degImAr5mxx1t8BRMBoczc4+w9hImCUJba36Hj9bzNcw5I33UX/KYTTgLUtvbHVBus0YElr3VxXv2MLgTnWfqq42iOLEJjiWo/TV39mFwKnXPtz5NAPrWLgcBj75cnmvrURxW3b2jeF/wGOq9fsu4f8UQAAAABJRU5ErkJggg==">
  <link rel="apple-touch-icon" sizes="180x180" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAAC0CAYAAAA9zQYyAAADX0lEQVR4nO3cOXJaQQBFUVA58JDa+1+glVpWZgceygOS/kh/rs5ZAOrg8tRAwfl0AO/ffvw2+gys9/B4fx59hiEHEPDrMCLwq/1BEb9u14p71z8iYi7ZM+5dHljITLFH2HdbP6CYmWqPVjZ7hgiZNbZa600WWsystVVDq54VQmYPa9Z68UKLmb2saWtR0GJmb0sbmx20mLmWJa3NClrMXNvc5iYHLWZGmdPepKDFzGhTG3wxaDFzFFNa3Pyjbxjp2aCtM0fzUpNPBi1mjuq5Nl05SLkYtHXm6J5q9L+gxcytuNSqKwcpfwVtnbk1/zZroUkRNCm/g3bd4Fb92a6FJkXQpNydTq4b3L5fDVtoUgRNiqBJObs/U2KhSRE0KYImRdCkCJoUQZPyZvQBlvjy9fPoIxzWh3efRh9hKAtNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiblJr8ku4cRXy71Zd/tWWhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCl+rPEnP5zYYKFJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KT4kuxPH959Gn0ENmChSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJqU8/u3H7+NPgRsxUKTImhSBE2KoEkRNCl3D4/359GHgC08PN6fLTQpgiZF0KTcnU4/7h6jDwJr/GrYQpMiaFJ+B+3awa36s10LTYqgSfkraNcObs2/zVpoUv4L2kpzKy61enGhRc3RPdWoKwcpTwZtpTmq59p8dqFFzdG81KQrBykvBm2lOYopLU5aaFEz2tQGJ185RM0oc9qbdYcWNdc2t7nZLwpFzbUsaW3RuxyiZm9LG1v8tp2o2cuatjaJ0k/ysoUtRnKTD1asNWtt1dDmIVpr5th6DDf/6NtaM9Uerewan7Xmkj1H72prKu7X7Vr/uYdcD8T9Ooy4fh7ivivwhiO8fvoO2onGYhMioSEAAAAASUVORK5CYII=">
  <title>Resume Analyzer — PlacementAI Pro</title>
  <link rel="stylesheet" href="css/style.css?v=5">
  <style>
    .upload-zone-new {
      border: 2px dashed var(--border2);
      border-radius: var(--radius-lg);
      padding: 56px 32px;
      text-align: center;
      cursor: pointer;
      transition: all .25s;
      position: relative;
      background: linear-gradient(135deg, var(--bg2) 0%, rgba(108,99,255,.03) 100%);
    }
    .upload-zone-new:hover, .upload-zone-new.dragover {
      border-color: var(--primary);
      background: rgba(108,99,255,.06);
    }
    .upload-zone-new h3 { color: var(--text); margin-bottom: 8px; }
    .upload-zone-new p { color: var(--text3); font-size: 13.5px; margin-bottom: 20px; }
    .browse-btn {
      display: inline-flex; align-items: center; gap: 8px;
      padding: 10px 22px; background: var(--primary-g); color: #fff;
      border-radius: 9px; font-size: 14px; font-weight: 600;
      cursor: pointer; border: none;
      box-shadow: 0 4px 14px rgba(108,99,255,.35);
      transition: transform .15s, box-shadow .15s;
    }
    .browse-btn:hover { transform: translateY(-1px); box-shadow: 0 6px 20px rgba(108,99,255,.45); }
    .ats-score-card { text-align:center; padding:20px 16px; background:var(--bg2); border:1px solid var(--border); border-radius:var(--radius); }
    .skill-tag { display:inline-block; padding:3px 10px; margin:3px; border-radius:99px; font-size:12px; font-weight:600; background:rgba(108,99,255,.1); border:1px solid rgba(108,99,255,.2); color:var(--primary-l); }
    .skill-tags { display:flex; flex-wrap:wrap; }
    .imp-item { display:flex; gap:10px; padding:12px; background:var(--bg2); border-radius:10px; margin-bottom:8px; border:1px solid var(--border); }
    .imp-num { width:22px; height:22px; border-radius:50%; background:var(--primary); color:#fff; display:flex; align-items:center; justify-content:center; font-size:11px; font-weight:700; flex-shrink:0; }
  </style>
</head>
<body>
<script src="js/app.js?v=5"></script>
<script>
const user = Auth.requireAuth('student');
if (user) { buildShell('resume'); setTimeout(()=>initResume(), 0); }

let selectedFile = null;

function initResume() {
  document.getElementById('topbarTitle').textContent = 'AI Resume Analyzer';
  const page = document.getElementById('mainPage');

  page.innerHTML = `
    <div class="page-header">
      <h1 style="font-size:1.6rem">📄 AI Resume Analyzer</h1>
      <p style="color:var(--text3);font-size:13px;margin-top:2px">Instant ATS score · Keyword gap analysis · Section scores · AI line-by-line improvements</p>
    </div>

    <div id="uploadSection" style="max-width:640px;margin:0 auto">
      <div id="alertBox"></div>

      <div class="upload-zone-new" id="dropZone">
        <div class="upload-icon" style="margin:0 auto 16px">
          <svg width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
            <polyline points="14 2 14 8 20 8"/>
            <line x1="12" y1="18" x2="12" y2="12"/>
            <polyline points="9 15 12 12 15 15"/>
          </svg>
        </div>
        <h3 style="margin-bottom:6px">Drop your resume here</h3>
        <p>PDF only · Max 5 MB · Results in ~15 seconds</p>
        <label for="resumeFileInput" class="browse-btn">
          <svg width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
          Browse File
        </label>
        <input type="file" id="resumeFileInput" accept=".pdf,application/pdf" style="display:none">
        <div style="margin-top:12px;font-size:12px;color:var(--text3)">or drag &amp; drop your PDF here</div>
      </div>

      <div id="filePreview" style="display:none;margin-top:16px" class="card">
        <div style="display:flex;align-items:center;gap:12px">
          <div style="width:42px;height:42px;background:rgba(239,68,68,.12);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:1.3rem">📄</div>
          <div style="flex:1">
            <div id="fileName" style="font-weight:600;color:var(--text);font-size:14px"></div>
            <div id="fileSize" style="font-size:12px;color:var(--text3)"></div>
          </div>
          <button onclick="clearFile()" class="btn btn-ghost btn-sm">✕ Remove</button>
        </div>
      </div>

      <button id="analyzeBtn" onclick="analyzeResume()" class="btn btn-primary btn-lg w-full mt-3" style="display:none;justify-content:center;gap:8px">
        <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
        Analyze Resume with AI
      </button>
      <div id="analyzeHint" style="font-size:11.5px;color:var(--text3);text-align:center;margin-top:8px;display:none">📊 Scores: ATS · Keywords · Sections · Job Match · Improvements</div>
    </div>

    <!-- Results -->
    <div id="resultsSection" style="display:none;margin-top:0">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px">
        <h2>📊 Analysis Report</h2>
        <button onclick="resetAnalyzer()" class="btn btn-ghost btn-sm">← Analyze Another</button>
      </div>
      <div class="grid-4 mb-6" id="scoreCards"></div>
      <div class="grid-2 mb-4">
        <div class="card"><div class="card-title mb-4">Section Scores</div><div id="sectionScores"></div></div>
        <div class="card"><div class="card-title mb-4">ATS Issues</div><div id="atsIssues"></div></div>
      </div>
      <div class="card">
        <div class="tabs" id="analysisTabs">
          <button class="tab-btn active" data-tab="improvements-tab">💡 Improvements</button>
          <button class="tab-btn" data-tab="keywords-tab">🔑 Keywords</button>
          <button class="tab-btn" data-tab="strengths-tab">✅ Strengths</button>
          <button class="tab-btn" data-tab="parsed-tab">📋 Parsed Data</button>
        </div>
        <div id="improvements-tab" class="tab-pane active"></div>
        <div id="keywords-tab" class="tab-pane"></div>
        <div id="strengths-tab" class="tab-pane"></div>
        <div id="parsed-tab" class="tab-pane"></div>
      </div>
    </div>`;

  // File input via label (proper click-to-browse)
  const fileInput = document.getElementById('resumeFileInput');
  fileInput.addEventListener('change', function() {
    if (this.files && this.files[0]) handleFile(this.files[0]);
  });

  // Drag and drop on the zone
  const zone = document.getElementById('dropZone');
  zone.addEventListener('dragover', e => { e.preventDefault(); zone.classList.add('dragover'); });
  zone.addEventListener('dragleave', () => zone.classList.remove('dragover'));
  zone.addEventListener('drop', e => {
    e.preventDefault();
    zone.classList.remove('dragover');
    const f = e.dataTransfer.files[0];
    if (f) handleFile(f);
  });

  initTabs(document.getElementById('analysisTabs'));
}

function handleFile(file) {
  const alertBox = document.getElementById('alertBox');
  if (!file) return;
  if (file.type !== 'application/pdf' && !file.name.toLowerCase().endsWith('.pdf')) {
    showAlert(alertBox, 'Please upload a PDF file.'); return;
  }
  if (file.size > 5 * 1024 * 1024) {
    showAlert(alertBox, 'File too large. Max 5 MB.'); return;
  }
  clearAlert(alertBox);
  selectedFile = file;
  document.getElementById('fileName').textContent = file.name;
  document.getElementById('fileSize').textContent = (file.size / 1024).toFixed(0) + ' KB';
  document.getElementById('filePreview').style.display = 'block';
  document.getElementById('analyzeBtn').style.display = 'flex';
  document.getElementById('analyzeHint').style.display = 'block';
  document.getElementById('dropZone').style.display = 'none';
}

function clearFile() {
  selectedFile = null;
  document.getElementById('filePreview').style.display = 'none';
  document.getElementById('analyzeBtn').style.display = 'none';
  document.getElementById('dropZone').style.display = 'block';
  document.getElementById('resumeFileInput').value = '';
}

function resetAnalyzer() {
  clearFile();
  document.getElementById('uploadSection').style.display = 'block';
  document.getElementById('resultsSection').style.display = 'none';
}

async function analyzeResume() {
  if (!selectedFile) return;
  const btn = document.getElementById('analyzeBtn');
  loading(btn, true, 'Analyzing with AI…');

  try {
    const fd = new FormData();
    fd.append('resume', selectedFile);
    fd.append('user_id', user.id);
    const data = await API.postForm('resume_analyze.php', fd);
    if (!data.success) throw new Error(data.message || 'Analysis failed');
    document.getElementById('uploadSection').style.display = 'none';
    document.getElementById('resultsSection').style.display = 'block';
    renderResults(data);
  } catch(e) {
    loading(btn, false);
    showAlert(document.getElementById('alertBox'), e.message || 'Analysis failed. Ensure API key is set in config.php.');
  }
}

function progressBar(label, val, max, color='green') {
  const pct = Math.round((val / max) * 100);
  const colors = { green:'var(--emerald)', amber:'var(--accent2)', rose:'var(--red)' };
  return `<div style="margin-bottom:14px">
    <div style="display:flex;justify-content:space-between;margin-bottom:5px">
      <span style="font-size:13px;color:var(--text2)">${esc(label)}</span>
      <span style="font-size:13px;font-weight:700;color:${colors[color]||'var(--primary)'}">${pct}%</span>
    </div>
    <div style="height:6px;background:var(--border);border-radius:99px;overflow:hidden">
      <div style="height:100%;width:${pct}%;background:${colors[color]||'var(--primary)'};border-radius:99px;transition:width .6s ease"></div>
    </div>
  </div>`;
}

function renderResults(d) {
  const overall = d.overall_score || d.score || 0;
  const ats = d.ats_score || 0;
  const kwMatch = d.scores?.keyword_match ? Math.round(d.scores.keyword_match / 30 * 100) : 0;
  const jobMatch = d.job_match?.score || 0;

  document.getElementById('scoreCards').innerHTML = `
    <div class="ats-score-card">${scoreRing(overall, 110)}<div style="font-size:12px;color:var(--text3);margin-top:8px;font-weight:600">Overall Score</div></div>
    <div class="ats-score-card">${scoreRing(ats, 110, '#10b981')}<div style="font-size:12px;color:var(--text3);margin-top:8px;font-weight:600">ATS Score</div></div>
    <div class="ats-score-card">${scoreRing(kwMatch, 110, '#f59e0b')}<div style="font-size:12px;color:var(--text3);margin-top:8px;font-weight:600">Keyword Match</div></div>
    <div class="ats-score-card">${scoreRing(jobMatch, 110, '#06b6d4')}<div style="font-size:12px;color:var(--text3);margin-top:8px;font-weight:600">Job Match</div></div>`;

  const ss = d.section_scores || {};
  document.getElementById('sectionScores').innerHTML =
    Object.entries(ss).map(([k,v]) => progressBar(k.charAt(0).toUpperCase()+k.slice(1), v, 100, v>=70?'green':v>=40?'amber':'rose')).join('') ||
    '<p style="font-size:13px;color:var(--text3)">No section data</p>';

  const issues = d.ats_issues || [];
  document.getElementById('atsIssues').innerHTML = issues.length
    ? issues.map(i=>`<div style="display:flex;gap:10px;margin-bottom:12px;align-items:flex-start">
        <span class="badge ${i.severity==='high'?'badge-red':i.severity==='medium'?'badge-amber':'badge-cyan'}" style="flex-shrink:0">${i.severity}</span>
        <span style="font-size:13px;color:var(--text2)">${esc(i.issue)}</span></div>`).join('')
    : '<div class="alert alert-success">✓ No major ATS issues found!</div>';

  const imps = d.improvements || d.feedback || [];
  document.getElementById('improvements-tab').innerHTML = imps.length
    ? `<ul style="list-style:none;display:flex;flex-direction:column;gap:12px;padding:4px 0">
        ${imps.map((imp,i)=>`<li style="display:flex;gap:12px;align-items:flex-start">
          <span style="background:var(--primary);color:#fff;width:22px;height:22px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;flex-shrink:0">${i+1}</span>
          <span style="font-size:13.5px;color:var(--text2);line-height:1.6">${esc(imp)}</span></li>`).join('')}</ul>`
    : '<p style="color:var(--text3);font-size:13px;padding:4px 0">Excellent resume — no major improvements needed!</p>';

  const kf = d.keywords_found || d.skillsExtracted || [];
  const km = d.keywords_missing || [];
  document.getElementById('keywords-tab').innerHTML = `
    <div style="margin-bottom:20px">
      <div style="font-size:11px;font-weight:700;color:var(--emerald);margin-bottom:10px;text-transform:uppercase;letter-spacing:.08em">✓ Found (${kf.length})</div>
      <div class="skill-tags">${kf.map(k=>`<span class="skill-tag">${esc(k)}</span>`).join('') || '—'}</div>
    </div>
    <div>
      <div style="font-size:11px;font-weight:700;color:var(--red);margin-bottom:10px;text-transform:uppercase;letter-spacing:.08em">✗ Missing (${km.length})</div>
      <div class="skill-tags">${km.map(k=>`<span class="skill-tag" style="background:rgba(239,68,68,.1);color:var(--red);border-color:rgba(239,68,68,.25)">${esc(k)}</span>`).join('') || 'None — great coverage!'}</div>
    </div>`;

  const str = d.strengths || [];
  document.getElementById('strengths-tab').innerHTML = str.length
    ? str.map(s=>`<div style="display:flex;gap:10px;margin-bottom:12px">
        <span style="color:var(--emerald);font-size:1.1rem">✓</span>
        <span style="font-size:13.5px;color:var(--text2)">${esc(s)}</span></div>`).join('')
    : '<p style="color:var(--text3);font-size:13px">No specific strengths identified.</p>';

  const p = d.parsed || {};
  document.getElementById('parsed-tab').innerHTML = `
    <div class="grid-2">
      <div>
        <div style="font-size:11px;color:var(--text3);text-transform:uppercase;letter-spacing:.08em;margin-bottom:8px">Contact</div>
        <div style="font-size:13px;color:var(--text2);line-height:1.9">${esc(p.name||'—')}<br>${esc(p.email||'—')}<br>${esc(p.phone||'—')}</div>
      </div>
      <div>
        <div style="font-size:11px;color:var(--text3);text-transform:uppercase;letter-spacing:.08em;margin-bottom:8px">Skills Detected</div>
        <div class="skill-tags">${(p.skills||[]).map(s=>`<span class="skill-tag">${esc(s)}</span>`).join('') || '—'}</div>
      </div>
    </div>`;
}
</script>
</body>
</html>

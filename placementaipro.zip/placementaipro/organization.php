<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">  <link rel="icon" type="image/svg+xml" href="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAzMiAzMiIgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIj4KICA8ZGVmcz4KICAgIDxsaW5lYXJHcmFkaWVudCBpZD0iZyIgeDE9IjAiIHkxPSIxIiB4Mj0iMSIgeTI9IjAiPgogICAgICA8c3RvcCBvZmZzZXQ9IjAlIiBzdG9wLWNvbG9yPSIjZmY0NzU3Ii8+CiAgICAgIDxzdG9wIG9mZnNldD0iMTAwJSIgc3RvcC1jb2xvcj0iI2Y1OWUwYiIvPgogICAgPC9saW5lYXJHcmFkaWVudD4KICA8L2RlZnM+CiAgPHJlY3Qgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIiByeD0iNyIgZmlsbD0iIzFlMWExMCIvPgogIDxyZWN0IHg9IjYiIHk9IjIxIiB3aWR0aD0iNSIgaGVpZ2h0PSI5IiByeD0iMS41IiBmaWxsPSIjZjU5ZTBiIiBvcGFjaXR5PSIuNSIvPgogIDxyZWN0IHg9IjEzIiB5PSIxNSIgd2lkdGg9IjUiIGhlaWdodD0iMTUiIHJ4PSIxLjUiIGZpbGw9IiNmZjZiMzUiIG9wYWNpdHk9Ii43NSIvPgogIDxyZWN0IHg9IjIwIiB5PSI4IiB3aWR0aD0iNSIgaGVpZ2h0PSIyMiIgcng9IjEuNSIgZmlsbD0idXJsKCNnKSIvPgogIDxwb2x5bGluZSBwb2ludHM9IjIzLDQgMjcsOCAyNyw1IiBmaWxsPSJub25lIiBzdHJva2U9InVybCgjZykiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIi8+CiAgPGxpbmUgeDE9IjE5IiB5MT0iNSIgeDI9IjI3IiB5Mj0iNCIgc3Ryb2tlPSJ1cmwoI2cpIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPgo8L3N2Zz4=">
  <link rel="icon" type="image/x-icon" href="data:image/x-icon;base64,AAABAAEAEBAAAAAAIACgAAAAFgAAAIlQTkcNChoKAAAADUlIRFIAAAAQAAAAEAgGAAAAH/P/YQAAAGdJREFUeJxjZIACLg6R/wwkgG8/3jAyMDAwMJGjGVkPIzmakQETJZoZGBgYWNAFvn5/jVMxN6co9V1AWwOwOZkkA/CFB1EGEAOoH43IgOIwIAZQnpRhuYoc8O3HG0YmGIMczQwMDAwA+P4aS3/n/2IAAAAASUVORK5CYII=">
  <link rel="icon" type="image/png" sizes="32x32" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAoElEQVR4nO2XvQ6AIAyES+Pgz6rv/4Cyimw6kWhDxID0HLixabyPozHUUERjPx+xeqmct0bWboVaxk8grG0uvVjbXEJwqrG2DOL0V8ET6FIN275mfXgalld98AQaABwgOYQxyQHLHVSiHyTQALJmoOTOpeAJNAA4wCc/ohLBE2gAcAD8ozS2LmnJeWvgV8CBRNs4eLIsaJoTie04SHM9PwGQNi1E3UY9bQAAAABJRU5ErkJggg==">
  <link rel="icon" type="image/png" sizes="192x192" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMAAAADACAYAAABS3GwHAAADvklEQVR4nO3dQVLjVgBFUZvqASFTsv8FhmkIMzJIdRc0YCxL8pd8z1kAaPCuvmy61MfDxjzcP76OvgbW8/zydBx9DW8NvRhj53AYG8XVf7HRc8q1Y7jaLzN8prhWCKv/EsNnjrVDWO2HGz5LWiuExX+o4bOmpUO4W/KHGT9rW3pji9Rk+IywxGkw+wQwfkZZYnuzAjB+Rpu7wYsDMH62Ys4WLwrA+NmaSzc5OQDjZ6su2eakAIyfrZu60bMDMH72YspWzwrA+Nmbczf7bQDGz16ds91F/ykE7M3JANz92bvvNvxlAMbPrTi1ZY9ApH0agLs/t+arTTsBSPsQgLs/t+qzbTsBSHsXgLs/t+73jTsBSPsVgLs/FW+37gQgTQCk3R0OHn/o+bl5JwBpAiBNAKQJgLSjD8CUOQFIEwBpAiBNAKQJgDQBkPZj9AXM9c+/f4++hF3584+/Rl/CpjgBSBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYC03b8VYi0j356w1psuvBHiIycAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANKOD/ePr6MvYo61XiV+q7wi/T0nAGkCIE0ApAmANAGQJgDSBECaAEgTAGkCIE0ApAmANAGQJgDSBECaAEgTAGkCIE0ApAmANAGQ9mP0BWyVtyc0OAFIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0o4P94+voy8CRnECkCYA0gRAmgBIEwBpd88vT8fRFwEjPL88HZ0ApAmANAGQJgDS7g6H/z8MjL4QuKafm3cCkCYA0n4F4DGIirdbdwKQ9i4ApwC37veNOwFI+xCAU4Bb9dm2nQCkfRqAU4Bb89WmnQCkfRmAU4BbcWrLJ08AEbB3323YIxBp3wbgFGCvztnuWSeACNibczd79iOQCNiLKVud9BlABGzd1I1O/hAsArbqkm1e9C2QCNiaSzd58degImAr5mxx1t8BRMBoczc4+w9hImCUJba36Hj9bzNcw5I33UX/KYTTgLUtvbHVBus0YElr3VxXv2MLgTnWfqq42iOLEJjiWo/TV39mFwKnXPtz5NAPrWLgcBj75cnmvrURxW3b2jeF/wGOq9fsu4f8UQAAAABJRU5ErkJggg==">
  <link rel="apple-touch-icon" sizes="180x180" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAAC0CAYAAAA9zQYyAAADX0lEQVR4nO3cOXJaQQBFUVA58JDa+1+glVpWZgceygOS/kh/rs5ZAOrg8tRAwfl0AO/ffvw2+gys9/B4fx59hiEHEPDrMCLwq/1BEb9u14p71z8iYi7ZM+5dHljITLFH2HdbP6CYmWqPVjZ7hgiZNbZa600WWsystVVDq54VQmYPa9Z68UKLmb2saWtR0GJmb0sbmx20mLmWJa3NClrMXNvc5iYHLWZGmdPepKDFzGhTG3wxaDFzFFNa3Pyjbxjp2aCtM0fzUpNPBi1mjuq5Nl05SLkYtHXm6J5q9L+gxcytuNSqKwcpfwVtnbk1/zZroUkRNCm/g3bd4Fb92a6FJkXQpNydTq4b3L5fDVtoUgRNiqBJObs/U2KhSRE0KYImRdCkCJoUQZPyZvQBlvjy9fPoIxzWh3efRh9hKAtNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiblJr8ku4cRXy71Zd/tWWhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCl+rPEnP5zYYKFJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KT4kuxPH959Gn0ENmChSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJqU8/u3H7+NPgRsxUKTImhSBE2KoEkRNCl3D4/359GHgC08PN6fLTQpgiZF0KTcnU4/7h6jDwJr/GrYQpMiaFJ+B+3awa36s10LTYqgSfkraNcObs2/zVpoUv4L2kpzKy61enGhRc3RPdWoKwcpTwZtpTmq59p8dqFFzdG81KQrBykvBm2lOYopLU5aaFEz2tQGJ185RM0oc9qbdYcWNdc2t7nZLwpFzbUsaW3RuxyiZm9LG1v8tp2o2cuatjaJ0k/ysoUtRnKTD1asNWtt1dDmIVpr5th6DDf/6NtaM9Uerewan7Xmkj1H72prKu7X7Vr/uYdcD8T9Ooy4fh7ivivwhiO8fvoO2onGYhMioSEAAAAASUVORK5CYII=">
  <title>Org Portal — PlacementAI Pro</title>
  <link rel="stylesheet" href="css/style.css?v=5">
</head>
<body>
<script src="js/app.js?v=5"></script>
<script>
const user = Auth.requireAuth('organization');
if (user) { buildShell('organization'); setTimeout(()=>initOrg(), 0); }

async function initOrg() {
  document.getElementById('topbarTitle').textContent = 'Organization Portal';
  document.getElementById('topbarActions').innerHTML = `<button class="btn btn-primary btn-sm" onclick="openModal('postJobModal')">${iconPlus()} Post Job</button>`;
  const page = document.getElementById('mainPage');

  page.innerHTML = `
    <div class="page-header">
      <h1>🏢 Organization Portal</h1>
      <p class="breadcrumb">Manage jobs, review applicants and hire top talent</p>
    </div>

    <!-- Stats -->
    <div class="grid-4 mb-6" id="orgStats">
      <div class="loading-center" style="grid-column:1/-1"><div class="spinner"></div></div>
    </div>

    <!-- Tabs -->
    <div class="tabs" id="orgTabs">
      <button class="tab-btn active" data-tab="jobs-panel">My Jobs</button>
      <button class="tab-btn" data-tab="students-panel">Browse Students</button>
      <button class="tab-btn" data-tab="interviews-panel" id="interviewTab">📅 Interviews</button>
      <button class="tab-btn" data-tab="aptitude-panel" id="aptitudeTab">📝 Aptitude Questions</button>
    </div>
    <div id="jobs-panel" class="tab-pane active" style="margin-top:16px"></div>
    <div id="students-panel" class="tab-pane" style="margin-top:16px"></div>
    <div id="interviews-panel" class="tab-pane" style="margin-top:16px"></div>
    <div id="aptitude-panel" class="tab-pane" style="margin-top:16px"></div>

    <!-- Post job modal -->
    <div class="modal-overlay" id="postJobModal">
      <div class="modal" style="max-width:600px">
        <div class="modal-header">
          <div class="modal-title">Post New Job</div>
          <button class="modal-close" onclick="closeModal('postJobModal')">${iconX()}</button>
        </div>
        <div id="postJobAlert"></div>
        <form id="postJobForm">
          <div class="form-group"><label class="form-label">Job Title *</label><input type="text" id="jTitle" class="form-input" placeholder="Software Engineer" required></div>
          <div class="form-group"><label class="form-label">Job Description *</label><textarea id="jDesc" class="form-textarea" rows="4" placeholder="Describe the role, responsibilities…" required></textarea></div>
          <div class="form-group"><label class="form-label">Required Skills</label><input type="text" id="jSkills" class="form-input" placeholder="Python, Java, SQL, AWS…"></div>
          <div class="form-row">
            <div class="form-group"><label class="form-label">Min CGPA</label><input type="number" id="jMinCgpa" class="form-input" value="6.0" min="0" max="10" step="0.1"></div>
            <div class="form-group"><label class="form-label">Experience Level</label><select id="jExp" class="form-select"><option>Entry</option><option>Mid</option><option>Senior</option></select></div>
          </div>
          <div class="form-row">
            <div class="form-group"><label class="form-label">Location</label><input type="text" id="jLocation" class="form-input" placeholder="Bangalore / Remote"></div>
            <div class="form-group"><label class="form-label">Salary Range</label><input type="text" id="jSalary" class="form-input" placeholder="8-12 LPA"></div>
          </div>
          <button type="submit" id="postJobBtn" class="btn btn-primary w-full">Post Job</button>
        </form>
      </div>
    </div>`;

  initTabs(document.getElementById('orgTabs'));
  document.querySelector('[data-tab="students-panel"]').addEventListener('click', loadStudents);
  document.querySelector('[data-tab="interviews-panel"]').addEventListener('click', loadInterviews);
  document.querySelector('[data-tab="aptitude-panel"]').addEventListener('click', loadAptitudePanel);

  // Check for tab param in URL
  const urlTab = new URLSearchParams(location.search).get('tab');
  if (urlTab === 'aptitude') {
    document.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
    document.querySelector('[data-tab="aptitude-panel"]')?.classList.add('active');
    document.querySelectorAll('.tab-pane').forEach(p=>p.classList.remove('active'));
    document.getElementById('aptitude-panel')?.classList.add('active');
    loadAptitudePanel();
  }

  loadOrgData();

  document.getElementById('postJobForm').addEventListener('submit', async e=>{
    e.preventDefault();
    const btn = document.getElementById('postJobBtn');
    loading(btn, true, 'Posting…');
    clearAlert(document.getElementById('postJobAlert'));
    try {
      await API.post('org_panel.php', {
        action:'create_job', user_id:user.id,
        title:   document.getElementById('jTitle').value.trim(),
        description: document.getElementById('jDesc').value.trim(),
        required_skills: document.getElementById('jSkills').value.trim(),
        min_cgpa: parseFloat(document.getElementById('jMinCgpa').value)||0,
        experience_level: document.getElementById('jExp').value,
        location: document.getElementById('jLocation').value.trim(),
        salary_range: document.getElementById('jSalary').value.trim()
      });
      closeModal('postJobModal');
      document.getElementById('postJobForm').reset();
      await loadOrgData();
    } catch(err) {
      loading(btn, false);
      showAlert(document.getElementById('postJobAlert'), err.message);
    }
  });
}

async function loadOrgData() {
  try {
    const [ov, jobs] = await Promise.all([
      API.post('org_panel.php', {action:'overview', user_id:user.id}),
      API.post('org_panel.php', {action:'jobs', user_id:user.id})
    ]);

    const o = ov.overview||{};
    document.getElementById('orgStats').innerHTML = `
      <div class="stat-card"><div class="stat-icon purple">${iconBriefcase()}</div><div class="stat-value">${o.total_jobs||0}</div><div class="stat-label">Total Jobs</div></div>
      <div class="stat-card accent-green"><div class="stat-icon green">${iconUsers()}</div><div class="stat-value">${o.total_apps||0}</div><div class="stat-label">Applications</div></div>
      <div class="stat-card accent-amber"><div class="stat-icon amber">${iconStar()}</div><div class="stat-value">${o.shortlisted||0}</div><div class="stat-label">Shortlisted</div></div>
      <div class="stat-card accent-rose"><div class="stat-icon rose">${iconTrophy()}</div><div class="stat-value">${o.hired||0}</div><div class="stat-label">Hired</div></div>`;

    const jList = jobs.jobs||[];
    document.getElementById('jobs-panel').innerHTML = jList.length ? `
      <div class="grid-auto">
        ${jList.map(j=>`
          <div class="card">
            <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:10px;margin-bottom:12px">
              <div>
                <div style="font-family:var(--font-display);font-size:15px;font-weight:700;color:var(--text);margin-bottom:4px">${esc(j.title)}</div>
                <div style="font-size:12px;color:var(--text3)">${esc(j.location||'—')} · ${esc(j.salary_range||'—')}</div>
              </div>
              ${j.is_active ? '<span class="badge badge-green">Active</span>' : '<span class="badge badge-gray">Paused</span>'}
            </div>
            <div style="display:flex;gap:7px;flex-wrap:wrap;margin-bottom:14px">
              <span class="badge badge-cyan">${j.applicant_count||0} applicants</span>
              <span class="badge badge-gray">Min CGPA ${j.min_cgpa}</span>
            </div>
            <div style="display:flex;gap:8px">
              <button onclick="viewApplicants(${j.id})" class="btn btn-secondary btn-sm" style="flex:1">View Applicants</button>
              <button onclick="toggleJob(${j.id},this)" class="btn btn-ghost btn-sm">${j.is_active?'Pause':'Resume'}</button>
            </div>
          </div>`).join('')}
      </div>` : `<div class="empty-state"><h4>No jobs posted yet</h4><p>Click "Post Job" to create your first listing</p></div>`;
  } catch(e) {
    document.getElementById('orgStats').innerHTML = `<div class="alert alert-error" style="grid-column:1/-1">${esc(e.message)}</div>`;
  }
}

async function loadStudents() {
  const panel = document.getElementById('students-panel');
  if (panel.innerHTML.trim()) return;
  panel.innerHTML = '<div class="loading-center"><div class="spinner"></div></div>';
  try {
    const d = await API.post('org_panel.php', {action:'students', user_id:user.id});
    const students = d.students||[];
    window._stuData = students;
    panel.innerHTML = `
      <div class="mb-4"><div class="input-group"><span class="input-icon">${iconSearch()}</span><input type="text" id="stuSearch" class="form-input" placeholder="Search by name or skill…" oninput="filterStudents(this.value)"></div></div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Student</th><th>Branch</th><th>CGPA</th><th>Skills</th><th>Resume</th><th>Actions</th></tr></thead>
          <tbody id="stuTbody">${stuRows(students)}</tbody>
        </table>
      </div>`;
  } catch(e) { panel.innerHTML=`<div class="alert alert-error">${esc(e.message)}</div>`; }
}

function stuRows(arr) {
  // Store a local ref so filtered arrays still resolve correctly
  window._stuRowsRef = arr;
  return arr.slice(0,50).map((s,i)=>`<tr>
    <td><div class="td-main">${esc(s.name)}</div><div style="font-size:11px;color:var(--text3)">${esc(s.email)}</div></td>
    <td>${esc(s.branch||'—')}</td>
    <td style="font-weight:700;color:${parseFloat(s.cgpa)>=8?'var(--emerald)':'var(--text2)'}">${s.cgpa||'—'}</td>
    <td style="max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:12px;color:var(--text3)">${esc((s.skills||'').slice(0,40))||'—'}</td>
    <td>${s.resume_score ? `<span style="font-weight:700;color:${s.resume_score>=70?'var(--emerald)':'var(--accent2)'}">${s.resume_score}</span>` : '—'}</td>
    <td><button class="btn btn-ghost btn-sm" onclick="viewStudentProfile(window._stuRowsRef[${i}])">View</button></td>
  </tr>`).join('');
}

function filterStudents(q) {
  const filtered = (window._stuData||[]).filter(s=>`${s.name} ${s.skills} ${s.email}`.toLowerCase().includes(q.toLowerCase()));
  document.getElementById('stuTbody').innerHTML = stuRows(filtered);
}

async function toggleJob(id, btn) {
  loading(btn, true);
  try { await API.post('org_panel.php', {action:'toggle_job', user_id:user.id, job_id:id}); await loadOrgData(); }
  catch(e) { loading(btn, false); }
}

// ── Applicant Management ────────────────────────────────────
let _currentJobId = null;

async function viewApplicants(jobId) {
  _currentJobId = jobId;

  // Inject modal if not present
  if (!document.getElementById('applicantsModal')) {
    const m = document.createElement('div');
    m.className = 'modal-overlay';
    m.id = 'applicantsModal';
    m.innerHTML = `
      <div class="modal" style="max-width:820px;width:95vw">
        <div class="modal-header">
          <div>
            <div class="modal-title" id="applicantsTitle">Applicants</div>
            <div id="applicantsSubtitle" style="font-size:12px;color:var(--text3);margin-top:2px"></div>
          </div>
          <button class="modal-close" onclick="closeModal('applicantsModal')">${iconX()}</button>
        </div>

        <!-- Status filter tabs -->
        <div style="display:flex;gap:6px;flex-wrap:wrap;padding:0 0 14px 0;border-bottom:1px solid var(--border);margin-bottom:16px">
          ${[['all','All'],['applied','Applied'],['shortlisted','Shortlisted'],['interview_scheduled','Interview'],['hired','Hired'],['rejected','Rejected']].map(([v,l])=>
            `<button onclick="filterApplicants('${v}',this)" class="btn btn-ghost btn-sm app-filter-btn" data-filter="${v}" style="${v==='all'?'background:var(--surface2);color:var(--text);':'color:var(--text3)'}">${l}</button>`
          ).join('')}
        </div>

        <div id="applicantsBody" style="max-height:60vh;overflow-y:auto">
          <div class="loading-center"><div class="spinner"></div></div>
        </div>
      </div>`;
    document.body.appendChild(m);
  }

  openModal('applicantsModal');
  await loadApplicants(jobId, 'all');
}

async function loadApplicants(jobId, statusFilter='all') {
  const body = document.getElementById('applicantsBody');
  body.innerHTML = '<div class="loading-center"><div class="spinner"></div> Loading applicants…</div>';
  try {
    const d = await API.post('org_panel.php', {action:'candidates', user_id:user.id, job_id:jobId, status_filter:statusFilter});
    const job = d.job || {};
    const all = d.candidates || [];

    // All returned rows are actual applicants (SQL uses INNER JOIN now)
    const candidates = all;

    document.getElementById('applicantsTitle').textContent = `Applicants — ${job.title || ''}`;
    document.getElementById('applicantsSubtitle').textContent = `${candidates.length} applicant${candidates.length!==1?'s':''} · Min CGPA ${job.min_cgpa||0}`;

    if (!candidates.length) {
      body.innerHTML = `<div class="empty-state" style="padding:40px">
        <svg width="40" height="40" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>
        <h4 style="margin-top:12px">No applicants${statusFilter!=='all'?' with this status':' yet'}</h4>
        <p style="font-size:13px;color:var(--text3)">Share the job listing to attract candidates.</p>
      </div>`;
      return;
    }

    body.innerHTML = candidates.map(c => {
      const statusColors = {applied:'badge-purple',shortlisted:'badge-amber',interview_scheduled:'badge-cyan',hired:'badge-green',rejected:'badge-red'};
      const statusLabels = {applied:'Applied',shortlisted:'Shortlisted',interview_scheduled:'Interview Set',hired:'Hired',rejected:'Rejected'};
      const st = c.app_status || 'applied';
      const matchColor = c.match_score >= 70 ? 'var(--emerald)' : c.match_score >= 40 ? 'var(--accent2)' : 'var(--red)';

      return `<div class="card" style="margin-bottom:12px;position:relative" id="appcard_${c.app_id}">
        <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;flex-wrap:wrap">

          <!-- Left: student info -->
          <div style="flex:1;min-width:200px">
            <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
              <div style="width:38px;height:38px;border-radius:50%;background:linear-gradient(135deg,var(--primary),var(--accent));display:flex;align-items:center;justify-content:center;font-weight:700;color:#fff;font-size:14px;flex-shrink:0">
                ${(c.name||'?').charAt(0).toUpperCase()}
              </div>
              <div>
                <div style="font-weight:700;font-size:14px;color:var(--text)">${esc(c.name)}</div>
                <div style="font-size:11.5px;color:var(--text3)">${esc(c.email)}</div>
              </div>
            </div>

            <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px">
              <span class="badge badge-gray">CGPA ${c.cgpa||'—'}</span>
              ${c.branch ? `<span class="badge badge-gray">${esc(c.branch)}</span>` : ''}
              <span class="badge ${statusColors[st]||'badge-gray'}">${statusLabels[st]||st}</span>
            </div>

            <!-- Skills match -->
            ${c.matched_skills?.length ? `<div style="font-size:11.5px;color:var(--text3);margin-bottom:4px">Matched skills:</div>
            <div style="display:flex;gap:5px;flex-wrap:wrap;margin-bottom:6px">
              ${c.matched_skills.map(s=>`<span class="skill-tag" style="background:rgba(0,214,143,.1);color:var(--emerald);border-color:rgba(0,214,143,.25);font-size:11px">✓ ${esc(s)}</span>`).join('')}
              ${(c.missing_skills||[]).map(s=>`<span class="skill-tag" style="background:rgba(239,68,68,.08);color:var(--red);border-color:rgba(239,68,68,.2);font-size:11px">✕ ${esc(s)}</span>`).join('')}
            </div>` : ''}

            ${c.org_notes ? `<div style="font-size:12px;color:var(--text3);margin-top:4px;padding:6px 10px;background:var(--surface2);border-radius:6px">📝 ${esc(c.org_notes)}</div>` : ''}
          </div>

          <!-- Right: match score + actions -->
          <div style="display:flex;flex-direction:column;align-items:flex-end;gap:10px;flex-shrink:0">
            <div style="text-align:center">
              <div style="font-size:22px;font-weight:900;color:${matchColor}">${c.match_score}%</div>
              <div style="font-size:10px;color:var(--text3);text-transform:uppercase;letter-spacing:.05em">Match</div>
            </div>

            <!-- Action buttons -->
            <div style="display:flex;flex-direction:column;gap:6px;min-width:148px">
              ${st !== 'shortlisted' && st !== 'hired' ? `<button onclick="updateAppStatus(${c.app_id},'shortlisted',this)" class="btn btn-sm" style="background:rgba(245,158,11,.15);color:var(--accent2);border:1px solid rgba(245,158,11,.3);justify-content:center">⭐ Shortlist</button>` : ''}
              ${st !== 'interview_scheduled' && st !== 'hired' ? `<button onclick="openScheduleInterview(${c.app_id},'${esc(c.name)}')" class="btn btn-sm" style="background:rgba(124,106,255,.12);color:var(--primary-l);border:1px solid rgba(124,106,255,.25);justify-content:center">📅 Schedule Interview</button>` : ''}
              ${st !== 'hired' ? `<button onclick="updateAppStatus(${c.app_id},'hired',this)" class="btn btn-sm" style="background:rgba(0,214,143,.12);color:var(--emerald);border:1px solid rgba(0,214,143,.25);justify-content:center">🏆 Mark Hired</button>` : ''}
              ${st !== 'rejected' ? `<button onclick="updateAppStatus(${c.app_id},'rejected',this)" class="btn btn-ghost btn-sm" style="color:var(--red);justify-content:center">✕ Reject</button>` : ''}
            </div>
          </div>
        </div>
      </div>`;
    }).join('');

  } catch(e) {
    body.innerHTML = `<div class="alert alert-error">${esc(e.message)}</div>`;
  }
}

function filterApplicants(status, btn) {
  document.querySelectorAll('.app-filter-btn').forEach(b => {
    b.style.background = ''; b.style.color = 'var(--text3)';
  });
  btn.style.background = 'var(--surface2)';
  btn.style.color = 'var(--text)';
  loadApplicants(_currentJobId, status);
}

async function updateAppStatus(appId, newStatus, btn) {
  const labels = {shortlisted:'Shortlisting…',hired:'Marking hired…',rejected:'Rejecting…'};
  loading(btn, true, labels[newStatus]||'Updating…');
  try {
    await API.post('org_panel.php', {action:'update_status', user_id:user.id, app_id:appId, status:newStatus, notes:''});
    // Reload current filter
    const activeFilter = document.querySelector('.app-filter-btn[style*="var(--surface2)"]')?.dataset.filter || 'all';
    await loadApplicants(_currentJobId, activeFilter);
    await loadOrgData(); // refresh stats & applicant counts
  } catch(e) {
    loading(btn, false);
    alert(e.message);
  }
}

function openScheduleInterview(appId, studentName) {
  // Inject schedule modal if not present
  if (!document.getElementById('scheduleModal')) {
    const sm = document.createElement('div');
    sm.className = 'modal-overlay';
    sm.id = 'scheduleModal';
    sm.innerHTML = `
      <div class="modal" style="max-width:420px">
        <div class="modal-header">
          <div class="modal-title" id="scheduleTitle">Schedule Interview</div>
          <button class="modal-close" onclick="closeModal('scheduleModal')">${iconX()}</button>
        </div>
        <div id="scheduleAlert"></div>
        <div class="form-group">
          <label class="form-label">Date & Time *</label>
          <input type="datetime-local" id="scheduleDateTime" class="form-input">
        </div>
        <div class="form-group">
          <label class="form-label">Notes / Location</label>
          <textarea id="scheduleNotes" class="form-textarea" rows="3" placeholder="e.g. Google Meet link, Office Room 3B…"></textarea>
        </div>
        <button onclick="confirmScheduleInterview()" id="scheduleBtn" class="btn btn-primary w-full">Confirm & Notify Student</button>
      </div>`;
    document.body.appendChild(sm);
  }
  document.getElementById('scheduleTitle').textContent = `Schedule Interview — ${studentName}`;
  document.getElementById('scheduleAlert').innerHTML = '';
  document.getElementById('scheduleDateTime').value = '';
  document.getElementById('scheduleNotes').value = '';
  document.getElementById('scheduleBtn').dataset.appId = appId;
  openModal('scheduleModal');
}

async function confirmScheduleInterview() {
  const btn   = document.getElementById('scheduleBtn');
  const appId = parseInt(btn.dataset.appId);
  const dt    = document.getElementById('scheduleDateTime').value;
  const notes = document.getElementById('scheduleNotes').value.trim();
  if (!dt) { showAlert(document.getElementById('scheduleAlert'), 'Please pick a date and time.'); return; }
  loading(btn, true, 'Scheduling…');
  try {
    await API.post('interview_schedule.php', {action:'schedule', user_id:user.id, application_id:appId, datetime:dt, notes});
    closeModal('scheduleModal');
    const activeFilter = document.querySelector('.app-filter-btn[style*="var(--surface2)"]')?.dataset.filter || 'all';
    await loadApplicants(_currentJobId, activeFilter);
    await loadOrgData();
  } catch(e) {
    loading(btn, false);
    showAlert(document.getElementById('scheduleAlert'), e.message);
  }
}

async function loadInterviews() {
  const panel = document.getElementById('interviews-panel');
  panel.innerHTML = `<div class="loading-center"><div class="spinner"></div></div>`;
  try {
    const d = await API.post('interview_schedule.php', {action:'org_list', user_id:user.id});
    const interviews = d.interviews||[];
    if (!interviews.length) {
      panel.innerHTML = `<div class="empty-state"><h4>No interviews scheduled</h4><p>Shortlist students and schedule interviews from the candidates view.</p></div>`;
      return;
    }
    panel.innerHTML = `<div class="card"><div class="card-header"><div class="card-title">Scheduled Interviews</div></div>
    <div class="table-wrap"><table><thead><tr><th>Student</th><th>Job</th><th>Interview Date/Time</th><th>Notes</th></tr></thead>
    <tbody>${interviews.map(i=>`<tr>
      <td><strong>${esc(i.student_name)}</strong><div style="font-size:11px;color:var(--text3)">${esc(i.student_email)}</div></td>
      <td>${esc(i.job_title)}</td>
      <td style="color:var(--primary-l);font-weight:600">${i.interview_datetime ? new Date(i.interview_datetime).toLocaleString('en-IN',{weekday:'short',day:'numeric',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'}) : '—'}</td>
      <td style="font-size:12px;color:var(--text3)">${esc(i.interview_notes||'—')}</td>
    </tr>`).join('')}</tbody></table></div></div>`;
  } catch(e) {
    panel.innerHTML = `<div class="alert alert-error">Failed to load interviews.</div>`;
  }
}



async function loadAptitudePanel() {
  const panel = document.getElementById('aptitude-panel');
  panel.innerHTML = `<div class="loading-center"><div class="spinner"></div></div>`;
  try {
    // Get org jobs for dropdown
    const jd = await API.post('org_panel.php', {action:'jobs', user_id:user.id});
    const jobs = jd.jobs||[];
    const qd = await API.post('org_aptitude.php', {action:'list', user_id:user.id});
    const questions = qd.questions||[];
    
    panel.innerHTML = `<div class="card">
      <div class="card-header">
        <div><div class="card-title">📝 Custom Aptitude Questions</div><div class="card-subtitle">Add job-specific questions for candidates to solve during application</div></div>
      </div>
      <div style="background:var(--surface2);border-radius:var(--radius);padding:20px;margin-bottom:20px">
        <div class="card-title" style="margin-bottom:14px;font-size:14px">Add New Question</div>
        <div class="form-group"><label class="form-label">Question *</label><textarea id="aq_question" class="form-textarea" rows="2" placeholder="What is the time complexity of binary search?"></textarea></div>
        <div class="form-row">
          <div class="form-group"><label class="form-label">Option A *</label><input id="aq_a" class="form-input" placeholder="O(n)"></div>
          <div class="form-group"><label class="form-label">Option B *</label><input id="aq_b" class="form-input" placeholder="O(log n)"></div>
        </div>
        <div class="form-row">
          <div class="form-group"><label class="form-label">Option C</label><input id="aq_c" class="form-input" placeholder="O(n²)"></div>
          <div class="form-group"><label class="form-label">Option D</label><input id="aq_d" class="form-input" placeholder="O(1)"></div>
        </div>
        <div class="form-row">
          <div class="form-group"><label class="form-label">Correct Answer *</label>
            <select id="aq_ans" class="form-select"><option value="a">A</option><option value="b">B</option><option value="c">C</option><option value="d">D</option></select>
          </div>
          <div class="form-group"><label class="form-label">Difficulty</label>
            <select id="aq_diff" class="form-select"><option value="easy">Easy</option><option value="medium" selected>Medium</option><option value="hard">Hard</option></select>
          </div>
          <div class="form-group"><label class="form-label">Category</label>
            <input id="aq_cat" class="form-input" value="Technical" placeholder="Technical, Aptitude…">
          </div>
          <div class="form-group"><label class="form-label">For Job (optional)</label>
            <select id="aq_job" class="form-select"><option value="">All Jobs</option>${jobs.map(j=>`<option value="${j.id}">${esc(j.title)}</option>`).join('')}</select>
          </div>
        </div>
        <button onclick="addQuestion()" class="btn btn-primary">Add Question</button>
      </div>
      
      <div class="card-title" style="margin-bottom:12px">Existing Questions (${questions.length})</div>
      ${questions.length===0?'<div style="color:var(--text3);font-size:13px">No questions yet. Add your first question above.</div>':
        `<div class="table-wrap"><table>
          <thead><tr><th>#</th><th>Question</th><th>Category</th><th>Difficulty</th><th>Correct</th><th>Action</th></tr></thead>
          <tbody>${questions.map((q,i)=>`<tr>
            <td style="color:var(--text3);font-size:12px">${i+1}</td>
            <td style="max-width:300px;font-size:13px">${esc(q.question)}</td>
            <td><span class="badge badge-gray">${esc(q.category)}</span></td>
            <td><span class="badge ${q.difficulty==='easy'?'badge-green':q.difficulty==='hard'?'badge-red':'badge-amber'}">${q.difficulty}</span></td>
            <td style="font-weight:700;color:var(--emerald)">${q.correct.toUpperCase()}</td>
            <td><button onclick="deleteQuestion(${q.id})" class="btn btn-ghost btn-sm" style="color:var(--red)">Delete</button></td>
          </tr>`).join('')}</tbody>
        </table></div>`}
    </div>`;
  } catch(e) {
    panel.innerHTML = `<div class="alert alert-error">Failed to load aptitude panel.</div>`;
  }
}

async function addQuestion() {
  const q = document.getElementById('aq_question')?.value;
  const a = document.getElementById('aq_a')?.value;
  const b = document.getElementById('aq_b')?.value;
  const c = document.getElementById('aq_c')?.value;
  const d2 = document.getElementById('aq_d')?.value;
  const ans = document.getElementById('aq_ans')?.value;
  const diff = document.getElementById('aq_diff')?.value;
  const cat = document.getElementById('aq_cat')?.value;
  const job_id = document.getElementById('aq_job')?.value;
  if (!q || !a || !b) { alert('Question, Option A and B are required'); return; }
  try {
    await API.post('org_aptitude.php', {action:'add', user_id:user.id, question:q, option_a:a, option_b:b, option_c:c, option_d:d2, correct:ans, difficulty:diff, category:cat, job_id:job_id||null});
    loadAptitudePanel();
  } catch(e) { alert('Failed: '+e.message); }
}

async function deleteQuestion(qid) {
  if (!confirm('Delete this question?')) return;
  try {
    await API.post('org_aptitude.php', {action:'delete', user_id:user.id, question_id:qid});
    loadAptitudePanel();
  } catch(e) { alert('Failed'); }
}

// ── Student Profile Modal (Browse Students → View) ───────────
function viewStudentProfile(s) {
  if (!s) return;
  const skills = (s.skills||'').split(',').map(sk=>sk.trim()).filter(Boolean);
  const skillsHtml = skills.length
    ? skills.map(sk=>`<span style="display:inline-block;padding:3px 10px;background:rgba(108,99,255,.12);border:1px solid rgba(108,99,255,.2);border-radius:99px;font-size:11.5px;color:var(--primary-l);margin:2px">${esc(sk)}</span>`).join('')
    : '<span style="color:var(--text3);font-size:12px">No skills listed</span>';

  const cgpa   = parseFloat(s.cgpa)||0;
  const resume = parseInt(s.resume_score)||0;
  const apt    = parseInt(s.aptitude_score)||0;
  const intv   = parseInt(s.interview_score)||0;

  function scoreBar(label, val, color) {
    const pct = Math.min(100, val);
    return `<div style="margin-bottom:10px">
      <div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:4px">
        <span style="color:var(--text2)">${label}</span>
        <span style="font-weight:700;color:${color}">${val||'—'}</span>
      </div>
      <div style="height:5px;background:var(--bg3);border-radius:99px;overflow:hidden">
        <div style="height:100%;width:${pct}%;background:${color};border-radius:99px;transition:width .6s ease"></div>
      </div>
    </div>`;
  }

  const initials = (s.name||'?').split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase();

  if (!document.getElementById('stuModalAnimStyle')) {
    const st = document.createElement('style');
    st.id = 'stuModalAnimStyle';
    st.textContent = `
      @keyframes stuFadeIn{from{opacity:0}to{opacity:1}}
      @keyframes stuSlideUp{from{opacity:0;transform:translateY(22px) scale(.97)}to{opacity:1;transform:translateY(0) scale(1)}}
    `;
    document.head.appendChild(st);
  }

  document.getElementById('stuProfileModal')?.remove();

  const wrap = document.createElement('div');
  wrap.id = 'stuProfileModal';
  wrap.style.cssText = 'position:fixed;inset:0;z-index:2000;display:flex;align-items:center;justify-content:center;padding:16px;background:rgba(0,0,0,.6);backdrop-filter:blur(4px);animation:stuFadeIn .2s ease';
  wrap.innerHTML = `
    <div style="background:var(--surface);border:1px solid var(--border2);border-radius:18px;width:100%;max-width:520px;max-height:90vh;overflow-y:auto;box-shadow:0 24px 80px rgba(0,0,0,.6);animation:stuSlideUp .25s cubic-bezier(.34,1.56,.64,1)">
      <div style="padding:22px 22px 0;display:flex;align-items:flex-start;justify-content:space-between;gap:12px">
        <div style="display:flex;align-items:center;gap:14px">
          <div style="width:52px;height:52px;border-radius:14px;background:var(--primary-g);display:flex;align-items:center;justify-content:center;font-family:var(--font-display);font-weight:800;font-size:18px;color:#fff;flex-shrink:0">${initials}</div>
          <div>
            <div style="font-family:var(--font-display);font-size:1.1rem;font-weight:800;color:var(--text)">${esc(s.name)}</div>
            <div style="font-size:12.5px;color:var(--text3);margin-top:2px">${esc(s.email)}</div>
            ${s.branch?`<div style="font-size:12px;color:var(--primary-l);margin-top:3px;font-weight:600">${esc(s.branch)}</div>`:''}
          </div>
        </div>
        <button onclick="document.getElementById('stuProfileModal').remove()" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;width:32px;height:32px;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;color:var(--text2);font-size:15px;transition:background .15s" onmouseover="this.style.background='var(--surface3)'" onmouseout="this.style.background='var(--surface2)'">✕</button>
      </div>
      <div style="padding:18px 22px 22px">
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:18px">
          ${[['CGPA',cgpa||'—',cgpa>=8?'var(--emerald)':'var(--accent2)'],['Resume',resume||'—',resume>=70?'var(--emerald)':'var(--accent2)'],['Aptitude',apt||'—',apt>=70?'var(--emerald)':'var(--accent2)']].map(([l,v,c])=>`
          <div style="background:var(--bg2);border:1px solid var(--border);border-radius:10px;padding:12px;text-align:center">
            <div style="font-family:var(--font-display);font-size:1.35rem;font-weight:800;color:${c}">${v}</div>
            <div style="font-size:11px;color:var(--text3);margin-top:2px">${l}</div>
          </div>`).join('')}
        </div>
        <div style="background:var(--bg2);border:1px solid var(--border);border-radius:12px;padding:16px;margin-bottom:14px">
          <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--text3);margin-bottom:12px">Performance</div>
          ${scoreBar('Resume Score',resume,'var(--primary-l)')}
          ${scoreBar('Aptitude Score',apt,'var(--emerald)')}
          ${scoreBar('Interview Score',intv,'var(--accent2)')}
        </div>
        <div style="background:var(--bg2);border:1px solid var(--border);border-radius:12px;padding:16px;margin-bottom:14px">
          <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--text3);margin-bottom:10px">Skills</div>
          <div>${skillsHtml}</div>
        </div>
        ${(s.phone||s.college||s.passing_year)?`
        <div style="background:var(--bg2);border:1px solid var(--border);border-radius:12px;padding:16px;margin-bottom:14px">
          <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--text3);margin-bottom:10px">Details</div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
            ${s.phone?`<div><div style="font-size:10.5px;color:var(--text3)">Phone</div><div style="font-size:13px;color:var(--text);font-weight:600">${esc(s.phone)}</div></div>`:''}
            ${s.passing_year?`<div><div style="font-size:10.5px;color:var(--text3)">Passing Year</div><div style="font-size:13px;color:var(--text);font-weight:600">${esc(s.passing_year)}</div></div>`:''}
            ${s.college?`<div style="grid-column:1/-1"><div style="font-size:10.5px;color:var(--text3)">College</div><div style="font-size:13px;color:var(--text);font-weight:600">${esc(s.college)}</div></div>`:''}
          </div>
        </div>`:''}
        <div style="display:flex;gap:10px;flex-wrap:wrap">
          <a href="mailto:${esc(s.email)}" class="btn btn-secondary btn-sm" style="flex:1;justify-content:center;text-decoration:none;min-width:120px">✉ Send Email</a>
          <button onclick="document.getElementById('stuProfileModal').remove()" class="btn btn-primary btn-sm" style="flex:1;justify-content:center;min-width:120px">Close</button>
        </div>
      </div>
    </div>`;

  wrap.addEventListener('click', e => { if (e.target === wrap) wrap.remove(); });
  document.body.appendChild(wrap);
}

</script>
</body>
</html>

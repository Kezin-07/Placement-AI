<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">  <link rel="icon" type="image/svg+xml" href="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAzMiAzMiIgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIj4KICA8ZGVmcz4KICAgIDxsaW5lYXJHcmFkaWVudCBpZD0iZyIgeDE9IjAiIHkxPSIxIiB4Mj0iMSIgeTI9IjAiPgogICAgICA8c3RvcCBvZmZzZXQ9IjAlIiBzdG9wLWNvbG9yPSIjZmY0NzU3Ii8+CiAgICAgIDxzdG9wIG9mZnNldD0iMTAwJSIgc3RvcC1jb2xvcj0iI2Y1OWUwYiIvPgogICAgPC9saW5lYXJHcmFkaWVudD4KICA8L2RlZnM+CiAgPHJlY3Qgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIiByeD0iNyIgZmlsbD0iIzFlMWExMCIvPgogIDxyZWN0IHg9IjYiIHk9IjIxIiB3aWR0aD0iNSIgaGVpZ2h0PSI5IiByeD0iMS41IiBmaWxsPSIjZjU5ZTBiIiBvcGFjaXR5PSIuNSIvPgogIDxyZWN0IHg9IjEzIiB5PSIxNSIgd2lkdGg9IjUiIGhlaWdodD0iMTUiIHJ4PSIxLjUiIGZpbGw9IiNmZjZiMzUiIG9wYWNpdHk9Ii43NSIvPgogIDxyZWN0IHg9IjIwIiB5PSI4IiB3aWR0aD0iNSIgaGVpZ2h0PSIyMiIgcng9IjEuNSIgZmlsbD0idXJsKCNnKSIvPgogIDxwb2x5bGluZSBwb2ludHM9IjIzLDQgMjcsOCAyNyw1IiBmaWxsPSJub25lIiBzdHJva2U9InVybCgjZykiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIi8+CiAgPGxpbmUgeDE9IjE5IiB5MT0iNSIgeDI9IjI3IiB5Mj0iNCIgc3Ryb2tlPSJ1cmwoI2cpIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPgo8L3N2Zz4=">
  <link rel="icon" type="image/x-icon" href="data:image/x-icon;base64,AAABAAEAEBAAAAAAIACgAAAAFgAAAIlQTkcNChoKAAAADUlIRFIAAAAQAAAAEAgGAAAAH/P/YQAAAGdJREFUeJxjZIACLg6R/wwkgG8/3jAyMDAwMJGjGVkPIzmakQETJZoZGBgYWNAFvn5/jVMxN6co9V1AWwOwOZkkA/CFB1EGEAOoH43IgOIwIAZQnpRhuYoc8O3HG0YmGIMczQwMDAwA+P4aS3/n/2IAAAAASUVORK5CYII=">
  <link rel="icon" type="image/png" sizes="32x32" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAoElEQVR4nO2XvQ6AIAyES+Pgz6rv/4Cyimw6kWhDxID0HLixabyPozHUUERjPx+xeqmct0bWboVaxk8grG0uvVjbXEJwqrG2DOL0V8ET6FIN275mfXgalld98AQaABwgOYQxyQHLHVSiHyTQALJmoOTOpeAJNAA4wCc/ohLBE2gAcAD8ozS2LmnJeWvgV8CBRNs4eLIsaJoTie04SHM9PwGQNi1E3UY9bQAAAABJRU5ErkJggg==">
  <link rel="icon" type="image/png" sizes="192x192" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMAAAADACAYAAABS3GwHAAADvklEQVR4nO3dQVLjVgBFUZvqASFTsv8FhmkIMzJIdRc0YCxL8pd8z1kAaPCuvmy61MfDxjzcP76OvgbW8/zydBx9DW8NvRhj53AYG8XVf7HRc8q1Y7jaLzN8prhWCKv/EsNnjrVDWO2HGz5LWiuExX+o4bOmpUO4W/KHGT9rW3pji9Rk+IywxGkw+wQwfkZZYnuzAjB+Rpu7wYsDMH62Ys4WLwrA+NmaSzc5OQDjZ6su2eakAIyfrZu60bMDMH72YspWzwrA+Nmbczf7bQDGz16ds91F/ykE7M3JANz92bvvNvxlAMbPrTi1ZY9ApH0agLs/t+arTTsBSPsQgLs/t+qzbTsBSHsXgLs/t+73jTsBSPsVgLs/FW+37gQgTQCk3R0OHn/o+bl5JwBpAiBNAKQJgLSjD8CUOQFIEwBpAiBNAKQJgDQBkPZj9AXM9c+/f4++hF3584+/Rl/CpjgBSBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYC03b8VYi0j356w1psuvBHiIycAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANKOD/ePr6MvYo61XiV+q7wi/T0nAGkCIE0ApAmANAGQJgDSBECaAEgTAGkCIE0ApAmANAGQJgDSBECaAEgTAGkCIE0ApAmANAGQ9mP0BWyVtyc0OAFIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0o4P94+voy8CRnECkCYA0gRAmgBIEwBpd88vT8fRFwEjPL88HZ0ApAmANAGQJgDS7g6H/z8MjL4QuKafm3cCkCYA0n4F4DGIirdbdwKQ9i4ApwC37veNOwFI+xCAU4Bb9dm2nQCkfRqAU4Bb89WmnQCkfRmAU4BbcWrLJ08AEbB3323YIxBp3wbgFGCvztnuWSeACNibczd79iOQCNiLKVud9BlABGzd1I1O/hAsArbqkm1e9C2QCNiaSzd58degImAr5mxx1t8BRMBoczc4+w9hImCUJba36Hj9bzNcw5I33UX/KYTTgLUtvbHVBus0YElr3VxXv2MLgTnWfqq42iOLEJjiWo/TV39mFwKnXPtz5NAPrWLgcBj75cnmvrURxW3b2jeF/wGOq9fsu4f8UQAAAABJRU5ErkJggg==">
  <link rel="apple-touch-icon" sizes="180x180" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAAC0CAYAAAA9zQYyAAADX0lEQVR4nO3cOXJaQQBFUVA58JDa+1+glVpWZgceygOS/kh/rs5ZAOrg8tRAwfl0AO/ffvw2+gys9/B4fx59hiEHEPDrMCLwq/1BEb9u14p71z8iYi7ZM+5dHljITLFH2HdbP6CYmWqPVjZ7hgiZNbZa600WWsystVVDq54VQmYPa9Z68UKLmb2saWtR0GJmb0sbmx20mLmWJa3NClrMXNvc5iYHLWZGmdPepKDFzGhTG3wxaDFzFFNa3Pyjbxjp2aCtM0fzUpNPBi1mjuq5Nl05SLkYtHXm6J5q9L+gxcytuNSqKwcpfwVtnbk1/zZroUkRNCm/g3bd4Fb92a6FJkXQpNydTq4b3L5fDVtoUgRNiqBJObs/U2KhSRE0KYImRdCkCJoUQZPyZvQBlvjy9fPoIxzWh3efRh9hKAtNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiblJr8ku4cRXy71Zd/tWWhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCl+rPEnP5zYYKFJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KT4kuxPH959Gn0ENmChSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJqU8/u3H7+NPgRsxUKTImhSBE2KoEkRNCl3D4/359GHgC08PN6fLTQpgiZF0KTcnU4/7h6jDwJr/GrYQpMiaFJ+B+3awa36s10LTYqgSfkraNcObs2/zVpoUv4L2kpzKy61enGhRc3RPdWoKwcpTwZtpTmq59p8dqFFzdG81KQrBykvBm2lOYopLU5aaFEz2tQGJ185RM0oc9qbdYcWNdc2t7nZLwpFzbUsaW3RuxyiZm9LG1v8tp2o2cuatjaJ0k/ysoUtRnKTD1asNWtt1dDmIVpr5th6DDf/6NtaM9Uerewan7Xmkj1H72prKu7X7Vr/uYdcD8T9Ooy4fh7ivivwhiO8fvoO2onGYhMioSEAAAAASUVORK5CYII=">
  <title>Prediction AI — PlacementAI Pro</title>
  <link rel="stylesheet" href="css/style.css?v=5">
  <style>
    .prob-ring-wrap { text-align:center; padding: 24px 0; }
    .prob-ring-wrap .ring-label { font-size:13px;color:var(--text3);margin-top:12px;font-weight:600 }

    .factor-bar { margin-bottom: 14px; }
    .factor-bar-header { display:flex;justify-content:space-between;margin-bottom:5px }
    .factor-bar-label { font-size:13px;color:var(--text2);font-weight:500 }
    .factor-bar-pct { font-size:13px;font-weight:700 }
    .factor-bar-track { height:7px;background:var(--border);border-radius:99px;overflow:hidden }
    .factor-bar-fill { height:100%;border-radius:99px;transition:width .7s cubic-bezier(.4,0,.2,1) }

    .company-match { display:flex;align-items:center;justify-content:space-between;padding:12px 16px;background:var(--bg3);border-radius:10px;margin-bottom:8px;border:1px solid var(--border) }
    .suggestion-item { display:flex;gap:12px;align-items:flex-start;padding:14px 16px;border-radius:10px;margin-bottom:8px }
    .suggestion-item.high   { background:rgba(239,68,68,.06);border:1px solid rgba(239,68,68,.2) }
    .suggestion-item.medium { background:rgba(245,158,11,.06);border:1px solid rgba(245,158,11,.2) }
    .suggestion-item.low    { background:rgba(16,185,129,.06);border:1px solid rgba(16,185,129,.2) }

    .status-badge {
      display:inline-flex;align-items:center;gap:6px;padding:6px 16px;border-radius:99px;font-size:13px;font-weight:700
    }
    .status-badge.very-high { background:rgba(16,185,129,.15);color:#10b981 }
    .status-badge.high      { background:rgba(16,185,129,.12);color:#6ee7b7 }
    .status-badge.moderate  { background:rgba(245,158,11,.12);color:#f59e0b }
    .status-badge.low       { background:rgba(239,68,68,.1);color:#ef4444 }
    .status-badge.very-low  { background:rgba(239,68,68,.15);color:#ef4444 }
  
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');

  /* Override font globally on this page */
  body, .form-label, .form-input, .form-select, .card-title, h1, h2, h3 {
    font-family: 'Plus Jakarta Sans', var(--font-body) !important;
  }

  /* Input form card: clean elevated surface */
  .grid-2 > .card:first-child {
    background: var(--surface) !important;
    border: 1px solid var(--border2) !important;
    border-radius: 20px !important;
    box-shadow: 0 8px 40px rgba(0,0,0,.3) !important;
    position: relative; overflow: hidden;
  }
  .grid-2 > .card:first-child::before {
    content: '';
    position: absolute; top: 0; left: 0; right: 0; height: 3px;
    background: linear-gradient(90deg, #7c6aff, #a78bfa, #00e5b4);
    border-radius: 20px 20px 0 0;
  }

  /* Labels: clean small caps */
  .grid-2 > .card:first-child .form-label {
    font-size: 11.5px !important;
    font-weight: 600 !important;
    color: var(--text2) !important;
    letter-spacing: .01em !important;
    text-transform: none !important;
  }

  /* Inputs: polished */
  .grid-2 > .card:first-child .form-input,
  .grid-2 > .card:first-child .form-select {
    background: var(--bg2) !important;
    border: 1px solid var(--border2) !important;
    border-radius: 10px !important;
    color: var(--text) !important;
    font-size: 14px !important;
    font-weight: 500 !important;
    font-family: 'Plus Jakarta Sans', sans-serif !important;
    transition: border-color .18s, box-shadow .18s !important;
  }
  .grid-2 > .card:first-child .form-input:focus,
  .grid-2 > .card:first-child .form-select:focus {
    border-color: var(--primary) !important;
    box-shadow: 0 0 0 3px rgba(124,106,255,.14) !important;
    outline: none !important;
  }
  .grid-2 > .card:first-child .form-input::placeholder { color: var(--text3) !important; }
  .grid-2 > .card:first-child option { background: var(--surface); color: var(--text); }

  /* Predict button: rich purple gradient */
  #predictBtn {
    background: linear-gradient(135deg, #6c52ff 0%, #7c6aff 50%, #a78bfa 100%) !important;
    color: #fff !important;
    font-family: 'Plus Jakarta Sans', sans-serif !important;
    font-size: 14px !important;
    font-weight: 700 !important;
    letter-spacing: .02em !important;
    border: none !important;
    border-radius: 12px !important;
    box-shadow: 0 4px 20px rgba(124,106,255,.35) !important;
    transition: all .2s !important;
  }
  #predictBtn:hover {
    transform: translateY(-2px) !important;
    box-shadow: 0 8px 28px rgba(124,106,255,.5) !important;
  }
  #predictBtn svg { stroke: #fff !important; }

  /* AI Model v2 badge */
  .badge-cyan {
    background: rgba(124,106,255,.12) !important;
    color: var(--primary-l) !important;
    border: 1px solid rgba(124,106,255,.25) !important;
    font-family: 'Plus Jakarta Sans', sans-serif !important;
    font-size: 11px !important;
    font-weight: 600 !important;
    letter-spacing: .01em !important;
    padding: 4px 10px !important;
    border-radius: 99px !important;
  }

  /* Results panel: clean cards */
  #resultsPanel .card {
    background: var(--surface) !important;
    border: 1px solid var(--border) !important;
    border-radius: 20px !important;
    box-shadow: 0 4px 24px rgba(0,0,0,.2) !important;
  }

  /* Ready to Analyze state */
  #resultsPanel .card h3 {
    font-family: 'Plus Jakarta Sans', sans-serif !important;
    font-size: 1.3rem !important;
    font-weight: 800 !important;
    color: var(--text) !important;
  }

  /* Factor bar fills - use primary gradient */
  .factor-bar-fill {
    border-radius: 99px !important;
  }

  /* Company match items */
  .company-match {
    background: var(--bg2) !important;
    border: 1px solid var(--border) !important;
    border-radius: 12px !important;
    transition: border-color .15s !important;
  }
  .company-match:hover { border-color: var(--border2) !important; }

  /* Page header */
  .page-header h1 {
    font-family: 'Plus Jakarta Sans', sans-serif !important;
    font-weight: 800 !important;
    letter-spacing: -.02em !important;
  }

  </style>
</head>
<body>
<script src="js/app.js?v=5"></script>
<script>
const user = Auth.requireAuth('student');
if (user) { buildShell('predict'); setTimeout(()=>initPredict(), 0); }

async function initPredict() {
  document.getElementById('topbarTitle').textContent = 'Placement Prediction AI';
  const page = document.getElementById('mainPage');
  let profile = null;
  try {
    const p = await API.get(`student_profile.php?user_id=${user.id}`);
    profile = p.profile;
  } catch(e) {}

  page.innerHTML = `
    <div class="page-header">
      <h1 style="font-size:1.6rem">🔮 Placement Prediction AI</h1>
      <p style="color:var(--text3);font-size:13px;margin-top:2px">15-factor ML model · Company tier matching · Personalized action plan · Interview readiness score</p>
    </div>
    <div class="grid-2" style="align-items:start">
      <!-- Input form -->
      <div class="card">
        <div class="card-header">
          <div class="card-title">Your Profile Data</div>
          <span class="badge badge-cyan">AI Model v2</span>
        </div>
        <div id="alertBox"></div>
        <form id="predictForm">
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">CGPA (out of 10)</label>
              <input type="number" id="cgpa" class="form-input" value="${profile?.cgpa||''}" min="0" max="10" step="0.01" placeholder="8.5" required>
            </div>
            <div class="form-group">
              <label class="form-label">Branch</label>
              <select id="branch" class="form-select">
                ${['Computer Science','Information Technology','Electronics','Mechanical','Civil','Chemical','Data Science'].map(b=>`<option ${profile?.branch===b?'selected':''}>${b}</option>`).join('')}
              </select>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Projects Count</label>
              <input type="number" id="projects" class="form-input" value="${profile?.projects||0}" min="0" max="20" placeholder="3" required>
            </div>
            <div class="form-group">
              <label class="form-label">Internships</label>
              <input type="number" id="internships" class="form-input" value="${profile?.internships||0}" min="0" max="10" placeholder="1" required>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Aptitude Score (%)</label>
              <input type="number" id="aptitude" class="form-input" value="${profile?.aptitude_score||''}" min="0" max="100" placeholder="75" required>
            </div>
            <div class="form-group">
              <label class="form-label">Communication (1-10)</label>
              <input type="number" id="communication" class="form-input" value="${profile?.communication_rating||5}" min="1" max="10" step="0.5" placeholder="7" required>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Resume Score (0-100)</label>
              <input type="number" id="resume_score" class="form-input" value="${profile?.resume_score||0}" min="0" max="100" placeholder="75">
            </div>
            <div class="form-group">
              <label class="form-label">Interview Score (0-100)</label>
              <input type="number" id="interview_score" class="form-input" value="${profile?.interview_score||0}" min="0" max="100" placeholder="70">
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Skills (comma separated)</label>
            <input type="text" id="skills" class="form-input" value="${profile?.skills||''}" placeholder="Python, React, SQL, AWS, DSA…">
          </div>
          <button type="submit" id="predictBtn" class="btn btn-primary btn-lg w-full" style="justify-content:center;gap:8px">
            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
            Predict Placement Probability
          </button>
          <div style="font-size:11.5px;color:var(--text3);text-align:center;margin-top:8px">Analyzes 15 factors: CGPA, skills, projects, aptitude, communication & more</div>
        </form>
      </div>

      <!-- Results -->
      <div id="resultsPanel">
        <div class="card" style="text-align:center;padding:48px">
          <div style="font-size:3.5rem;margin-bottom:12px">🔮</div>
          <h3 style="margin-bottom:8px">Ready to Analyze</h3>
          <p style="font-size:13.5px;color:var(--text3)">Fill in your profile and click Predict to get a detailed analysis</p>
        </div>
      </div>
    </div>`;

  document.getElementById('predictForm').addEventListener('submit', async e => {
    e.preventDefault();
    const btn = document.getElementById('predictBtn');
    loading(btn, true, 'Analyzing profile…');
    clearAlert(document.getElementById('alertBox'));

    try {
      const data = await API.post('predict.php', {
        cgpa:                parseFloat(document.getElementById('cgpa').value),
        branch:              document.getElementById('branch').value,
        projects:            parseInt(document.getElementById('projects').value),
        internships:         parseInt(document.getElementById('internships').value),
        aptitude_score:      parseFloat(document.getElementById('aptitude').value),
        communication_rating:parseFloat(document.getElementById('communication').value),
        skills:              document.getElementById('skills').value,
        resume_score:        parseFloat(document.getElementById('resume_score').value)||0,
        interview_score:     parseFloat(document.getElementById('interview_score').value)||0,
      });
      loading(btn, false);
      renderResults(data);
    } catch(err) {
      loading(btn, false);
      showAlert(document.getElementById('alertBox'), err.message || 'Prediction failed.');
    }
  });
}

function getStatusClass(status) {
  const map = {'Very High':'very-high','High':'high','Moderate':'moderate','Low':'low','Very Low':'very-low'};
  return map[status] || 'moderate';
}

function renderResults(d) {
  const prob = d.probability || 0;
  const readiness = d.readiness || 0;
  const color = prob >= 75 ? '#10b981' : prob >= 50 ? '#f59e0b' : '#ef4444';
  const statusClass = getStatusClass(d.status);

  const shap = d.shap || [];
  const suggestions = d.suggestions || [];
  const companies = d.company_matches || [];

  document.getElementById('resultsPanel').innerHTML = `
    <!-- Main probability -->
    <div class="card mb-4">
      <div class="prob-ring-wrap">
        ${scoreRing(prob, 160, color)}
        <div class="ring-label">Placement Probability</div>
        <div style="margin-top:10px">
          <span class="status-badge ${statusClass}">● ${esc(d.status)}</span>
        </div>
      </div>
      <div class="glow-line"></div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;padding:16px 0">
        <div style="text-align:center">
          <div style="font-family:var(--font-display);font-size:1.8rem;font-weight:900;color:var(--primary)">${prob}%</div>
          <div style="font-size:11px;color:var(--text3)">Probability</div>
        </div>
        <div style="text-align:center">
          <div style="font-family:var(--font-display);font-size:1.8rem;font-weight:900;color:var(--emerald)">${readiness}%</div>
          <div style="font-size:11px;color:var(--text3)">Interview Readiness</div>
        </div>
      </div>
    </div>

    <!-- Factor Analysis -->
    <div class="card mb-4">
      <div class="card-title mb-4">📊 Factor Analysis</div>
      ${shap.map(f => {
        const pct = f.impact;
        const fc = pct >= 80 ? '#10b981' : pct >= 50 ? '#6c63ff' : pct >= 30 ? '#f59e0b' : '#ef4444';
        return `<div class="factor-bar">
          <div class="factor-bar-header">
            <span class="factor-bar-label">${esc(f.factor)}</span>
            <span class="factor-bar-pct" style="color:${fc}">${pct}%</span>
          </div>
          <div class="factor-bar-track">
            <div class="factor-bar-fill" style="width:${pct}%;background:${fc}"></div>
          </div>
        </div>`;
      }).join('')}
    </div>

    <!-- Company Matches -->
    ${companies.length ? `<div class="card mb-4">
      <div class="card-title mb-4">🏢 Company Tier Match</div>
      ${companies.map(c => {
        const cColor = c.match >= 75 ? '#10b981' : c.match >= 50 ? '#6c63ff' : '#f59e0b';
        return `<div class="company-match">
          <span style="font-size:13.5px;font-weight:600;color:var(--text)">${esc(c.name)}</span>
          <div style="display:flex;align-items:center;gap:10px">
            <div style="width:80px;height:6px;background:var(--border);border-radius:99px;overflow:hidden">
              <div style="height:100%;width:${c.match}%;background:${cColor};border-radius:99px"></div>
            </div>
            <span style="font-size:13px;font-weight:700;color:${cColor};min-width:36px">${c.match}%</span>
          </div>
        </div>`;
      }).join('')}
    </div>` : ''}

    <!-- Suggestions -->
    ${suggestions.length ? `<div class="card">
      <div class="card-title mb-4">💡 Action Plan</div>
      ${suggestions.slice(0,6).map(s => {
        const icons = {high:'🔴',medium:'🟡',low:'🟢'};
        return `<div class="suggestion-item ${s.priority}">
          <span style="font-size:1rem;flex-shrink:0">${icons[s.priority]||'●'}</span>
          <div>
            <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;margin-bottom:4px;color:${s.priority==='high'?'var(--red)':s.priority==='medium'?'var(--accent2)':'var(--emerald)'}">${s.priority} priority</div>
            <div style="font-size:13.5px;color:var(--text2);line-height:1.6">${esc(s.text)}</div>
          </div>
        </div>`;
      }).join('')}
    </div>` : ''}`;
}
</script>
</body>
</html>

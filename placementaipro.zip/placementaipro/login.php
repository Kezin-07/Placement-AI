<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">  <link rel="icon" type="image/svg+xml" href="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAzMiAzMiIgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIj4KICA8ZGVmcz4KICAgIDxsaW5lYXJHcmFkaWVudCBpZD0iZyIgeDE9IjAiIHkxPSIxIiB4Mj0iMSIgeTI9IjAiPgogICAgICA8c3RvcCBvZmZzZXQ9IjAlIiBzdG9wLWNvbG9yPSIjZmY0NzU3Ii8+CiAgICAgIDxzdG9wIG9mZnNldD0iMTAwJSIgc3RvcC1jb2xvcj0iI2Y1OWUwYiIvPgogICAgPC9saW5lYXJHcmFkaWVudD4KICA8L2RlZnM+CiAgPHJlY3Qgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIiByeD0iNyIgZmlsbD0iIzFlMWExMCIvPgogIDxyZWN0IHg9IjYiIHk9IjIxIiB3aWR0aD0iNSIgaGVpZ2h0PSI5IiByeD0iMS41IiBmaWxsPSIjZjU5ZTBiIiBvcGFjaXR5PSIuNSIvPgogIDxyZWN0IHg9IjEzIiB5PSIxNSIgd2lkdGg9IjUiIGhlaWdodD0iMTUiIHJ4PSIxLjUiIGZpbGw9IiNmZjZiMzUiIG9wYWNpdHk9Ii43NSIvPgogIDxyZWN0IHg9IjIwIiB5PSI4IiB3aWR0aD0iNSIgaGVpZ2h0PSIyMiIgcng9IjEuNSIgZmlsbD0idXJsKCNnKSIvPgogIDxwb2x5bGluZSBwb2ludHM9IjIzLDQgMjcsOCAyNyw1IiBmaWxsPSJub25lIiBzdHJva2U9InVybCgjZykiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIi8+CiAgPGxpbmUgeDE9IjE5IiB5MT0iNSIgeDI9IjI3IiB5Mj0iNCIgc3Ryb2tlPSJ1cmwoI2cpIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPgo8L3N2Zz4=">
  <link rel="icon" type="image/x-icon" href="data:image/x-icon;base64,AAABAAEAEBAAAAAAIACgAAAAFgAAAIlQTkcNChoKAAAADUlIRFIAAAAQAAAAEAgGAAAAH/P/YQAAAGdJREFUeJxjZIACLg6R/wwkgG8/3jAyMDAwMJGjGVkPIzmakQETJZoZGBgYWNAFvn5/jVMxN6co9V1AWwOwOZkkA/CFB1EGEAOoH43IgOIwIAZQnpRhuYoc8O3HG0YmGIMczQwMDAwA+P4aS3/n/2IAAAAASUVORK5CYII=">
  <link rel="icon" type="image/png" sizes="32x32" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAoElEQVR4nO2XvQ6AIAyES+Pgz6rv/4Cyimw6kWhDxID0HLixabyPozHUUERjPx+xeqmct0bWboVaxk8grG0uvVjbXEJwqrG2DOL0V8ET6FIN275mfXgalld98AQaABwgOYQxyQHLHVSiHyTQALJmoOTOpeAJNAA4wCc/ohLBE2gAcAD8ozS2LmnJeWvgV8CBRNs4eLIsaJoTie04SHM9PwGQNi1E3UY9bQAAAABJRU5ErkJggg==">
  <link rel="icon" type="image/png" sizes="192x192" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMAAAADACAYAAABS3GwHAAADvklEQVR4nO3dQVLjVgBFUZvqASFTsv8FhmkIMzJIdRc0YCxL8pd8z1kAaPCuvmy61MfDxjzcP76OvgbW8/zydBx9DW8NvRhj53AYG8XVf7HRc8q1Y7jaLzN8prhWCKv/EsNnjrVDWO2HGz5LWiuExX+o4bOmpUO4W/KHGT9rW3pji9Rk+IywxGkw+wQwfkZZYnuzAjB+Rpu7wYsDMH62Ys4WLwrA+NmaSzc5OQDjZ6su2eakAIyfrZu60bMDMH72YspWzwrA+Nmbczf7bQDGz16ds91F/ykE7M3JANz92bvvNvxlAMbPrTi1ZY9ApH0agLs/t+arTTsBSPsQgLs/t+qzbTsBSHsXgLs/t+73jTsBSPsVgLs/FW+37gQgTQCk3R0OHn/o+bl5JwBpAiBNAKQJgLSjD8CUOQFIEwBpAiBNAKQJgDQBkPZj9AXM9c+/f4++hF3584+/Rl/CpjgBSBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYC03b8VYi0j356w1psuvBHiIycAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANKOD/ePr6MvYo61XiV+q7wi/T0nAGkCIE0ApAmANAGQJgDSBECaAEgTAGkCIE0ApAmANAGQJgDSBECaAEgTAGkCIE0ApAmANAGQ9mP0BWyVtyc0OAFIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0o4P94+voy8CRnECkCYA0gRAmgBIEwBpd88vT8fRFwEjPL88HZ0ApAmANAGQJgDS7g6H/z8MjL4QuKafm3cCkCYA0n4F4DGIirdbdwKQ9i4ApwC37veNOwFI+xCAU4Bb9dm2nQCkfRqAU4Bb89WmnQCkfRmAU4BbcWrLJ08AEbB3323YIxBp3wbgFGCvztnuWSeACNibczd79iOQCNiLKVud9BlABGzd1I1O/hAsArbqkm1e9C2QCNiaSzd58degImAr5mxx1t8BRMBoczc4+w9hImCUJba36Hj9bzNcw5I33UX/KYTTgLUtvbHVBus0YElr3VxXv2MLgTnWfqq42iOLEJjiWo/TV39mFwKnXPtz5NAPrWLgcBj75cnmvrURxW3b2jeF/wGOq9fsu4f8UQAAAABJRU5ErkJggg==">
  <link rel="apple-touch-icon" sizes="180x180" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAAC0CAYAAAA9zQYyAAADX0lEQVR4nO3cOXJaQQBFUVA58JDa+1+glVpWZgceygOS/kh/rs5ZAOrg8tRAwfl0AO/ffvw2+gys9/B4fx59hiEHEPDrMCLwq/1BEb9u14p71z8iYi7ZM+5dHljITLFH2HdbP6CYmWqPVjZ7hgiZNbZa600WWsystVVDq54VQmYPa9Z68UKLmb2saWtR0GJmb0sbmx20mLmWJa3NClrMXNvc5iYHLWZGmdPepKDFzGhTG3wxaDFzFFNa3Pyjbxjp2aCtM0fzUpNPBi1mjuq5Nl05SLkYtHXm6J5q9L+gxcytuNSqKwcpfwVtnbk1/zZroUkRNCm/g3bd4Fb92a6FJkXQpNydTq4b3L5fDVtoUgRNiqBJObs/U2KhSRE0KYImRdCkCJoUQZPyZvQBlvjy9fPoIxzWh3efRh9hKAtNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiblJr8ku4cRXy71Zd/tWWhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCl+rPEnP5zYYKFJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KT4kuxPH959Gn0ENmChSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJqU8/u3H7+NPgRsxUKTImhSBE2KoEkRNCl3D4/359GHgC08PN6fLTQpgiZF0KTcnU4/7h6jDwJr/GrYQpMiaFJ+B+3awa36s10LTYqgSfkraNcObs2/zVpoUv4L2kpzKy61enGhRc3RPdWoKwcpTwZtpTmq59p8dqFFzdG81KQrBykvBm2lOYopLU5aaFEz2tQGJ185RM0oc9qbdYcWNdc2t7nZLwpFzbUsaW3RuxyiZm9LG1v8tp2o2cuatjaJ0k/ysoUtRnKTD1asNWtt1dDmIVpr5th6DDf/6NtaM9Uerewan7Xmkj1H72prKu7X7Vr/uYdcD8T9Ooy4fh7ivivwhiO8fvoO2onGYhMioSEAAAAASUVORK5CYII=">
  <title>Sign In — PlacementAI Pro</title>
  <link rel="stylesheet" href="css/style.css?v=5">
  <style>
    body { background:#0a0a0a; overflow:hidden; }
    .login-wrap { display:flex; height:100vh; }

    /* Left: animated visual panel */
    .login-visual {
      flex:1; position:relative; overflow:hidden;
      background: #0a0a0a;
      display:flex; flex-direction:column; justify-content:space-between;
      padding:36px 48px;
    }
    .noise-bg {
      position:absolute; inset:0;
      background: radial-gradient(ellipse 80% 60% at 50% 0%, rgba(124,106,255,.18) 0%, transparent 70%),
                  radial-gradient(ellipse 60% 80% at 80% 80%, rgba(0,229,180,.08) 0%, transparent 60%);
    }
    .grid-lines {
      position:absolute; inset:0;
      background-image: linear-gradient(rgba(255,255,255,.03) 1px, transparent 1px),
                        linear-gradient(90deg, rgba(255,255,255,.03) 1px, transparent 1px);
      background-size: 48px 48px;
    }
    .visual-content { position:relative; z-index:1; }
    .brand { display:flex; align-items:center; gap:10px; }
    .brand-ico { width:34px; height:34px; background:linear-gradient(135deg,#7c6aff,#a78bfa); border-radius:9px; display:flex; align-items:center; justify-content:center; }
    .brand-name { font-size:.95rem; font-weight:700; color:#fafafa; letter-spacing:-.02em; }

    .vis-hero { position:relative; z-index:1; }
    .vis-hero h1 { font-size:clamp(2rem,3.5vw,2.8rem); font-weight:900; line-height:1.1; letter-spacing:-.04em; color:#fafafa; margin-bottom:16px; }
    .vis-hero h1 em { font-style:normal; background:linear-gradient(135deg,#7c6aff,#a78bfa 50%,#00e5b4); -webkit-background-clip:text; -webkit-text-fill-color:transparent; background-clip:text; }
    .vis-hero p { color:#666; font-size:14.5px; line-height:1.7; max-width:380px; }

    .feature-list { position:relative; z-index:1; display:flex; flex-direction:column; gap:10px; }
    .feat { display:flex; align-items:center; gap:12px; padding:13px 16px; background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.07); border-radius:12px; backdrop-filter:blur(10px); }
    .feat-ico { width:34px; height:34px; border-radius:9px; display:flex; align-items:center; justify-content:center; font-size:1rem; flex-shrink:0; }
    .feat-ico.v { background:rgba(124,106,255,.2); }
    .feat-ico.g { background:rgba(0,214,143,.15); }
    .feat-ico.a { background:rgba(0,200,255,.15); }
    .feat-body strong { display:block; font-size:13px; font-weight:600; color:#fafafa; }
    .feat-body span   { font-size:11.5px; color:#555; }

    /* Right: form panel */
    .login-form-panel {
      width:440px; flex-shrink:0;
      background:#111;
      border-left:1px solid rgba(255,255,255,.07);
      display:flex; align-items:center; justify-content:center;
      padding:40px 44px;
    }
    .form-inner { width:100%; max-width:340px; }
    .form-title { font-size:1.4rem; font-weight:800; letter-spacing:-.03em; margin-bottom:5px; }
    .form-sub { color:#555; font-size:13.5px; margin-bottom:30px; }

    .f-label { font-size:11.5px; font-weight:600; color:#666; text-transform:uppercase; letter-spacing:.05em; display:block; margin-bottom:7px; }
    .f-input-wrap { position:relative; margin-bottom:16px; }
    .f-input-wrap svg { position:absolute; left:13px; top:50%; transform:translateY(-50%); color:#444; pointer-events:none; }
    .f-input {
      width:100%; background:#0a0a0a; border:1px solid rgba(255,255,255,.1);
      border-radius:9px; padding:10px 14px 10px 40px;
      color:#fafafa; font-size:14px; font-family:inherit; outline:none;
      transition:border-color .15s, box-shadow .15s;
    }
    .f-input:focus { border-color:#7c6aff; box-shadow:0 0 0 3px rgba(124,106,255,.12); }
    .f-input::placeholder { color:#333; }

    .sign-btn {
      width:100%; padding:11px; border:none; border-radius:9px; cursor:pointer;
      background:linear-gradient(135deg,#7c6aff,#a78bfa); color:#fff;
      font-size:14.5px; font-weight:700; font-family:inherit;
      display:flex; align-items:center; justify-content:center; gap:8px;
      transition:filter .15s, transform .15s; box-shadow:0 2px 16px rgba(124,106,255,.3);
      margin-top:6px;
    }
    .sign-btn:hover { filter:brightness(1.1); transform:translateY(-1px); }
    .sign-btn:disabled { opacity:.5; transform:none; cursor:not-allowed; }

    .or-div { display:flex; align-items:center; gap:10px; margin:20px 0; color:#333; font-size:12px; }
    .or-div::before,.or-div::after { content:''; flex:1; height:1px; background:rgba(255,255,255,.07); }

    .demo-row { display:grid; grid-template-columns:1fr 1fr; gap:8px; }
    .demo-btn {
      padding:9px 10px; background:#161616; border:1px solid rgba(255,255,255,.09);
      border-radius:9px; color:#888; font-size:12.5px; font-weight:600; font-family:inherit;
      cursor:pointer; display:flex; align-items:center; justify-content:center; gap:6px;
      transition:all .15s;
    }
    .demo-btn:hover { background:#1e1e1e; border-color:rgba(255,255,255,.15); color:#fafafa; }
    .demo-tag { font-size:10px; padding:2px 6px; border-radius:99px; font-weight:700; }
    .demo-tag.s { background:rgba(0,214,143,.12); color:var(--emerald,#00d68f); }
    .demo-tag.a { background:rgba(255,71,87,.12); color:#ff4757; }

    .foot-links { text-align:center; margin-top:22px; font-size:13px; color:#444; }
    .foot-links a { color:#a78bfa; font-weight:600; }

    #alertMsg { margin-bottom:14px; }
    .err-msg { padding:10px 13px; background:rgba(255,71,87,.1); border:1px solid rgba(255,71,87,.2); border-radius:8px; color:#ff8a95; font-size:13px; }
    .ok-msg  { padding:10px 13px; background:rgba(0,214,143,.1); border:1px solid rgba(0,214,143,.2); border-radius:8px; color:#4ecca3; font-size:13px; }
    .spin { width:15px; height:15px; border:2px solid rgba(255,255,255,.2); border-top-color:#fff; border-radius:50%; animation:spin .6s linear infinite; }
    @keyframes spin { to{transform:rotate(360deg)} }

    .creds-box { margin-top:18px; padding:13px; background:#0d0d0d; border:1px solid rgba(255,255,255,.07); border-radius:9px; }
    .creds-title { font-size:10px; font-weight:700; text-transform:uppercase; letter-spacing:.07em; color:#444; margin-bottom:8px; }
    .cred-row { font-size:12.5px; color:#666; line-height:1.9; }
    .cred-row strong { color:#888; }

    @media(max-width:860px) { .login-visual{display:none} .login-form-panel{width:100%;border:none;padding:32px 24px} }

    /* ── Login page animations ── */
    @keyframes loginFadeUp   { from{opacity:0;transform:translateY(24px)} to{opacity:1;transform:translateY(0)} }
    @keyframes loginFadeLeft { from{opacity:0;transform:translateX(-28px)} to{opacity:1;transform:translateX(0)} }
    @keyframes loginScaleIn  { from{opacity:0;transform:scale(.94)} to{opacity:1;transform:scale(1)} }
    @keyframes loginGlow     { 0%,100%{opacity:.5} 50%{opacity:1} }
    @keyframes loginOrb      { 0%,100%{transform:translate(0,0) scale(1)} 33%{transform:translate(20px,-15px) scale(1.05)} 66%{transform:translate(-10px,10px) scale(.95)} }
    @keyframes featSlide     { from{opacity:0;transform:translateX(-16px)} to{opacity:1;transform:translateX(0)} }

    /* Visual panel */
    .login-visual { animation: loginFadeLeft .7s cubic-bezier(.4,0,.2,1) both; }
    .vis-hero h1  { animation: loginFadeUp .8s ease .2s both; }
    .vis-hero p   { animation: loginFadeUp .8s ease .35s both; }
    .feat:nth-child(1) { animation: featSlide .6s ease .4s both; opacity:0; }
    .feat:nth-child(2) { animation: featSlide .6s ease .55s both; opacity:0; }
    .feat:nth-child(3) { animation: featSlide .6s ease .7s both; opacity:0; }

    /* Form panel */
    .login-form-panel { animation: loginScaleIn .6s cubic-bezier(.34,1.56,.64,1) .15s both; }
    .form-title        { animation: loginFadeUp .6s ease .25s both; opacity:0; }
    .form-sub          { animation: loginFadeUp .6s ease .35s both; opacity:0; }
    .f-input-wrap:nth-child(1) { animation: loginFadeUp .5s ease .45s both; opacity:0; }
    .f-input-wrap:nth-child(2) { animation: loginFadeUp .5s ease .55s both; opacity:0; }
    .sign-btn          { animation: loginFadeUp .5s ease .65s both; opacity:0; }
    .foot-links        { animation: loginFadeUp .5s ease .75s both; opacity:0; }

    /* Floating orbs behind visual */
    .login-visual::before {
      content:''; position:absolute; width:300px; height:300px;
      background:radial-gradient(circle, rgba(124,106,255,.18) 0%, transparent 70%);
      border-radius:50%; top:10%; left:10%; pointer-events:none;
      animation: loginOrb 8s ease-in-out infinite;
    }
    .login-visual::after {
      content:''; position:absolute; width:200px; height:200px;
      background:radial-gradient(circle, rgba(0,229,180,.12) 0%, transparent 70%);
      border-radius:50%; bottom:15%; right:15%; pointer-events:none;
      animation: loginOrb 10s ease-in-out 3s infinite reverse;
    }

    /* Input focus ring */
    .f-input:focus { box-shadow: 0 0 0 3px rgba(124,106,255,.2); border-color: #7c6aff !important; outline: none; }

    /* Sign btn hover */
    .sign-btn { transition: transform .15s, box-shadow .15s !important; }
    .sign-btn:hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(124,106,255,.4); }
    .sign-btn:active { transform: scale(.97); }
  </style>
</head>
<body>
<div class="login-wrap">
  <!-- LEFT visual -->
  <div class="login-visual">
    <div class="noise-bg"></div>
    <div class="grid-lines"></div>
    <div class="visual-content">
      <div class="brand">
        <div class="brand-ico" style="background:none;padding:0"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" width="20" height="20"><defs><linearGradient id="gcl20" x1="0" y1="1" x2="1" y2="0"><stop offset="0%" stop-color="#ff4757"/><stop offset="100%" stop-color="#f59e0b"/></linearGradient></defs><rect width="20" height="20" rx="4" fill="#1e1a10"/><rect x="3" y="13" width="3" height="6" rx="1" fill="#f59e0b" opacity=".45"/><rect x="8" y="9" width="3" height="10" rx="1" fill="#ff6b35" opacity=".7"/><rect x="12" y="5" width="3" height="14" rx="1" fill="url(#gcl20)"/><polyline points="14,3 16,5 16,4" fill="none" stroke="url(#gcl20)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><line x1="12" y1="4" x2="14" y2="3" stroke="url(#gcl20)" stroke-width="1.5" stroke-linecap="round"/></svg></div>
        <div class="brand-name">PlacementAI Pro</div>
      </div>
    </div>
    <div class="vis-hero">
      <h1>Land your<br><em>dream job</em><br>with AI</h1>
      <p>Interview coaching, resume analysis, and personalized roadmaps — everything you need to ace placements.</p>
    </div>
    <div class="feature-list">
      <div class="feat"><div class="feat-ico v">🎙️</div><div class="feat-body"><strong>AI Mock Interviews</strong><span>Company-specific, no repeat questions</span></div></div>
      <div class="feat"><div class="feat-ico g">📄</div><div class="feat-body"><strong>Resume ATS Analyzer</strong><span>Score your resume against job descriptions</span></div></div>
      <div class="feat"><div class="feat-ico a">🗺</div><div class="feat-body"><strong>Job-Targeted Roadmap</strong><span>Paste any job post, get a custom prep plan</span></div></div>
    </div>
  </div>

  <!-- RIGHT form -->
  <div class="login-form-panel">
    <div class="form-inner">
      <h2 class="form-title">Welcome back</h2>
      <p class="form-sub">Sign in to your PlacementAI account</p>

      <div id="alertMsg"></div>

      <form id="loginForm">
        <label class="f-label">Email address</label>
        <div class="f-input-wrap">
          <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
          <input type="email" id="email" class="f-input" placeholder="you@college.edu" required autocomplete="email">
        </div>

        <label class="f-label">Password</label>
        <div class="f-input-wrap">
          <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
          <input type="password" id="password" class="f-input" placeholder="Your password" required autocomplete="current-password">
        </div>

        <button type="submit" id="signBtn" class="sign-btn">Sign In</button>
      </form>

      <div class="foot-links">
        New here? <a href="register.php">Create account</a> &nbsp;·&nbsp; <a href="register-org.php">Register company</a>
      </div>
    </div>
  </div>
</div>

<script src="js/app.js?v=5"></script>
<script>
document.getElementById('loginForm').addEventListener('submit', async e => {
  e.preventDefault();
  const btn = document.getElementById('signBtn');
  const alertDiv = document.getElementById('alertMsg');
  alertDiv.innerHTML = '';
  btn.disabled = true;
  btn.innerHTML = '<div class="spin"></div> Signing in…';

  try {
    const data = await API.post('auth_login.php', {
      email:    document.getElementById('email').value.trim(),
      password: document.getElementById('password').value
    });
    Auth.setUser(data.user);
    alertDiv.innerHTML = '<div class="ok-msg">✓ Success! Redirecting…</div>';
    setTimeout(() => {
      const r = data.user.role;
      location.href = r==='admin' ? 'admin.php' : r==='organization' ? 'organization.php' : 'dashboard.php';
    }, 500);
  } catch(err) {
    btn.disabled = false;
    btn.innerHTML = 'Sign In';
    alertDiv.innerHTML = `<div class="err-msg">⚠ ${esc(err.message || 'Invalid email or password')}</div>`;
  }
});


</script>
</body>
</html>

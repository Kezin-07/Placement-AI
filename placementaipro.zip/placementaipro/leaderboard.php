<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="icon" type="image/svg+xml" href="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAzMiAzMiIgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIj48ZGVmcz48bGluZWFyR3JhZGllbnQgaWQ9ImciIHgxPSIwIiB5MT0iMSIgeDI9IjEiIHkyPSIwIj48c3RvcCBvZmZzZXQ9IjAlIiBzdG9wLWNvbG9yPSIjZmY0NzU3Ii8+PHN0b3Agb2Zmc2V0PSIxMDAlIiBzdG9wLWNvbG9yPSIjZjU5ZTBiIi8+PC9saW5lYXJHcmFkaWVudD48L2RlZnM+PHJlY3Qgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIiByeD0iNyIgZmlsbD0iIzFlMWExMCIvPjxyZWN0IHg9IjYiIHk9IjIxIiB3aWR0aD0iNSIgaGVpZ2h0PSI5IiByeD0iMS41IiBmaWxsPSIjZjU5ZTBiIiBvcGFjaXR5PSIuNSIvPjxyZWN0IHg9IjEzIiB5PSIxNSIgd2lkdGg9IjUiIGhlaWdodD0iMTUiIHJ4PSIxLjUiIGZpbGw9IiNmZjZiMzUiIG9wYWNpdHk9Ii43NSIvPjxyZWN0IHg9IjIwIiB5PSI4IiB3aWR0aD0iNSIgaGVpZ2h0PSIyMiIgcng9IjEuNSIgZmlsbD0idXJsKCNnKSIvPjxwb2x5bGluZSBwb2ludHM9IjIzLDQgMjcsOCAyNyw1IiBmaWxsPSJub25lIiBzdHJva2U9InVybCgjZykiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIi8+PGxpbmUgeDE9IjE5IiB5MT0iNSIgeDI9IjI3IiB5Mj0iNCIgc3Ryb2tlPSJ1cmwoI2cpIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPjwvc3ZnPg==">
  <title>Leaderboard — PlacementAI Pro</title>
  <link rel="stylesheet" href="css/style.css?v=5">
  <style>
    .lb-wrap { overflow-x: auto; }
    .lb-table { width:100%; border-collapse:collapse; min-width:600px; }
    .lb-table th { background:var(--surface2); padding:11px 14px; text-align:left; font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:.08em; color:var(--text3); white-space:nowrap; }
    .lb-table td { padding:11px 14px; border-bottom:1px solid var(--border); font-size:13px; vertical-align:middle; }
    .lb-table tr:last-child td { border-bottom:none; }
    .lb-table tr:hover td { background:rgba(255,255,255,.03); }
    .rank-cell { font-family:var(--font-display); font-size:1.15rem; font-weight:800; width:52px; text-align:center; }
    .score-pill { display:inline-flex; align-items:center; gap:5px; padding:4px 11px; border-radius:99px; font-size:12px; font-weight:700; }
    .branch-chip { display:inline-block; padding:2px 9px; border-radius:6px; font-size:11px; font-weight:600; background:var(--surface2); color:var(--text2); border:1px solid var(--border); }
    .my-rank-banner { background:rgba(108,99,255,.08); border:1px solid rgba(108,99,255,.25); border-radius:var(--radius); padding:14px 20px; margin-bottom:20px; display:flex; align-items:center; gap:16px; flex-wrap:wrap; }
    .rank-me td { background:rgba(108,99,255,.07) !important; }
    .rank-me td:first-child { border-left:3px solid var(--primary); }
    .avatar-xs { width:32px; height:32px; border-radius:50%; background:var(--primary-g); display:flex; align-items:center; justify-content:center; font-size:12px; font-weight:700; color:#fff; flex-shrink:0; }
    .filter-bar { display:flex; gap:8px; flex-wrap:wrap; align-items:center; }
    .lb-top3 { display:grid; grid-template-columns:1fr 1fr 1fr; gap:14px; margin-bottom:24px; }
    @media(max-width:600px) { .lb-top3 { grid-template-columns:1fr; } }
    .podium-card { background:var(--surface); border:1px solid var(--border); border-radius:var(--radius-lg); padding:20px 16px; text-align:center; transition:border-color .2s, transform .2s; }
    .podium-card:hover { transform:translateY(-3px); border-color:var(--border2); }
    .podium-card.gold   { border-color:rgba(255,215,0,.3); background:rgba(255,215,0,.04); }
    .podium-card.silver { border-color:rgba(192,192,192,.3); background:rgba(192,192,192,.03); }
    .podium-card.bronze { border-color:rgba(205,127,50,.3); background:rgba(205,127,50,.03); }
    .podium-avatar { width:52px; height:52px; border-radius:50%; background:var(--primary-g); display:flex; align-items:center; justify-content:center; font-family:var(--font-display); font-size:1.3rem; font-weight:800; color:#fff; margin:0 auto 10px; }
  </style>
</head>
<body>
<script src="js/app.js?v=5"></script>
<script>
const user = Auth.requireAuth('student');
if (user) { buildShell('leaderboard'); setTimeout(()=>initLeaderboard(), 0); }

let lbData = [], lbBranches = [], lbMyRank = null, lbBranch = '';

async function initLeaderboard() {
  document.getElementById('topbarTitle').textContent = 'Leaderboard';
  renderPage();
  await loadLeaderboard('');
}

function renderPage() {
  const page = document.getElementById('mainPage');
  page.innerHTML = `
    <div class="page-header" style="margin-bottom:20px">
      <h1 style="font-size:1.6rem">🏆 Leaderboard</h1>
      <p style="color:var(--text3);font-size:13px;margin-top:2px">Live rankings · Composite score: CGPA + Aptitude + Resume + XP</p>
    </div>
    <div id="myRankBanner"></div>
    <div id="top3Podium"></div>
    <div class="card">
      <div class="card-header">
        <div class="card-title">All Rankings</div>
        <div id="filterBar" class="filter-bar" style="margin:0"></div>
      </div>
      <div id="lbLoading" class="loading-center"><div class="spinner"></div></div>
      <div class="lb-wrap">
        <table class="lb-table">
          <thead>
            <tr>
              <th>#</th>
              <th>Student</th>
              <th>Branch</th>
              <th>CGPA</th>
              <th>Aptitude</th>
              <th>Resume</th>
              <th>XP</th>
              <th>Score</th>
            </tr>
          </thead>
          <tbody id="lbBody"></tbody>
        </table>
        <div id="lbEmpty" style="display:none" class="empty-state">
          <h4>No students yet</h4>
          <p>Be the first to complete your profile!</p>
        </div>
      </div>
    </div>`;
}

async function loadLeaderboard(branch) {
  lbBranch = branch;
  document.getElementById('lbLoading').style.display = 'flex';
  document.getElementById('lbBody').innerHTML = '';

  try {
    const d = await API.get('leaderboard.php?user_id=' + user.id + '&branch=' + encodeURIComponent(branch));
    if (!d.success) throw new Error(d.message || 'Failed to load');
    lbData     = d.students  || [];
    lbBranches = d.branches  || [];
    lbMyRank   = d.my_rank   || null;
    renderLeaderboard();
  } catch(e) {
    document.getElementById('lbLoading').style.display = 'none';
    document.getElementById('lbBody').innerHTML = '<tr><td colspan="8" style="text-align:center;color:var(--red);padding:24px">' + esc(e.message) + '</td></tr>';
  }
}

function renderLeaderboard() {
  document.getElementById('lbLoading').style.display = 'none';

  // ── My rank banner ──────────────────────────────────────────
  if (lbMyRank) {
    const topPct = Math.ceil((lbMyRank / Math.max(lbData.length, 1)) * 100);
    document.getElementById('myRankBanner').innerHTML =
      '<div class="my-rank-banner">' +
        '<div style="font-size:2rem;line-height:1">🎯</div>' +
        '<div>' +
          '<div style="font-size:10px;color:var(--text3);font-weight:700;text-transform:uppercase;letter-spacing:.1em;margin-bottom:2px">Your Rank</div>' +
          '<div style="font-family:var(--font-display);font-size:2rem;font-weight:900;color:var(--primary);line-height:1">#' + lbMyRank + '</div>' +
        '</div>' +
        '<div style="margin-left:auto;text-align:right">' +
          '<div style="font-size:12px;color:var(--text3)">out of ' + lbData.length + ' students</div>' +
          '<div style="font-size:12px;color:var(--emerald);font-weight:700;margin-top:3px">Top ' + topPct + '%</div>' +
        '</div>' +
      '</div>';
  }

  // ── Top 3 podium cards ──────────────────────────────────────
  const top3 = lbData.slice(0, 3);
  if (top3.length >= 1) {
    const podiumClasses = ['gold', 'silver', 'bronze'];
    const podiumEmoji   = ['🥇', '🥈', '🥉'];
    document.getElementById('top3Podium').innerHTML =
      '<div class="lb-top3">' +
      top3.map(function(s, i) {
        const initials = s.name.split(' ').map(function(w){return w[0];}).join('').slice(0,2).toUpperCase();
        return '<div class="podium-card ' + podiumClasses[i] + '">' +
          '<div style="font-size:1.6rem;margin-bottom:8px">' + podiumEmoji[i] + '</div>' +
          '<div class="podium-avatar">' + esc(initials) + '</div>' +
          '<div style="font-weight:700;font-size:14px;color:var(--text);margin-bottom:3px">' + esc(s.name) + '</div>' +
          '<div style="font-size:12px;color:var(--text3);margin-bottom:8px">' + esc(s.branch||'—') + '</div>' +
          '<div style="font-family:var(--font-display);font-size:1.4rem;font-weight:900;color:' + (i===0?'#f5c518':i===1?'#a8a8a8':'#cd7f32') + '">' + s.composite_score + '</div>' +
          '<div style="font-size:10.5px;color:var(--text3);margin-top:2px">Composite Score</div>' +
        '</div>';
      }).join('') +
      '</div>';
  }

  // ── Branch filter ───────────────────────────────────────────
  document.getElementById('filterBar').innerHTML =
    '<span style="font-size:11px;color:var(--text3);font-weight:700">FILTER:</span>' +
    '<button onclick="loadLeaderboard(\'\')" class="btn ' + (lbBranch===''?'btn-primary':'btn-ghost') + ' btn-sm">All</button>' +
    lbBranches.map(function(b) {
      return '<button onclick="loadLeaderboard(\'' + esc(b) + '\')" class="btn ' + (lbBranch===b?'btn-primary':'btn-ghost') + ' btn-sm">' + esc(b) + '</button>';
    }).join('');

  if (!lbData.length) {
    document.getElementById('lbEmpty').style.display = 'block';
    return;
  }

  // ── Table rows ──────────────────────────────────────────────
  const rows = lbData.map(function(s) {
    const isMe = String(s.id) === String(user.id);
    const medal = s.rank===1 ? '🥇' : s.rank===2 ? '🥈' : s.rank===3 ? '🥉' : '';
    const initials = s.name.split(' ').map(function(w){return w[0];}).join('').slice(0,2).toUpperCase();
    const photo = s.photo_url
      ? '<img src="' + esc(s.photo_url) + '" style="width:32px;height:32px;border-radius:50%;object-fit:cover;margin-right:8px">'
      : '<div class="avatar-xs" style="margin-right:8px">' + esc(initials) + '</div>';

    const scoreColor = s.composite_score>=80 ? 'var(--emerald)' : s.composite_score>=60 ? 'var(--primary-l)' : 'var(--accent2)';
    const scoreBg    = s.composite_score>=80 ? 'rgba(16,185,129,.15)' : s.composite_score>=60 ? 'rgba(108,99,255,.12)' : 'rgba(245,158,11,.12)';

    return '<tr class="' + (isMe?'rank-me':'') + '">' +
      '<td class="rank-cell">' + (medal ? '<span>' + medal + '</span>' : '#' + s.rank) + '</td>' +
      '<td><div style="display:flex;align-items:center">' + photo +
        '<div>' +
          '<div style="font-weight:' + (isMe?700:500) + ';color:var(--text)">' + esc(s.name) + (isMe?' <span style="font-size:10px;color:var(--primary);font-weight:700">(You)</span>':'') + '</div>' +
        '</div>' +
      '</div></td>' +
      '<td><span class="branch-chip">' + esc(s.branch||'—') + '</span></td>' +
      '<td style="font-weight:600">' + (s.cgpa ? parseFloat(s.cgpa).toFixed(2) : '—') + '</td>' +
      '<td>' + (s.aptitude_score ? Math.round(s.aptitude_score)+'%' : '—') + '</td>' +
      '<td>' + (s.resume_score ? Math.round(s.resume_score)+'%' : '—') + '</td>' +
      '<td style="color:var(--accent2);font-weight:600">' + (s.total_xp ? fmtNum(s.total_xp)+' XP' : '—') + '</td>' +
      '<td><span class="score-pill" style="background:' + scoreBg + ';color:' + scoreColor + '">⚡ ' + s.composite_score + '</span></td>' +
    '</tr>';
  }).join('');

  document.getElementById('lbBody').innerHTML = rows;
}
</script>
</body>
</html>

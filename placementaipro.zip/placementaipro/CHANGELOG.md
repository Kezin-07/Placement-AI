# PlacementAI Pro — Changelog

## v2.0 — Final Release (Tested & Enhanced)

### 🔧 Bugs Fixed
1. **Placement Predictor over-scored weak students** (`predict.php`)
   - CGPA < 6.5 now uses `cgpa × 4` weight (was `cgpa × 8`)
   - Students below real-world cutoff (6.5) now correctly tier as "Needs Work"

2. **Streak record missing after registration** (`auth_register.php`)
   - Students had no `streak_data` row, causing daily check-in to fail silently
   - Fixed by auto-inserting streak record at registration time

### ✅ Enhancements Added

#### Enhancement 1 — Streak Auto-Created on Register (`auth_register.php`)
- Every student now gets a `streak_data` row the moment they register
- Eliminates "orphan" students who couldn't earn XP or check in

#### Enhancement 2 — Aptitude Score History (`aptitude_save.php`)
- Response now includes: `history[]`, `avg_score`, `best_score`, `attempt_count`
- Bonus XP (+25) awarded when student beats their previous best score
- Base XP: 30 + score/5 per attempt

#### Enhancement 3 — Profile Completion XP (`student_profile_save.php`)
- One-time XP bonus (filled_fields × 20) when student fills ≥5 profile fields
- Response includes `completion_pct` (0–100%) on every save
- Uses `profile_xp_awarded` flag to prevent double-awarding

#### Enhancement 4 — Application Spam Cap (`apply_job.php`)
- Hard limit of 20 applications per student
- Returns HTTP-429 with clear message: "Application limit reached (max 20)"
- Normal students unaffected; only prevents spam behaviour

#### Enhancement 5 — Notification Bell Badge (`app.js` — already built)
- `Notifs.startPolling(uid)` fires on every page load for logged-in users
- Polls `notifications.php?action=unread_count` every 30 seconds
- Supports per-item mark-read and mark-all-read
- Badge shows count, hides when 0

#### Enhancement 6 — Skill-Match Job Recommendations (`job_recommendations.php` — already built)
- `match_score` = 65% skill overlap + 35% CGPA eligibility
- Returns `matched_skills[]` and `missing_skills[]` per job
- Excludes already-applied jobs
- Sorted by match_score DESC, max 10 results

### 📊 Test Results (v2.0)
- **438 tests run** across 18 phases
- **438 passed — 100% pass rate**
- Tested: 50 students, 50 organizations, 1 admin
- 75 jobs posted, 215+ applications, 453+ notifications generated

<?php
// php/admin_panel.php  –  Unified Admin API
require 'config.php';

$pdo    = getDB();
$body   = getBody();
$action = $body['action'] ?? $_GET['action'] ?? '';
$adminId= intval($body['admin_id'] ?? $_GET['admin_id'] ?? 0);

// Auth check for all actions except ping
if ($action !== 'ping') requireAdmin();

switch ($action) {

// ── Overview stats ──────────────────────────────────────────
case 'stats':
    $stats = [];
    foreach ([
        'students'     => "SELECT COUNT(*) FROM users WHERE role='student' AND is_active=1",
        'orgs_total'   => "SELECT COUNT(*) FROM organizations",
        'orgs_pending' => "SELECT COUNT(*) FROM organizations WHERE verified=0",
        'orgs_verified'=> "SELECT COUNT(*) FROM organizations WHERE verified=1",
        'jobs_active'  => "SELECT COUNT(*) FROM job_posts WHERE is_active=1",
        'applications' => "SELECT COUNT(*) FROM applications",
        'placed'       => "SELECT COUNT(*) FROM applications WHERE status='hired'",
    ] as $key => $sql) {
        $stats[$key] = (int)$pdo->query($sql)->fetchColumn();
    }
    $placement_rate = $stats['students'] > 0
        ? round(($stats['placed'] / $stats['students']) * 100, 1) : 0;
    $stats['placement_rate'] = $placement_rate;

    // Branch stats
    $branch = $pdo->query("SELECT branch, COUNT(*) as cnt FROM student_profiles GROUP BY branch ORDER BY cnt DESC LIMIT 8")->fetchAll();
    $stats['by_branch'] = $branch;

    // Recent registrations
    $recent = $pdo->query("SELECT name,email,role,created_at FROM users ORDER BY created_at DESC LIMIT 8")->fetchAll();
    $stats['recent'] = $recent;

    respond(['success'=>true,'stats'=>$stats]);

// ── List students ───────────────────────────────────────────
case 'students':
    $q      = '%'.($body['q'] ?? $_GET['q'] ?? '').'%';
    $branch = $body['branch'] ?? $_GET['branch'] ?? '';
    $sql    = "SELECT u.id,u.name,u.email,u.is_active,u.created_at,
                      sp.branch,sp.cgpa,sp.skills,sp.projects,sp.internships,
                      sp.aptitude_score,sp.resume_score,sp.ats_score,sp.interview_score
               FROM users u
               LEFT JOIN student_profiles sp ON sp.user_id=u.id
               WHERE u.role='student' AND (u.name LIKE ? OR u.email LIKE ?)";
    $params = [$q,$q];
    if ($branch) { $sql .= ' AND sp.branch LIKE ?'; $params[] = "%$branch%"; }
    $sql .= ' ORDER BY u.created_at DESC LIMIT 100';
    $s = $pdo->prepare($sql);
    $s->execute($params);
    respond(['success'=>true,'students'=>$s->fetchAll()]);

// ── List orgs ───────────────────────────────────────────────
case 'orgs':
    $status = $body['status'] ?? $_GET['status'] ?? 'all';
    $sql    = "SELECT o.*,u.name,u.email,u.is_active,
                      (SELECT COUNT(*) FROM job_posts jp WHERE jp.org_id=o.id) as job_count
               FROM organizations o JOIN users u ON u.id=o.user_id";
    $params = [];
    if ($status === 'pending')  { $sql .= ' WHERE o.verified=0'; }
    if ($status === 'verified') { $sql .= ' WHERE o.verified=1'; }
    $sql .= ' ORDER BY o.created_at DESC';
    $s = $pdo->prepare($sql); $s->execute($params);
    respond(['success'=>true,'orgs'=>$s->fetchAll()]);

// ── Approve / reject org ────────────────────────────────────
case 'approve_org':
    $org_id  = intval($body['org_id'] ?? 0);
    $approve = (bool)($body['approve'] ?? true);
    $notes   = $body['notes'] ?? '';
    if (!$org_id) respond(['success'=>false,'message'=>'org_id required'], 400);
    $orgUser = $pdo->prepare("SELECT o.user_id, u.name, o.company_name FROM organizations o JOIN users u ON u.id=o.user_id WHERE o.id=? LIMIT 1");
    $orgUser->execute([$org_id]); $orgInfo = $orgUser->fetch();
    $s = $pdo->prepare('UPDATE organizations SET verified=?,admin_notes=? WHERE id=?');
    $s->execute([$approve?1:0, $notes, $org_id]);
    // Activate or deactivate all job posts for this org based on approval status
    $pdo->prepare('UPDATE job_posts SET is_active=? WHERE org_id=?')
        ->execute([$approve?1:0, $org_id]);
    // Notify org user (wrapped in try-catch in case notifications table doesn't exist)
    if ($orgInfo) {
        try {
            $title_n = $approve ? '✅ Organization Approved!' : '❌ Organization Not Approved';
            $body_n  = $approve ? "Your organization \"{$orgInfo['company_name']}\" has been verified. You can now post jobs." : "Your organization \"{$orgInfo['company_name']}\" was not approved. Notes: $notes";
            $pdo->prepare("INSERT INTO notifications (user_id,type,title,body,link) VALUES (?,?,?,?,?)")
                ->execute([$orgInfo['user_id'], $approve?'org_approved':'org_rejected', $title_n, $body_n, 'organization.html']);
        } catch (\Exception $e) {
            // notifications table may not exist — silently skip
        }
    }
    respond(['success'=>true,'verified'=>$approve]);

// ── Block/unblock user ──────────────────────────────────────
case 'toggle_user':
    $uid = intval($body['user_id'] ?? 0);
    if (!$uid) respond(['success'=>false,'message'=>'user_id required'], 400);
    $s   = $pdo->prepare('SELECT is_active FROM users WHERE id=? LIMIT 1');
    $s->execute([$uid]); $row = $s->fetch();
    if (!$row) respond(['success'=>false,'message'=>'User not found'], 404);
    $new = $row['is_active'] ? 0 : 1;
    $pdo->prepare('UPDATE users SET is_active=? WHERE id=?')->execute([$new,$uid]);
    respond(['success'=>true,'is_active'=>$new]);

// ── Delete user ─────────────────────────────────────────────
case 'delete_user':
    $uid = intval($body['user_id'] ?? 0);
    if (!$uid) respond(['success'=>false,'message'=>'user_id required'], 400);
    $pdo->prepare('DELETE FROM users WHERE id=? AND role!=\'admin\'')->execute([$uid]);
    respond(['success'=>true]);

// ── Analytics: top skills ───────────────────────────────────
case 'analytics':
    // Skill frequency
    $rows = $pdo->query("SELECT skills FROM student_profiles WHERE skills IS NOT NULL AND skills != ''")->fetchAll(PDO::FETCH_COLUMN);
    $freq = [];
    foreach ($rows as $row) {
        foreach (explode(',', $row) as $sk) {
            $sk = ucwords(trim($sk));
            if ($sk) $freq[$sk] = ($freq[$sk]??0)+1;
        }
    }
    arsort($freq);
    $topSkills = array_slice($freq, 0, 15, true);

    // Placement by branch
    $branch = $pdo->query("SELECT sp.branch, COUNT(*) as total,
        SUM(CASE WHEN a.status='hired' THEN 1 ELSE 0 END) as placed
        FROM student_profiles sp
        LEFT JOIN applications a ON a.student_id=sp.user_id
        GROUP BY sp.branch ORDER BY total DESC")->fetchAll();

    // Top companies by applications
    $companies = $pdo->query("SELECT o.company_name, COUNT(a.id) as apps
        FROM applications a
        JOIN job_posts jp ON jp.id=a.job_id
        JOIN organizations o ON o.id=jp.org_id
        GROUP BY o.id ORDER BY apps DESC LIMIT 8")->fetchAll();

    // Avg scores
    $avgs = $pdo->query("SELECT 
        AVG(cgpa) as avg_cgpa,
        AVG(aptitude_score) as avg_aptitude,
        AVG(resume_score) as avg_resume,
        AVG(ats_score) as avg_ats
        FROM student_profiles")->fetch();

    respond([
        'success'          => true,
        'top_skills'       => $topSkills,
        'placement_branch' => $branch,
        'top_companies'    => $companies,
        'avg_scores'       => $avgs,
    ]);

default:
    respond(['success'=>false,'message'=>'Unknown action: '.$action], 400);
}
?>

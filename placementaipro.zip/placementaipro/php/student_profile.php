<?php
// php/student_profile.php – Get student profile (PDO)
require 'config.php';

$user_id = intval($_GET['user_id'] ?? 0);
if (!$user_id) respond(['success' => false, 'message' => 'user_id required'], 400);

try {
    $pdo  = getDB();
    $stmt = $pdo->prepare('SELECT sp.*, u.name, u.email FROM student_profiles sp JOIN users u ON u.id=sp.user_id WHERE sp.user_id = ? LIMIT 1');
    $stmt->execute([$user_id]);
    $profile = $stmt->fetch();
    // Always return success:true — dashboard must not throw when profile row doesn't exist yet
    // Ensure valid UTF-8 for JSON
if ($profile) {
    foreach ($profile as $k => $v) {
        if (is_string($v)) $profile[$k] = mb_convert_encoding($v, 'UTF-8', 'UTF-8');
    }
}
respond(['success' => true, 'profile' => $profile ?: null]);
} catch (Exception $e) {
    respond(['success' => false, 'message' => 'DB error: ' . $e->getMessage()]);
}

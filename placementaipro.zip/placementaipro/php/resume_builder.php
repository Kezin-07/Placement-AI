<?php
// php/resume_builder.php – AI-powered Resume Builder (generates HTML→PDF-ready)
require 'config.php';

$body   = getBody();
$uid    = intval($body['user_id'] ?? 0);
$action = $body['action'] ?? 'generate';

if (!$uid) respond(['success'=>false,'message'=>'user_id required'], 401);

$pdo = getDB();

switch ($action) {

case 'generate':
    $data = $body['resume_data'] ?? [];
    if (empty($data)) respond(['success'=>false,'message'=>'resume_data required'], 400);

    // Build structured HTML resume
    $name       = htmlspecialchars($data['name'] ?? '');
    $email      = htmlspecialchars($data['email'] ?? '');
    $phone      = htmlspecialchars($data['phone'] ?? '');
    $linkedin   = htmlspecialchars($data['linkedin'] ?? '');
    $github     = htmlspecialchars($data['github'] ?? '');
    $branch     = htmlspecialchars($data['branch'] ?? '');
    $cgpa       = htmlspecialchars($data['cgpa'] ?? '');
    $skills     = htmlspecialchars($data['skills'] ?? '');
    $summary    = htmlspecialchars($data['summary'] ?? '');
    $experience = $data['experience'] ?? [];
    $education  = $data['education'] ?? [];
    $projects   = $data['projects'] ?? [];
    $college    = htmlspecialchars($data['college'] ?? '');
    $grad_year  = htmlspecialchars($data['grad_year'] ?? '');

    $expHTML = '';
    foreach ($experience as $exp) {
        $expHTML .= '<div class="entry">
            <div class="entry-header">
                <span class="entry-title">'.htmlspecialchars($exp['role']??'').'</span>
                <span class="entry-date">'.htmlspecialchars($exp['duration']??'').'</span>
            </div>
            <div class="entry-sub">'.htmlspecialchars($exp['company']??'').'</div>
            <p>'.htmlspecialchars($exp['description']??'').'</p>
        </div>';
    }

    $projHTML = '';
    foreach ($projects as $proj) {
        $projHTML .= '<div class="entry">
            <div class="entry-header">
                <span class="entry-title">'.htmlspecialchars($proj['name']??'').'</span>
                <span class="entry-date">'.htmlspecialchars($proj['tech']??'').'</span>
            </div>
            <p>'.htmlspecialchars($proj['description']??'').'</p>
        </div>';
    }

    $eduHTML = '';
    foreach ($education as $edu) {
        $eduHTML .= '<div class="entry">
            <div class="entry-header">
                <span class="entry-title">'.htmlspecialchars($edu['degree']??'').'</span>
                <span class="entry-date">'.htmlspecialchars($edu['year']??'').'</span>
            </div>
            <div class="entry-sub">'.htmlspecialchars($edu['institution']??'').' — CGPA: '.htmlspecialchars($edu['cgpa']??'').'</div>
        </div>';
    }

    $skillsFormatted = implode(' • ', array_map('trim', explode(',', $skills)));

    $html = <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>{$name} — Resume</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
  * { box-sizing:border-box; margin:0; padding:0; }
  body { font-family:'Inter',sans-serif; font-size:13px; color:#1a1a1a; background:#fff; padding:0; line-height:1.5; }
  .page { max-width:780px; margin:0 auto; padding:40px 48px; }
  .header { border-bottom:2.5px solid #6c63ff; padding-bottom:16px; margin-bottom:20px; }
  h1 { font-size:24px; font-weight:700; color:#1a1a1a; letter-spacing:-.02em; }
  .contact { display:flex; gap:16px; flex-wrap:wrap; margin-top:6px; font-size:12px; color:#555; }
  .contact a { color:#6c63ff; text-decoration:none; }
  h2 { font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:#6c63ff; margin:18px 0 8px; border-bottom:1px solid #e8e8e8; padding-bottom:4px; }
  .summary { color:#444; font-size:13px; }
  .skills-list { color:#333; font-size:12.5px; line-height:1.8; }
  .entry { margin-bottom:12px; }
  .entry-header { display:flex; justify-content:space-between; align-items:baseline; }
  .entry-title { font-weight:600; color:#1a1a1a; font-size:13.5px; }
  .entry-date { font-size:11.5px; color:#888; }
  .entry-sub { font-size:12.5px; color:#6c63ff; font-weight:500; margin:1px 0 4px; }
  .entry p { color:#555; font-size:12.5px; }
  @media print { body { padding:0; } .page { padding:24px 32px; } }
</style>
</head>
<body>
<div class="page">
  <div class="header">
    <h1>{$name}</h1>
    <div class="contact">
      <span>✉ {$email}</span>
      {$phone ? "<span>📞 {$phone}</span>" : ''}
      {$linkedin ? "<a href='{$linkedin}' target='_blank'>💼 LinkedIn</a>" : ''}
      {$github ? "<a href='{$github}' target='_blank'>💻 GitHub</a>" : ''}
    </div>
  </div>

  {$summary ? "<h2>Summary</h2><p class='summary'>{$summary}</p>" : ''}

  <h2>Education</h2>
  {$eduHTML ?: "<div class='entry'><div class='entry-header'><span class='entry-title'>{$branch}</span><span class='entry-date'>{$grad_year}</span></div><div class='entry-sub'>{$college} — CGPA: {$cgpa}</div></div>"}

  {$skills ? "<h2>Technical Skills</h2><div class='skills-list'>{$skillsFormatted}</div>" : ''}

  {$expHTML ? "<h2>Experience</h2>{$expHTML}" : ''}

  {$projHTML ? "<h2>Projects</h2>{$projHTML}" : ''}
</div>
</body>
</html>
HTML;

    // Save resume text to profile for later analysis
    $pdo->prepare("UPDATE student_profiles SET resume_text=? WHERE user_id=?")->execute([$html, $uid]);

    respond(['success'=>true,'html'=>$html]);

default:
    respond(['success'=>false,'message'=>'Unknown action'], 400);
}
?>

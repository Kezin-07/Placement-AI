<?php
// Run this once to fix admin password: visit fix_admin.php in browser
require 'config.php';
$pdo = getDB();

// Set admin password to 'admin123'
$hash = password_hash('admin123', PASSWORD_BCRYPT, ['cost'=>10]);
$stmt = $pdo->prepare("UPDATE users SET password_hash=? WHERE email='admin@placementai.com'");
$stmt->execute([$hash]);

// Also ensure admin is active
$stmt2 = $pdo->prepare("UPDATE users SET is_active=1, role='admin' WHERE email='admin@placementai.com'");
$stmt2->execute();

echo json_encode([
  'success' => true,
  'message' => 'Admin password reset to admin123',
  'hash' => $hash,
  'email' => 'admin@placementai.com'
]);

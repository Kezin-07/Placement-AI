<?php
// php/org_aptitude.php – Org custom aptitude questions (with auto-table-create)
require 'config.php';

$pdo    = getDB();

// Auto-create table if missing
$pdo->exec("CREATE TABLE IF NOT EXISTS org_aptitude_questions (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    org_id      INT UNSIGNED NOT NULL,
    job_id      INT UNSIGNED DEFAULT NULL,
    question    TEXT NOT NULL,
    option_a    VARCHAR(500) NOT NULL,
    option_b    VARCHAR(500) NOT NULL,
    option_c    VARCHAR(500) DEFAULT NULL,
    option_d    VARCHAR(500) DEFAULT NULL,
    correct     ENUM('a','b','c','d') NOT NULL DEFAULT 'a',
    difficulty  ENUM('easy','medium','hard') NOT NULL DEFAULT 'medium',
    category    VARCHAR(100) NOT NULL DEFAULT 'General',
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_org (org_id),
    INDEX idx_job (job_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$body   = getBody();
$action = $body['action'] ?? $_GET['action'] ?? '';
$uid    = intval($body['user_id'] ?? $_GET['user_id'] ?? 0);

if (!$uid) respond(['success'=>false,'message'=>'user_id required'], 401);
requireVerifiedOrg($uid);

$orgRow = $pdo->prepare('SELECT id FROM organizations WHERE user_id=?');
$orgRow->execute([$uid]); $org = $orgRow->fetch();
if (!$org) respond(['success'=>false,'message'=>'Organization not found'], 404);
$org_id = (int)$org['id'];

switch ($action) {

case 'list':
    $job_id = intval($body['job_id'] ?? $_GET['job_id'] ?? 0);
    $sql = "SELECT * FROM org_aptitude_questions WHERE org_id=?";
    $params = [$org_id];
    if ($job_id) { $sql .= " AND (job_id=? OR job_id IS NULL)"; $params[] = $job_id; }
    $sql .= " ORDER BY created_at DESC";
    $s = $pdo->prepare($sql); $s->execute($params);
    respond(['success'=>true,'questions'=>$s->fetchAll()]);

case 'add':
    $q   = trim($body['question'] ?? '');
    $a   = trim($body['option_a'] ?? '');
    $b   = trim($body['option_b'] ?? '');
    $c   = trim($body['option_c'] ?? '');
    $d   = trim($body['option_d'] ?? '');
    $ans = strtolower(trim($body['correct'] ?? ''));
    $diff= in_array($body['difficulty']??'',['easy','medium','hard']) ? $body['difficulty'] : 'medium';
    $cat = trim($body['category'] ?? 'General');
    $jid = !empty($body['job_id']) ? intval($body['job_id']) : null;

    if (!$q || !$a || !$b || !in_array($ans,['a','b','c','d'])) {
        respond(['success'=>false,'message'=>'question, option_a, option_b, correct (a/b/c/d) are required'], 400);
    }
    $s = $pdo->prepare("INSERT INTO org_aptitude_questions (org_id,job_id,question,option_a,option_b,option_c,option_d,correct,difficulty,category) VALUES (?,?,?,?,?,?,?,?,?,?)");
    $s->execute([$org_id,$jid,$q,$a,$b,$c?:null,$d?:null,$ans,$diff,$cat]);
    respond(['success'=>true,'id'=>(int)$pdo->lastInsertId()]);

case 'delete':
    $qid = intval($body['question_id'] ?? 0);
    if (!$qid) respond(['success'=>false,'message'=>'question_id required'], 400);
    $pdo->prepare("DELETE FROM org_aptitude_questions WHERE id=? AND org_id=?")->execute([$qid,$org_id]);
    respond(['success'=>true]);

case 'update':
    $qid = intval($body['question_id'] ?? 0);
    if (!$qid) respond(['success'=>false,'message'=>'question_id required'], 400);
    $q   = trim($body['question'] ?? '');
    $a   = trim($body['option_a'] ?? '');
    $b   = trim($body['option_b'] ?? '');
    $c   = trim($body['option_c'] ?? '');
    $d   = trim($body['option_d'] ?? '');
    $ans = strtolower(trim($body['correct'] ?? ''));
    $diff= in_array($body['difficulty']??'',['easy','medium','hard']) ? $body['difficulty'] : 'medium';
    $cat = trim($body['category'] ?? 'General');
    $pdo->prepare("UPDATE org_aptitude_questions SET question=?,option_a=?,option_b=?,option_c=?,option_d=?,correct=?,difficulty=?,category=? WHERE id=? AND org_id=?")
        ->execute([$q,$a,$b,$c?:null,$d?:null,$ans,$diff,$cat,$qid,$org_id]);
    respond(['success'=>true]);

case 'student_get':
    $job_id = intval($body['job_id'] ?? $_GET['job_id'] ?? 0);
    if (!$job_id) respond(['success'=>false,'message'=>'job_id required'], 400);
    $j = $pdo->prepare("SELECT org_id FROM job_posts WHERE id=? LIMIT 1");
    $j->execute([$job_id]); $jrow = $j->fetch();
    if (!$jrow) respond(['success'=>false,'message'=>'Job not found'], 404);
    $s = $pdo->prepare("SELECT id,question,option_a,option_b,option_c,option_d,difficulty,category FROM org_aptitude_questions WHERE org_id=? AND (job_id=? OR job_id IS NULL) ORDER BY difficulty, created_at LIMIT 20");
    $s->execute([$jrow['org_id'], $job_id]);
    respond(['success'=>true,'questions'=>$s->fetchAll()]);

default:
    respond(['success'=>false,'message'=>'Unknown action'], 400);
}
?>

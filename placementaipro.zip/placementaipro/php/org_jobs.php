<?php
// php/org_jobs.php – Get jobs for org (PDO)
require 'config.php';

$user_id = intval($_GET['user_id'] ?? 0);
if (!$user_id) respond(['success'=>false,'message'=>'user_id required'], 400);
requireVerifiedOrg($user_id);

$pdo  = getDB();
$org  = $pdo->prepare('SELECT id FROM organizations WHERE user_id=? LIMIT 1');
$org->execute([$user_id]); $orgRow=$org->fetch();
if (!$orgRow) respond(['success'=>false,'message'=>'Org not found'], 404);

$stmt = $pdo->prepare("SELECT jp.*,(SELECT COUNT(*) FROM applications a WHERE a.job_id=jp.id) as applicant_count FROM job_posts jp WHERE jp.org_id=? ORDER BY jp.created_at DESC");
$stmt->execute([$orgRow['id']]);
respond(['success'=>true,'jobs'=>$stmt->fetchAll()]);

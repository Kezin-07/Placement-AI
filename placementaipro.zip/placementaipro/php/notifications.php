<?php
// php/notifications.php – Notifications API
require 'config.php';

$pdo    = getDB();

// Auto-create notifications table if not exists
$pdo->exec("CREATE TABLE IF NOT EXISTS notifications (
    id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id    INT UNSIGNED NOT NULL,
    type       VARCHAR(60)  NOT NULL DEFAULT 'info',
    title      VARCHAR(200) NOT NULL,
    body       TEXT,
    link       VARCHAR(400) DEFAULT NULL,
    is_read    TINYINT(1)   NOT NULL DEFAULT 0,
    created_at TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user (user_id, is_read)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$body   = getBody();
$action = $body['action'] ?? $_GET['action'] ?? 'list';
$uid    = intval($body['user_id'] ?? $_GET['user_id'] ?? 0);

if (!$uid) respond(['success'=>false,'message'=>'user_id required'], 401);

switch ($action) {

case 'list':
    $limit = intval($_GET['limit'] ?? $body['limit'] ?? 20);
    $s = $pdo->prepare('SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT ?');
    $s->execute([$uid, $limit]);
    $rows = $s->fetchAll();
    $unread = (int)$pdo->prepare('SELECT COUNT(*) FROM notifications WHERE user_id=? AND is_read=0')->execute([$uid]) 
              ? (int)$pdo->prepare('SELECT COUNT(*) FROM notifications WHERE user_id=? AND is_read=0')->execute([$uid]) : 0;
    // simpler unread count
    $u2 = $pdo->prepare('SELECT COUNT(*) FROM notifications WHERE user_id=? AND is_read=0');
    $u2->execute([$uid]);
    $unread = (int)$u2->fetchColumn();
    respond(['success'=>true,'notifications'=>$rows,'unread'=>$unread]);

case 'mark_read':
    $nid = intval($body['notification_id'] ?? 0);
    if ($nid) {
        $pdo->prepare('UPDATE notifications SET is_read=1 WHERE id=? AND user_id=?')->execute([$nid,$uid]);
    } else {
        $pdo->prepare('UPDATE notifications SET is_read=1 WHERE user_id=?')->execute([$uid]);
    }
    respond(['success'=>true]);

case 'unread_count':
    $s = $pdo->prepare('SELECT COUNT(*) FROM notifications WHERE user_id=? AND is_read=0');
    $s->execute([$uid]);
    respond(['success'=>true,'count'=>(int)$s->fetchColumn()]);

default:
    respond(['success'=>false,'message'=>'Unknown action'], 400);
}

// Helper used by other endpoints
function createNotification(PDO $pdo, int $user_id, string $type, string $title, string $body_text, string $link=''): void {
    $s = $pdo->prepare('INSERT INTO notifications (user_id,type,title,body,link) VALUES (?,?,?,?,?)');
    $s->execute([$user_id,$type,$title,$body_text,$link]);
}
?>

<?php
// php/org_job_create.php – Create job (PDO)
require 'config.php';

$body    = getBody();
$user_id = intval($body['user_id'] ?? 0);
if (!$user_id) respond(['success'=>false,'message'=>'user_id required'], 400);
requireVerifiedOrg($user_id);

$pdo = getDB();
$orgRow = $pdo->prepare('SELECT id FROM organizations WHERE user_id=? LIMIT 1');
$orgRow->execute([$user_id]); $org=$orgRow->fetch();
if (!$org) respond(['success'=>false,'message'=>'Org not found'], 404);

$stmt = $pdo->prepare('INSERT INTO job_posts (org_id,title,description,required_skills,min_cgpa,max_cgpa,experience_level,location,salary_range) VALUES (?,?,?,?,?,?,?,?,?)');
$stmt->execute([$org['id'],trim($body['title']??''),trim($body['description']??''),trim($body['required_skills']??''),floatval($body['min_cgpa']??0),floatval($body['max_cgpa']??10),$body['experience_level']??'Entry',trim($body['location']??''),trim($body['salary_range']??'')]);
respond(['success'=>true,'job_id'=>(int)$pdo->lastInsertId()]);

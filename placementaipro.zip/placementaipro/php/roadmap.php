<?php
// php/roadmap.php – AI Placement Roadmap Generator powered by Google Gemini (FREE)
require_once __DIR__ . '/config.php';

header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') respond(['success'=>false,'message'=>'POST required'], 405);

$body     = getBody();
$uid      = intval($body['user_id'] ?? 0);
$focus    = $body['focus']    ?? '';
$job_post = $body['job_post'] ?? '';

if (!$uid) respond(['success'=>false,'message'=>'user_id required'], 400);

$pdo  = getDB();
$stmt = $pdo->prepare("SELECT * FROM student_profiles WHERE user_id = ? LIMIT 1");
$stmt->execute([$uid]);
$profile = $stmt->fetch() ?: [];

$name    = $profile['full_name']     ?? 'Student';
$branch  = $profile['branch']        ?? 'Computer Science';
$cgpa    = $profile['cgpa']          ?? '7.0';
$skills  = $profile['skills']        ?? 'None listed';
$year    = $profile['year_of_study'] ?? 'Final year';

$focusLabels = ['dsa'=>'DSA & Algorithms','system_design'=>'System Design','hr'=>'HR & Soft Skills',
    'data_science'=>'Data Science / ML','fullstack'=>'Full Stack Web Development',''=>'General Placement Preparation'];
$focusLabel = $focusLabels[$focus] ?? 'General Placement Preparation';
$jobContext = $job_post ? "Apply for this role:\n\"\"\"\n{$job_post}\n\"\"\"" : "Focus area: {$focusLabel}";

$prompt = "Create an 8-week placement preparation roadmap for this Indian engineering student.

Student: Name={$name}, Branch={$branch}, CGPA={$cgpa}, Year={$year}, Skills={$skills}
{$jobContext}

Return ONLY a valid JSON array with exactly 8 objects. Each object:
- \"week\": \"Week 1\" through \"Week 8\"
- \"title\": short title (max 8 words)
- \"tasks\": array of 3-5 specific actionable task strings
- \"resources\": string with 2-3 free resource recommendations

Return ONLY the JSON array. No markdown. No explanation.";

$aiText = callGemini(
    'You are a placement expert. Return ONLY valid JSON arrays. No markdown, no code blocks, no explanation.',
    [],
    $prompt,
    2500
);

$aiText = preg_replace('/```json\s*/i', '', $aiText);
$aiText = preg_replace('/```\s*/', '', $aiText);
$aiText = trim($aiText);

$roadmap = json_decode($aiText, true);
if (!is_array($roadmap) || empty($roadmap)) respond(['success'=>false,'message'=>'Failed to parse roadmap. Try again.'], 500);

foreach ($roadmap as &$week) {
    $week['week']      = $week['week']      ?? 'Week';
    $week['title']     = $week['title']     ?? 'Preparation';
    $week['tasks']     = $week['tasks']     ?? [];
    $week['resources'] = $week['resources'] ?? '';
}
unset($week);

respond(['success'=>true,'roadmap'=>$roadmap]);
?>

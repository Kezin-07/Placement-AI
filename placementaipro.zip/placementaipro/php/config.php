<?php
// =============================================================
// php/config.php  –  PlacementAI Pro Core Config
// =============================================================
error_reporting(0);
ini_set('display_errors', '0');

define('DB_HOST',    'localhost');
define('DB_USER',    'root');
define('DB_PASS',    '');
define('DB_NAME',    'placement_db');
define('DB_CHARSET', 'utf8mb4');

// ─────────────────────────────────────────────────────────────
// 🔑 Groq API Key (FREE – works in India, 14,400 req/day)
//    Get yours at: https://console.groq.com → API Keys
// ─────────────────────────────────────────────────────────────
define('GROQ_API_KEY', getenv('GROQ_API_KEY') ?: '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');
define('GROQ_URL',     'https://api.groq.com/openai/v1/chat/completions');
define('GROQ_MODEL',   'llama-3.3-70b-versatile'); // Fast, free, very capable

// Keep for backward compat
define('CLAUDE_API_KEY', '');
define('GEMINI_API_KEY', '');

// ── Shared Groq caller ────────────────────────────────────────
// Groq uses OpenAI-compatible format: system + messages array
function callGroq(string $systemPrompt, array $history, string $userMessage = '', int $maxTokens = 1000): string {
    if (!function_exists('curl_init')) respond(['success'=>false,'message'=>'cURL not enabled. Enable php_curl in php.ini.']);

    // Build messages array (OpenAI format)
    $messages = [['role' => 'system', 'content' => $systemPrompt]];

    foreach ($history as $h) {
        if (!isset($h['role'], $h['content']) || !strlen(trim($h['content']))) continue;
        $role = ($h['role'] === 'assistant' || $h['role'] === 'model') ? 'assistant' : 'user';
        $messages[] = ['role' => $role, 'content' => (string)$h['content']];
    }

    if ($userMessage) {
        $messages[] = ['role' => 'user', 'content' => $userMessage];
    }

    // If no user message at all, add a start prompt
    $hasUser = count(array_filter($messages, fn($m) => $m['role'] === 'user')) > 0;
    if (!$hasUser) {
        $messages[] = ['role' => 'user', 'content' => 'Begin.'];
    }

    $payload = json_encode([
        'model'       => GROQ_MODEL,
        'messages'    => $messages,
        'max_tokens'  => $maxTokens,
        'temperature' => 0.7,
    ]);

    $ch = curl_init(GROQ_URL);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $payload,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . GROQ_API_KEY,
        ],
        CURLOPT_TIMEOUT        => 45,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => false,
    ]);

    $result  = curl_exec($ch);
    $curlErr = curl_error($ch);
    $code    = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($curlErr) respond(['success'=>false,'message'=>'Connection error: '.$curlErr], 500);

    $data = json_decode($result, true);
    if (!$data) respond(['success'=>false,'message'=>'Invalid Groq response. HTTP '.$code], 500);

    if (isset($data['error'])) {
        $msg = $data['error']['message'] ?? 'Unknown Groq error';
        respond(['success'=>false,'message'=>'AI Error: '.$msg], 500);
    }

    $text = $data['choices'][0]['message']['content'] ?? '';
    if (!$text) respond(['success'=>false,'message'=>'Empty response from Groq. HTTP '.$code], 500);

    return $text;
}

// Alias so existing files that call callGemini() still work
function callGemini(string $systemPrompt, array $history, string $userMessage = '', int $maxTokens = 1000): string {
    return callGroq($systemPrompt, $history, $userMessage, $maxTokens);
}

function getDB(): PDO {
    static $pdo = null; if ($pdo) return $pdo;
    try {
        $pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset='.DB_CHARSET, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci",
        ]);
    } catch (PDOException $e) {
        while (ob_get_level()) ob_end_clean();
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8');
        die(json_encode(['success'=>false,'message'=>'DB connection failed: '.$e->getMessage()]));
    }
    return $pdo;
}

// CORS headers (safe to send early)
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') { http_response_code(200); exit; }

function getBody(): array {
    $raw = file_get_contents('php://input');
    return $raw ? (json_decode($raw, true) ?? []) : [];
}

function sanitizeForJson($val) {
    if (is_string($val)) {
        // Force valid UTF-8 - replace invalid bytes with replacement char
        $val = mb_convert_encoding($val, 'UTF-8', 'UTF-8');
        $val = htmlspecialchars_decode(htmlspecialchars($val, ENT_SUBSTITUTE, 'UTF-8'));
        return $val;
    }
    if (is_array($val)) { return array_map('sanitizeForJson', $val); }
    return $val;
}

function respond(array $data, int $code = 200): void {
    while (ob_get_level() > 0) { ob_end_clean(); }
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache');
    // Sanitize all string values to valid UTF-8 before encoding
    $data = sanitizeForJson($data);
    $json = json_encode($data, JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR);
    if ($json === false || $json === null) {
        $err = json_last_error_msg();
        $json = json_encode(['success' => false, 'message' => 'Response encode failed: ' . $err]);
    }
    echo $json;
    exit(0);
}

function requireAdmin(): array {
    $uid = intval(getBody()['admin_id'] ?? $_GET['admin_id'] ?? 0);
    if (!$uid) respond(['success'=>false,'message'=>'Admin auth required'], 403);
    $pdo  = getDB();
    $stmt = $pdo->prepare("SELECT id,name,role FROM users WHERE id=? AND role='admin' AND is_active=1 LIMIT 1");
    $stmt->execute([$uid]);
    $u = $stmt->fetch();
    if (!$u) respond(['success'=>false,'message'=>'Forbidden'], 403);
    return $u;
}

function requireVerifiedOrg(int $user_id): void {
    $pdo  = getDB();
    $stmt = $pdo->prepare("SELECT o.verified FROM organizations o JOIN users u ON u.id=o.user_id WHERE u.id=? AND u.role='organization' AND u.is_active=1 LIMIT 1");
    $stmt->execute([$user_id]);
    $org = $stmt->fetch();
    if (!$org) respond(['success'=>false,'message'=>'Organization not found'], 404);
    if (!$org['verified']) respond(['success'=>false,'message'=>'Organization pending verification.','verified'=>false], 403);
}

function hashPassword(string $plain): string { return password_hash($plain, PASSWORD_BCRYPT, ['cost'=>12]); }
function verifyPassword(string $plain, string $hash): bool { return password_verify($plain, $hash); }
?>

<?php
// php/interview_schedule.php – Interview Scheduler (with auto-column-create)
require 'config.php';

$pdo    = getDB();

// Auto-add missing columns to applications table
try {
    $pdo->exec("ALTER TABLE applications ADD COLUMN interview_datetime DATETIME DEFAULT NULL");
} catch(PDOException $e) {} // ignore if already exists
try {
    $pdo->exec("ALTER TABLE applications ADD COLUMN interview_notes TEXT DEFAULT NULL");
} catch(PDOException $e) {}
try {
    $pdo->exec("ALTER TABLE applications ADD COLUMN timeline JSON DEFAULT NULL");
} catch(PDOException $e) {}

$body   = getBody();
$action = $body['action'] ?? $_GET['action'] ?? '';
$uid    = intval($body['user_id'] ?? $_GET['user_id'] ?? 0);

if (!$uid) respond(['success'=>false,'message'=>'user_id required'], 401);

switch ($action) {

case 'schedule':
    requireVerifiedOrg($uid);
    $app_id   = intval($body['application_id'] ?? 0);
    $datetime = trim($body['datetime'] ?? '');
    $notes    = trim($body['notes'] ?? '');
    if (!$app_id || !$datetime) respond(['success'=>false,'message'=>'application_id and datetime required'], 400);

    $check = $pdo->prepare("SELECT a.id, a.student_id, jp.title, o.company_name
        FROM applications a
        JOIN job_posts jp ON jp.id = a.job_id
        JOIN organizations o ON o.id = jp.org_id
        JOIN users u ON u.id = o.user_id
        WHERE a.id=? AND u.id=?");
    $check->execute([$app_id, $uid]);
    $app = $check->fetch();
    if (!$app) respond(['success'=>false,'message'=>'Application not found or access denied'], 404);

    $pdo->prepare("UPDATE applications SET status='interview_scheduled', interview_datetime=?, interview_notes=? WHERE id=?")
        ->execute([$datetime, $notes, $app_id]);

    // Notify student
    try {
        $pdo->prepare("INSERT INTO notifications (user_id,type,title,body,link) VALUES (?,?,?,?,?)")
            ->execute([$app['student_id'], 'interview_scheduled',
                '📅 Interview Scheduled!',
                "Your interview for {$app['title']} at {$app['company_name']} is scheduled for $datetime. Notes: $notes",
                'jobs.html'
            ]);
    } catch(PDOException $e) {}

    respond(['success'=>true,'message'=>'Interview scheduled successfully']);

case 'org_list':
    requireVerifiedOrg($uid);
    $orgRow = $pdo->prepare('SELECT id FROM organizations WHERE user_id=?');
    $orgRow->execute([$uid]); $org = $orgRow->fetch();
    if (!$org) respond(['success'=>false,'message'=>'Organization not found'], 404);

    $s = $pdo->prepare("SELECT a.id, a.interview_datetime, a.interview_notes, a.status,
        u.name AS student_name, u.email AS student_email,
        jp.title AS job_title
        FROM applications a
        JOIN users u ON u.id = a.student_id
        JOIN job_posts jp ON jp.id = a.job_id
        WHERE jp.org_id = ? AND a.interview_datetime IS NOT NULL
        ORDER BY a.interview_datetime ASC");
    $s->execute([$org['id']]);
    respond(['success'=>true,'interviews'=>$s->fetchAll()]);

case 'student_list':
    $s = $pdo->prepare("SELECT a.id, a.interview_datetime, a.interview_notes, a.status,
        jp.title AS job_title, o.company_name
        FROM applications a
        JOIN job_posts jp ON jp.id = a.job_id
        JOIN organizations o ON o.id = jp.org_id
        WHERE a.student_id = ? AND a.interview_datetime IS NOT NULL
        ORDER BY a.interview_datetime ASC");
    $s->execute([$uid]);
    respond(['success'=>true,'interviews'=>$s->fetchAll()]);

default:
    respond(['success'=>false,'message'=>'Unknown action: '.$action], 400);
}
?>

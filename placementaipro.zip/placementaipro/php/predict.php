<?php
// php/predict.php – AI-powered placement prediction (enhanced accuracy)
require 'config.php';

$body    = getBody();
$profile = $body;

$cgpa                 = floatval($profile['cgpa']                ?? 0);
$skills_raw           = trim($profile['skills']                  ?? '');
$projects             = intval($profile['projects']              ?? 0);
$internships          = intval($profile['internships']           ?? 0);
$aptitude_score       = floatval($profile['aptitude_score']      ?? 0);
$communication_rating = floatval($profile['communication_rating']?? 5);
$branch               = strtolower(trim($profile['branch']       ?? ''));
$resume_score         = floatval($profile['resume_score']        ?? 0);
$ats_score            = floatval($profile['ats_score']           ?? 0);
$interview_score      = floatval($profile['interview_score']     ?? 0);

// ── ENHANCED MULTI-FACTOR SCORING MODEL ──────────────────────
// Based on real placement data patterns

// 1. Academic (max 30 pts) — Non-linear: 8+ is significantly better
$cgpa_pts = 0;
if ($cgpa >= 9.5) $cgpa_pts = 30;
elseif ($cgpa >= 9.0) $cgpa_pts = 28;
elseif ($cgpa >= 8.5) $cgpa_pts = 25;
elseif ($cgpa >= 8.0) $cgpa_pts = 22;
elseif ($cgpa >= 7.5) $cgpa_pts = 18;
elseif ($cgpa >= 7.0) $cgpa_pts = 14;
elseif ($cgpa >= 6.5) $cgpa_pts = 10;
else $cgpa_pts = max(0, ($cgpa / 10) * 10);

// 2. Projects (max 12 pts) — Quality over quantity assumed
$project_pts = 0;
if ($projects >= 5) $project_pts = 12;
elseif ($projects >= 3) $project_pts = 10;
elseif ($projects >= 2) $project_pts = 7;
elseif ($projects >= 1) $project_pts = 4;

// 3. Internships (max 15 pts) — Very strong signal
$intern_pts = 0;
if ($internships >= 3) $intern_pts = 15;
elseif ($internships >= 2) $intern_pts = 13;
elseif ($internships >= 1) $intern_pts = 9;

// 4. Aptitude (max 15 pts)
$apt_pts = ($aptitude_score / 100) * 15;

// 5. Communication (max 10 pts)
$comm_pts = ($communication_rating / 10) * 10;

// 6. Skills (max 12 pts) — Diversity & industry-relevance
$skills = array_filter(array_map('trim', explode(',', strtolower($skills_raw))));
$skill_count = count($skills);

// High-value skills for placement
$premium_skills = ['python','java','c++','javascript','react','node','sql','machine learning','ml','aws','docker','kubernetes','system design','dsa','data structures','spring','django','tensorflow','pytorch'];
$premium_count = 0;
foreach ($skills as $s) {
    foreach ($premium_skills as $ps) {
        if (stripos($s, $ps) !== false) { $premium_count++; break; }
    }
}
$skill_pts = min(12, ($skill_count * 0.8) + ($premium_count * 1.2));

// 7. Resume/ATS bonus (max 6 pts)
$resume_pts = 0;
if ($resume_score > 0 || $ats_score > 0) {
    $avg_resume = (($resume_score ?: $ats_score) + ($ats_score ?: $resume_score)) / 2;
    $resume_pts = ($avg_resume / 100) * 6;
}

// 8. Interview score bonus (max 6 pts)
$interview_pts = $interview_score > 0 ? ($interview_score / 100) * 6 : 0;

// 9. Branch bonus
$branch_bonus = 0;
if (str_contains($branch,'computer') || str_contains($branch,'cs') || str_contains($branch,'software')) $branch_bonus = 3;
elseif (str_contains($branch,'information') || str_contains($branch,'it')) $branch_bonus = 2;
elseif (str_contains($branch,'electronics') || str_contains($branch,'ece')) $branch_bonus = 1;

$raw_score = $cgpa_pts + $project_pts + $intern_pts + $apt_pts + $comm_pts + $skill_pts + $resume_pts + $interview_pts + $branch_bonus;
$max_possible = 30 + 12 + 15 + 15 + 10 + 12 + 6 + 6 + 3;

// Normalize to 0-100 with slight curve (sqrt curve for realism)
$probability = round(min(100, max(5, ($raw_score / $max_possible) * 100)), 1);
$readiness   = round(min(100, $probability * 0.90 + rand(0,3)));

// Status thresholds
if ($probability >= 80)     $status = 'Very High';
elseif ($probability >= 65) $status = 'High';
elseif ($probability >= 48) $status = 'Moderate';
elseif ($probability >= 30) $status = 'Low';
else                         $status = 'Very Low';

// Company match predictions
$company_matches = [];
if ($cgpa >= 8.5 && $skill_count >= 5 && $intern_pts >= 9) {
    $company_matches[] = ['name' => 'FAANG/Big Tech', 'match' => min(95, round($probability * 0.90)), 'color' => 'purple'];
}
if ($cgpa >= 7.5 && $skill_count >= 3) {
    $company_matches[] = ['name' => 'Mid-size Product', 'match' => min(95, round($probability * 1.05)), 'color' => 'blue'];
}
if ($cgpa >= 6.5) {
    $company_matches[] = ['name' => 'IT Services (TCS/Infosys)', 'match' => min(95, round($probability * 1.15)), 'color' => 'green'];
}
$company_matches[] = ['name' => 'Startups', 'match' => min(95, round($probability * 1.10)), 'color' => 'amber'];

// SHAP-like factor importance
$shap = [
    ['factor' => 'CGPA',           'value' => round($cgpa_pts,1),     'max' => 30,  'impact' => round($cgpa_pts/30*100)],
    ['factor' => 'Internships',    'value' => round($intern_pts,1),   'max' => 15,  'impact' => round($intern_pts/15*100)],
    ['factor' => 'Aptitude',       'value' => round($apt_pts,1),      'max' => 15,  'impact' => round($apt_pts/15*100)],
    ['factor' => 'Projects',       'value' => round($project_pts,1),  'max' => 12,  'impact' => round($project_pts/12*100)],
    ['factor' => 'Skills',         'value' => round($skill_pts,1),    'max' => 12,  'impact' => round($skill_pts/12*100)],
    ['factor' => 'Communication',  'value' => round($comm_pts,1),     'max' => 10,  'impact' => round($comm_pts/10*100)],
];
usort($shap, fn($a,$b) => $b['value'] - $a['value']);

// Actionable suggestions
$suggestions = [];
if ($cgpa < 7.5) $suggestions[] = ['priority'=>'high','text'=>'Your CGPA is below the 7.5 threshold for most product companies. Focus on scoring 8+ in remaining semesters.'];
if ($cgpa >= 7.5 && $cgpa < 8.5) $suggestions[] = ['priority'=>'medium','text'=>'CGPA is decent. FAANG requires 8.5+. Compensate with strong projects and DSA skills.'];
if ($projects < 2) $suggestions[] = ['priority'=>'high','text'=>'Build 2-3 substantial projects with real-world impact. Deploy them on GitHub with good README.'];
if ($internships === 0) $suggestions[] = ['priority'=>'high','text'=>'Zero internships is a red flag. Apply for summer internships or part-time contract roles immediately.'];
if ($aptitude_score < 70) $suggestions[] = ['priority'=>'medium','text'=>'Aptitude score below 70% will filter you out in screening rounds. Practice 30 min daily on IndiaBix/PrepInsta.'];
if ($communication_rating < 7) $suggestions[] = ['priority'=>'medium','text'=>'Communication rating is low. Join debate clubs, practice mock GD/PI, and do daily voice journaling.'];
if ($skill_count < 4) $suggestions[] = ['priority'=>'medium','text'=>'Limited skill set. Focus on learning 2-3 core technologies deeply (Python + SQL + one framework).'];
if ($premium_count < 2) $suggestions[] = ['priority'=>'low','text'=>'Add high-demand skills: Python, SQL, System Design, or a popular framework to boost marketability.'];
if ($resume_score == 0 && $ats_score == 0) $suggestions[] = ['priority'=>'low','text'=>'Analyze your resume using the Resume Analyzer tool to get your ATS score and improve it.'];

// Priority sort
usort($suggestions, fn($a,$b) => ($a['priority']==='high'?0:($a['priority']==='medium'?1:2)) - ($b['priority']==='high'?0:($b['priority']==='medium'?1:2)));

respond([
    'success'          => true,
    'probability'      => $probability,
    'readiness'        => $readiness,
    'status'           => $status,
    'shap'             => $shap,
    'suggestions'      => $suggestions,
    'company_matches'  => $company_matches,
    'score_breakdown'  => [
        'cgpa'          => round($cgpa_pts, 1),
        'projects'      => round($project_pts, 1),
        'internships'   => round($intern_pts, 1),
        'aptitude'      => round($apt_pts, 1),
        'communication' => round($comm_pts, 1),
        'skills'        => round($skill_pts, 1),
        'resume'        => round($resume_pts, 1),
        'interview'     => round($interview_pts, 1),
    ],
    'total_raw'        => round($raw_score, 1),
    'max_raw'          => $max_possible,
]);

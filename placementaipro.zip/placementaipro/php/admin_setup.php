<?php
// admin_setup.php — Run once to seed admin + verify demo orgs
// Visit: localhost/placement_fixed/admin_setup.php
// DELETE this file after setup is done!

require __DIR__ . '/config.php';
$pdo = getDB();
$results = [];

// 1. Create or reset admin user
$hash = password_hash('admin123', PASSWORD_BCRYPT, ['cost' => 10]);
$check = $pdo->prepare("SELECT id FROM users WHERE email = 'admin@placementai.com' LIMIT 1");
$check->execute();
if ($check->fetch()) {
    $pdo->prepare("UPDATE users SET password_hash=?, is_active=1, role='admin' WHERE email='admin@placementai.com'")->execute([$hash]);
    $results[] = "✅ Admin password reset to <strong>admin123</strong>";
} else {
    $pdo->prepare("INSERT INTO users (name, email, password_hash, role, is_active) VALUES ('Admin', 'admin@placementai.com', ?, 'admin', 1)")->execute([$hash]);
    $results[] = "✅ Admin user created — email: <strong>admin@placementai.com</strong> / password: <strong>admin123</strong>";
}

// 2. Ensure demo org users exist and are verified
$demoOrgs = [
    ['Google HR', 'hr@google.com', 'Google', 'Technology'],
    ['TCS HR', 'hr@tcs.com', 'TCS', 'IT Services'],
    ['Infosys HR', 'hr@infosys.com', 'Infosys', 'IT Services'],
];

foreach ($demoOrgs as [$name, $email, $company, $industry]) {
    $chk = $pdo->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
    $chk->execute([$email]);
    $existing = $chk->fetch();

    if (!$existing) {
        $orgHash = password_hash('password', PASSWORD_BCRYPT, ['cost' => 10]);
        $pdo->prepare("INSERT INTO users (name, email, password_hash, role, is_active) VALUES (?, ?, ?, 'organization', 1)")->execute([$name, $email, $orgHash]);
        $uid = (int)$pdo->lastInsertId();
        $pdo->prepare("INSERT IGNORE INTO organizations (user_id, company_name, industry, verified) VALUES (?, ?, ?, 1)")->execute([$uid, $company, $industry]);
        $results[] = "✅ Created org: <strong>$company</strong>";
    } else {
        $uid = $existing['id'];
        $pdo->prepare("UPDATE organizations SET verified=1 WHERE user_id=?")->execute([$uid]);
        $results[] = "✅ Verified org: <strong>$company</strong>";
    }
}

// 3. Seed demo jobs if none exist
$jobCount = $pdo->query("SELECT COUNT(*) FROM job_posts")->fetchColumn();
if ($jobCount == 0) {
    $orgStmt = $pdo->query("SELECT o.id FROM organizations o WHERE o.verified=1 LIMIT 1");
    $org = $orgStmt->fetch();
    if ($org) {
        $oid = $org['id'];
        $jobs = [
            [$oid, 'Software Engineer', 'Build scalable web applications.', 'PHP, MySQL, JavaScript, HTML, CSS', 7.0, 'Entry', 'Bangalore', '6-10 LPA'],
            [$oid, 'ML Engineer', 'Work on AI/ML products.', 'Python, TensorFlow, SQL, PyTorch', 7.5, 'Entry', 'Hyderabad', '10-18 LPA'],
            [$oid, 'Data Analyst', 'Analyze business data.', 'Python, SQL, Excel, Power BI', 6.5, 'Entry', 'Pune', '5-8 LPA'],
        ];
        $ins = $pdo->prepare("INSERT INTO job_posts (org_id, title, description, required_skills, min_cgpa, experience_level, location, salary_range, is_active) VALUES (?,?,?,?,?,?,?,?,1)");
        foreach ($jobs as $j) { $ins->execute($j); }
        $results[] = "✅ Seeded <strong>3 demo jobs</strong>";
    }
} else {
    $results[] = "ℹ️ Jobs already exist ($jobCount found), skipping seed";
}

// 4. Create notifications table if missing
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `notifications` (
        `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `user_id` INT UNSIGNED NOT NULL,
        `type` VARCHAR(60) NOT NULL DEFAULT 'info',
        `title` VARCHAR(200) NOT NULL,
        `body` TEXT,
        `is_read` TINYINT(1) NOT NULL DEFAULT 0,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        KEY `idx_notif_user` (`user_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $results[] = "✅ Notifications table ready";
} catch (Exception $e) {
    $results[] = "⚠️ Notifications table: " . $e->getMessage();
}

// 5. Add missing columns safely
$alterations = [
    "ALTER TABLE `applications` ADD COLUMN IF NOT EXISTS `interview_datetime` DATETIME DEFAULT NULL",
    "ALTER TABLE `applications` ADD COLUMN IF NOT EXISTS `org_notes` TEXT DEFAULT NULL",
    "ALTER TABLE `student_profiles` ADD COLUMN IF NOT EXISTS `interview_score` DECIMAL(5,2) DEFAULT NULL",
    "ALTER TABLE `student_profiles` ADD COLUMN IF NOT EXISTS `resume_score` DECIMAL(5,2) DEFAULT NULL",
];
foreach ($alterations as $sql) {
    try { $pdo->exec($sql); } catch (Exception $e) { /* column may already exist */ }
}
$results[] = "✅ Schema columns verified";
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>PlacementAI Setup</title>
  <style>
    body { font-family: system-ui, sans-serif; max-width: 600px; margin: 60px auto; padding: 20px; background: #f5f5f5; }
    .card { background: #fff; border-radius: 12px; padding: 28px; box-shadow: 0 2px 12px rgba(0,0,0,.08); }
    h2 { color: #6c63ff; margin-top: 0; }
    li { padding: 6px 0; font-size: 15px; border-bottom: 1px solid #f0f0f0; }
    .login-box { background: #f0f0ff; border-radius: 8px; padding: 16px; margin-top: 20px; font-size: 14px; }
    .login-box strong { color: #6c63ff; }
    a.btn { display:inline-block; margin-top:16px; padding:10px 22px; background:#6c63ff; color:#fff; border-radius:8px; text-decoration:none; font-weight:600; }
  </style>
</head>
<body>
  <div class="card">
    <h2>🚀 PlacementAI Pro — Setup Complete</h2>
    <ul>
      <?php foreach ($results as $r) echo "<li>$r</li>"; ?>
    </ul>
    <div class="login-box">
      <strong>Admin Login:</strong><br>
      Email: <strong>admin@placementai.com</strong><br>
      Password: <strong>admin123</strong>
    </div>
    <a class="btn" href="login.php">Go to Login →</a>
    <p style="color:#999;font-size:12px;margin-top:16px">⚠️ Delete <code>admin_setup.php</code> after setup.</p>
  </div>
</body>
</html>

<?php
// php/leaderboard.php – Student Leaderboard API
require 'config.php';

$pdo    = getDB();
$branch = $_GET['branch'] ?? '';
$uid    = intval($_GET['user_id'] ?? 0);

$sql = "SELECT u.id, u.name,
        sp.branch, sp.cgpa, sp.aptitude_score, sp.resume_score,
        COALESCE(sd.total_xp, 0) as total_xp,
        COALESCE(sp.interview_score, 0) as interview_score,
        (
          COALESCE(sp.cgpa,0)*5 +
          COALESCE(sp.aptitude_score,0)*0.4 +
          COALESCE(sp.resume_score,0)*0.3 +
          COALESCE(sp.interview_score,0)*0.3 +
          COALESCE(sd.total_xp,0)*0.01
        ) as composite_score
        FROM users u
        JOIN student_profiles sp ON sp.user_id=u.id
        LEFT JOIN streak_data sd ON sd.user_id=u.id
        WHERE u.role='student' AND u.is_active=1";

$params = [];
if ($branch) { $sql .= ' AND sp.branch=?'; $params[] = $branch; }
$sql .= ' ORDER BY composite_score DESC LIMIT 50';

try {
    $s = $pdo->prepare($sql);
    $s->execute($params);
    $students = $s->fetchAll();
} catch (\Exception $e) {
    respond(['success'=>false,'message'=>'Query failed: '.$e->getMessage()], 500);
}

// Add rank and format
foreach ($students as $i => &$row) {
    $row['rank'] = $i+1;
    $row['composite_score'] = round(floatval($row['composite_score']), 1);
}
unset($row);

// Get branches for filter
$branches = $pdo->query("SELECT DISTINCT branch FROM student_profiles ORDER BY branch")->fetchAll(PDO::FETCH_COLUMN);

// Find requesting user's rank
$my_rank = null;
if ($uid) {
    foreach ($students as $s2) {
        if ($s2['id'] == $uid) { $my_rank = $s2['rank']; break; }
    }
}

respond(['success'=>true,'students'=>$students,'branches'=>$branches,'my_rank'=>$my_rank]);
?>

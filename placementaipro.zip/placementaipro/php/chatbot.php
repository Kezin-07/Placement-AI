<?php
// php/chatbot.php – PlacementAI Chatbot powered by Groq (FREE, works in India)
require_once __DIR__ . '/config.php';

$body     = getBody();
$messages = $body['messages'] ?? [];
$system   = $body['system']   ?? buildDefaultSystem();

// Support single message string (used by resume builder)
if (empty($messages) && !empty($body['message'])) {
    $messages = [['role' => 'user', 'content' => $body['message']]];
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') respond(['error'=>['message'=>'POST required']]);
if (empty($messages)) respond(['error'=>['message'=>'No messages provided']]);

// Build OpenAI-format messages for Groq
$groqMessages = [['role' => 'system', 'content' => $system]];
foreach ($messages as $h) {
    if (!isset($h['role'], $h['content']) || !strlen(trim($h['content']))) continue;
    $role = ($h['role'] === 'assistant') ? 'assistant' : 'user';
    $groqMessages[] = ['role' => $role, 'content' => (string)$h['content']];
}

$payload = json_encode([
    'model'       => GROQ_MODEL,
    'messages'    => $groqMessages,
    'max_tokens'  => 1200,
    'temperature' => 0.7,
]);

$ch = curl_init(GROQ_URL);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => $payload,
    CURLOPT_HTTPHEADER     => [
        'Content-Type: application/json',
        'Authorization: Bearer ' . GROQ_API_KEY,
    ],
    CURLOPT_TIMEOUT        => 45,
    CURLOPT_SSL_VERIFYPEER => false,
]);

$result  = curl_exec($ch);
$curlErr = curl_error($ch);
$code    = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($curlErr) respond(['error'=>['message'=>'Connection error: '.$curlErr]]);

$data = json_decode($result, true);
if (!$data)             respond(['error'=>['message'=>'Invalid response from Groq']]);
if (isset($data['error'])) respond(['error'=>$data['error']]);

$text = $data['choices'][0]['message']['content'] ?? '';
if (!$text) respond(['error'=>['message'=>'Empty response from Groq']]);

// Return in same format the frontend expects (compatible with old Anthropic format)
respond([
    'content' => [['type' => 'text', 'text' => $text]],
    'reply'   => $text,
]);

function buildDefaultSystem(): string {
    return 'You are PlacementAI Assistant — an expert AI career advisor for Indian engineering students.
You specialize in:
1. Resume feedback — ATS tips, keyword optimization, section improvements
2. Interview preparation — HR questions, technical rounds, coding interviews, group discussions
3. Career guidance — which companies to target, roadmaps, skill building
4. Coding help — DSA, algorithms, debugging, language advice
5. Aptitude prep — quantitative, verbal, logical reasoning for placement tests

Personality: Warm, encouraging, like a senior who cracked top company placements. Give specific, actionable advice. Use bullet points for clarity. Keep responses concise but complete. Support markdown formatting.';
}
?>

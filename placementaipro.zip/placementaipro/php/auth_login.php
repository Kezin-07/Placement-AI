<?php
// php/auth_login.php – Secure Login with admin-once enforcement
require 'config.php';

$body     = getBody();
$email    = trim($body['email']    ?? '');
$password = trim($body['password'] ?? '');

if (!$email || !$password) respond(['success'=>false,'message'=>'Email and password are required'], 400);

$pdo  = getDB();
$stmt = $pdo->prepare('SELECT id,name,email,role,password_hash,is_active FROM users WHERE email=? LIMIT 1');
$stmt->execute([$email]);
$user = $stmt->fetch();

if (!$user || !password_verify($password, $user['password_hash'])) {
    respond(['success'=>false,'message'=>'Invalid email or password'], 401);
}

if (!$user['is_active']) {
    respond(['success'=>false,'message'=>'Your account has been suspended. Contact admin.'], 403);
}

// Only the ONE registered admin (role=admin in DB) can log in as admin
if ($user['role'] === 'organization') {
    $s2 = $pdo->prepare('SELECT verified FROM organizations WHERE user_id=? LIMIT 1');
    $s2->execute([$user['id']]);
    $org = $s2->fetch();
    if (!$org || !$org['verified']) {
        respond(['success'=>false,'message'=>'Your organization is pending admin verification.','pending_verification'=>true], 403);
    }
}

unset($user['password_hash'], $user['is_active']);
respond(['success'=>true,'user'=>$user]);

<?php
// php/auth_register.php – Student Registration with auto-profile creation
require 'config.php';

$body     = getBody();
$name     = trim($body['name']     ?? '');
$email    = trim($body['email']    ?? '');
$password = trim($body['password'] ?? '');
$branch   = trim($body['branch']   ?? 'Computer Science');

if (!$name || !$email || !$password) respond(['success'=>false,'message'=>'All fields are required'], 400);
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) respond(['success'=>false,'message'=>'Invalid email address'], 400);
if (strlen($password) < 6) respond(['success'=>false,'message'=>'Password must be at least 6 characters'], 400);

$pdo = getDB();
// Check duplicate
$chk = $pdo->prepare('SELECT id FROM users WHERE email=? LIMIT 1');
$chk->execute([$email]);
if ($chk->fetch()) respond(['success'=>false,'message'=>'An account with this email already exists'], 409);

$hash = hashPassword($password);
$ins  = $pdo->prepare('INSERT INTO users (name,email,password_hash,role) VALUES (?,?,?,\'student\')');
$ins->execute([$name, $email, $hash]);
$uid  = (int)$pdo->lastInsertId();

// Auto-create student profile so dashboard shows data immediately
$profile = $pdo->prepare('INSERT IGNORE INTO student_profiles (user_id, branch, cgpa, skills, projects, internships, aptitude_score, communication_rating) VALUES (?,?,0,\'\',0,0,0,5.0)');
$profile->execute([$uid, $branch]);

// ENHANCEMENT 1: Auto-create streak_data on register so checkin & XP work from day 1
$pdo->prepare('INSERT IGNORE INTO streak_data (user_id, current_streak, longest_streak, total_xp, badges) VALUES (?,0,0,0,\'[]\')')
    ->execute([$uid]);

// Return full user object so frontend can auto-login immediately
$newUser = $pdo->prepare('SELECT id, name, email, role FROM users WHERE id = ? LIMIT 1');
$newUser->execute([$uid]);
$userRow = $newUser->fetch();

respond(['success'=>true, 'userId'=>$uid, 'user'=>$userRow, 'message'=>'Account created! Please sign in.']);

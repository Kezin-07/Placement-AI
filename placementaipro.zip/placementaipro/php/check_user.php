<?php
// php/check_user.php — Debug: verify a user's password hash in DB
// DELETE THIS FILE after debugging!
require 'config.php';

$email    = $_GET['email']    ?? '';
$password = $_GET['password'] ?? '';

if (!$email || !$password) {
    die(json_encode(['error' => 'Pass ?email=x&password=y in URL']));
}

$pdo  = getDB();
$stmt = $pdo->prepare('SELECT id, name, email, role, password_hash FROM users WHERE email = ? LIMIT 1');
$stmt->execute([$email]);
$user = $stmt->fetch();

if (!$user) {
    die(json_encode(['found' => false, 'message' => 'No user with that email']));
}

$verify = password_verify($password, $user['password_hash']);

echo json_encode([
    'found'         => true,
    'id'            => $user['id'],
    'name'          => $user['name'],
    'role'          => $user['role'],
    'hash_stored'   => substr($user['password_hash'], 0, 20) . '…',
    'password_ok'   => $verify,
    'php_version'   => PHP_VERSION,
], JSON_PRETTY_PRINT);

<?php
// php/mock_interview.php – AI Mock Interview powered by Google Gemini (FREE)
require 'config.php';

$body       = getBody();
$profile    = $body['profile']    ?? [];
$history    = $body['history']    ?? [];
$message    = trim($body['message'] ?? '');
$company    = trim($body['company']   ?? 'a top tech company');
$round      = trim($body['round']     ?? 'Technical');
$difficulty = trim($body['difficulty'] ?? 'Medium');

$maxQ = $difficulty === 'Easy' ? 5 : ($difficulty === 'Hard' ? 10 : 8);

$branch      = $profile['branch']      ?? 'Computer Science';
$cgpa        = $profile['cgpa']        ?? '0';
$skills      = $profile['skills']      ?? '';
$projects    = $profile['projects']    ?? 0;
$internships = $profile['internships'] ?? 0;

// Extract already-asked questions
$askedQuestions = [];
foreach ($history as $msg) {
    if ($msg['role'] === 'assistant') {
        preg_match_all('/\*\*([^*]+\?[^*]*)\*\*/', $msg['content'] ?? '', $matches);
        foreach ($matches[1] as $q) $askedQuestions[] = trim($q);
    }
}
$askedStr = !empty($askedQuestions)
    ? "QUESTIONS ALREADY ASKED (DO NOT REPEAT):\n- " . implode("\n- ", array_slice($askedQuestions, 0, 10)) . "\n\n"
    : "";

$questionCount = count(array_filter($history, fn($h) => $h['role'] === 'user'));

$roundGuidance = [
    'Technical'     => "Focus on DSA, data structures, algorithms, CS fundamentals (OS, DBMS, CN), coding problems relevant to $company.",
    'HR'            => "Focus on behavioral questions (STAR method), culture fit, motivation, teamwork, conflict resolution, leadership.",
    'System Design' => "Focus on scalable systems, API design, database choices, caching, load balancing, distributed systems.",
    'Mixed'         => "Alternate between HR behavioral and technical questions.",
];
$guidance = $roundGuidance[$round] ?? "Ask relevant interview questions for $company.";

$system = "You are a senior $round interviewer at $company conducting a real interview.

CANDIDATE PROFILE:
- Branch: $branch, CGPA: $cgpa/10
- Skills: $skills
- Projects: $projects, Internships: $internships

{$askedStr}INTERVIEW RULES:
1. Ask exactly ONE question per turn. NEVER ask two questions at once.
2. $guidance
3. After the candidate answers, give brief feedback (2-3 sentences, Score: X/10), then ask the NEXT question.
4. Make questions progressively harder based on candidate performance.
5. After $maxQ candidate answers, give FINAL ASSESSMENT: overall score /100, top 3 strengths, 2 areas to improve.
6. NEVER repeat a question already asked.
7. Customize to $company's style (Google=algorithms, Amazon=leadership principles, etc).
8. Format: Use **bold** for the question text. Keep response under 180 words.";

$startMsg = empty($history) && !$message
    ? "Start the interview. Introduce yourself briefly and ask your first $round question for $company."
    : $message;

$reply = callGemini($system, $history, $startMsg, 500);

respond(['success' => true, 'reply' => $reply, 'question_num' => $questionCount + 1, 'max_questions' => $maxQ]);

<?php
// php/org_students.php – Get all students for org panel (PDO)
require 'config.php';

$user_id = intval($_GET['user_id'] ?? 0);
if ($user_id) requireVerifiedOrg($user_id);

$pdo  = getDB();
$stmt = $pdo->query("SELECT sp.*,u.name,u.email FROM student_profiles sp JOIN users u ON u.id=sp.user_id WHERE u.role='student' AND u.is_active=1 ORDER BY sp.cgpa DESC LIMIT 200");
respond(['success'=>true,'students'=>$stmt->fetchAll()]);

<?php
// php/resume_analyze.php – AI Resume Analyzer powered by Groq (FREE)
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') respond(['success'=>false,'message'=>'POST required'], 405);

$user_id = intval($_POST['user_id'] ?? 0);

if (!isset($_FILES['resume']) || $_FILES['resume']['error'] !== UPLOAD_ERR_OK) {
    $errMap = [1=>'File too large (php.ini)',2=>'File too large (form)',3=>'Partial upload',4=>'No file',6=>'No tmp dir',7=>'Write failed'];
    $code = $_FILES['resume']['error'] ?? 4;
    respond(['success'=>false,'message'=>$errMap[$code] ?? 'Upload error '.$code], 400);
}

$file = $_FILES['resume'];
if ($file['size'] > 5*1024*1024) respond(['success'=>false,'message'=>'Max 5 MB'], 400);
$ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
if ($ext !== 'pdf') respond(['success'=>false,'message'=>'Only PDF files accepted'], 400);

// ── Extract text from PDF ──────────────────────────────────
$tmpPath = $file['tmp_name'];
$text    = '';
if (function_exists('exec')) {
    $out = []; @exec('pdftotext '.escapeshellarg($tmpPath).' - 2>/dev/null', $out, $ret);
    if ($ret === 0) $text = implode("\n", $out);
}
if (empty(trim($text))) {
    $bin = @file_get_contents($tmpPath) ?: '';
    preg_match_all('/BT.*?ET/s', $bin, $btBlocks);
    foreach ($btBlocks[0]??[] as $block) {
        preg_match_all('/\(([^\)\\\]{2,200})\)/', $block, $m);
        $text .= implode(' ', $m[1]??[]).' ';
    }
    if (empty(trim($text))) {
        preg_match_all('/[ -~]{4,}/', $bin, $m2);
        $text = implode(' ', array_filter($m2[0]??[], fn($s) => strlen(trim($s)) > 3));
    }
}
if (empty(trim($text))) $text = 'Resume text extraction limited. Filename: '.basename($file['name']);

// Truncate to avoid token overflow — keep it short so JSON response fits in limit
$text      = mb_substr($text, 0, 2500);
$wordCount = str_word_count($text);

// ── Ask AI for analysis ────────────────────────────────────
// Split into TWO smaller prompts to avoid JSON truncation:
// 1) Scores + issues  2) Keywords + improvements + parsed info

// --- Prompt 1: Scores ---
$prompt1 = "Analyze this resume and return ONLY a valid JSON object. No markdown, no explanation, no code fences.

Resume ({$wordCount} words):
===
{$text}
===

Return ONLY this JSON (integers for scores, arrays for lists):
{\"overall_score\":75,\"ats_score\":70,\"job_match\":{\"score\":68},\"section_scores\":{\"contact\":80,\"summary\":60,\"experience\":75,\"education\":85,\"skills\":70,\"projects\":65,\"formatting\":75},\"ats_issues\":[{\"severity\":\"high\",\"issue\":\"specific issue here\"},{\"severity\":\"medium\",\"issue\":\"another issue\"}],\"strengths\":[\"strength1\",\"strength2\",\"strength3\"]}

Fill with REAL values based on the resume. Return ONLY the JSON.";

// --- Prompt 2: Keywords + improvements + parsed ---
$prompt2 = "Analyze this resume and return ONLY a valid JSON object. No markdown, no explanation, no code fences.

Resume ({$wordCount} words):
===
{$text}
===

Return ONLY this JSON:
{\"improvements\":[\"tip1\",\"tip2\",\"tip3\",\"tip4\",\"tip5\"],\"keywords_found\":[\"skill1\",\"skill2\",\"skill3\"],\"keywords_missing\":[\"missing1\",\"missing2\",\"missing3\"],\"parsed\":{\"name\":\"Full Name\",\"email\":\"email@example.com\",\"phone\":\"1234567890\",\"skills\":[\"skill1\",\"skill2\",\"skill3\"]}}

Fill with REAL values from the resume. Return ONLY the JSON.";

function callGroqRaw(string $systemMsg, string $userMsg, int $maxTokens): ?array {
    if (!function_exists('curl_init')) return null;
    $payload = json_encode([
        'model'       => GROQ_MODEL,
        'messages'    => [
            ['role' => 'system', 'content' => $systemMsg],
            ['role' => 'user',   'content' => $userMsg],
        ],
        'max_tokens'  => $maxTokens,
        'temperature' => 0.3, // Lower temp = more consistent JSON
    ]);
    $ch = curl_init(GROQ_URL);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true,
        CURLOPT_POSTFIELDS     => $payload,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json', 'Authorization: Bearer '.GROQ_API_KEY],
        CURLOPT_TIMEOUT => 45, CURLOPT_SSL_VERIFYPEER => false,
    ]);
    $result = curl_exec($ch); curl_close($ch);
    $data = json_decode($result, true);
    if (!$data || isset($data['error'])) return null;
    $text = $data['choices'][0]['message']['content'] ?? '';
    // Clean and parse JSON
    $text = preg_replace('/^```[a-z]*\s*/i', '', trim($text));
    $text = preg_replace('/\s*```$/', '', $text);
    $text = trim($text);
    if (preg_match('/\{.*\}/s', $text, $m)) $text = $m[0];
    return json_decode($text, true) ?: null;
}

$sysMsg = 'You are an ATS resume expert. Return ONLY valid compact JSON. No markdown. No explanation. No extra text.';

$part1 = callGroqRaw($sysMsg, $prompt1, 800);
$part2 = callGroqRaw($sysMsg, $prompt2, 600);

// ── Merge results ─────────────────────────────────────────
if ($part1 && isset($part1['overall_score'])) {
    $analysis = $part1;
    if ($part2) {
        $analysis['improvements']    = $part2['improvements']    ?? [];
        $analysis['keywords_found']  = $part2['keywords_found']  ?? [];
        $analysis['keywords_missing']= $part2['keywords_missing'] ?? [];
        $analysis['parsed']          = $part2['parsed']          ?? ['name'=>'','email'=>'','phone'=>'','skills'=>[]];
    } else {
        // part2 failed — fill with heuristics
        $analysis['improvements']    = ['Add quantified achievements (e.g. improved X by 40%)', 'Include LinkedIn and GitHub URLs', 'Add a professional summary at the top', 'Use action verbs: Built, Designed, Deployed', 'Tailor skills section to job description'];
        $analysis['keywords_found']  = [];
        $analysis['keywords_missing']= ['Docker', 'CI/CD', 'REST API', 'Agile', 'AWS'];
        $analysis['parsed']          = ['name'=>'', 'email'=>'', 'phone'=>'', 'skills'=>[]];
    }
} else {
    // Full fallback — AI failed entirely, use heuristic scoring
    $t = strtolower($text);
    $hasEmail    = preg_match('/[\w.+-]+@[\w-]+\.[\w.]+/', $text) ? 1 : 0;
    $hasPhone    = preg_match('/[+\d][\d\s\-(). ]{9,15}/', $text) ? 1 : 0;
    $hasLinkedin = str_contains($t, 'linkedin') ? 1 : 0;
    $hasGithub   = str_contains($t, 'github') ? 1 : 0;
    $hasSummary  = preg_match('/summary|objective|profile|about/i', $text) ? 1 : 0;
    $hasExp      = preg_match('/experience|internship|work/i', $text) ? 1 : 0;
    $hasEdu      = preg_match('/education|university|college|cgpa|btech/i', $text) ? 1 : 0;
    $hasProjects = preg_match('/project|built|developed/i', $text) ? 1 : 0;
    $hasNumbers  = preg_match('/\d+%|\d+x|\d+ (users|projects|people)/i', $text) ? 1 : 0;
    $techKw = ['python','java','javascript','react','nodejs','sql','mongodb','git','docker','aws','html','css','spring','django','flask'];
    $found  = array_values(array_filter($techKw, fn($k) => str_contains($t, $k)));
    $overall = intval(40 + ($hasEmail*5)+($hasPhone*5)+($hasLinkedin*5)+($hasGithub*5)+($hasSummary*5)+($hasExp*10)+($hasEdu*5)+($hasProjects*10)+($hasNumbers*10)+count($found)*2);
    $analysis = [
        'overall_score'  => min(95, $overall),
        'ats_score'      => min(90, intval($overall * 0.9)),
        'job_match'      => ['score' => min(85, intval($overall * 0.85))],
        'section_scores' => ['contact'=>($hasEmail+$hasPhone)*40+($hasLinkedin+$hasGithub)*10,'summary'=>$hasSummary?70:30,'experience'=>$hasExp?75:20,'education'=>$hasEdu?80:30,'skills'=>20+count($found)*8,'projects'=>$hasProjects?70:20,'formatting'=>60],
        'ats_issues'     => array_values(array_filter([
            !$hasNumbers ? ['severity'=>'high',  'issue'=>'No quantified achievements — add metrics like "Improved speed by 40%"'] : null,
            !$hasSummary ? ['severity'=>'medium','issue'=>'No professional summary — add 3-line intro at top'] : null,
            !$hasLinkedin? ['severity'=>'medium','issue'=>'LinkedIn URL missing from contact section'] : null,
            !$hasGithub  ? ['severity'=>'low',   'issue'=>'GitHub profile missing — important for tech roles'] : null,
        ])),
        'strengths'      => array_values(array_filter([
            $hasEdu     ? 'Education section present' : null,
            $hasProjects? 'Projects section shows practical experience' : null,
            count($found)>3 ? 'Good technical skills coverage' : null,
            'Resume successfully uploaded and parsed',
        ])),
        'improvements'   => ['Add quantified metrics to each bullet point','Include LinkedIn and GitHub in header','Add professional summary tailored to target role','Use strong action verbs: Built, Deployed, Optimized','Add more industry keywords for ATS'],
        'keywords_found' => $found,
        'keywords_missing'=> array_values(array_diff(['Docker','CI/CD','REST API','Agile','AWS'], $found)),
        'parsed'         => ['name'=>'', 'email'=>'', 'phone'=>'', 'skills'=>$found],
    ];
}

// ── Save to DB ─────────────────────────────────────────────
if ($user_id) {
    try {
        getDB()->prepare("UPDATE student_profiles SET resume_score=?, ats_score=?, resume_text=? WHERE user_id=?")
            ->execute([round($analysis['overall_score']??0,2), round($analysis['ats_score']??0,2), mb_substr($text,0,5000), $user_id]);
    } catch (Exception $e) { /* non-fatal */ }
}

$analysis['success'] = true;
respond($analysis);
?>

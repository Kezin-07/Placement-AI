<?php
// php/aptitude_save.php – Save aptitude test result to aptitude_results table and update student profile
require 'config.php';

$body         = getBody();
$user_id      = intval($body['user_id']      ?? 0);
$score        = floatval($body['score']       ?? 0);
$tab_warnings = intval($body['tab_warnings'] ?? 0);

if (!$user_id) respond(['success' => false, 'message' => 'user_id required'], 400);
if ($score < 0 || $score > 100) respond(['success' => false, 'message' => 'Score must be between 0 and 100'], 400);

$pdo = getDB();

// Verify user exists and is a student
$chk = $pdo->prepare("SELECT id FROM users WHERE id=? AND role='student' AND is_active=1 LIMIT 1");
$chk->execute([$user_id]);
if (!$chk->fetch()) respond(['success' => false, 'message' => 'Student not found'], 404);

// Insert into aptitude_results (keeps history of all attempts)
$ins = $pdo->prepare('INSERT INTO aptitude_results (user_id, score, tab_warnings) VALUES (?, ?, ?)');
$ins->execute([$user_id, $score, $tab_warnings]);

// Update aptitude_score on student_profiles (keeps latest score)
$upd = $pdo->prepare('UPDATE student_profiles SET aptitude_score=? WHERE user_id=?');
$upd->execute([$score, $user_id]);

// ENHANCEMENT 2: Return full score history so frontend can show improvement trend
$hist = $pdo->prepare('SELECT score, tab_warnings, taken_at FROM aptitude_results WHERE user_id=? ORDER BY taken_at DESC LIMIT 20');
$hist->execute([$user_id]);
$history = $hist->fetchAll();
$avg = count($history) > 0 ? round(array_sum(array_column($history,'score'))/count($history),1) : $score;
$best = count($history) > 0 ? max(array_column($history,'score')) : $score;

// XP reward for aptitude (50 base + bonus if score > previous best)
try {
    $prevBest = $pdo->prepare('SELECT MAX(score) FROM aptitude_results WHERE user_id=? AND taken_at < NOW() ORDER BY taken_at DESC LIMIT 1');
    $prevBest->execute([$user_id]);
    $previousBest = (float)$prevBest->fetchColumn();
    $xpEarned = 30 + intval($score / 5);
    if ($score > $previousBest && $previousBest > 0) $xpEarned += 25; // improvement bonus
    $pdo->prepare('UPDATE streak_data SET total_xp = total_xp + ? WHERE user_id=?')->execute([$xpEarned, $user_id]);
} catch (Exception $e) {}

respond(['success' => true, 'message' => 'Aptitude score saved', 'score' => $score,
    'history' => $history, 'avg_score' => $avg, 'best_score' => $best,
    'attempt_count' => count($history)]);
?>

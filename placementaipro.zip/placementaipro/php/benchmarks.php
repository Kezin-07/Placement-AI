<?php
// php/benchmarks.php – Branch performance benchmarks (PDO)
require 'config.php';

$user_id   = intval($_GET['user_id'] ?? 0);
$branch    = trim($_GET['branch']   ?? 'Computer Science');
$cgpa      = floatval($_GET['cgpa'] ?? 0);

$pdo  = getDB();
$stmt = $pdo->prepare('SELECT * FROM student_profiles WHERE user_id = ? LIMIT 1');
$stmt->execute([$user_id]);
$profile = $stmt->fetch();

$all = $pdo->query("SELECT cgpa, aptitude_score, communication_rating, projects, internships, skills FROM student_profiles WHERE cgpa > 0")->fetchAll();
$branch_rows = $pdo->prepare("SELECT cgpa, aptitude_score, projects, internships FROM student_profiles sp JOIN users u ON u.id=sp.user_id WHERE sp.branch LIKE ? AND sp.cgpa > 0");
$branch_rows->execute(["%$branch%"]);
$branchData = $branch_rows->fetchAll();

function safeAvg(array $rows, string $col): float {
    $vals = array_filter(array_column($rows, $col));
    return count($vals) ? round(array_sum($vals) / count($vals), 2) : 0.0;
}

$overall_avg_cgpa = safeAvg($all, 'cgpa');
$branch_avg_cgpa  = safeAvg($branchData, 'cgpa') ?: $overall_avg_cgpa;
$branch_avg_apt   = safeAvg($branchData, 'aptitude_score') ?: safeAvg($all, 'aptitude_score');
$branch_avg_proj  = safeAvg($branchData, 'projects') ?: safeAvg($all, 'projects');
$branch_avg_int   = safeAvg($branchData, 'internships') ?: safeAvg($all, 'internships');

$rank = 0; $total = count($all);
foreach ($all as $r) { if ($r['cgpa'] < $cgpa) $rank++; }
$percentile = $total > 0 ? round(($rank / $total) * 100) : 50;

respond([
    'avg_cgpa'          => $branch_avg_cgpa,
    'overall_avg_cgpa'  => $overall_avg_cgpa,
    'avg_aptitude'      => $branch_avg_apt,
    'avg_projects'      => $branch_avg_proj,
    'avg_internships'   => $branch_avg_int,
    'percentile'        => $percentile,
    'total_students'    => $total,
    'branch'            => $branch,
]);

?>

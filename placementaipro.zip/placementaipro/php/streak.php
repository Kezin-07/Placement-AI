<?php
// php/streak.php – Daily streak, XP, badges & personalized daily challenges
require 'config.php';

$body    = getBody();
$user_id = intval($body['user_id'] ?? $_GET['user_id'] ?? 0);
$action  = $body['action'] ?? 'get';
if (!$user_id) respond(['success'=>false,'message'=>'user_id required'], 400);

$pdo  = getDB();
$stmt = $pdo->prepare('SELECT * FROM streak_data WHERE user_id = ? LIMIT 1');
$stmt->execute([$user_id]);
$streak = $stmt->fetch();

if (!$streak) {
    $pdo->prepare('INSERT IGNORE INTO streak_data (user_id,badges) VALUES (?,?)')->execute([$user_id,'[]']);
    $streak = ['user_id'=>$user_id,'current_streak'=>0,'longest_streak'=>0,'total_xp'=>0,'last_checkin'=>null,'badges'=>'[]'];
}

$badges = json_decode($streak['badges'] ?? '[]', true) ?: [];

// Badge definitions
function getBadgeRewards(int $streak, int $totalXP): array {
    $all = [
        ['id'=>'first_checkin','name'=>'First Step',     'icon'=>'🌱','desc'=>'Checked in for the first time',   'xp_req'=>0,   'streak_req'=>1],
        ['id'=>'streak_3',     'name'=>'On a Roll',      'icon'=>'🔥','desc'=>'3-day streak',                    'xp_req'=>0,   'streak_req'=>3],
        ['id'=>'streak_7',     'name'=>'Week Warrior',   'icon'=>'⚡','desc'=>'7-day streak',                    'xp_req'=>0,   'streak_req'=>7],
        ['id'=>'streak_14',    'name'=>'Fortnight Fire', 'icon'=>'🌟','desc'=>'14-day streak',                   'xp_req'=>0,   'streak_req'=>14],
        ['id'=>'streak_30',    'name'=>'Month Master',   'icon'=>'👑','desc'=>'30-day streak',                   'xp_req'=>0,   'streak_req'=>30],
        ['id'=>'xp_500',       'name'=>'XP Hunter',      'icon'=>'💎','desc'=>'Earned 500 total XP',             'xp_req'=>500, 'streak_req'=>0],
        ['id'=>'xp_2000',      'name'=>'XP Legend',      'icon'=>'🏆','desc'=>'Earned 2000 total XP',            'xp_req'=>2000,'streak_req'=>0],
        ['id'=>'consistent',   'name'=>'Consistency King','icon'=>'🎯','desc'=>'7-day streak AND 500+ XP',       'xp_req'=>500, 'streak_req'=>7],
        ['id'=>'task_master',  'name'=>'Task Master',    'icon'=>'✅','desc'=>'Complete 10 daily tasks',         'xp_req'=>300, 'streak_req'=>0],
        ['id'=>'interview_ace','name'=>'Interview Ace',  'icon'=>'🎙','desc'=>'Interview score above 75',         'xp_req'=>0,   'streak_req'=>0],
    ];
    $earned = [];
    foreach ($all as $b) {
        if (($b['streak_req'] === 0 || $streak >= $b['streak_req']) &&
            ($b['xp_req'] === 0 || $totalXP >= $b['xp_req'])) {
            $earned[] = $b;
        }
    }
    return $earned;
}

// ── Personalized daily challenges ────────────────────────────
function getDailyChallenges(int $user_id, $pdo): array {
    // Get student profile to personalize tasks
    $profile = null;
    try {
        $s = $pdo->prepare('SELECT * FROM student_profiles WHERE user_id = ? LIMIT 1');
        $s->execute([$user_id]);
        $profile = $s->fetch();
    } catch(Exception $e) {}

    $cgpa       = floatval($profile['cgpa'] ?? 0);
    $aptitude   = floatval($profile['aptitude_score'] ?? 0);
    $interview  = floatval($profile['interview_score'] ?? 0);
    $resume     = floatval($profile['resume_score'] ?? 0);

    // Seed random by user_id + date so each user gets different tasks but consistent per day
    $seed = crc32($user_id . date('Y-m-d'));
    mt_srand(abs($seed));

    // Task pool with difficulty levels
    $easy = [
        ['task'=>'Check in on the portal today',                         'xp'=>20, 'difficulty'=>'Easy',   'icon'=>'📋'],
        ['task'=>'Read one article about your target industry',           'xp'=>20, 'difficulty'=>'Easy',   'icon'=>'📖'],
        ['task'=>'Update your LinkedIn headline',                         'xp'=>25, 'difficulty'=>'Easy',   'icon'=>'💼'],
        ['task'=>'Review 5 commonly asked HR questions',                  'xp'=>20, 'difficulty'=>'Easy',   'icon'=>'🗣'],
        ['task'=>'Browse 3 job listings on the Job Portal',              'xp'=>15, 'difficulty'=>'Easy',   'icon'=>'🔍'],
        ['task'=>'Write down your 3 key strengths',                       'xp'=>20, 'difficulty'=>'Easy',   'icon'=>'✍'],
        ['task'=>'Watch a 10-min YouTube video on interview tips',        'xp'=>20, 'difficulty'=>'Easy',   'icon'=>'▶'],
    ];
    $medium = [
        ['task'=>'Complete a 20-question aptitude practice test',         'xp'=>40, 'difficulty'=>'Medium', 'icon'=>'🧠'],
        ['task'=>'Solve 2 quantitative reasoning problems',               'xp'=>35, 'difficulty'=>'Medium', 'icon'=>'📐'],
        ['task'=>'Do a 15-minute mock HR interview session',              'xp'=>50, 'difficulty'=>'Medium', 'icon'=>'🎤'],
        ['task'=>'Write a STAR-method answer for one behavioral question','xp'=>35, 'difficulty'=>'Medium', 'icon'=>'⭐'],
        ['task'=>'Apply to at least 1 job on the portal',                'xp'=>40, 'difficulty'=>'Medium', 'icon'=>'📨'],
        ['task'=>'Research your top 3 target companies',                  'xp'=>35, 'difficulty'=>'Medium', 'icon'=>'🏢'],
        ['task'=>'Revise your resume and update one section',             'xp'=>40, 'difficulty'=>'Medium', 'icon'=>'📄'],
        ['task'=>'Prepare answers for top 5 technical questions',         'xp'=>45, 'difficulty'=>'Medium', 'icon'=>'💡'],
    ];
    $hard = [
        ['task'=>'Complete a full 30-min AI Mock Interview session',      'xp'=>80, 'difficulty'=>'Hard',   'icon'=>'🎯'],
        ['task'=>'Solve a full aptitude test (30 questions, timed)',       'xp'=>70, 'difficulty'=>'Hard',   'icon'=>'⏱'],
        ['task'=>'Record yourself answering 3 interview questions',        'xp'=>75, 'difficulty'=>'Hard',   'icon'=>'🎬'],
        ['task'=>'Build or update a GitHub project and push changes',     'xp'=>80, 'difficulty'=>'Hard',   'icon'=>'💻'],
        ['task'=>'Write a detailed self-assessment on your weak areas',   'xp'=>65, 'difficulty'=>'Hard',   'icon'=>'📊'],
        ['task'=>'Complete AI roadmap analysis for a target job role',    'xp'=>70, 'difficulty'=>'Hard',   'icon'=>'🗺'],
    ];

    // Personalize: if weak in aptitude, add more aptitude tasks
    if ($aptitude < 50) {
        $medium[] = ['task'=>'Practice 15 aptitude questions focusing on weak areas', 'xp'=>45, 'difficulty'=>'Medium', 'icon'=>'🔢'];
        $hard[]   = ['task'=>'Take the full Aptitude Test and aim for 60%+',          'xp'=>80, 'difficulty'=>'Hard',   'icon'=>'📈'];
    }
    if ($interview < 50) {
        $medium[] = ['task'=>'Do 1 AI Mock Interview and review your score',          'xp'=>55, 'difficulty'=>'Medium', 'icon'=>'🎙'];
        $hard[]   = ['task'=>'Complete 2 full AI Mock Interview rounds',              'xp'=>90, 'difficulty'=>'Hard',   'icon'=>'🎯'];
    }
    if ($resume < 60) {
        $medium[] = ['task'=>'Analyze your resume using the Resume Analyzer',         'xp'=>40, 'difficulty'=>'Medium', 'icon'=>'🔎'];
    }
    if ($cgpa < 7) {
        $easy[]   = ['task'=>'Study 1 core subject concept from your branch',         'xp'=>25, 'difficulty'=>'Easy',   'icon'=>'📚'];
    }

    // Pick 1 easy, 1 medium, 1 hard per day (shuffle with seed)
    shuffle($easy);
    shuffle($medium);
    shuffle($hard);

    return [
        array_shift($easy),
        array_shift($medium),
        array_shift($hard),
    ];
}

// ── Action: check in ─────────────────────────────────────────
if ($action === 'checkin') {
    $today     = date('Y-m-d');
    $last      = $streak['last_checkin'];
    $yesterday = date('Y-m-d', strtotime('-1 day'));

    if ($last === $today) {
        respond(['success'=>true,'message'=>'Already checked in today','already_done'=>true]);
    }

    $newStreak = ($last === $yesterday) ? $streak['current_streak'] + 1 : 1;
    $longest   = max($streak['longest_streak'], $newStreak);

    $xpEarned = 50;
    $bonus = '';
    if ($newStreak === 3)              { $xpEarned += 50;  $bonus = '🔥 3-day streak bonus: +50 XP!'; }
    if ($newStreak === 7)              { $xpEarned += 150; $bonus = '⚡ Week streak bonus: +150 XP!'; }
    if ($newStreak === 14)             { $xpEarned += 300; $bonus = '🌟 Fortnight streak bonus: +300 XP!'; }
    if ($newStreak === 30)             { $xpEarned += 500; $bonus = '👑 Month streak bonus: +500 XP!'; }
    if ($newStreak % 7 === 0 && $newStreak > 7) { $xpEarned += 100; $bonus = '🎖 Weekly milestone: +100 XP!'; }

    $totalXP   = $streak['total_xp'] + $xpEarned;
    $newBadges = getBadgeRewards($newStreak, $totalXP);
    $existing  = array_column($badges ?? [], 'id');
    $newlyEarned = array_values(array_filter($newBadges, fn($b) => !in_array($b['id'], $existing)));

    $pdo->prepare('UPDATE streak_data SET current_streak=?,longest_streak=?,total_xp=?,last_checkin=?,badges=? WHERE user_id=?')
        ->execute([$newStreak,$longest,$totalXP,$today,json_encode($newBadges),$user_id]);

    respond(['success'=>true,'xp_earned'=>$xpEarned,'bonus'=>$bonus,'current_streak'=>$newStreak,
             'longest_streak'=>$longest,'total_xp'=>$totalXP,'new_badges'=>$newlyEarned]);
}

// ── Action: complete a daily task ────────────────────────────
if ($action === 'complete_task') {
    $xp       = intval($body['xp'] ?? 20);
    $taskName = substr($body['task'] ?? '', 0, 200);

    $newXP = $streak['total_xp'] + $xp;
    $newBadges = getBadgeRewards($streak['current_streak'], $newXP);
    $existing  = array_column($badges ?? [], 'id');
    $newlyEarned = array_values(array_filter($newBadges, fn($b) => !in_array($b['id'], $existing)));

    $pdo->prepare('UPDATE streak_data SET total_xp=?,badges=? WHERE user_id=?')
        ->execute([$newXP, json_encode($newBadges), $user_id]);

    respond(['success'=>true,'xp_earned'=>$xp,'total_xp'=>$newXP,'new_badges'=>$newlyEarned,
             'message'=>'+' . $xp . ' XP earned for: ' . $taskName]);
}

// ── Default: GET streak data ──────────────────────────────────
$allBadges  = getBadgeRewards((int)$streak['current_streak'], (int)$streak['total_xp']);
$challenges = getDailyChallenges($user_id, $pdo);
$level      = intval($streak['total_xp'] / 500) + 1;
$levelProg  = ($streak['total_xp'] % 500);

respond([
    'success'          => true,
    'streak'           => $streak,
    'current_streak'   => (int)$streak['current_streak'],
    'total_xp'         => (int)$streak['total_xp'],
    'longest_streak'   => (int)$streak['longest_streak'],
    'badges'           => $allBadges,
    'level'            => $level,
    'level_progress'   => $levelProg,
    'next_level_xp'    => 500,
    'daily_challenges' => $challenges,
    'last_checkin'     => $streak['last_checkin'],
    'can_checkin'      => $streak['last_checkin'] !== date('Y-m-d'),
]);
?>

<?php
// php/org_panel.php  –  Unified Organization Panel API
require 'config.php';

$pdo    = getDB();
$body   = getBody();
$action = $body['action'] ?? $_GET['action'] ?? '';
$uid    = intval($body['user_id'] ?? $_GET['user_id'] ?? 0);

if (!$uid) respond(['success'=>false,'message'=>'user_id required'], 401);
requireVerifiedOrg($uid);

// Get org_id
$orgRow = $pdo->prepare('SELECT id FROM organizations WHERE user_id=? LIMIT 1');
$orgRow->execute([$uid]); $org = $orgRow->fetch();
if (!$org) respond(['success'=>false,'message'=>'Organization not found'], 404);
$org_id = (int)$org['id'];

switch ($action) {

// ── Dashboard overview ──────────────────────────────────────
case 'overview':
    $s1 = $pdo->prepare('SELECT COUNT(*) FROM job_posts WHERE org_id=?');
    $s1->execute([$org_id]); $total_jobs = (int)$s1->fetchColumn();
    $s2 = $pdo->prepare('SELECT COUNT(*) FROM applications a JOIN job_posts jp ON jp.id=a.job_id WHERE jp.org_id=?');
    $s2->execute([$org_id]); $total_apps = (int)$s2->fetchColumn();
    $s3 = $pdo->prepare("SELECT COUNT(*) FROM applications a JOIN job_posts jp ON jp.id=a.job_id WHERE jp.org_id=? AND a.status='shortlisted'");
    $s3->execute([$org_id]); $shortlisted = (int)$s3->fetchColumn();
    $s4 = $pdo->prepare("SELECT COUNT(*) FROM applications a JOIN job_posts jp ON jp.id=a.job_id WHERE jp.org_id=? AND a.status='hired'");
    $s4->execute([$org_id]); $hired = (int)$s4->fetchColumn();
    $company_name = $pdo->prepare('SELECT company_name FROM organizations WHERE id=? LIMIT 1'); $company_name->execute([$org_id]); $cn = $company_name->fetchColumn();
    respond(['success'=>true,'overview'=>array_merge(compact('total_jobs','total_apps','shortlisted','hired'),['company_name'=>$cn])]);

// ── List jobs ───────────────────────────────────────────────
case 'jobs':
    $s = $pdo->prepare("SELECT jp.*,
            (SELECT COUNT(*) FROM applications a WHERE a.job_id=jp.id) as applicant_count,
            (SELECT COUNT(*) FROM applications a WHERE a.job_id=jp.id AND a.status='hired') as hired_count
         FROM job_posts jp WHERE jp.org_id=? ORDER BY jp.created_at DESC");
    $s->execute([$org_id]);
    respond(['success'=>true,'jobs'=>$s->fetchAll()]);

// ── Create job ──────────────────────────────────────────────
case 'create_job':
    $title  = trim($body['title']  ?? '');
    $desc   = trim($body['description'] ?? '');
    $skills = trim($body['required_skills'] ?? '');
    $min    = floatval($body['min_cgpa'] ?? 0);
    $max    = floatval($body['max_cgpa'] ?? 10);
    $exp    = in_array($body['experience_level']??'',['Entry','Mid','Senior']) ? $body['experience_level'] : 'Entry';
    $loc    = trim($body['location'] ?? '');
    $sal    = trim($body['salary_range'] ?? '');
    if (!$title || !$desc) respond(['success'=>false,'message'=>'Title and description required'], 400);
    $s = $pdo->prepare('INSERT INTO job_posts (org_id,title,description,required_skills,min_cgpa,max_cgpa,experience_level,location,salary_range,is_active) VALUES (?,?,?,?,?,?,?,?,?,1)');
    $s->execute([$org_id,$title,$desc,$skills,$min,$max,$exp,$loc,$sal]);
    respond(['success'=>true,'job_id'=>(int)$pdo->lastInsertId()]);

// ── Toggle job active ───────────────────────────────────────
case 'toggle_job':
    $jid = intval($body['job_id']??0);
    $s   = $pdo->prepare('SELECT is_active FROM job_posts WHERE id=? AND org_id=? LIMIT 1');
    $s->execute([$jid,$org_id]); $j=$s->fetch();
    if (!$j) respond(['success'=>false,'message'=>'Job not found'],404);
    $pdo->prepare('UPDATE job_posts SET is_active=? WHERE id=?')->execute([$j['is_active']?0:1,$jid]);
    respond(['success'=>true]);

// ── Candidates (applicants for a job) ──────────────────────
case 'candidates':
    $job_id   = intval($body['job_id'] ?? $_GET['job_id'] ?? 0);
    $status_f = $body['status_filter'] ?? $_GET['status_filter'] ?? 'all';
    if (!$job_id) respond(['success'=>false,'message'=>'job_id required'],400);

    $jc = $pdo->prepare('SELECT * FROM job_posts WHERE id=? AND org_id=? LIMIT 1');
    $jc->execute([$job_id,$org_id]); $job=$jc->fetch();
    if (!$job) respond(['success'=>false,'message'=>'Job not found'],404);

    $req_skills = array_filter(array_map('trim', explode(',', strtolower($job['required_skills'] ?? ''))));
    $min_cgpa   = floatval($job['min_cgpa'] ?? 0);

    // Only students who applied — no sp.full_name (column doesn't exist)
    $sql = "SELECT
                a.student_id as user_id,
                u.name,
                u.email,
                COALESCE(sp.branch, '') as branch,
                COALESCE(sp.cgpa, 0) as cgpa,
                COALESCE(sp.skills, '') as skills,
                COALESCE(sp.aptitude_score, 0) as aptitude_score,
                COALESCE(sp.resume_score, 50) as resume_score,
                COALESCE(sp.projects, 0) as projects,
                COALESCE(sp.internships, 0) as internships,
                a.id as app_id,
                a.status as app_status,
                a.applied_at,
                COALESCE(a.org_notes, '') as org_notes
            FROM applications a
            JOIN users u ON u.id = a.student_id
            LEFT JOIN student_profiles sp ON sp.user_id = a.student_id
            WHERE a.job_id = ? AND u.is_active = 1";

    $params = [$job_id];
    if ($status_f !== 'all') {
        $sql .= " AND a.status = ?";
        $params[] = $status_f;
    }
    $sql .= " ORDER BY COALESCE(sp.cgpa, 0) DESC, COALESCE(sp.aptitude_score, 0) DESC";

    try {
        $s = $pdo->prepare($sql);
        $s->execute($params);
        $rows = $s->fetchAll();
    } catch (Exception $e) {
        respond(['success'=>false,'message'=>'DB error: '.$e->getMessage()], 500);
    }

    $candidates = [];
    foreach ($rows as $r) {
        $stu_skills = array_filter(array_map('trim', explode(',', strtolower($r['skills'] ?? ''))));
        $matched    = array_values(array_intersect($req_skills, $stu_skills));
        $missing    = array_values(array_diff($req_skills, $stu_skills));
        $skill_pct  = count($req_skills) > 0 ? round((count($matched) / count($req_skills)) * 100) : 100;
        $cgpa_ok    = floatval($r['cgpa'] ?? 0) >= $min_cgpa;
        if (!$cgpa_ok) $skill_pct = max(0, $skill_pct - 20);
        $score = round(
            $skill_pct * 0.5 +
            (floatval($r['cgpa'] ?? 0) / 10) * 20 +
            min(10, (floatval($r['aptitude_score'] ?? 0) / 100) * 10) +
            (floatval($r['resume_score'] ?? 50) / 100) * 20
        );
        $candidates[] = array_merge($r, [
            'matched_skills' => array_map('ucwords', $matched),
            'missing_skills' => array_map('ucwords', $missing),
            'match_score'    => min(100, $score),
            'cgpa_ok'        => $cgpa_ok,
        ]);
    }
    usort($candidates, fn($a,$b) => $b['match_score'] - $a['match_score']);
    respond(['success'=>true,'job'=>$job,'candidates'=>$candidates]);

// ── Update application status ───────────────────────────────
case 'update_status':
    $app_id = intval($body['app_id'] ?? 0);
    $new_st = $body['status'] ?? '';
    $notes  = $body['notes'] ?? '';
    $valid  = ['applied','shortlisted','interview_scheduled','rejected','hired'];
    if (!$app_id || !in_array($new_st, $valid)) respond(['success'=>false,'message'=>'Invalid status'],400);

    $ck = $pdo->prepare("SELECT a.student_id, jp.title, o.company_name
                         FROM applications a
                         JOIN job_posts jp ON jp.id = a.job_id
                         JOIN organizations o ON o.id = jp.org_id
                         WHERE a.id = ? AND jp.org_id = ? LIMIT 1");
    $ck->execute([$app_id, $org_id]);
    $appInfo = $ck->fetch();
    if (!$appInfo) respond(['success'=>false,'message'=>'Forbidden'],403);

    $pdo->prepare('UPDATE applications SET status=?, org_notes=? WHERE id=?')
        ->execute([$new_st, $notes, $app_id]);

    // Send notification to student
    $notifMap = [
        'shortlisted'         => ['🎉 You\'ve been Shortlisted!', "{$appInfo['company_name']} shortlisted you for \"{$appInfo['title']}\""],
        'rejected'            => ['❌ Application Update',        "{$appInfo['company_name']} has updated your application for \"{$appInfo['title']}\""],
        'interview_scheduled' => ['📅 Interview Scheduled',       "{$appInfo['company_name']} scheduled an interview for \"{$appInfo['title']}\""],
        'hired'               => ['🏆 Congratulations! You\'re Hired!', "{$appInfo['company_name']} has selected you for \"{$appInfo['title']}\""],
    ];
    if (isset($notifMap[$new_st])) {
        [$title_n, $body_n] = $notifMap[$new_st];
        $pdo->prepare("INSERT INTO notifications (user_id,type,title,body,link) VALUES (?,?,?,?,?)")
            ->execute([$appInfo['student_id'], $new_st, $title_n, $body_n, 'jobs.html']);
    }
    respond(['success'=>true]);

// ── Student list ────────────────────────────────────────────
case 'students':
    $q    = '%'.($body['q'] ?? $_GET['q'] ?? '').'%';
    $cgpa = floatval($body['min_cgpa'] ?? $_GET['min_cgpa'] ?? 0);
    $s    = $pdo->prepare("SELECT sp.*, u.name, u.email
                           FROM student_profiles sp
                           JOIN users u ON u.id = sp.user_id
                           WHERE u.is_active = 1
                             AND (u.name LIKE ? OR sp.skills LIKE ?)
                             AND sp.cgpa >= ?
                           ORDER BY sp.cgpa DESC LIMIT 80");
    $s->execute([$q, $q, $cgpa]);
    respond(['success'=>true,'students'=>$s->fetchAll()]);

default:
    respond(['success'=>false,'message'=>'Unknown action: '.$action], 400);
}
?>

<?php
// php/placement_stats.php – Public placement stats page (no auth needed)
require 'config.php';

$pdo = getDB();

// Company-wise placements
$companies = $pdo->query("SELECT o.company_name, o.logo_url, o.industry,
    COUNT(a.id) as placed_count
    FROM applications a
    JOIN job_posts jp ON jp.id=a.job_id
    JOIN organizations o ON o.id=jp.org_id
    WHERE a.status='hired'
    GROUP BY o.id ORDER BY placed_count DESC LIMIT 20")->fetchAll();

// Overall stats
$total_placed = (int)$pdo->query("SELECT COUNT(*) FROM applications WHERE status='hired'")->fetchColumn();
$total_students = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='student' AND is_active=1")->fetchColumn();
$total_companies = (int)$pdo->query("SELECT COUNT(DISTINCT org_id) FROM job_posts WHERE is_active=1")->fetchColumn();
$avg_cgpa = round((float)$pdo->query("SELECT AVG(cgpa) FROM student_profiles")->fetchColumn(), 2);

// Branch-wise placement rate
$branch_stats = $pdo->query("SELECT sp.branch,
    COUNT(DISTINCT sp.user_id) as total,
    COUNT(DISTINCT CASE WHEN a.status='hired' THEN a.student_id END) as placed
    FROM student_profiles sp
    LEFT JOIN applications a ON a.student_id=sp.user_id
    GROUP BY sp.branch ORDER BY placed DESC")->fetchAll();

// Recent hires (latest 6)
$recent_hires = $pdo->query("SELECT u.name, sp.branch, sp.photo_url, o.company_name, jp.title, a.updated_at
    FROM applications a
    JOIN users u ON u.id=a.student_id
    JOIN student_profiles sp ON sp.user_id=u.id
    JOIN job_posts jp ON jp.id=a.job_id
    JOIN organizations o ON o.id=jp.org_id
    WHERE a.status='hired'
    ORDER BY a.updated_at DESC LIMIT 6")->fetchAll();

respond([
    'success'        => true,
    'total_placed'   => $total_placed,
    'total_students' => $total_students,
    'total_companies'=> $total_companies,
    'avg_cgpa'       => $avg_cgpa,
    'companies'      => $companies,
    'branch_stats'   => $branch_stats,
    'recent_hires'   => $recent_hires,
]);
?>

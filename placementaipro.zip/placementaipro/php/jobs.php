<?php
// php/jobs.php – Job Portal API
require 'config.php';

$pdo    = getDB();
$action = $_GET['action'] ?? 'list';

if ($action === 'list') {
    try {
        $stmt = $pdo->query("
            SELECT jp.id, jp.title, jp.description, jp.required_skills,
                   jp.min_cgpa, jp.max_cgpa, jp.experience_level,
                   jp.location, jp.salary_range, jp.job_type, jp.created_at,
                   o.company_name
            FROM job_posts jp
            JOIN organizations o ON o.id = jp.org_id
            WHERE jp.is_active = 1 AND o.verified = 1
            ORDER BY jp.created_at DESC
            LIMIT 100
        ");
        respond(['success' => true, 'jobs' => $stmt->fetchAll()]);
    } catch (\Exception $e) {
        // If job_type column doesn't exist (v3 schema), fallback
        $stmt = $pdo->query("
            SELECT jp.id, jp.title, jp.description, jp.required_skills,
                   jp.min_cgpa, jp.experience_level,
                   jp.location, jp.salary_range, jp.created_at,
                   o.company_name
            FROM job_posts jp
            JOIN organizations o ON o.id = jp.org_id
            WHERE jp.is_active = 1 AND o.verified = 1
            ORDER BY jp.created_at DESC
            LIMIT 100
        ");
        respond(['success' => true, 'jobs' => $stmt->fetchAll()]);
    }
}

if ($action === 'my_applications') {
    $uid = intval($_GET['user_id'] ?? 0);
    if (!$uid) respond(['success' => false, 'message' => 'user_id required'], 400);

    try {
        $stmt = $pdo->prepare("
            SELECT a.id, a.status, a.applied_at, a.org_notes,
                   a.interview_datetime,
                   jp.title, jp.salary_range, jp.location,
                   o.company_name
            FROM applications a
            JOIN job_posts jp ON jp.id = a.job_id
            JOIN organizations o ON o.id = jp.org_id
            WHERE a.student_id = ?
            ORDER BY a.applied_at DESC
        ");
        $stmt->execute([$uid]);
        respond(['success' => true, 'applications' => $stmt->fetchAll()]);
    } catch (\Exception $e) {
        respond(['success' => false, 'message' => 'Failed to load applications: ' . $e->getMessage()]);
    }
}

respond(['success' => false, 'message' => 'Unknown action'], 400);
?>

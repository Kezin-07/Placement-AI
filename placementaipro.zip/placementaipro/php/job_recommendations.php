<?php
// php/job_recommendations.php – Smart job matching engine
require 'config.php';

$uid = intval($_GET['user_id'] ?? 0);
if (!$uid) respond(['success'=>false,'message'=>'user_id required'], 401);

$pdo = getDB();

// Get student profile
$sp = $pdo->prepare("SELECT * FROM student_profiles WHERE user_id=? LIMIT 1");
$sp->execute([$uid]); $profile = $sp->fetch();
if (!$profile) respond(['success'=>false,'message'=>'Profile not found'], 404);

$student_skills = array_filter(array_map('strtolower', array_map('trim', explode(',', $profile['skills']??''))));
$student_cgpa   = floatval($profile['cgpa']);

// Get all active jobs not yet applied
$jobs = $pdo->prepare("SELECT jp.*, o.company_name, o.logo_url, o.industry,
    (SELECT COUNT(*) FROM applications WHERE job_id=jp.id) as applicant_count
    FROM job_posts jp
    JOIN organizations o ON o.id=jp.org_id
    WHERE jp.is_active=1
    AND jp.id NOT IN (SELECT job_id FROM applications WHERE student_id=?)
    AND o.verified=1
    ORDER BY jp.created_at DESC LIMIT 50");
$jobs->execute([$uid]);
$all_jobs = $jobs->fetchAll();

// Score each job
$scored = [];
foreach ($all_jobs as $job) {
    $req_skills = array_filter(array_map('strtolower', array_map('trim', explode(',', $job['required_skills']??''))));
    $min_cgpa   = floatval($job['min_cgpa']);
    $max_cgpa   = floatval($job['max_cgpa']);

    // Skill match %
    $match_count = 0;
    $matched_skills = [];
    $missing_skills = [];
    foreach ($req_skills as $sk) {
        $found = false;
        foreach ($student_skills as $ss) {
            if (str_contains($ss, $sk) || str_contains($sk, $ss)) { $found=true; break; }
        }
        if ($found) { $match_count++; $matched_skills[] = $sk; }
        else { $missing_skills[] = $sk; }
    }
    $skill_pct = count($req_skills) > 0 ? round(($match_count / count($req_skills)) * 100) : 50;

    // CGPA eligibility
    $cgpa_ok = $student_cgpa >= $min_cgpa && ($max_cgpa <= 0 || $student_cgpa <= $max_cgpa + 0.5);
    $cgpa_score = $cgpa_ok ? 100 : max(0, 100 - (($min_cgpa - $student_cgpa) * 20));

    // Composite match score
    $match_score = intval(($skill_pct * 0.65) + ($cgpa_score * 0.35));

    $scored[] = array_merge($job, [
        'match_score'    => $match_score,
        'skill_match'    => $skill_pct,
        'cgpa_eligible'  => $cgpa_ok,
        'matched_skills' => $matched_skills,
        'missing_skills' => array_slice($missing_skills, 0, 3),
    ]);
}

// Sort by match score
usort($scored, fn($a,$b) => $b['match_score'] - $a['match_score']);

respond(['success'=>true,'recommendations'=>array_slice($scored,0,10),'total'=>count($scored)]);
?>

<?php
// php/student_profile_save.php – Save/update student profile (PDO)
require 'config.php';

$body    = getBody();
$user_id = intval($body['user_id'] ?? 0);
if (!$user_id) respond(['success' => false, 'message' => 'user_id required'], 400);

try {
    $pdo = getDB();

    // Verify user exists
    $uStmt = $pdo->prepare("SELECT id, name, email FROM users WHERE id = ? AND is_active = 1 LIMIT 1");
    $uStmt->execute([$user_id]);
    $userRow = $uStmt->fetch();
    if (!$userRow) respond(['success' => false, 'message' => 'User not found'], 404);

    $fields = ['branch','cgpa','skills','projects','internships','aptitude_score','communication_rating','interview_score','resume_score','github_url','linkedin_url'];
    $data   = [];
    foreach ($fields as $f) { $data[$f] = $body[$f] ?? null; }

    // Use NULL for score fields when not provided, preserving existing DB values
    $interviewScore = isset($body['interview_score']) && $body['interview_score'] !== '' && $body['interview_score'] !== null
        ? floatval($body['interview_score']) : null;
    $resumeScore    = isset($body['resume_score'])    && $body['resume_score']    !== '' && $body['resume_score']    !== null
        ? floatval($body['resume_score'])    : null;

    // Upsert
    $pdo->prepare(
        "INSERT INTO student_profiles (user_id, branch, cgpa, skills, projects, internships, aptitude_score, communication_rating, interview_score, resume_score, github_url, linkedin_url)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           branch               = VALUES(branch),
           cgpa                 = VALUES(cgpa),
           skills               = VALUES(skills),
           projects             = VALUES(projects),
           internships          = VALUES(internships),
           aptitude_score       = VALUES(aptitude_score),
           communication_rating = VALUES(communication_rating),
           interview_score      = IF(VALUES(interview_score) IS NOT NULL, VALUES(interview_score), interview_score),
           resume_score         = IF(VALUES(resume_score)    IS NOT NULL, VALUES(resume_score),    resume_score),
           github_url           = VALUES(github_url),
           linkedin_url         = VALUES(linkedin_url)"
    )->execute([
        $user_id,
        $data['branch'],
        floatval($data['cgpa'] ?? 0),
        $data['skills'],
        intval($data['projects'] ?? 0),
        intval($data['internships'] ?? 0),
        floatval($data['aptitude_score'] ?? 0),
        floatval($data['communication_rating'] ?? 5),
        $interviewScore,
        $resumeScore,
        $data['github_url'],
        $data['linkedin_url']
    ]);

    // Return saved profile so frontend updates instantly
    $stmt = $pdo->prepare(
        'SELECT sp.*, u.name, u.email FROM student_profiles sp
         JOIN users u ON u.id = sp.user_id
         WHERE sp.user_id = ? LIMIT 1'
    );
    $stmt->execute([$user_id]);
    $profile = $stmt->fetch();

    // Ensure all profile values are valid UTF-8 strings for JSON encoding
    if ($profile) {
        foreach ($profile as $k => $v) {
            if (is_string($v)) {
                $profile[$k] = mb_convert_encoding($v, 'UTF-8', 'UTF-8');
            }
        }
    }
    // ENHANCEMENT 3: Award XP for profile completion (fields filled)
    $completionXP = 0;
    $filledFields = 0;
    $checkFields = ['cgpa','skills','projects','github_url','linkedin_url','resume_score','ats_score','interview_score'];
    foreach ($checkFields as $f) {
        if (!empty($profile[$f]) && $profile[$f] !== '0' && $profile[$f] !== '0.00') $filledFields++;
    }
    // Award XP only if not already awarded for full completion
    if ($filledFields >= 5) {
        try {
            $alreadyAwarded = $pdo->prepare('SELECT profile_xp_awarded FROM streak_data WHERE user_id=? LIMIT 1');
            $alreadyAwarded->execute([$user_id]);
            $row = $alreadyAwarded->fetch();
            // Add column if not exists (safe migration)
            if ($row !== false && !isset($row['profile_xp_awarded'])) {
                try { $pdo->exec('ALTER TABLE streak_data ADD COLUMN profile_xp_awarded TINYINT(1) DEFAULT 0'); } catch(Exception $ex) {}
                $row['profile_xp_awarded'] = 0;
            }
            if ($row && !$row['profile_xp_awarded']) {
                $completionXP = $filledFields * 20;
                $pdo->prepare('UPDATE streak_data SET total_xp = total_xp + ?, profile_xp_awarded = 1 WHERE user_id=?')
                    ->execute([$completionXP, $user_id]);
            }
        } catch (Exception $e) {}
    }
    respond(['success' => true, 'profile' => $profile, 'message' => 'Profile saved successfully',
        'completion_pct' => intval($filledFields / count($checkFields) * 100),
        'xp_earned' => $completionXP]);
} catch (Exception $e) {
    respond(['success' => false, 'message' => 'DB error: ' . $e->getMessage()]);
}

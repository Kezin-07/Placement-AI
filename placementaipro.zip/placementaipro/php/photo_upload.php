<?php
// php/photo_upload.php – Student profile photo upload
header('Content-Type: application/json; charset=utf-8');
require 'config.php';

$uid = intval($_POST['user_id'] ?? 0);
if (!$uid) respond(['success'=>false,'message'=>'user_id required'], 401);

if (empty($_FILES['photo']['tmp_name'])) respond(['success'=>false,'message'=>'Photo file required'], 400);

$file     = $_FILES['photo'];
$allowed  = ['image/jpeg','image/png','image/webp','image/gif'];
$mime     = mime_content_type($file['tmp_name']);

if (!in_array($mime, $allowed)) respond(['success'=>false,'message'=>'Only JPG/PNG/WEBP allowed'], 400);
if ($file['size'] > 3 * 1024 * 1024) respond(['success'=>false,'message'=>'Max file size is 3MB'], 400);

// Create uploads dir
$dir = __DIR__ . '/../uploads/photos/';
if (!is_dir($dir)) mkdir($dir, 0775, true);

$ext  = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif'][$mime];
$name = 'student_'.$uid.'_'.time().'.'.$ext;
$dest = $dir . $name;

if (!move_uploaded_file($file['tmp_name'], $dest)) respond(['success'=>false,'message'=>'Upload failed'], 500);

$url = 'uploads/photos/' . $name;

$pdo = getDB();
$pdo->prepare("UPDATE student_profiles SET photo_url=? WHERE user_id=?")->execute([$url, $uid]);

respond(['success'=>true,'photo_url'=>$url]);
?>

<?php
// php/apply_job.php – Student applies for a job
require 'config.php';

$body    = getBody();
$user_id = intval($body['user_id'] ?? 0);
$job_id  = intval($body['job_id']  ?? 0);

if (!$user_id || !$job_id) respond(['success'=>false,'message'=>'user_id and job_id required'], 400);

$pdo = getDB();

// Verify student exists
$u = $pdo->prepare("SELECT id FROM users WHERE id=? AND role='student' AND is_active=1 LIMIT 1");
$u->execute([$user_id]);
if (!$u->fetch()) respond(['success'=>false,'message'=>'Student not found'], 404);

// Verify job is active
$j = $pdo->prepare("SELECT id FROM job_posts WHERE id=? AND is_active=1 LIMIT 1");
$j->execute([$job_id]);
if (!$j->fetch()) respond(['success'=>false,'message'=>'Job not found or inactive'], 404);

// ENHANCEMENT 4: Application spam protection — max 20 per student
$appCount = $pdo->prepare('SELECT COUNT(*) FROM applications WHERE student_id=?');
$appCount->execute([$user_id]);
if ((int)$appCount->fetchColumn() >= 20) {
    respond(['success'=>false,'message'=>'Application limit reached (max 20). Withdraw an existing application to apply to new jobs.'], 429);
}

// Already applied?
$chk = $pdo->prepare('SELECT id FROM applications WHERE student_id=? AND job_id=? LIMIT 1');
$chk->execute([$user_id, $job_id]);
if ($chk->fetch()) respond(['success'=>false,'message'=>'Already applied'], 409);

// Insert application
$ins = $pdo->prepare("INSERT INTO applications (student_id, job_id, status) VALUES (?,?,'applied')");
$ins->execute([$user_id, $job_id]);

// Notifications (wrapped — table may not exist in v3 schema)
try {
    $orgNotif = $pdo->prepare("
        SELECT u2.id as org_user_id, o.company_name, jp.title, u.name as student_name
        FROM job_posts jp
        JOIN organizations o ON o.id = jp.org_id
        JOIN users u2 ON u2.id = o.user_id
        JOIN users u ON u.id = ?
        WHERE jp.id = ? LIMIT 1");
    $orgNotif->execute([$user_id, $job_id]);
    $row = $orgNotif->fetch();
    if ($row) {
        $pdo->prepare("INSERT INTO notifications (user_id,type,title,body,link) VALUES (?,?,?,?,?)")
            ->execute([$row['org_user_id'],'new_applicant','📋 New Application',
                "{$row['student_name']} applied for \"{$row['title']}\"", 'organization.html']);
        $pdo->prepare("INSERT INTO notifications (user_id,type,title,body,link) VALUES (?,?,?,?,?)")
            ->execute([$user_id,'applied','✅ Application Submitted',
                "Your application to {$row['company_name']} for \"{$row['title']}\" received.", 'jobs.html']);
    }
} catch (\Exception $e) {
    // notifications table may not exist — silently skip
}

respond(['success'=>true,'message'=>'Application submitted successfully!']);
?>

<?php
// php/bulk_import.php – Bulk student CSV import (admin only)
header('Content-Type: application/json; charset=utf-8');
require 'config.php';

$pdo = getDB();
$admin_id = intval($_POST['admin_id'] ?? 0);

// Verify admin
if (!$admin_id) respond(['success'=>false,'message'=>'Admin auth required'], 403);
$adm = $pdo->prepare("SELECT id FROM users WHERE id=? AND role='admin' AND is_active=1 LIMIT 1");
$adm->execute([$admin_id]); if (!$adm->fetch()) respond(['success'=>false,'message'=>'Forbidden'], 403);

if (empty($_FILES['csv']['tmp_name'])) respond(['success'=>false,'message'=>'CSV file required'], 400);

$handle = fopen($_FILES['csv']['tmp_name'], 'r');
if (!$handle) respond(['success'=>false,'message'=>'Cannot read file'], 400);

// Read header row
$header = fgetcsv($handle);
if (!$header) respond(['success'=>false,'message'=>'Empty CSV'], 400);
$header = array_map('strtolower', array_map('trim', $header));

// Expected columns (flexible – pick what's present)
$col = fn($name) => array_search($name, $header);

$total = 0; $imported = 0; $skipped = 0; $errors = [];

while (($row = fgetcsv($handle)) !== false) {
    $total++;
    if (count($row) < 2) { $skipped++; continue; }

    $name  = trim($row[$col('name')] ?? $row[0] ?? '');
    $email = strtolower(trim($row[$col('email')] ?? $row[1] ?? ''));
    if (!$name || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Row {$total}: Invalid name/email";
        $skipped++; continue;
    }

    $branch    = trim($row[$col('branch') !== false ? $col('branch') : -1] ?? 'Computer Science');
    $cgpa      = floatval($row[$col('cgpa') !== false ? $col('cgpa') : -1] ?? 0);
    $skills    = trim($row[$col('skills') !== false ? $col('skills') : -1] ?? '');
    $phone     = trim($row[$col('phone') !== false ? $col('phone') : -1] ?? '');

    // Check duplicate
    $dup = $pdo->prepare("SELECT id FROM users WHERE email=? LIMIT 1");
    $dup->execute([$email]);
    if ($dup->fetch()) { $skipped++; $errors[] = "Row {$total}: {$email} already exists"; continue; }

    try {
        $pdo->beginTransaction();
        // Insert user with temp password = first part of email
        $pw = password_hash(explode('@',$email)[0].'@123', PASSWORD_BCRYPT, ['cost'=>10]);
        $ins = $pdo->prepare("INSERT INTO users (name,email,password_hash,role) VALUES (?,?,?,'student')");
        $ins->execute([$name,$email,$pw]);
        $new_uid = (int)$pdo->lastInsertId();

        // Insert profile
        $prof = $pdo->prepare("INSERT INTO student_profiles (user_id,branch,cgpa,skills) VALUES (?,?,?,?)");
        $prof->execute([$new_uid, $branch ?: 'Computer Science', min(10, max(0, $cgpa)), $skills]);

        $pdo->commit();
        $imported++;
    } catch (Exception $e) {
        $pdo->rollBack();
        $errors[] = "Row {$total}: DB error — ".$e->getMessage();
        $skipped++;
    }
}
fclose($handle);

// Log import
$pdo->prepare("INSERT INTO bulk_import_log (admin_id,filename,total,imported,skipped,errors) VALUES (?,?,?,?,?,?)")
    ->execute([$admin_id, $_FILES['csv']['name'], $total, $imported, $skipped, json_encode($errors)]);

respond(['success'=>true,'total'=>$total,'imported'=>$imported,'skipped'=>$skipped,'errors'=>array_slice($errors,0,10)]);
?>

<?php
// php/auth_register_org.php  –  Organization Registration (verified=0 by default)
require 'config.php';

$body         = getBody();
$name         = trim($body['name']         ?? '');
$email        = trim($body['email']        ?? '');
$password     = trim($body['password']     ?? '');
$company_name = trim($body['company_name'] ?? '');
$description  = trim($body['description']  ?? '');
$website      = trim($body['website']      ?? '');
$industry     = trim($body['industry']     ?? '');

if (!$name || !$email || !$password || !$company_name)
    respond(['success'=>false,'message'=>'All required fields must be filled'], 400);
if (!filter_var($email, FILTER_VALIDATE_EMAIL))
    respond(['success'=>false,'message'=>'Invalid email address'], 400);
if (strlen($password) < 6)
    respond(['success'=>false,'message'=>'Password must be at least 6 characters'], 400);

$pdo = getDB();
$chk = $pdo->prepare('SELECT id FROM users WHERE email=? LIMIT 1');
$chk->execute([$email]);
if ($chk->fetch()) respond(['success'=>false,'message'=>'An account with this email already exists'], 409);

$pdo->beginTransaction();
try {
    $hash = hashPassword($password);
    $u = $pdo->prepare('INSERT INTO users (name,email,password_hash,role) VALUES (?,?,?,\'organization\')');
    $u->execute([$name, $email, $hash]);
    $uid = (int)$pdo->lastInsertId();

    // verified = 0 → admin must approve before login is allowed
    $o = $pdo->prepare('INSERT INTO organizations (user_id,company_name,description,website,industry,verified) VALUES (?,?,?,?,?,0)');
    $o->execute([$uid, $company_name, $description, $website, $industry]);
    $pdo->commit();
} catch (Exception $e) {
    $pdo->rollBack();
    respond(['success'=>false,'message'=>'Registration failed: '.$e->getMessage()], 500);
}

respond(['success'=>true,'message'=>'Registration successful! Awaiting admin verification.']);
?>

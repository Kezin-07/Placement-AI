<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">  <link rel="icon" type="image/svg+xml" href="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAzMiAzMiIgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIj4KICA8ZGVmcz4KICAgIDxsaW5lYXJHcmFkaWVudCBpZD0iZyIgeDE9IjAiIHkxPSIxIiB4Mj0iMSIgeTI9IjAiPgogICAgICA8c3RvcCBvZmZzZXQ9IjAlIiBzdG9wLWNvbG9yPSIjZmY0NzU3Ii8+CiAgICAgIDxzdG9wIG9mZnNldD0iMTAwJSIgc3RvcC1jb2xvcj0iI2Y1OWUwYiIvPgogICAgPC9saW5lYXJHcmFkaWVudD4KICA8L2RlZnM+CiAgPHJlY3Qgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIiByeD0iNyIgZmlsbD0iIzFlMWExMCIvPgogIDxyZWN0IHg9IjYiIHk9IjIxIiB3aWR0aD0iNSIgaGVpZ2h0PSI5IiByeD0iMS41IiBmaWxsPSIjZjU5ZTBiIiBvcGFjaXR5PSIuNSIvPgogIDxyZWN0IHg9IjEzIiB5PSIxNSIgd2lkdGg9IjUiIGhlaWdodD0iMTUiIHJ4PSIxLjUiIGZpbGw9IiNmZjZiMzUiIG9wYWNpdHk9Ii43NSIvPgogIDxyZWN0IHg9IjIwIiB5PSI4IiB3aWR0aD0iNSIgaGVpZ2h0PSIyMiIgcng9IjEuNSIgZmlsbD0idXJsKCNnKSIvPgogIDxwb2x5bGluZSBwb2ludHM9IjIzLDQgMjcsOCAyNyw1IiBmaWxsPSJub25lIiBzdHJva2U9InVybCgjZykiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIi8+CiAgPGxpbmUgeDE9IjE5IiB5MT0iNSIgeDI9IjI3IiB5Mj0iNCIgc3Ryb2tlPSJ1cmwoI2cpIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPgo8L3N2Zz4=">
  <link rel="icon" type="image/x-icon" href="data:image/x-icon;base64,AAABAAEAEBAAAAAAIACgAAAAFgAAAIlQTkcNChoKAAAADUlIRFIAAAAQAAAAEAgGAAAAH/P/YQAAAGdJREFUeJxjZIACLg6R/wwkgG8/3jAyMDAwMJGjGVkPIzmakQETJZoZGBgYWNAFvn5/jVMxN6co9V1AWwOwOZkkA/CFB1EGEAOoH43IgOIwIAZQnpRhuYoc8O3HG0YmGIMczQwMDAwA+P4aS3/n/2IAAAAASUVORK5CYII=">
  <link rel="icon" type="image/png" sizes="32x32" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAoElEQVR4nO2XvQ6AIAyES+Pgz6rv/4Cyimw6kWhDxID0HLixabyPozHUUERjPx+xeqmct0bWboVaxk8grG0uvVjbXEJwqrG2DOL0V8ET6FIN275mfXgalld98AQaABwgOYQxyQHLHVSiHyTQALJmoOTOpeAJNAA4wCc/ohLBE2gAcAD8ozS2LmnJeWvgV8CBRNs4eLIsaJoTie04SHM9PwGQNi1E3UY9bQAAAABJRU5ErkJggg==">
  <link rel="icon" type="image/png" sizes="192x192" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMAAAADACAYAAABS3GwHAAADvklEQVR4nO3dQVLjVgBFUZvqASFTsv8FhmkIMzJIdRc0YCxL8pd8z1kAaPCuvmy61MfDxjzcP76OvgbW8/zydBx9DW8NvRhj53AYG8XVf7HRc8q1Y7jaLzN8prhWCKv/EsNnjrVDWO2HGz5LWiuExX+o4bOmpUO4W/KHGT9rW3pji9Rk+IywxGkw+wQwfkZZYnuzAjB+Rpu7wYsDMH62Ys4WLwrA+NmaSzc5OQDjZ6su2eakAIyfrZu60bMDMH72YspWzwrA+Nmbczf7bQDGz16ds91F/ykE7M3JANz92bvvNvxlAMbPrTi1ZY9ApH0agLs/t+arTTsBSPsQgLs/t+qzbTsBSHsXgLs/t+73jTsBSPsVgLs/FW+37gQgTQCk3R0OHn/o+bl5JwBpAiBNAKQJgLSjD8CUOQFIEwBpAiBNAKQJgDQBkPZj9AXM9c+/f4++hF3584+/Rl/CpjgBSBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYC03b8VYi0j356w1psuvBHiIycAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANKOD/ePr6MvYo61XiV+q7wi/T0nAGkCIE0ApAmANAGQJgDSBECaAEgTAGkCIE0ApAmANAGQJgDSBECaAEgTAGkCIE0ApAmANAGQ9mP0BWyVtyc0OAFIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0o4P94+voy8CRnECkCYA0gRAmgBIEwBpd88vT8fRFwEjPL88HZ0ApAmANAGQJgDS7g6H/z8MjL4QuKafm3cCkCYA0n4F4DGIirdbdwKQ9i4ApwC37veNOwFI+xCAU4Bb9dm2nQCkfRqAU4Bb89WmnQCkfRmAU4BbcWrLJ08AEbB3323YIxBp3wbgFGCvztnuWSeACNibczd79iOQCNiLKVud9BlABGzd1I1O/hAsArbqkm1e9C2QCNiaSzd58degImAr5mxx1t8BRMBoczc4+w9hImCUJba36Hj9bzNcw5I33UX/KYTTgLUtvbHVBus0YElr3VxXv2MLgTnWfqq42iOLEJjiWo/TV39mFwKnXPtz5NAPrWLgcBj75cnmvrURxW3b2jeF/wGOq9fsu4f8UQAAAABJRU5ErkJggg==">
  <link rel="apple-touch-icon" sizes="180x180" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAAC0CAYAAAA9zQYyAAADX0lEQVR4nO3cOXJaQQBFUVA58JDa+1+glVpWZgceygOS/kh/rs5ZAOrg8tRAwfl0AO/ffvw2+gys9/B4fx59hiEHEPDrMCLwq/1BEb9u14p71z8iYi7ZM+5dHljITLFH2HdbP6CYmWqPVjZ7hgiZNbZa600WWsystVVDq54VQmYPa9Z68UKLmb2saWtR0GJmb0sbmx20mLmWJa3NClrMXNvc5iYHLWZGmdPepKDFzGhTG3wxaDFzFFNa3Pyjbxjp2aCtM0fzUpNPBi1mjuq5Nl05SLkYtHXm6J5q9L+gxcytuNSqKwcpfwVtnbk1/zZroUkRNCm/g3bd4Fb92a6FJkXQpNydTq4b3L5fDVtoUgRNiqBJObs/U2KhSRE0KYImRdCkCJoUQZPyZvQBlvjy9fPoIxzWh3efRh9hKAtNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiblJr8ku4cRXy71Zd/tWWhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCl+rPEnP5zYYKFJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KT4kuxPH959Gn0ENmChSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJqU8/u3H7+NPgRsxUKTImhSBE2KoEkRNCl3D4/359GHgC08PN6fLTQpgiZF0KTcnU4/7h6jDwJr/GrYQpMiaFJ+B+3awa36s10LTYqgSfkraNcObs2/zVpoUv4L2kpzKy61enGhRc3RPdWoKwcpTwZtpTmq59p8dqFFzdG81KQrBykvBm2lOYopLU5aaFEz2tQGJ185RM0oc9qbdYcWNdc2t7nZLwpFzbUsaW3RuxyiZm9LG1v8tp2o2cuatjaJ0k/ysoUtRnKTD1asNWtt1dDmIVpr5th6DDf/6NtaM9Uerewan7Xmkj1H72prKu7X7Vr/uYdcD8T9Ooy4fh7ivivwhiO8fvoO2onGYhMioSEAAAAASUVORK5CYII=">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Admin Dashboard — PlacementAI Pro</title>
  <link rel="stylesheet" href="css/style.css?v=5">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
  <style>
    /* ── Responsive Admin Overrides ── */
    .admin-tabs-wrap { overflow-x: auto; -webkit-overflow-scrolling: touch; }
    .tabs { flex-wrap: nowrap; min-width: max-content; }

    /* Mobile table: card layout */
    @media(max-width: 640px) {
      .table-wrap { overflow-x: auto; -webkit-overflow-scrolling: touch; border-radius: var(--radius); }
      .table-wrap table { min-width: 520px; }
      .grid-4 { grid-template-columns: 1fr 1fr !important; gap: 10px !important; }
      .grid-2 { grid-template-columns: 1fr !important; }
      .grid-auto { grid-template-columns: 1fr !important; }
      .page-header h1 { font-size: 1.2rem; }
      .stat-value { font-size: 1.4rem !important; }
      .tabs .tab-btn { font-size: 12px; padding: 6px 10px; }
    }
    @media(max-width: 860px) {
      .grid-4 { grid-template-columns: 1fr 1fr !important; }
    }
    @media(max-width: 480px) {
      .grid-4 { grid-template-columns: 1fr !important; }
      .page { padding: 12px; }
    }

    /* Org card grid — fixed 3 columns, rows grow as orgs are added */
    .grid-auto {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 16px;
      align-items: stretch;
    }
    .grid-auto > div { display: flex; flex-direction: column; }
    .grid-auto > div > div:last-child { margin-top: auto; }
    @media(max-width: 1100px) { .grid-auto { grid-template-columns: repeat(2, 1fr); } }
    @media(max-width: 640px)  { .grid-auto { grid-template-columns: 1fr; } }

    /* Better table on mobile */
    .table-wrap { border: 1px solid var(--border); border-radius: var(--radius); overflow: hidden; }
    .table-wrap table { width: 100%; border-collapse: collapse; }
    .table-wrap th { background: var(--bg3); padding: 10px 14px; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: .06em; color: var(--text3); text-align: left; white-space: nowrap; }
    .table-wrap td { padding: 11px 14px; border-top: 1px solid var(--border); font-size: 13px; color: var(--text2); vertical-align: middle; }
    .table-wrap tr:hover td { background: var(--surface2); }
    .td-main { font-weight: 600; color: var(--text); font-size: 13.5px; }

    /* Search bar */
    .search-bar { display: flex; gap: 10px; margin-bottom: 16px; flex-wrap: wrap; }
    .search-bar .input-group { flex: 1; min-width: 200px; }
    .input-group svg { position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: var(--text3); pointer-events: none; }
    .input-group .form-input { padding-left: 38px; }

    /* Topbar breadcrumb responsive */
    @media(max-width: 500px) {
      .topbar__title { font-size: 13px; }
      .topbar { padding: 0 14px; gap: 10px; }
    }
  </style>
</head>
<body>
<script src="js/app.js?v=5"></script>
<script>
// ── Run after DOM is ready ──────────────────────────────────
document.addEventListener('DOMContentLoaded', function() {
  const user = Auth.requireAuth('admin');
  if (user) { buildShell('admin'); setTimeout(()=>initAdmin(user), 0); }
});

async function initAdmin(user) {
  document.getElementById('topbarTitle').textContent = 'Admin Dashboard';
  document.getElementById('topbarActions').innerHTML =
    `<span class="badge badge-red">● Admin</span>`;

  const page = document.getElementById('mainPage');
  page.innerHTML = `
    <div class="page-header">
      <h1>📈 Admin Analytics</h1>
      <p class="breadcrumb">Platform overview and management</p>
    </div>
    <div class="admin-tabs-wrap">
      <div class="tabs" id="adminTabs">
        <button class="tab-btn active" data-tab="overview-tab">Overview</button>
        <button class="tab-btn" data-tab="students-tab">Students</button>
        <button class="tab-btn" data-tab="orgs-tab">Organizations</button>
        <button class="tab-btn" data-tab="analytics-tab">Analytics</button>
        <button class="tab-btn" data-tab="import-tab">📤 Bulk Import</button>
      </div>
    </div>
    <div id="overview-tab"  class="tab-pane active"><div class="loading-center"><div class="spinner"></div></div></div>
    <div id="students-tab"  class="tab-pane"></div>
    <div id="orgs-tab"      class="tab-pane"></div>
    <div id="analytics-tab" class="tab-pane"></div>
    <div id="import-tab" class="tab-pane"></div>`;

  // Tab click handlers
  document.querySelectorAll('#adminTabs .tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('#adminTabs .tab-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
      document.getElementById(btn.dataset.tab).classList.add('active');
      loadTab(btn.dataset.tab.replace('-tab',''), user);
    });
  });

  // Check URL param for deep-linking from sidebar
  const urlTab = new URLSearchParams(window.location.search).get('tab');
  if (urlTab && ['students','orgs','analytics','import'].includes(urlTab)) {
    const targetBtn = document.querySelector(`[data-tab="${urlTab}-tab"]`);
    if (targetBtn) targetBtn.click();
  } else {
    loadTab('overview', user);
  }
}

async function loadTab(tab, user) {
  window._adminUser = window._adminUser || user;
  const u = window._adminUser;
  if (!u) return;
  if (tab === 'overview')  await loadOverview(u);
  else if (tab === 'students') await loadStudents(u);
  else if (tab === 'orgs')     await loadOrgs(u);
  else if (tab === 'analytics') await loadAnalytics(u);
  else if (tab === 'import') loadBulkImport(u);
}

// ── OVERVIEW ──────────────────────────────────────────────
async function loadOverview(user) {
  const panel = document.getElementById('overview-tab');
  panel.innerHTML = `<div class="loading-center"><div class="spinner"></div> Loading stats…</div>`;
  try {
    const d = await API.post('admin_panel.php', {action:'stats', admin_id:user.id});
    const s = d.stats;
    panel.innerHTML = `
      <div class="grid-4 mb-6">
        <div class="stat-card accent-purple">
          <div class="stat-icon purple">${iconUsers()}</div>
          <div class="stat-value">${fmtNum(s.students)}</div>
          <div class="stat-label">Total Students</div>
        </div>
        <div class="stat-card accent-green">
          <div class="stat-icon green">${iconBriefcase()}</div>
          <div class="stat-value">${fmtNum(s.jobs_active)}</div>
          <div class="stat-label">Active Jobs</div>
        </div>
        <div class="stat-card accent-amber">
          <div class="stat-icon amber">${iconTrophy()}</div>
          <div class="stat-value">${s.placement_rate}%</div>
          <div class="stat-label">Placement Rate</div>
        </div>
        <div class="stat-card accent-rose">
          <div class="stat-icon rose">${iconChart()}</div>
          <div class="stat-value">${fmtNum(s.applications)}</div>
          <div class="stat-label">Applications</div>
        </div>
      </div>

      <div class="grid-2 mb-6">
        <div class="card">
          <div class="card-title mb-4">Organization Status</div>
          <div style="display:flex;flex-direction:column;gap:12px">
            ${[
              ['Total Registered', s.orgs_total, 'var(--text)'],
              ['Verified',         s.orgs_verified, 'var(--emerald)'],
              ['Pending Approval', s.orgs_pending, 'var(--accent2)'],
            ].map(([lbl,val,c])=>`
              <div style="display:flex;justify-content:space-between;align-items:center">
                <span style="color:var(--text2)">${lbl}</span>
                <span style="font-weight:700;color:${c}">${val}</span>
              </div>`).join('')}
            ${s.orgs_pending > 0 ? `<button onclick="document.querySelector('[data-tab=\\'orgs-tab\\']').click()" class="btn btn-ghost btn-sm">Review Pending →</button>` : ''}
          </div>
        </div>
        <div class="card">
          <div class="card-title mb-4">Recent Registrations</div>
          <div style="display:flex;flex-direction:column;gap:8px">
            ${(s.recent||[]).slice(0,5).map(u=>`
              <div style="display:flex;align-items:center;justify-content:space-between;gap:8px">
                <div style="min-width:0">
                  <div style="font-size:13px;font-weight:600;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(u.name)}</div>
                  <div style="font-size:11px;color:var(--text3);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(u.email)}</div>
                </div>
                ${statusBadge(u.role==='student'?'active':u.role==='organization'?'pending':'verified')}
              </div>`).join('')}
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-title mb-4">Students by Branch</div>
        <div style="display:flex;flex-direction:column;gap:10px">
          ${(s.by_branch||[]).map(b=>`
            <div style="display:flex;align-items:center;gap:10px">
              <div style="width:min(160px,30vw);font-size:13px;color:var(--text2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex-shrink:0">${esc(b.branch)}</div>
              <div style="flex:1;background:var(--bg3);border-radius:99px;height:8px;overflow:hidden">
                <div style="height:100%;width:${Math.min(100,(b.cnt/Math.max(s.students,1))*100)}%;background:var(--primary-g);border-radius:99px;transition:width .6s ease"></div>
              </div>
              <div style="width:36px;text-align:right;font-size:13px;font-weight:700;color:var(--text);flex-shrink:0">${b.cnt}</div>
            </div>`).join('')||'<p class="text-muted text-sm">No branch data</p>'}
        </div>
      </div>`;
  } catch(e) {
    panel.innerHTML = `<div class="alert alert-error">⚠️ ${esc(e.message)}</div>`;
  }
}

// ── STUDENTS ──────────────────────────────────────────────
async function loadStudents(user) {
  const panel = document.getElementById('students-tab');
  panel.innerHTML = `<div class="loading-center"><div class="spinner"></div> Loading students…</div>`;
  try {
    const d = await API.post('admin_panel.php', {action:'students', admin_id:user.id, q:''});
    window._allStudents = d.students || [];
    window._adminUser = user;
    panel.innerHTML = `
      <div class="search-bar">
        <div class="input-group" style="flex:1;min-width:200px;position:relative">
          ${iconSearch()}
          <input type="text" class="form-input" placeholder="Search by name or email…" id="studentSearch"
            oninput="filterStudents(this.value)" style="padding-left:38px">
        </div>
        <div style="color:var(--text3);font-size:13px;display:flex;align-items:center;white-space:nowrap">
          ${fmtNum(window._allStudents.length)} students
        </div>
      </div>
      <div class="table-wrap" style="overflow-x:auto">
        <table style="min-width:560px">
          <thead>
            <tr>
              <th>Name</th>
              <th>Branch</th>
              <th>CGPA</th>
              <th>Aptitude</th>
              <th>Resume</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody id="studentsTbody">${studentsRows(window._allStudents)}</tbody>
        </table>
      </div>`;
  } catch(e) {
    panel.innerHTML = `<div class="alert alert-error">⚠️ ${esc(e.message)}</div>`;
  }
}

function studentsRows(arr) {
  if (!arr.length) return '<tr><td colspan="7" style="text-align:center;color:var(--text3);padding:32px">No students found</td></tr>';
  return arr.map(s => {
    const cgpaColor = parseFloat(s.cgpa) >= 8 ? 'var(--emerald)' : parseFloat(s.cgpa) >= 6.5 ? 'var(--accent2)' : 'var(--red)';
    return `<tr>
      <td>
        <div class="td-main">${esc(s.name)}</div>
        <div style="font-size:11px;color:var(--text3)">${esc(s.email)}</div>
      </td>
      <td>${esc(s.branch || '—')}</td>
      <td style="font-weight:700;color:${cgpaColor}">${s.cgpa || '—'}</td>
      <td>${s.aptitude_score || '—'}</td>
      <td>${s.resume_score || '—'}</td>
      <td>${statusBadge(s.is_active ? 'active' : 'inactive')}</td>
      <td>
        <button onclick="toggleUser(${s.id}, this)" class="btn btn-ghost btn-sm">
          ${s.is_active ? 'Block' : 'Unblock'}
        </button>
      </td>
    </tr>`;
  }).join('');
}

function filterStudents(q) {
  const filtered = (window._allStudents || []).filter(s =>
    s.name?.toLowerCase().includes(q.toLowerCase()) ||
    s.email?.toLowerCase().includes(q.toLowerCase())
  );
  document.getElementById('studentsTbody').innerHTML = studentsRows(filtered);
}

async function toggleUser(uid, btn) {
  const user = window._adminUser;
  loading(btn, true);
  try {
    await API.post('admin_panel.php', {action:'toggle_user', admin_id:user.id, user_id:uid});
    await loadStudents(user);
  } catch(e) {
    loading(btn, false);
    alert(e.message);
  }
}

// ── ORGANIZATIONS ─────────────────────────────────────────
async function loadOrgs(user) {
  const panel = document.getElementById('orgs-tab');
  panel.innerHTML = `<div class="loading-center"><div class="spinner"></div> Loading organizations…</div>`;
  try {
    const d = await API.post('admin_panel.php', {action:'orgs', admin_id:user.id, status:'all'});
    const orgs = d.orgs || [];
    window._adminUser = user;
    if (!orgs.length) {
      panel.innerHTML = `<div class="card" style="text-align:center;padding:48px">
        <div style="font-size:2.5rem;margin-bottom:12px">🏢</div>
        <h4>No organizations yet</h4>
        <p class="text-muted text-sm" style="margin-top:6px">Organizations will appear here once they register.</p>
      </div>`;
      return;
    }
    panel.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;flex-wrap:wrap;gap:8px">
        <span style="color:var(--text3);font-size:13px">${orgs.length} organization${orgs.length!==1?'s':''}</span>
        <div style="display:flex;gap:8px">
          ${statusBadge('verified')} <span style="font-size:12px;color:var(--text3);align-self:center">${orgs.filter(o=>o.verified).length}</span>
          &nbsp;
          ${statusBadge('pending')} <span style="font-size:12px;color:var(--text3);align-self:center">${orgs.filter(o=>!o.verified).length}</span>
        </div>
      </div>
      <div class="grid-auto">
        ${orgs.map(o => `
          <div class="card" style="position:relative;overflow:hidden;display:flex;flex-direction:column;padding:0">
            <!-- Top accent bar -->
            <div style="height:3px;background:${o.verified?'linear-gradient(90deg,#00d68f,#00c8ff)':'linear-gradient(90deg,#f59e0b,#ffd32a)'}"></div>
            <div style="padding:16px 16px 12px;flex:1;display:flex;flex-direction:column;gap:0">
              <!-- Header row -->
              <div style="display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:10px;gap:8px">
                <div style="display:flex;align-items:center;gap:10px;min-width:0">
                  <div style="width:40px;height:40px;border-radius:10px;background:linear-gradient(135deg,rgba(108,99,255,.2),rgba(167,139,250,.15));border:1px solid rgba(108,99,255,.2);display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:800;color:var(--primary);flex-shrink:0">
                    ${esc(o.company_name||'?').charAt(0).toUpperCase()}
                  </div>
                  <div style="min-width:0">
                    <div style="font-weight:700;font-size:14px;color:var(--text);margin-bottom:1px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(o.company_name)}</div>
                    <div style="font-size:11.5px;color:var(--text3);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(o.email)}</div>
                  </div>
                </div>
                ${statusBadge(o.verified ? 'verified' : 'pending')}
              </div>
              <!-- Industry -->
              ${o.industry ? `<div style="font-size:12px;color:var(--text3);margin-bottom:8px;display:flex;align-items:center;gap:4px">🏭 <span>${esc(o.industry)}</span></div>` : ''}
              <!-- Description -->
              ${o.description ? `<div style="font-size:12.5px;color:var(--text2);line-height:1.5;flex:1;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;margin-bottom:12px">${esc(o.description)}</div>` : '<div style="flex:1"></div>'}
            </div>
            <!-- Action bar pinned to bottom -->
            <div style="padding:10px 16px;border-top:1px solid var(--border);display:flex;gap:8px;align-items:center">
              ${!o.verified
                ? `<button onclick="approveOrg(${o.id},1,this)" class="btn btn-success btn-sm" style="flex:1;justify-content:center">✓ Approve</button>
                   <button onclick="approveOrg(${o.id},0,this)" class="btn btn-danger btn-sm" style="flex:1;justify-content:center">✗ Reject</button>`
                : `<span style="font-size:12px;color:var(--emerald);font-weight:600">✓ Verified organization</span>`
              }
            </div>
          </div>`).join('')}
      </div>`;
  } catch(e) {
    panel.innerHTML = `<div class="alert alert-error">⚠️ ${esc(e.message)}</div>`;
  }
}

async function approveOrg(orgId, approve, btn) {
  const user = window._adminUser;
  loading(btn, true);
  try {
    await API.post('admin_panel.php', {action:'approve_org', admin_id:user.id, org_id:orgId, approve:!!approve});
    await loadOrgs(user);
  } catch(e) {
    loading(btn, false);
    alert(e.message);
  }
}

// ── ANALYTICS ─────────────────────────────────────────────
async function loadAnalytics(user) {
  const panel = document.getElementById('analytics-tab');
  panel.innerHTML = `<div class="loading-center"><div class="spinner"></div> Loading analytics…</div>`;
  try {
    const d = await API.post('admin_panel.php', {action:'analytics', admin_id:user.id});
    const topSkills = Object.entries(d.top_skills || {}).slice(0, 10);
    const maxSkill  = topSkills.length ? topSkills[0][1] : 1;

    panel.innerHTML = `
      <div class="grid-2 mb-4">
        <div class="card">
          <div class="card-title mb-4">Top Skills on Platform</div>
          <div style="display:flex;flex-direction:column;gap:10px">
            ${topSkills.map(([k,v]) => `
              <div style="display:flex;align-items:center;gap:10px">
                <div style="width:min(120px,28vw);font-size:13px;color:var(--text2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex-shrink:0">${esc(k)}</div>
                <div style="flex:1;background:var(--bg3);border-radius:99px;height:6px;overflow:hidden">
                  <div style="height:100%;width:${Math.min(100,(v/maxSkill)*100)}%;background:var(--primary-g);border-radius:99px"></div>
                </div>
                <div style="width:24px;text-align:right;font-size:12px;color:var(--text3);flex-shrink:0">${v}</div>
              </div>`).join('') || '<p class="text-muted text-sm">No skill data yet</p>'}
          </div>
        </div>
        <div class="card">
          <div class="card-title mb-4">Platform Averages</div>
          <div style="display:flex;flex-direction:column;gap:4px">
            ${[
              {label:'Avg CGPA',     val:parseFloat(d.avg_scores?.avg_cgpa||0).toFixed(2),     max:10,  color:'purple'},
              {label:'Avg Aptitude', val:parseFloat(d.avg_scores?.avg_aptitude||0).toFixed(1), max:100, color:'green'},
              {label:'Avg Resume',   val:parseFloat(d.avg_scores?.avg_resume||0).toFixed(1),   max:100, color:'amber'},
              {label:'Avg ATS',      val:parseFloat(d.avg_scores?.avg_ats||0).toFixed(1),      max:100, color:'rose'},
            ].map(x => progressBar(`${x.label}: ${x.val}`, parseFloat(x.val), x.max, x.color)).join('')}
          </div>
        </div>
      </div>
      <div class="card">
        <div class="card-title mb-4">Top Companies by Applications</div>
        ${(d.top_companies||[]).length ? `
        <div class="table-wrap" style="overflow-x:auto">
          <table style="min-width:320px">
            <thead><tr><th>Company</th><th>Applications</th><th style="min-width:100px">Share</th></tr></thead>
            <tbody>
              ${(d.top_companies||[]).map(c => {
                const maxApps = d.top_companies[0]?.apps || 1;
                return `<tr>
                  <td class="td-main">${esc(c.company_name)}</td>
                  <td style="font-weight:700;color:var(--text)">${c.apps}</td>
                  <td>
                    <div style="background:var(--bg3);border-radius:99px;height:6px;width:100%;max-width:120px;overflow:hidden">
                      <div style="height:100%;width:${Math.min(100,(c.apps/maxApps)*100)}%;background:var(--primary-g);border-radius:99px"></div>
                    </div>
                  </td>
                </tr>`;
              }).join('')}
            </tbody>
          </table>
        </div>` : '<p class="text-muted text-sm">No application data yet</p>'}
      </div>`;
  } catch(e) {
    panel.innerHTML = `<div class="alert alert-error">⚠️ ${esc(e.message)}</div>`;
  }
}

function loadBulkImport(u) {
  const panel = document.getElementById('import-tab');
  panel.innerHTML = `
    <div class="card" style="max-width:600px">
      <div class="card-header">
        <div>
          <div class="card-title">📤 Bulk Student Import</div>
          <div class="card-subtitle">Upload a CSV file to add multiple students at once</div>
        </div>
      </div>
      <div class="alert alert-info mb-4" style="font-size:13px">
        <strong>CSV Format Required:</strong> Columns: <code>name, email, branch, cgpa, skills</code><br>
        First row should be header. Email becomes login. Default password: <code>username@123</code>
      </div>
      <div style="border:2px dashed var(--border2);border-radius:var(--radius);padding:32px;text-align:center;margin-bottom:20px" id="dropZone">
        <div style="font-size:2.5rem;margin-bottom:10px">📁</div>
        <div style="font-weight:700;margin-bottom:6px">Drop CSV file here or click to browse</div>
        <div style="font-size:12px;color:var(--text3);margin-bottom:16px">Supports .csv format only</div>
        <input type="file" id="csvFile" accept=".csv" style="display:none" onchange="handleCsvSelect(this)">
        <button onclick="document.getElementById('csvFile').click()" class="btn btn-primary btn-sm">Browse File</button>
      </div>
      <div id="importPreview"></div>
      <div id="importResult"></div>
    </div>`;
}

async function handleCsvSelect(input) {
  const file = input.files[0];
  if (!file) return;
  document.getElementById('importPreview').innerHTML = `
    <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 16px;background:var(--surface2);border-radius:var(--radius);margin-bottom:14px">
      <div>
        <div style="font-weight:700;font-size:13.5px">📄 ${esc(file.name)}</div>
        <div style="font-size:12px;color:var(--text3)">${(file.size/1024).toFixed(1)} KB</div>
      </div>
      <button onclick="startImport()" class="btn btn-primary btn-sm">⬆ Import Students</button>
    </div>`;
}

async function startImport() {
  const file = document.getElementById('csvFile')?.files[0];
  if (!file) return;
  const u = Auth.getUser();
  const fd = new FormData();
  fd.append('csv', file);
  fd.append('admin_id', u.id);
  const resultEl = document.getElementById('importResult');
  resultEl.innerHTML = `<div class="loading-center"><div class="spinner"></div> Importing…</div>`;
  try {
    const r = await fetch('php/bulk_import.php', {method:'POST', body:fd});
    const d = await r.json();
    if (d.success) {
      resultEl.innerHTML = `
        <div style="background:rgba(0,214,143,.08);border:1px solid rgba(0,214,143,.25);border-radius:var(--radius);padding:20px;margin-top:16px">
          <div style="font-size:1.5rem;font-weight:900;color:var(--emerald);margin-bottom:6px">${d.imported} Students Imported!</div>
          <div style="font-size:13px;color:var(--text2)">Total rows: ${d.total} • Imported: ${d.imported} • Skipped: ${d.skipped}</div>
          ${d.errors?.length?`<div style="margin-top:10px;font-size:12px;color:var(--red)">${d.errors.map(e=>esc(e)).join('<br>')}</div>`:''}
          <a href="admin.php?tab=students" class="btn btn-primary btn-sm" style="margin-top:14px;display:inline-block">View Students →</a>
        </div>`;
    } else {
      resultEl.innerHTML = `<div class="alert alert-error">${esc(d.message)}</div>`;
    }
  } catch(e) {
    resultEl.innerHTML = `<div class="alert alert-error">Import failed: ${esc(e.message)}</div>`;
  }
}

</script>
</body>
</html>

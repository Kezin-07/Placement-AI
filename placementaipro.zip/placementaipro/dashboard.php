<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">  <link rel="icon" type="image/svg+xml" href="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAzMiAzMiIgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIj4KICA8ZGVmcz4KICAgIDxsaW5lYXJHcmFkaWVudCBpZD0iZyIgeDE9IjAiIHkxPSIxIiB4Mj0iMSIgeTI9IjAiPgogICAgICA8c3RvcCBvZmZzZXQ9IjAlIiBzdG9wLWNvbG9yPSIjZmY0NzU3Ii8+CiAgICAgIDxzdG9wIG9mZnNldD0iMTAwJSIgc3RvcC1jb2xvcj0iI2Y1OWUwYiIvPgogICAgPC9saW5lYXJHcmFkaWVudD4KICA8L2RlZnM+CiAgPHJlY3Qgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIiByeD0iNyIgZmlsbD0iIzFlMWExMCIvPgogIDxyZWN0IHg9IjYiIHk9IjIxIiB3aWR0aD0iNSIgaGVpZ2h0PSI5IiByeD0iMS41IiBmaWxsPSIjZjU5ZTBiIiBvcGFjaXR5PSIuNSIvPgogIDxyZWN0IHg9IjEzIiB5PSIxNSIgd2lkdGg9IjUiIGhlaWdodD0iMTUiIHJ4PSIxLjUiIGZpbGw9IiNmZjZiMzUiIG9wYWNpdHk9Ii43NSIvPgogIDxyZWN0IHg9IjIwIiB5PSI4IiB3aWR0aD0iNSIgaGVpZ2h0PSIyMiIgcng9IjEuNSIgZmlsbD0idXJsKCNnKSIvPgogIDxwb2x5bGluZSBwb2ludHM9IjIzLDQgMjcsOCAyNyw1IiBmaWxsPSJub25lIiBzdHJva2U9InVybCgjZykiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIi8+CiAgPGxpbmUgeDE9IjE5IiB5MT0iNSIgeDI9IjI3IiB5Mj0iNCIgc3Ryb2tlPSJ1cmwoI2cpIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPgo8L3N2Zz4=">
  <link rel="icon" type="image/x-icon" href="data:image/x-icon;base64,AAABAAEAEBAAAAAAIACgAAAAFgAAAIlQTkcNChoKAAAADUlIRFIAAAAQAAAAEAgGAAAAH/P/YQAAAGdJREFUeJxjZIACLg6R/wwkgG8/3jAyMDAwMJGjGVkPIzmakQETJZoZGBgYWNAFvn5/jVMxN6co9V1AWwOwOZkkA/CFB1EGEAOoH43IgOIwIAZQnpRhuYoc8O3HG0YmGIMczQwMDAwA+P4aS3/n/2IAAAAASUVORK5CYII=">
  <link rel="icon" type="image/png" sizes="32x32" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAoElEQVR4nO2XvQ6AIAyES+Pgz6rv/4Cyimw6kWhDxID0HLixabyPozHUUERjPx+xeqmct0bWboVaxk8grG0uvVjbXEJwqrG2DOL0V8ET6FIN275mfXgalld98AQaABwgOYQxyQHLHVSiHyTQALJmoOTOpeAJNAA4wCc/ohLBE2gAcAD8ozS2LmnJeWvgV8CBRNs4eLIsaJoTie04SHM9PwGQNi1E3UY9bQAAAABJRU5ErkJggg==">
  <link rel="icon" type="image/png" sizes="192x192" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMAAAADACAYAAABS3GwHAAADvklEQVR4nO3dQVLjVgBFUZvqASFTsv8FhmkIMzJIdRc0YCxL8pd8z1kAaPCuvmy61MfDxjzcP76OvgbW8/zydBx9DW8NvRhj53AYG8XVf7HRc8q1Y7jaLzN8prhWCKv/EsNnjrVDWO2HGz5LWiuExX+o4bOmpUO4W/KHGT9rW3pji9Rk+IywxGkw+wQwfkZZYnuzAjB+Rpu7wYsDMH62Ys4WLwrA+NmaSzc5OQDjZ6su2eakAIyfrZu60bMDMH72YspWzwrA+Nmbczf7bQDGz16ds91F/ykE7M3JANz92bvvNvxlAMbPrTi1ZY9ApH0agLs/t+arTTsBSPsQgLs/t+qzbTsBSHsXgLs/t+73jTsBSPsVgLs/FW+37gQgTQCk3R0OHn/o+bl5JwBpAiBNAKQJgLSjD8CUOQFIEwBpAiBNAKQJgDQBkPZj9AXM9c+/f4++hF3584+/Rl/CpjgBSBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYC03b8VYi0j356w1psuvBHiIycAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANKOD/ePr6MvYo61XiV+q7wi/T0nAGkCIE0ApAmANAGQJgDSBECaAEgTAGkCIE0ApAmANAGQJgDSBECaAEgTAGkCIE0ApAmANAGQ9mP0BWyVtyc0OAFIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0o4P94+voy8CRnECkCYA0gRAmgBIEwBpd88vT8fRFwEjPL88HZ0ApAmANAGQJgDS7g6H/z8MjL4QuKafm3cCkCYA0n4F4DGIirdbdwKQ9i4ApwC37veNOwFI+xCAU4Bb9dm2nQCkfRqAU4Bb89WmnQCkfRmAU4BbcWrLJ08AEbB3323YIxBp3wbgFGCvztnuWSeACNibczd79iOQCNiLKVud9BlABGzd1I1O/hAsArbqkm1e9C2QCNiaSzd58degImAr5mxx1t8BRMBoczc4+w9hImCUJba36Hj9bzNcw5I33UX/KYTTgLUtvbHVBus0YElr3VxXv2MLgTnWfqq42iOLEJjiWo/TV39mFwKnXPtz5NAPrWLgcBj75cnmvrURxW3b2jeF/wGOq9fsu4f8UQAAAABJRU5ErkJggg==">
  <link rel="apple-touch-icon" sizes="180x180" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAAC0CAYAAAA9zQYyAAADX0lEQVR4nO3cOXJaQQBFUVA58JDa+1+glVpWZgceygOS/kh/rs5ZAOrg8tRAwfl0AO/ffvw2+gys9/B4fx59hiEHEPDrMCLwq/1BEb9u14p71z8iYi7ZM+5dHljITLFH2HdbP6CYmWqPVjZ7hgiZNbZa600WWsystVVDq54VQmYPa9Z68UKLmb2saWtR0GJmb0sbmx20mLmWJa3NClrMXNvc5iYHLWZGmdPepKDFzGhTG3wxaDFzFFNa3Pyjbxjp2aCtM0fzUpNPBi1mjuq5Nl05SLkYtHXm6J5q9L+gxcytuNSqKwcpfwVtnbk1/zZroUkRNCm/g3bd4Fb92a6FJkXQpNydTq4b3L5fDVtoUgRNiqBJObs/U2KhSRE0KYImRdCkCJoUQZPyZvQBlvjy9fPoIxzWh3efRh9hKAtNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiblJr8ku4cRXy71Zd/tWWhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCl+rPEnP5zYYKFJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KT4kuxPH959Gn0ENmChSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJqU8/u3H7+NPgRsxUKTImhSBE2KoEkRNCl3D4/359GHgC08PN6fLTQpgiZF0KTcnU4/7h6jDwJr/GrYQpMiaFJ+B+3awa36s10LTYqgSfkraNcObs2/zVpoUv4L2kpzKy61enGhRc3RPdWoKwcpTwZtpTmq59p8dqFFzdG81KQrBykvBm2lOYopLU5aaFEz2tQGJ185RM0oc9qbdYcWNdc2t7nZLwpFzbUsaW3RuxyiZm9LG1v8tp2o2cuatjaJ0k/ysoUtRnKTD1asNWtt1dDmIVpr5th6DDf/6NtaM9Uerewan7Xmkj1H72prKu7X7Vr/uYdcD8T9Ooy4fh7ivivwhiO8fvoO2onGYhMioSEAAAAASUVORK5CYII=">
  <title>Dashboard — PlacementAI Pro</title>
  <link rel="stylesheet" href="css/style.css?v=5">
  <style>
    /* Fixed stat cards — no stretch */
    .stat-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 24px; }
    @media(max-width:900px) { .stat-grid { grid-template-columns: repeat(2,1fr); } }
    @media(max-width:480px) { .stat-grid { grid-template-columns: 1fr; } }

    .stat-card-v2 {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: var(--radius);
      padding: 20px;
      position: relative;
      overflow: hidden;
      transition: border-color .2s, transform .2s;
    }
    .stat-card-v2:hover { border-color: var(--border2); transform: translateY(-2px); }
    .stat-card-v2::after {
      content: '';
      position: absolute; top: 0; left: 0; right: 0; height: 3px;
      border-radius: var(--radius) var(--radius) 0 0;
    }
    .stat-card-v2.c-purple::after { background: linear-gradient(90deg,#6c63ff,#a78bfa); }
    .stat-card-v2.c-green::after  { background: linear-gradient(90deg,#10b981,#06b6d4); }
    .stat-card-v2.c-amber::after  { background: linear-gradient(90deg,#f59e0b,#f43f5e); }
    .stat-card-v2.c-rose::after   { background: linear-gradient(90deg,#f43f5e,#f97316); }

    .stat-card-v2 .s-icon {
      width: 38px; height: 38px; border-radius: 9px;
      display: flex; align-items: center; justify-content: center;
      margin-bottom: 14px; flex-shrink: 0;
    }
    .s-icon.p { background: rgba(108,99,255,.15); color: #a78bfa; }
    .s-icon.g { background: rgba(16,185,129,.15);  color: #10b981; }
    .s-icon.a { background: rgba(245,158,11,.15);  color: #f59e0b; }
    .s-icon.r { background: rgba(244,63,94,.15);   color: #f43f5e; }

    .s-val { font-family: var(--font-display); font-size: 2.2rem; font-weight: 900; line-height: 1; color: var(--text); }
    .s-lbl { font-size: 12px; color: var(--text3); font-weight: 500; margin-top: 5px; }
    .s-sub { font-size: 11.5px; font-weight: 600; margin-top: 6px; }
    .s-sub.up   { color: #10b981; }
    .s-sub.warn { color: #f59e0b; }
    .s-sub.down { color: #ef4444; }

    /* Streak section */
    .streak-wrap { text-align: center; padding: 12px 0 18px; }
    .streak-num { font-family: var(--font-display); font-size: 3.5rem; font-weight: 900; color: #f59e0b; line-height:1; }
    .streak-label { font-size: 13px; color: var(--text3); margin-top: 4px; }
    .xp-row { display: flex; justify-content: center; gap: 40px; margin-top: 18px; }
    .xp-item { text-align: center; }
    .xp-item .val { font-family: var(--font-display); font-size: 1.5rem; font-weight: 800; color: var(--primary); }
    .xp-item .lbl { font-size: 11px; color: var(--text3); }

    /* Quick action cards */
    .qa-grid { display: grid; grid-template-columns: repeat(4,1fr); gap: 14px; margin-bottom: 24px; }
    @media(max-width:900px) { .qa-grid { grid-template-columns: repeat(2,1fr); } }
    .qa-card {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: var(--radius);
      padding: 20px 16px;
      text-decoration: none;
      display: block;
      transition: border-color .18s, transform .18s, box-shadow .18s;
      cursor: pointer;
    }
    .qa-card:hover { border-color: rgba(108,99,255,.4); transform: translateY(-3px); box-shadow: 0 8px 28px rgba(0,0,0,.3); }
    .qa-icon { font-size: 1.75rem; margin-bottom: 10px; display: block; }
    .qa-title { font-family: var(--font-display); font-size: 13.5px; font-weight: 700; color: var(--text); margin-bottom: 3px; }
    .qa-desc  { font-size: 11.5px; color: var(--text3); }
  </style>
</head>
<body>
<script src="js/app.js?v=5"></script>
<script>
const user = Auth.requireAuth('student');
if (user) { buildShell('dashboard'); setTimeout(()=>initDashboard(), 0); }

async function initDashboard() {
  document.getElementById('topbarTitle').textContent = 'Dashboard';
  document.getElementById('topbarActions').innerHTML = `
    <a href="interview.php" class="btn btn-primary btn-sm" style="display:flex;align-items:center;gap:6px">
      <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
        <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/>
        <path d="M19 10v2a7 7 0 0 1-14 0v-2"/>
      </svg>
      Start Interview
    </a>`;

  const hour = new Date().getHours();
  const greet = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';
  const name = user.name.split(' ')[0];

  // ── Render shell IMMEDIATELY with placeholders ─────────────
  const page = document.getElementById('mainPage');
  page.innerHTML = `
    <div class="page-header" style="margin-bottom:20px">
      <h1 style="font-size:1.8rem">${greet}, ${esc(name)} &#128075;</h1>
      <p style="color:var(--text3);font-size:13.5px">Here's your placement readiness overview</p>
    </div>

    <!-- STAT CARDS with skeleton placeholders -->
    <div class="stat-grid" id="statGrid">
      ${['CGPA','Resume Score','Aptitude Score','Interview Score'].map((lbl,i)=>`
      <div class="stat-card-v2 ${['c-purple','c-green','c-amber','c-rose'][i]}">
        <div class="s-icon ${['p','g','a','r'][i]}">
          <div style="width:17px;height:17px;border-radius:3px;background:rgba(255,255,255,.1);animation:skelPulse 1.5s ease infinite"></div>
        </div>
        <div class="s-val" style="background:rgba(255,255,255,.07);border-radius:6px;width:60px;height:32px;animation:skelPulse 1.5s ease ${i*.1}s infinite">&nbsp;</div>
        <div class="s-lbl">${lbl}</div>
        <div style="width:80px;height:12px;background:rgba(255,255,255,.05);border-radius:4px;margin-top:6px;animation:skelPulse 1.5s ease ${i*.15}s infinite"></div>
      </div>`).join('')}
    </div>

    <!-- READINESS + STREAK -->
    <div class="grid-2 mb-6">
      <div class="card" id="readinessCard">
        <div class="card-header">
          <div><div class="card-title">Placement Readiness</div><div class="card-subtitle">Your overall preparation score</div></div>
          <a href="predict.php" class="btn btn-ghost btn-sm">Full Analysis &rarr;</a>
        </div>
        <div id="progressBars" style="display:flex;flex-direction:column;gap:10px">
          ${[['Resume & ATS',''],['Aptitude','green'],['Interview','amber'],['CGPA','rose']].map(([l,c])=>progressBar(l,0,100,c)).join('')}
        </div>
      </div>
      <div class="card" id="streakCard">
        <div class="loading-center" style="padding:32px"><div class="spinner"></div></div>
      </div>
    </div>

    <!-- QUICK ACTIONS - static, loads instantly -->
    <h3 style="margin-bottom:14px;font-size:1rem">Quick Actions</h3>
    <div class="qa-grid">
      <a href="interview.php" class="qa-card">
        <div style="width:44px;height:44px;border-radius:12px;background:rgba(124,106,255,.15);display:flex;align-items:center;justify-content:center;margin-bottom:12px">
          <svg width="22" height="22" fill="none" stroke="#a78bfa" stroke-width="2" viewBox="0 0 24 24"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg>
        </div>
        <div class="qa-title">AI Interview</div><div class="qa-desc">Voice-powered mock rounds</div>
      </a>
      <a href="resume.php" class="qa-card">
        <div style="width:44px;height:44px;border-radius:12px;background:rgba(0,214,143,.1);display:flex;align-items:center;justify-content:center;margin-bottom:12px">
          <svg width="22" height="22" fill="none" stroke="#00d68f" stroke-width="2" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>
        </div>
        <div class="qa-title">Analyze Resume</div><div class="qa-desc">Get ATS score instantly</div>
      </a>
      <a href="aptitude.php" class="qa-card">
        <div style="width:44px;height:44px;border-radius:12px;background:rgba(245,158,11,.1);display:flex;align-items:center;justify-content:center;margin-bottom:12px">
          <svg width="22" height="22" fill="none" stroke="#f59e0b" stroke-width="2" viewBox="0 0 24 24"><path d="M9.5 2A2.5 2.5 0 0 1 12 4.5v15a2.5 2.5 0 0 1-4.96-.46 2.5 2.5 0 0 1-2.96-3.08 3 3 0 0 1-.34-5.58 2.5 2.5 0 0 1 1.32-4.24 2.5 2.5 0 0 1 1.98-3A2.5 2.5 0 0 1 9.5 2z"/><path d="M14.5 2A2.5 2.5 0 0 0 12 4.5v15a2.5 2.5 0 0 0 4.96-.46 2.5 2.5 0 0 0 2.96-3.08 3 3 0 0 0 .34-5.58 2.5 2.5 0 0 0-1.32-4.24 2.5 2.5 0 0 0-1.98-3A2.5 2.5 0 0 0 14.5 2z"/></svg>
        </div>
        <div class="qa-title">Aptitude Test</div><div class="qa-desc">AI-powered test & scoring</div>
      </a>
      <a href="jobs.php" class="qa-card">
        <div style="width:44px;height:44px;border-radius:12px;background:rgba(0,200,255,.1);display:flex;align-items:center;justify-content:center;margin-bottom:12px">
          <svg width="22" height="22" fill="none" stroke="#00c8ff" stroke-width="2" viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"/><line x1="12" y1="12" x2="12" y2="16"/><line x1="10" y1="14" x2="14" y2="14"/></svg>
        </div>
        <div class="qa-title">Browse Jobs</div><div class="qa-desc">Open listings</div>
      </a>
    </div>

    <!-- JOBS table placeholder -->
    <div class="card" id="jobsCard">
      <div class="card-header"><div class="card-title">Open Positions</div><a href="jobs.php" class="btn btn-ghost btn-sm">View All &rarr;</a></div>
      <div class="loading-center" style="padding:20px"><div class="spinner"></div></div>
    </div>`;

  // Add skeleton animation
  if (!document.getElementById('skelStyle')) {
    const s = document.createElement('style');
    s.id = 'skelStyle';
    s.textContent = '@keyframes skelPulse{0%,100%{opacity:.5}50%{opacity:1}}';
    document.head.appendChild(s);
  }

  // ── Load data in parallel, update UI as each resolves ──────
  let profile = null;
  let streak = {current_streak:0,total_xp:0,longest_streak:0,level:1,level_progress:0,badges:[],daily_challenges:[],can_checkin:true};

  // Profile + streak load together
  Promise.allSettled([
    API.get('student_profile.php?user_id=' + user.id),
    API.get('streak.php?user_id=' + user.id + '&action=get')
  ]).then(([p, s]) => {
    try {
      if (p.status === 'fulfilled' && p.value && p.value.profile) {
        profile = p.value.profile;
      }
      if (s.status === 'fulfilled' && s.value) {
        var sv = s.value;
        // Merge carefully - avoid prototype pollution
        streak.current_streak  = sv.current_streak  || sv.streak && sv.streak.current_streak  || 0;
        streak.longest_streak  = sv.longest_streak  || sv.streak && sv.streak.longest_streak  || 0;
        streak.total_xp        = sv.total_xp        || sv.streak && sv.streak.total_xp        || 0;
        streak.level           = sv.level           || 1;
        streak.level_progress  = sv.level_progress  || 0;
        streak.badges          = sv.badges          || [];
        streak.daily_challenges= sv.daily_challenges|| [];
        streak.can_checkin     = sv.can_checkin !== false;
        streak.last_checkin    = sv.last_checkin    || null;
      }
    } catch(mergeErr) {
      console.error('Streak merge error:', mergeErr);
    }
    try { updateStatCards(profile); }    catch(e){ console.error('updateStatCards error:', e); }
    try { updateStreakCard(streak); }    catch(e){ console.error('updateStreakCard error:', e); }
    try { updateProgressBars(profile); } catch(e){ console.error('updateProgressBars error:', e); }
    try { updateProfileBanner(profile); }catch(e){ console.error('updateProfileBanner error:', e); }
  }).catch(function(err) {
    console.error('Dashboard data load failed:', err);
    // Still try to render streak with defaults so spinner goes away
    try { updateStreakCard(streak); } catch(e) {}
  });

  // Render streak card immediately with defaults — never stays on spinner
  setTimeout(function() {
    var card = document.getElementById('streakCard');
    if (card && card.innerHTML.indexOf('spinner') !== -1) {
      try { updateStreakCard(streak); } catch(e) { console.error('Streak render error:', e); }
    }
  }, 100);

  // Jobs load independently (may be slower)
  API.get('jobs.php?action=list&limit=5').then(j => {
    updateJobsCard(j?.jobs || []);
  }).catch(() => updateJobsCard([]));

  // Dummy to prevent rest of function from running the old way
  const jobs = [];


  // ── Update functions called when data arrives ──────────────
  function updateProfileBanner(profile) {
    const banner = document.getElementById('profileBanner');
    if (banner) banner.style.display = profile ? 'none' : 'flex';
    else if (!profile) {
      const ph = document.querySelector('.page-header');
      if (ph) {
        const b = document.createElement('div');
        b.id = 'profileBanner';
        b.style.cssText = 'background:rgba(108,99,255,.12);border:1px solid rgba(108,99,255,.3);border-radius:var(--radius);padding:14px 18px;margin-bottom:20px;display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap';
        b.innerHTML = '<div style="display:flex;align-items:center;gap:10px"><span style="font-size:1.3rem">&#x1F4CB;</span><div><div style="font-weight:700;font-size:14px;color:var(--text)">Your profile is incomplete</div><div style="font-size:12px;color:var(--text3)">Add your CGPA, skills and scores to unlock dashboard stats</div></div></div><a href=\'profile.php\' class=\'btn btn-primary btn-sm\'>Complete Profile &#x2192;</a>';
        ph.after(b);
      }
    }
  }

  function updateStatCards(profile) {
    const cgpa   = profile?.cgpa ? parseFloat(profile.cgpa).toFixed(2) : null;
    const resume = profile?.resume_score   ? Math.round(profile.resume_score)   : null;
    const apt    = profile?.aptitude_score ? Math.round(profile.aptitude_score) : null;
    const intv   = profile?.interview_score? Math.round(profile.interview_score): null;
    const vals   = [cgpa, resume, apt, intv];
    const subs   = [
      cgpa  ? (cgpa>=8?'<span class="s-sub up">Excellent</span>'  : cgpa>=6.5?'<span class="s-sub warn">Good standing</span>' :'<span class="s-sub down">Needs improvement</span>') : '<span class="s-sub down">Not set</span>',
      resume? (resume>=75?'<span class="s-sub up">ATS Ready</span>':'<span class="s-sub warn">Needs work</span>') : '<span class="s-sub down">Not analyzed yet</span>',
      apt   ? (apt>=80?'<span class="s-sub up">Top performer</span>':'<span class="s-sub warn">Keep practicing</span>') : '<span class="s-sub down">Take test now</span>',
      intv  ? (intv>=75?'<span class="s-sub up">Interview-ready</span>':'<span class="s-sub warn">More practice</span>') : '<span class="s-sub down">Try AI interview</span>',
    ];
    const icons = [
      '<svg width="17" height="17" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>',
      '<svg width="17" height="17" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>',
      '<svg width="17" height="17" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9.5 2A2.5 2.5 0 0 1 12 4.5v15a2.5 2.5 0 0 1-4.96-.46 2.5 2.5 0 0 1-2.96-3.08 3 3 0 0 1-.34-5.58 2.5 2.5 0 0 1 1.32-4.24 2.5 2.5 0 0 1 1.98-3A2.5 2.5 0 0 1 9.5 2z"/><path d="M14.5 2A2.5 2.5 0 0 0 12 4.5v15a2.5 2.5 0 0 0 4.96-.46 2.5 2.5 0 0 0 2.96-3.08 3 3 0 0 0 .34-5.58 2.5 2.5 0 0 0-1.32-4.24 2.5 2.5 0 0 0-1.98-3A2.5 2.5 0 0 0 14.5 2z"/></svg>',
      '<svg width="17" height="17" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/></svg>',
    ];
    const classes = ['c-purple p','c-green g','c-amber a','c-rose r'];
    const labels  = ['CGPA','Resume Score','Aptitude Score','Interview Score'];
    document.getElementById('statGrid').innerHTML = vals.map((v,i)=>`
      <div class="stat-card-v2 ${classes[i].split(' ')[0]}" style="animation:fadeUp .5s ease ${i*.08}s both">
        <div class="s-icon ${classes[i].split(' ')[1]}">${icons[i]}</div>
        <div class="s-val">${v ?? '—'}</div>
        <div class="s-lbl">${labels[i]}</div>
        ${subs[i]}
      </div>`).join('');
  }

  function updateProgressBars(profile) {
    const cgpa   = profile?.cgpa   ? Math.round((parseFloat(profile.cgpa)/10)*100) : 0;
    const resume = profile?.resume_score   ? Math.round(profile.resume_score)   : 0;
    const apt    = profile?.aptitude_score ? Math.round(profile.aptitude_score) : 0;
    const intv   = profile?.interview_score? Math.round(profile.interview_score): 0;
    const bars   = document.querySelectorAll('#progressBars .card, #progressBars > div');
    // Regenerate with real data
    document.getElementById('progressBars').innerHTML = [
      ['Resume & ATS', resume, ''],
      ['Aptitude',     apt,    'green'],
      ['Interview',    intv,   'amber'],
      ['CGPA',         cgpa,   'rose'],
    ].map(([lbl,val,col])=>progressBar(lbl,val,100,col)).join('');
  }

  function updateStreakCard(streak) {
    const card = document.getElementById('streakCard');
    if (!card) return;

    const level       = streak.level || 1;
    const xpProg      = streak.level_progress || 0;
    const xpPct       = Math.min(100, Math.round((xpProg / 500) * 100));
    const curStreak   = streak.current_streak || 0;
    const totalXp     = streak.total_xp || 0;
    const bestStreak  = streak.longest_streak || 0;
    const canCheckin  = streak.can_checkin !== false;

    // Safely parse badges and challenges — may arrive as JSON strings from DB
    function safeParse(val) {
      if (Array.isArray(val)) return val;
      if (typeof val === 'string') { try { var p = JSON.parse(val); return Array.isArray(p) ? p : []; } catch(e) { return []; } }
      return [];
    }
    const challenges  = safeParse(streak.daily_challenges);
    const badges      = safeParse(streak.badges);

    // Build checkin button or already-done message
    const checkinHtml = canCheckin
      ? '<button id="checkinBtn" onclick="doCheckin(this)" class="btn btn-primary w-full mb-3" style="justify-content:center">🔥 Check In Today (+50 XP)</button>'
      : '<div class="alert alert-success mb-3" style="text-align:center;font-size:13px">✅ Checked in today! Come back tomorrow</div>';

    // Build task list
    const taskHtml = challenges.map(function(c, i) {
      var diffColor = c.difficulty === 'Easy' ? '#00d68f' : c.difficulty === 'Medium' ? '#f59e0b' : '#ff4757';
      var diffBg    = c.difficulty === 'Easy' ? 'rgba(0,214,143,.1)' : c.difficulty === 'Medium' ? 'rgba(245,158,11,.1)' : 'rgba(255,71,87,.1)';
      var taskLabel = esc(c.task);
      var safeTask  = taskLabel.replace(/"/g, '&quot;');
      var html = '<div id="task_' + i + '" style="display:flex;align-items:flex-start;gap:10px;padding:10px 0;border-bottom:1px solid var(--border)">';
      html += '<button id="taskBtn_' + i + '" data-idx="' + i + '" data-xp="' + c.xp + '" data-task="' + safeTask + '" onclick="completeTask(this.dataset.idx,this.dataset.task,this.dataset.xp)" style="width:22px;height:22px;border-radius:6px;border:2px solid rgba(255,255,255,.2);background:transparent;cursor:pointer;flex-shrink:0;display:flex;align-items:center;justify-content:center;transition:all .2s;margin-top:1px"></button>';
      html += '<div style="flex:1">';
      html += '<div style="font-size:12.5px;color:var(--text2);line-height:1.5">' + (c.icon || '📌') + ' ' + taskLabel + '</div>';
      html += '<div style="display:flex;gap:6px;margin-top:4px;align-items:center">';
      html += '<span style="font-size:10px;padding:2px 8px;border-radius:99px;background:' + diffBg + ';color:' + diffColor + ';font-weight:600">' + c.difficulty + '</span>';
      html += '<span style="font-size:11px;color:var(--accent2);font-weight:600">+' + c.xp + ' XP</span>';
      html += '</div></div></div>';
      return html;
    }).join('');

    // Build badges section
    const badgesHtml = badges.length
      ? '<div style="border-top:1px solid var(--border);padding-top:12px;margin-top:8px">'
        + '<div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--text3);margin-bottom:8px">🏅 Badges Earned</div>'
        + '<div style="display:flex;flex-wrap:wrap;gap:6px">'
        + badges.map(b => '<div title="' + esc(b.desc) + '" style="display:flex;align-items:center;gap:4px;padding:4px 9px;background:rgba(108,99,255,.1);border:1px solid rgba(108,99,255,.2);border-radius:99px;font-size:11.5px;color:var(--text2)">' + b.icon + ' <span>' + esc(b.name) + '</span></div>').join('')
        + '</div></div>'
      : '';

    card.innerHTML =
      '<div class="card-header">'
      + '<div class="card-title">🔥 Daily Streak</div>'
      + '<span id="levelBadge" class="badge badge-purple" style="font-size:11px">Lv. ' + level + '</span>'
      + '</div>'
      + '<div class="streak-wrap">'
      + '<div style="position:relative;display:inline-block">'
      + '<div style="font-size:2.8rem;line-height:1;margin-bottom:4px">🔥</div>'
      + (curStreak >= 7 ? '<div style="position:absolute;top:-4px;right:-10px;font-size:1rem">⚡</div>' : '')
      + '</div>'
      + '<div class="streak-num">' + curStreak + '</div>'
      + '<div class="streak-label">day streak</div>'
      + '<div style="margin:10px 0 6px;background:var(--bg3);border-radius:99px;height:6px;overflow:hidden">'
      + '<div style="height:100%;width:' + xpPct + '%;background:linear-gradient(90deg,#6c63ff,#a78bfa);border-radius:99px;transition:width .5s"></div>'
      + '</div>'
      + '<div style="font-size:11px;color:var(--text3);margin-bottom:10px">' + xpProg + ' / 500 XP to Level ' + (level + 1) + '</div>'
      + '<div class="xp-row">'
      + '<div class="xp-item"><div class="val" id="totalXpDisplay">' + fmtNum(totalXp) + '</div><div class="lbl">Total XP</div></div>'
      + '<div class="xp-item"><div class="val" style="color:var(--accent2)">' + bestStreak + '</div><div class="lbl">Best Streak</div></div>'
      + '</div></div>'
      + checkinHtml
      + '<div style="border-top:1px solid var(--border);padding-top:14px">'
      + '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">'
      + '<div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--text3)">📋 Today Tasks</div>'
      + '<div style="font-size:11px;color:var(--text3)" id="taskProgress">0/' + challenges.length + ' done</div>'
      + '</div>'
      + '<div id="taskList">' + taskHtml + '</div>'
      + '</div>'
      + badgesHtml;
  }

  function updateJobsCard(jobs) {
    const card = document.getElementById('jobsCard');
    if (!card) return;
    card.innerHTML = `
      <div class="card-header"><div class="card-title">Open Positions</div><a href="jobs.php" class="btn btn-ghost btn-sm">View All &rarr;</a></div>
      ${jobs.length?`
      <div class="table-wrap">
        <table>
          <thead><tr><th>Company</th><th>Role</th><th>Location</th><th>Package</th><th>Min CGPA</th><th></th></tr></thead>
          <tbody>
            ${jobs.map(j=>`<tr>
              <td class="td-main">${esc(j.company_name||'—')}</td>
              <td>${esc(j.title)}</td>
              <td style="color:var(--text3)">${esc(j.location||'—')}</td>
              <td style="color:var(--emerald);font-weight:700">${esc(j.salary_range||'—')}</td>
              <td>${esc(j.min_cgpa||'0')}</td>
              <td><a href="jobs.php" class="btn btn-secondary btn-sm">Apply</a></td>
            </tr>`).join('')}
          </tbody>
        </table>
      </div>`:`<div class="empty-state"><h4>No jobs yet</h4><p>Check back soon</p></div>`}`;
  }

} // end initDashboard

async function doCheckin(btn) {
  loading(btn, true, 'Checking in…');
  try {
    const res = await API.post('streak.php', { user_id: user.id, action: 'checkin' });
    const xp = res.xp_earned || 50;
    btn.innerHTML = '✅ Checked in! +' + xp + ' XP';
    btn.style.background = 'linear-gradient(135deg,#10b981,#059669)';
    btn.disabled = true;

    const rect = btn.getBoundingClientRect();
    floatXP(xp, rect.left + rect.width/2, rect.top);

    // Update XP display
    const xpEl = document.getElementById('totalXpDisplay');
    if (xpEl) xpEl.textContent = fmtNum(res.total_xp || 0);

    // Show bonus toast
    if (res.bonus) showToast(res.bonus, '#6c63ff', 4000);

    // New badges
    if (res.new_badges?.length) {
      const b = res.new_badges[0];
      setTimeout(()=> showCongrats('Badge Unlocked!', b.icon + ' <strong>' + b.name + '</strong><br>' + b.desc, b.icon), 600);
    } else {
      showCongrats(
        'Checked In! 🔥',
        'You earned <strong style="color:#f59e0b">+' + xp + ' XP</strong> for checking in today!<br>Keep your streak alive — come back tomorrow!',
        '🔥'
      );
    }
  } catch(e) {
    loading(btn, false);
  }
}
</script>
</body>
</html>

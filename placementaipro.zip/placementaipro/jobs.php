<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">  <link rel="icon" type="image/svg+xml" href="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAzMiAzMiIgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIj4KICA8ZGVmcz4KICAgIDxsaW5lYXJHcmFkaWVudCBpZD0iZyIgeDE9IjAiIHkxPSIxIiB4Mj0iMSIgeTI9IjAiPgogICAgICA8c3RvcCBvZmZzZXQ9IjAlIiBzdG9wLWNvbG9yPSIjZmY0NzU3Ii8+CiAgICAgIDxzdG9wIG9mZnNldD0iMTAwJSIgc3RvcC1jb2xvcj0iI2Y1OWUwYiIvPgogICAgPC9saW5lYXJHcmFkaWVudD4KICA8L2RlZnM+CiAgPHJlY3Qgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIiByeD0iNyIgZmlsbD0iIzFlMWExMCIvPgogIDxyZWN0IHg9IjYiIHk9IjIxIiB3aWR0aD0iNSIgaGVpZ2h0PSI5IiByeD0iMS41IiBmaWxsPSIjZjU5ZTBiIiBvcGFjaXR5PSIuNSIvPgogIDxyZWN0IHg9IjEzIiB5PSIxNSIgd2lkdGg9IjUiIGhlaWdodD0iMTUiIHJ4PSIxLjUiIGZpbGw9IiNmZjZiMzUiIG9wYWNpdHk9Ii43NSIvPgogIDxyZWN0IHg9IjIwIiB5PSI4IiB3aWR0aD0iNSIgaGVpZ2h0PSIyMiIgcng9IjEuNSIgZmlsbD0idXJsKCNnKSIvPgogIDxwb2x5bGluZSBwb2ludHM9IjIzLDQgMjcsOCAyNyw1IiBmaWxsPSJub25lIiBzdHJva2U9InVybCgjZykiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIi8+CiAgPGxpbmUgeDE9IjE5IiB5MT0iNSIgeDI9IjI3IiB5Mj0iNCIgc3Ryb2tlPSJ1cmwoI2cpIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPgo8L3N2Zz4=">
  <link rel="icon" type="image/x-icon" href="data:image/x-icon;base64,AAABAAEAEBAAAAAAIACgAAAAFgAAAIlQTkcNChoKAAAADUlIRFIAAAAQAAAAEAgGAAAAH/P/YQAAAGdJREFUeJxjZIACLg6R/wwkgG8/3jAyMDAwMJGjGVkPIzmakQETJZoZGBgYWNAFvn5/jVMxN6co9V1AWwOwOZkkA/CFB1EGEAOoH43IgOIwIAZQnpRhuYoc8O3HG0YmGIMczQwMDAwA+P4aS3/n/2IAAAAASUVORK5CYII=">
  <link rel="icon" type="image/png" sizes="32x32" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAoElEQVR4nO2XvQ6AIAyES+Pgz6rv/4Cyimw6kWhDxID0HLixabyPozHUUERjPx+xeqmct0bWboVaxk8grG0uvVjbXEJwqrG2DOL0V8ET6FIN275mfXgalld98AQaABwgOYQxyQHLHVSiHyTQALJmoOTOpeAJNAA4wCc/ohLBE2gAcAD8ozS2LmnJeWvgV8CBRNs4eLIsaJoTie04SHM9PwGQNi1E3UY9bQAAAABJRU5ErkJggg==">
  <link rel="icon" type="image/png" sizes="192x192" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMAAAADACAYAAABS3GwHAAADvklEQVR4nO3dQVLjVgBFUZvqASFTsv8FhmkIMzJIdRc0YCxL8pd8z1kAaPCuvmy61MfDxjzcP76OvgbW8/zydBx9DW8NvRhj53AYG8XVf7HRc8q1Y7jaLzN8prhWCKv/EsNnjrVDWO2HGz5LWiuExX+o4bOmpUO4W/KHGT9rW3pji9Rk+IywxGkw+wQwfkZZYnuzAjB+Rpu7wYsDMH62Ys4WLwrA+NmaSzc5OQDjZ6su2eakAIyfrZu60bMDMH72YspWzwrA+Nmbczf7bQDGz16ds91F/ykE7M3JANz92bvvNvxlAMbPrTi1ZY9ApH0agLs/t+arTTsBSPsQgLs/t+qzbTsBSHsXgLs/t+73jTsBSPsVgLs/FW+37gQgTQCk3R0OHn/o+bl5JwBpAiBNAKQJgLSjD8CUOQFIEwBpAiBNAKQJgDQBkPZj9AXM9c+/f4++hF3584+/Rl/CpjgBSBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYC03b8VYi0j356w1psuvBHiIycAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANKOD/ePr6MvYo61XiV+q7wi/T0nAGkCIE0ApAmANAGQJgDSBECaAEgTAGkCIE0ApAmANAGQJgDSBECaAEgTAGkCIE0ApAmANAGQ9mP0BWyVtyc0OAFIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0o4P94+voy8CRnECkCYA0gRAmgBIEwBpd88vT8fRFwEjPL88HZ0ApAmANAGQJgDS7g6H/z8MjL4QuKafm3cCkCYA0n4F4DGIirdbdwKQ9i4ApwC37veNOwFI+xCAU4Bb9dm2nQCkfRqAU4Bb89WmnQCkfRmAU4BbcWrLJ08AEbB3323YIxBp3wbgFGCvztnuWSeACNibczd79iOQCNiLKVud9BlABGzd1I1O/hAsArbqkm1e9C2QCNiaSzd58degImAr5mxx1t8BRMBoczc4+w9hImCUJba36Hj9bzNcw5I33UX/KYTTgLUtvbHVBus0YElr3VxXv2MLgTnWfqq42iOLEJjiWo/TV39mFwKnXPtz5NAPrWLgcBj75cnmvrURxW3b2jeF/wGOq9fsu4f8UQAAAABJRU5ErkJggg==">
  <link rel="apple-touch-icon" sizes="180x180" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAAC0CAYAAAA9zQYyAAADX0lEQVR4nO3cOXJaQQBFUVA58JDa+1+glVpWZgceygOS/kh/rs5ZAOrg8tRAwfl0AO/ffvw2+gys9/B4fx59hiEHEPDrMCLwq/1BEb9u14p71z8iYi7ZM+5dHljITLFH2HdbP6CYmWqPVjZ7hgiZNbZa600WWsystVVDq54VQmYPa9Z68UKLmb2saWtR0GJmb0sbmx20mLmWJa3NClrMXNvc5iYHLWZGmdPepKDFzGhTG3wxaDFzFFNa3Pyjbxjp2aCtM0fzUpNPBi1mjuq5Nl05SLkYtHXm6J5q9L+gxcytuNSqKwcpfwVtnbk1/zZroUkRNCm/g3bd4Fb92a6FJkXQpNydTq4b3L5fDVtoUgRNiqBJObs/U2KhSRE0KYImRdCkCJoUQZPyZvQBlvjy9fPoIxzWh3efRh9hKAtNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiblJr8ku4cRXy71Zd/tWWhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCl+rPEnP5zYYKFJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KT4kuxPH959Gn0ENmChSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJqU8/u3H7+NPgRsxUKTImhSBE2KoEkRNCl3D4/359GHgC08PN6fLTQpgiZF0KTcnU4/7h6jDwJr/GrYQpMiaFJ+B+3awa36s10LTYqgSfkraNcObs2/zVpoUv4L2kpzKy61enGhRc3RPdWoKwcpTwZtpTmq59p8dqFFzdG81KQrBykvBm2lOYopLU5aaFEz2tQGJ185RM0oc9qbdYcWNdc2t7nZLwpFzbUsaW3RuxyiZm9LG1v8tp2o2cuatjaJ0k/ysoUtRnKTD1asNWtt1dDmIVpr5th6DDf/6NtaM9Uerewan7Xmkj1H72prKu7X7Vr/uYdcD8T9Ooy4fh7ivivwhiO8fvoO2onGYhMioSEAAAAASUVORK5CYII=">
  <title>Job Portal — PlacementAI Pro</title>
  <link rel="stylesheet" href="css/style.css?v=5">
  <style>
    #jobsGrid { display:grid; grid-template-columns:repeat(3,1fr); gap:16px; align-items:stretch; }
    #jobsGrid > div { display:flex; flex-direction:column; }
    #jobsGrid > div > div:last-child { margin-top:auto; }
    @media(max-width:1100px) { #jobsGrid { grid-template-columns:repeat(2,1fr); } }
    @media(max-width:680px)  { #jobsGrid { grid-template-columns:1fr; } }
  
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');

  /* Overall page font */
  body { font-family: 'Plus Jakarta Sans', var(--font-body) !important; }

  /* Page header enhancement */
  .page-header h1 {
    font-family: 'Plus Jakarta Sans', sans-serif !important;
    font-weight: 800 !important;
    letter-spacing: -.02em !important;
  }

  /* Tab pills */
  #tab_browse, #tab_recommended, #tab_myapps {
    font-family: 'Plus Jakarta Sans', sans-serif !important;
    font-weight: 600 !important;
    font-size: 13px !important;
    transition: all .18s !important;
  }

  /* Filter card */
  #filterSection {
    background: var(--surface) !important;
    border: 1px solid var(--border) !important;
    border-radius: 16px !important;
    padding: 18px 20px !important;
  }
  #filterSection .form-label {
    font-size: 11px !important;
    font-weight: 600 !important;
    text-transform: uppercase !important;
    letter-spacing: .06em !important;
    color: var(--text3) !important;
  }
  #filterSection .form-input,
  #filterSection .form-select {
    background: var(--bg2) !important;
    border-radius: 10px !important;
    border: 1px solid var(--border2) !important;
    font-size: 13.5px !important;
    transition: border-color .18s, box-shadow .18s !important;
  }
  #filterSection .form-input:focus,
  #filterSection .form-select:focus {
    border-color: var(--primary) !important;
    box-shadow: 0 0 0 3px rgba(124,106,255,.12) !important;
  }

  /* Job cards: elevated with top accent */
  #jobsGrid > div > .card,
  #jobsGrid .card {
    border-radius: 16px !important;
    border: 1px solid var(--border) !important;
    background: var(--surface) !important;
    transition: border-color .2s, transform .2s, box-shadow .2s !important;
    position: relative !important;
    overflow: hidden !important;
  }
  #jobsGrid > div > .card::before,
  #jobsGrid .card::before {
    content: '';
    position: absolute; top: 0; left: 0; right: 0; height: 2px;
    background: linear-gradient(90deg, #7c6aff, #a78bfa, #00e5b4);
    opacity: 0;
    transition: opacity .2s;
  }
  #jobsGrid > div > .card:hover,
  #jobsGrid .card:hover {
    border-color: rgba(124,106,255,.35) !important;
    transform: translateY(-4px) !important;
    box-shadow: 0 16px 40px rgba(0,0,0,.35) !important;
  }
  #jobsGrid > div > .card:hover::before,
  #jobsGrid .card:hover::before { opacity: 1; }

  /* Company avatar: cleaner */
  #jobsGrid .card [style*="border-radius:50%"][style*="background"] {
    border-radius: 12px !important;
    box-shadow: 0 2px 8px rgba(0,0,0,.2) !important;
  }

  /* Job title */
  #jobsGrid .card [style*="font-weight:700"] {
    font-family: 'Plus Jakarta Sans', sans-serif !important;
    font-size: 15px !important;
    letter-spacing: -.01em !important;
  }

  /* Apply button: purple gradient */
  #jobsGrid .btn-primary {
    background: linear-gradient(135deg, #6c52ff, #7c6aff) !important;
    border: none !important;
    border-radius: 10px !important;
    font-weight: 700 !important;
    font-size: 13px !important;
    letter-spacing: .01em !important;
    box-shadow: 0 3px 12px rgba(124,106,255,.3) !important;
    transition: all .18s !important;
  }
  #jobsGrid .btn-primary:hover {
    box-shadow: 0 5px 20px rgba(124,106,255,.5) !important;
    transform: translateY(-1px) !important;
  }

  /* View Details button */
  #jobsGrid .btn-ghost {
    border-radius: 10px !important;
    font-weight: 600 !important;
    font-size: 13px !important;
  }

  /* Salary highlight */
  #jobsGrid [style*="color:var(--emerald)"] {
    font-weight: 800 !important;
    font-size: 14px !important;
  }

  /* Skills/tags chips */
  #jobsGrid .badge {
    border-radius: 6px !important;
    font-size: 11.5px !important;
    font-weight: 600 !important;
  }

  /* Modal polish */
  .modal {
    border-radius: 20px !important;
    border: 1px solid var(--border2) !important;
    box-shadow: 0 24px 80px rgba(0,0,0,.6) !important;
  }
  .modal-header {
    border-bottom: 1px solid var(--border) !important;
    padding: 20px 24px !important;
  }
  .modal-title {
    font-family: 'Plus Jakarta Sans', sans-serif !important;
    font-weight: 800 !important;
    font-size: 16px !important;
  }

  /* Empty state */
  .empty-state h4 {
    font-family: 'Plus Jakarta Sans', sans-serif !important;
    font-weight: 700 !important;
  }

  </style>
</head>
<body>
<script src="js/app.js?v=5"></script>
<script>
const user = Auth.requireAuth('student');
if (user) { buildShell('jobs'); setTimeout(initJobs, 0); }

let allJobs = [], profile = null;

async function initJobs() {
  document.getElementById('topbarTitle').textContent = 'Job Portal';
  const page = document.getElementById('mainPage');
  page.innerHTML = `
    <div class="page-header">
      <h1 style="font-size:1.6rem">🏢 Job Portal</h1>
      <p style="color:var(--text3);font-size:13px;margin-top:2px">Browse verified openings · Check eligibility · Apply directly — no middlemen</p>
    </div>
    <div id="alertBox"></div>

    <!-- Tab switch area -->
    <div style="display:flex;gap:8px;margin-bottom:20px">
      <button onclick="switchJobTab('browse')" id="tab_browse" class="btn btn-primary btn-sm" style="border-radius:99px;padding:8px 18px;white-space:nowrap">🔍 Browse All</button>
      <button onclick="switchJobTab('recommended')" id="tab_recommended" class="btn btn-ghost btn-sm" style="border-radius:99px;padding:8px 18px;white-space:nowrap">⭐ Best Matches</button>
      <button onclick="switchJobTab('myapps')" id="tab_myapps" class="btn btn-ghost btn-sm" style="border-radius:99px;padding:8px 18px;white-space:nowrap">📋 My Applications</button>
    </div>

    <!-- Filters -->
    <div id="filterSection" class="card mb-4">
      <div style="display:flex;gap:14px;flex-wrap:wrap;align-items:flex-end">
        <div class="form-group" style="margin:0;flex:1;min-width:200px">
          <label class="form-label">Search</label>
          <div class="input-group">
            ${iconSearch()}
            <input type="text" id="searchInput" class="form-input" placeholder="Role, company, skill…" oninput="filterJobs()">
          </div>
        </div>
        <div class="form-group" style="margin:0;min-width:140px">
          <label class="form-label">Experience</label>
          <select id="expFilter" class="form-select" onchange="filterJobs()">
            <option value="">All Levels</option>
            <option>Entry</option><option>Mid</option><option>Senior</option>
          </select>
        </div>
        <div class="form-group" style="margin:0;min-width:120px">
          <label class="form-label">Min CGPA</label>
          <input type="number" id="cgpaFilter" class="form-input" placeholder="e.g. 7.0" min="0" max="10" step="0.1" oninput="filterJobs()">
        </div>
      </div>
    </div>

    <!-- Job grid -->
    <div id="jobsGrid">
      <div class="loading-center"><div class="spinner"></div> Loading jobs…</div>
    </div>

    <!-- Apply modal -->
    <div class="modal-overlay" id="applyModal">
      <div class="modal">
        <div class="modal-header">
          <div class="modal-title" id="modalTitle">Apply for Job</div>
          <button class="modal-close" onclick="closeModal('applyModal')" style="background:none;border:none;color:var(--text2);cursor:pointer;font-size:20px;line-height:1;padding:2px">&#215;</button>
        </div>
        <div id="modalBody"></div>
      </div>
    </div>`;

  try {
    const [j, p] = await Promise.allSettled([
      API.get('jobs.php?action=list'),
      API.get(`student_profile.php?user_id=${user.id}`)
    ]);
    if (j.status==='fulfilled') allJobs = j.value.jobs||[];
    else { console.warn('Jobs API error:', j.reason); }
    if (p.status==='fulfilled') profile = p.value.profile;
  } catch(e) { console.warn('Jobs init error:', e); }

  if (!allJobs.length) {
    document.getElementById('jobsGrid').innerHTML = `
      <div class="empty-state" style="grid-column:1/-1">
        <svg width="48" height="48" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"/></svg>
        <h4>No jobs listed yet</h4>
        <p style="font-size:13px;color:var(--text3)">No verified companies have posted jobs yet.<br>Check back soon or ask your admin to verify organizations.</p>
      </div>`;
    return;
  }

  filterJobs();
}

function filterJobs() {
  const q = (document.getElementById('searchInput')?.value||'').toLowerCase();
  const exp = document.getElementById('expFilter')?.value||'';
  const minCgpa = parseFloat(document.getElementById('cgpaFilter')?.value||'0')||0;

  const filtered = allJobs.filter(j=>{
    const txt = `${j.title} ${j.company_name} ${j.required_skills} ${j.location}`.toLowerCase();
    if (q && !txt.includes(q)) return false;
    if (exp && j.experience_level!==exp) return false;
    if (minCgpa && j.min_cgpa > minCgpa) return false;
    return true;
  });

  const grid = document.getElementById('jobsGrid');
  if (!filtered.length) {
    grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1">
      <svg width="48" height="48" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"/></svg>
      <h4>No jobs found</h4><p>Try adjusting your filters</p></div>`;
    return;
  }

  grid.innerHTML = filtered.map(j=>{
    const skills = (j.required_skills||'').split(',').map(s=>s.trim()).filter(Boolean).slice(0,5);
    const mySkills = (profile?.skills||'').toLowerCase();
    const matched = skills.filter(s=>mySkills.includes(s.toLowerCase())).length;
    const matchPct = skills.length ? Math.round((matched/skills.length)*100) : 0;
    const cgpaOk = !profile || parseFloat(profile.cgpa||0) >= parseFloat(j.min_cgpa||0);
    const matchColor = matchPct>=70?'#00d68f':matchPct>=40?'#f59e0b':'#a0a0a0';
    const initials = (j.company_name||'C').split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase();

    return `<div class="card" style="display:flex;flex-direction:column;gap:0;padding:0;overflow:hidden;transition:transform .2s,box-shadow .2s" onmouseover="this.style.transform='translateY(-2px)';this.style.boxShadow='0 8px 32px rgba(0,0,0,.4)'" onmouseout="this.style.transform='';this.style.boxShadow=''">

      <!-- Card header -->
      <div style="padding:18px 18px 14px;display:flex;align-items:flex-start;justify-content:space-between;gap:12px">
        <div style="display:flex;align-items:flex-start;gap:12px">
          <div style="width:44px;height:44px;background:linear-gradient(135deg,rgba(108,99,255,.2),rgba(167,139,250,.2));border:1px solid rgba(108,99,255,.25);border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:800;color:var(--primary);flex-shrink:0">${initials}</div>
          <div>
            <div style="font-size:15px;font-weight:700;color:var(--text);line-height:1.3;margin-bottom:2px">${esc(j.title)}</div>
            <div style="font-size:12.5px;color:var(--primary);font-weight:600">${esc(j.company_name||'Company')}</div>
          </div>
        </div>
        ${matchPct>0?`<div style="flex-shrink:0;text-align:center;background:rgba(0,0,0,.3);border-radius:10px;padding:6px 10px;border:1px solid ${matchColor}33"><div style="font-size:14px;font-weight:800;color:${matchColor}">${matchPct}%</div><div style="font-size:9px;color:var(--text3);font-weight:600;letter-spacing:.04em">MATCH</div></div>`:''}
      </div>

      <!-- Meta row -->
      <div style="padding:0 18px 12px;display:flex;align-items:center;gap:6px;flex-wrap:wrap">
        <span style="font-size:11px;padding:3px 9px;border-radius:99px;background:rgba(255,255,255,.06);color:var(--text3);border:1px solid var(--border)">${esc(j.experience_level||'Entry')}</span>
        ${cgpaOk
          ? '<span style="font-size:11px;padding:3px 9px;border-radius:99px;background:rgba(0,214,143,.1);color:#00d68f;border:1px solid rgba(0,214,143,.25)">✓ CGPA eligible</span>'
          : `<span style="font-size:11px;padding:3px 9px;border-radius:99px;background:rgba(245,158,11,.1);color:#f59e0b;border:1px solid rgba(245,158,11,.25)">⚠ Need ${j.min_cgpa}+ CGPA</span>`}
        ${j.location?`<span style="font-size:11px;padding:3px 9px;border-radius:99px;background:rgba(255,255,255,.05);color:var(--text3);border:1px solid var(--border)">📍 ${esc(j.location)}</span>`:''}
      </div>

      <!-- Skills -->
      ${skills.length?`<div style="padding:0 18px 14px">
        <div style="display:flex;flex-wrap:wrap;gap:5px">
          ${skills.map(s=>{
            const m = mySkills.includes(s.toLowerCase());
            return `<span style="font-size:11px;padding:3px 10px;border-radius:99px;font-weight:500;${m?'background:rgba(0,214,143,.1);color:#00d68f;border:1px solid rgba(0,214,143,.3)':'background:rgba(255,255,255,.05);color:var(--text3);border:1px solid var(--border)'}">${m?'✓ ':''}${esc(s)}</span>`;
          }).join('')}
        </div>
      </div>`:''}

      <!-- Salary -->
      ${j.salary_range?`<div style="padding:0 18px 14px;display:flex;align-items:center;gap:6px">
        <svg width="13" height="13" fill="none" stroke="#00d68f" stroke-width="2" viewBox="0 0 24 24"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
        <span style="font-size:13px;font-weight:700;color:#00d68f">${esc(j.salary_range)}</span>
      </div>`:''}

      <!-- Action bar -->
      <div style="padding:12px 18px;border-top:1px solid var(--border);display:flex;gap:8px;margin-top:auto">
        <button onclick="openApply(${j.id})" class="btn btn-primary" style="flex:1;justify-content:center;font-size:13px;padding:9px 16px">
          Apply Now
        </button>
        <button onclick="viewDetails(${j.id})" style="padding:9px 14px;border-radius:var(--radius-sm);border:1px solid var(--border);background:transparent;color:var(--text2);cursor:pointer;font-size:12.5px;font-weight:500;transition:background .15s;white-space:nowrap" onmouseover="this.style.background='var(--surface2)'" onmouseout="this.style.background='transparent'">
          View Details
        </button>
      </div>
    </div>`;
  }).join('');
}

async function openApply(jobId) {
  const job = allJobs.find(j=>j.id===jobId);
  if (!job) return;
  document.getElementById('modalTitle').textContent = `Apply — ${job.title} at ${job.company_name||'Company'}`;
  document.getElementById('modalBody').innerHTML = `
    <div class="alert alert-info mb-4">
      Your profile and resume will be shared with ${esc(job.company_name||'the company')}. Make sure your profile is complete.
    </div>
    <div style="display:flex;flex-direction:column;gap:8px;margin-bottom:20px;font-size:13.5px">
      <div style="display:flex;justify-content:space-between"><span style="color:var(--text3)">Role</span><span style="color:var(--text);font-weight:600">${esc(job.title)}</span></div>
      <div style="display:flex;justify-content:space-between"><span style="color:var(--text3)">Package</span><span style="color:var(--emerald);font-weight:700">${esc(job.salary_range||'—')}</span></div>
      <div style="display:flex;justify-content:space-between"><span style="color:var(--text3)">Location</span><span style="color:var(--text2)">${esc(job.location||'—')}</span></div>
      <div style="display:flex;justify-content:space-between"><span style="color:var(--text3)">Min CGPA</span><span style="color:var(--text2)">${esc(job.min_cgpa||'—')}</span></div>
    </div>
    <div id="applyAlert"></div>
    <button onclick="confirmApply(${jobId})" id="confirmBtn" class="btn btn-primary w-full">Confirm Application</button>`;
  openModal('applyModal');
}

async function confirmApply(jobId) {
  const btn = document.getElementById('confirmBtn');
  loading(btn, true, 'Applying…');
  try {
    await API.post('apply_job.php', {user_id:user.id, job_id:jobId});
    document.getElementById('modalBody').innerHTML = `
      <div style="text-align:center;padding:24px">
        <div style="font-size:3rem;margin-bottom:12px">🎉</div>
        <h3 style="margin-bottom:8px">Application Submitted!</h3>
        <p style="font-size:13.5px;color:var(--text2)">The company will review your profile and get back to you.</p>
        <button onclick="closeModal('applyModal')" class="btn btn-primary mt-4">Done</button>
      </div>`;
  } catch(e) {
    loading(btn, false);
    showAlert(document.getElementById('applyAlert'), e.message==='Already applied' ? 'You already applied for this job.' : e.message);
  }
}

async function viewDetails(jobId) {
  const job = allJobs.find(j=>j.id===jobId);
  if (!job) { console.warn('Job not found:', jobId, allJobs.length); return; }
  document.getElementById('modalTitle').textContent = job.title + ' — ' + (job.company_name||'Company');
  const skills = (job.required_skills||'').split(',').filter(s=>s.trim());
  const myS = (profile?.skills||'').toLowerCase();
  document.getElementById('modalBody').innerHTML = `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:16px;font-size:13px">
      <div style="background:var(--bg3);border-radius:10px;padding:12px">
        <div style="color:var(--text3);font-size:11px;margin-bottom:3px">PACKAGE</div>
        <div style="font-weight:700;color:var(--emerald);font-size:15px">${esc(job.salary_range||'Not specified')}</div>
      </div>
      <div style="background:var(--bg3);border-radius:10px;padding:12px">
        <div style="color:var(--text3);font-size:11px;margin-bottom:3px">LOCATION</div>
        <div style="font-weight:600;color:var(--text)">${esc(job.location||'Not specified')}</div>
      </div>
      <div style="background:var(--bg3);border-radius:10px;padding:12px">
        <div style="color:var(--text3);font-size:11px;margin-bottom:3px">MIN CGPA</div>
        <div style="font-weight:700;color:var(--text)">${esc(String(job.min_cgpa||'No cutoff'))}</div>
      </div>
      <div style="background:var(--bg3);border-radius:10px;padding:12px">
        <div style="color:var(--text3);font-size:11px;margin-bottom:3px">TYPE</div>
        <div style="font-weight:600;color:var(--text)">${esc(job.job_type||'Full-time')}</div>
      </div>
    </div>
    ${job.description ? `<div style="font-size:13.5px;color:var(--text2);line-height:1.7;margin-bottom:16px;padding:12px;background:var(--bg3);border-radius:10px">${esc(job.description).replace(/\n/g,'<br>')}</div>` : ''}
    ${skills.length ? `
    <div style="font-size:11px;color:var(--text3);font-weight:600;text-transform:uppercase;letter-spacing:.08em;margin-bottom:8px">Required Skills</div>
    <div class="skill-tags mb-4">
      ${skills.map(s=>{
        const match = myS.includes(s.trim().toLowerCase());
        return '<span class="skill-tag" style="'+(match?'background:rgba(0,214,143,.12);color:var(--emerald);border-color:var(--emerald)':'')+'" title="'+(match?'You have this skill':'Missing from your profile')+'">'+esc(s.trim())+' '+(match?'✓':'')+'</span>';
      }).join('')}
    </div>` : ''}
    <div id="detailsApplyAlert"></div>
    <button onclick="openApply(${jobId})" class="btn btn-primary w-full" style="justify-content:center;margin-top:4px">Apply Now</button>`;
  openModal('applyModal');
}

let currentJobTab = 'browse';
window.switchJobTab = function(tab) {
  currentJobTab = tab;
  ['browse','recommended','myapps'].forEach(t=>{
    const btn = document.getElementById('tab_'+t);
    if(btn) { btn.style.color = t===tab?'var(--primary)':''; btn.style.fontWeight = t===tab?'700':'600'; }
  });
  const filterCard = document.getElementById('filterSection');
  if (filterCard) filterCard.style.display = tab==='browse'?'':'none';
  if (tab==='browse') filterJobs();
  else if (tab==='recommended') loadRecommendations();
  else loadMyApplications();
};

async function loadRecommendations() {
  const grid = document.getElementById('jobsGrid');
  grid.innerHTML = `<div class="loading-center" style="grid-column:1/-1"><div class="spinner"></div> Finding best matches…</div>`;
  try {
    const d = await API.get(`job_recommendations.php?user_id=${user.id}`);
    if (!d.success) throw new Error('Failed');
    if (!d.recommendations.length) {
      grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1"><h4>No recommendations yet</h4><p>Complete your profile with skills and CGPA for personalized matches.</p></div>`;
      return;
    }
    grid.innerHTML = d.recommendations.map(j=>{
      const pct = j.match_score;
      const cls = pct>=70?'high':pct>=40?'mid':'low';
      const skills = (j.required_skills||'').split(',').map(s=>s.trim()).filter(Boolean).slice(0,4);
      return `<div class="card" style="display:flex;flex-direction:column;gap:0">
        <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:10px;margin-bottom:10px">
          <div>
            <div style="font-family:var(--font-display);font-size:14px;font-weight:700;color:var(--text)">${esc(j.title)}</div>
            <div style="font-size:12px;color:var(--primary);font-weight:600">${esc(j.company_name||'')}</div>
          </div>
          <span class="match-badge ${cls}">⚡ ${pct}% Match</span>
        </div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px">
          ${j.matched_skills?.map(s=>`<span class="skill-tag" style="background:rgba(0,214,143,.1);color:var(--emerald);border-color:rgba(0,214,143,.25)">✓ ${esc(s)}</span>`).join('')||''}
          ${j.missing_skills?.map(s=>`<span class="skill-tag" style="background:rgba(239,68,68,.08);color:var(--red);border-color:rgba(239,68,68,.2)">✕ ${esc(s)}</span>`).join('')||''}
        </div>
        <div style="font-size:12px;color:var(--text3);margin-bottom:12px">${esc(j.salary_range||'')} • ${esc(j.location||'')} • Min CGPA: ${j.min_cgpa}</div>
        <div style="border-top:1px solid var(--border);padding-top:10px">
          <button onclick="openApply(${j.id})" class="btn btn-primary btn-sm w-full">Apply Now</button>
        </div>
      </div>`;
    }).join('');
  } catch(e) {
    grid.innerHTML = `<div class="alert alert-error" style="grid-column:1/-1">Failed to load recommendations.</div>`;
  }
}

async function loadMyApplications() {
  const grid = document.getElementById('jobsGrid');
  grid.innerHTML = `<div class="loading-center" style="grid-column:1/-1"><div class="spinner"></div> Loading applications…</div>`;
  try {
    const r = await API.get(`jobs.php?action=my_applications&user_id=${user.id}`);
    const apps = r.applications||[];
    if (!apps.length) {
      grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1"><h4>No applications yet</h4><p>Browse jobs and apply to get started!</p></div>`;
      return;
    }
    grid.innerHTML = apps.map(a=>`
      <div class="card">
        <div style="display:flex;justify-content:space-between;align-items:start;margin-bottom:14px">
          <div>
            <div style="font-weight:700;font-size:14px">${esc(a.title)}</div>
            <div style="font-size:12px;color:var(--primary);font-weight:600">${esc(a.company_name||'')}</div>
            <div style="font-size:11px;color:var(--text3);margin-top:2px">Applied ${fmtDate(a.applied_at)}</div>
          </div>
          ${statusBadge(a.status)}
        </div>
        ${applicationTimeline(a.status)}
        ${a.interview_datetime?`<div style="margin-top:10px;padding:10px;background:rgba(124,106,255,.08);border-radius:8px;font-size:12px"><strong>📅 Interview:</strong> ${new Date(a.interview_datetime).toLocaleString('en-IN',{weekday:'short',day:'numeric',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'})}</div>`:''}
        ${a.org_notes?`<div style="margin-top:8px;font-size:12px;color:var(--text3)"><strong>Note:</strong> ${esc(a.org_notes)}</div>`:''}
      </div>`).join('');
  } catch(e) {
    grid.innerHTML = `<div class="alert alert-error" style="grid-column:1/-1">Failed to load applications.</div>`;
  }
}

</script>
</body>
</html>

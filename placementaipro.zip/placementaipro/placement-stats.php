<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">  <link rel="icon" type="image/svg+xml" href="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAzMiAzMiIgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIj4KICA8ZGVmcz4KICAgIDxsaW5lYXJHcmFkaWVudCBpZD0iZyIgeDE9IjAiIHkxPSIxIiB4Mj0iMSIgeTI9IjAiPgogICAgICA8c3RvcCBvZmZzZXQ9IjAlIiBzdG9wLWNvbG9yPSIjZmY0NzU3Ii8+CiAgICAgIDxzdG9wIG9mZnNldD0iMTAwJSIgc3RvcC1jb2xvcj0iI2Y1OWUwYiIvPgogICAgPC9saW5lYXJHcmFkaWVudD4KICA8L2RlZnM+CiAgPHJlY3Qgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIiByeD0iNyIgZmlsbD0iIzFlMWExMCIvPgogIDxyZWN0IHg9IjYiIHk9IjIxIiB3aWR0aD0iNSIgaGVpZ2h0PSI5IiByeD0iMS41IiBmaWxsPSIjZjU5ZTBiIiBvcGFjaXR5PSIuNSIvPgogIDxyZWN0IHg9IjEzIiB5PSIxNSIgd2lkdGg9IjUiIGhlaWdodD0iMTUiIHJ4PSIxLjUiIGZpbGw9IiNmZjZiMzUiIG9wYWNpdHk9Ii43NSIvPgogIDxyZWN0IHg9IjIwIiB5PSI4IiB3aWR0aD0iNSIgaGVpZ2h0PSIyMiIgcng9IjEuNSIgZmlsbD0idXJsKCNnKSIvPgogIDxwb2x5bGluZSBwb2ludHM9IjIzLDQgMjcsOCAyNyw1IiBmaWxsPSJub25lIiBzdHJva2U9InVybCgjZykiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIi8+CiAgPGxpbmUgeDE9IjE5IiB5MT0iNSIgeDI9IjI3IiB5Mj0iNCIgc3Ryb2tlPSJ1cmwoI2cpIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPgo8L3N2Zz4=">
  <link rel="icon" type="image/x-icon" href="data:image/x-icon;base64,AAABAAEAEBAAAAAAIACgAAAAFgAAAIlQTkcNChoKAAAADUlIRFIAAAAQAAAAEAgGAAAAH/P/YQAAAGdJREFUeJxjZIACLg6R/wwkgG8/3jAyMDAwMJGjGVkPIzmakQETJZoZGBgYWNAFvn5/jVMxN6co9V1AWwOwOZkkA/CFB1EGEAOoH43IgOIwIAZQnpRhuYoc8O3HG0YmGIMczQwMDAwA+P4aS3/n/2IAAAAASUVORK5CYII=">
  <link rel="icon" type="image/png" sizes="32x32" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAoElEQVR4nO2XvQ6AIAyES+Pgz6rv/4Cyimw6kWhDxID0HLixabyPozHUUERjPx+xeqmct0bWboVaxk8grG0uvVjbXEJwqrG2DOL0V8ET6FIN275mfXgalld98AQaABwgOYQxyQHLHVSiHyTQALJmoOTOpeAJNAA4wCc/ohLBE2gAcAD8ozS2LmnJeWvgV8CBRNs4eLIsaJoTie04SHM9PwGQNi1E3UY9bQAAAABJRU5ErkJggg==">
  <link rel="icon" type="image/png" sizes="192x192" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMAAAADACAYAAABS3GwHAAADvklEQVR4nO3dQVLjVgBFUZvqASFTsv8FhmkIMzJIdRc0YCxL8pd8z1kAaPCuvmy61MfDxjzcP76OvgbW8/zydBx9DW8NvRhj53AYG8XVf7HRc8q1Y7jaLzN8prhWCKv/EsNnjrVDWO2HGz5LWiuExX+o4bOmpUO4W/KHGT9rW3pji9Rk+IywxGkw+wQwfkZZYnuzAjB+Rpu7wYsDMH62Ys4WLwrA+NmaSzc5OQDjZ6su2eakAIyfrZu60bMDMH72YspWzwrA+Nmbczf7bQDGz16ds91F/ykE7M3JANz92bvvNvxlAMbPrTi1ZY9ApH0agLs/t+arTTsBSPsQgLs/t+qzbTsBSHsXgLs/t+73jTsBSPsVgLs/FW+37gQgTQCk3R0OHn/o+bl5JwBpAiBNAKQJgLSjD8CUOQFIEwBpAiBNAKQJgDQBkPZj9AXM9c+/f4++hF3584+/Rl/CpjgBSBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYC03b8VYi0j356w1psuvBHiIycAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANKOD/ePr6MvYo61XiV+q7wi/T0nAGkCIE0ApAmANAGQJgDSBECaAEgTAGkCIE0ApAmANAGQJgDSBECaAEgTAGkCIE0ApAmANAGQ9mP0BWyVtyc0OAFIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0o4P94+voy8CRnECkCYA0gRAmgBIEwBpd88vT8fRFwEjPL88HZ0ApAmANAGQJgDS7g6H/z8MjL4QuKafm3cCkCYA0n4F4DGIirdbdwKQ9i4ApwC37veNOwFI+xCAU4Bb9dm2nQCkfRqAU4Bb89WmnQCkfRmAU4BbcWrLJ08AEbB3323YIxBp3wbgFGCvztnuWSeACNibczd79iOQCNiLKVud9BlABGzd1I1O/hAsArbqkm1e9C2QCNiaSzd58degImAr5mxx1t8BRMBoczc4+w9hImCUJba36Hj9bzNcw5I33UX/KYTTgLUtvbHVBus0YElr3VxXv2MLgTnWfqq42iOLEJjiWo/TV39mFwKnXPtz5NAPrWLgcBj75cnmvrURxW3b2jeF/wGOq9fsu4f8UQAAAABJRU5ErkJggg==">
  <link rel="apple-touch-icon" sizes="180x180" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAAC0CAYAAAA9zQYyAAADX0lEQVR4nO3cOXJaQQBFUVA58JDa+1+glVpWZgceygOS/kh/rs5ZAOrg8tRAwfl0AO/ffvw2+gys9/B4fx59hiEHEPDrMCLwq/1BEb9u14p71z8iYi7ZM+5dHljITLFH2HdbP6CYmWqPVjZ7hgiZNbZa600WWsystVVDq54VQmYPa9Z68UKLmb2saWtR0GJmb0sbmx20mLmWJa3NClrMXNvc5iYHLWZGmdPepKDFzGhTG3wxaDFzFFNa3Pyjbxjp2aCtM0fzUpNPBi1mjuq5Nl05SLkYtHXm6J5q9L+gxcytuNSqKwcpfwVtnbk1/zZroUkRNCm/g3bd4Fb92a6FJkXQpNydTq4b3L5fDVtoUgRNiqBJObs/U2KhSRE0KYImRdCkCJoUQZPyZvQBlvjy9fPoIxzWh3efRh9hKAtNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiblJr8ku4cRXy71Zd/tWWhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCl+rPEnP5zYYKFJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KT4kuxPH959Gn0ENmChSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJqU8/u3H7+NPgRsxUKTImhSBE2KoEkRNCl3D4/359GHgC08PN6fLTQpgiZF0KTcnU4/7h6jDwJr/GrYQpMiaFJ+B+3awa36s10LTYqgSfkraNcObs2/zVpoUv4L2kpzKy61enGhRc3RPdWoKwcpTwZtpTmq59p8dqFFzdG81KQrBykvBm2lOYopLU5aaFEz2tQGJ185RM0oc9qbdYcWNdc2t7nZLwpFzbUsaW3RuxyiZm9LG1v8tp2o2cuatjaJ0k/ysoUtRnKTD1asNWtt1dDmIVpr5th6DDf/6NtaM9Uerewan7Xmkj1H72prKu7X7Vr/uYdcD8T9Ooy4fh7ivivwhiO8fvoO2onGYhMioSEAAAAASUVORK5CYII=">
  <title>Placement Stats — PlacementAI Pro</title>
  <link rel="stylesheet" href="css/style.css?v=5">
  <style>
    body.landing { background:var(--bg); }
    .stats-hero { text-align:center; padding:80px 24px 40px; }
    .stats-hero h1 { font-size:clamp(2rem,4vw,3rem); font-weight:900; letter-spacing:-.04em; margin-bottom:14px; }
    .stats-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:20px; max-width:900px; margin:0 auto 60px; padding:0 24px; }
    .stat-box { background:var(--surface); border:1px solid var(--border); border-radius:var(--radius-lg); padding:28px; text-align:center; }
    .stat-box .num { display:block; font-family:var(--font-display); font-size:3rem; font-weight:900; line-height:1; margin-bottom:8px; }
    .stat-box .lbl { font-size:13px; color:var(--text3); font-weight:500; }
    .companies-section { max-width:1000px; margin:0 auto; padding:0 24px 60px; }
    .companies-section h2 { text-align:center; margin-bottom:32px; }
    .company-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(160px,1fr)); gap:14px; }
    .company-card { background:var(--surface); border:1px solid var(--border); border-radius:var(--radius); padding:20px; text-align:center; transition:transform .2s,border-color .2s; }
    .company-card:hover { transform:translateY(-3px); border-color:var(--border2); }
    .company-count { font-family:var(--font-display); font-size:2rem; font-weight:900; color:var(--primary-l); }
    .company-name { font-size:12px; font-weight:600; color:var(--text2); margin-top:4px; }
    .recent-section { max-width:900px; margin:0 auto; padding:0 24px 80px; }
    .hire-card { background:var(--surface); border:1px solid var(--border); border-radius:var(--radius); padding:16px; display:flex; align-items:center; gap:14px; }
    .hire-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(280px,1fr)); gap:14px; }
    .nav-landing { display:flex; align-items:center; justify-content:space-between; padding:16px 32px; border-bottom:1px solid var(--border); position:sticky; top:0; background:rgba(10,10,10,.85); backdrop-filter:blur(12px); z-index:100; }
    [data-theme="light"] .nav-landing { background:rgba(245,245,247,.9); }
    @keyframes countUp { from { opacity:0; transform:translateY(10px); } to { opacity:1; transform:translateY(0); } }
    .animated-num { animation:countUp .6s ease forwards; display:inline-block; }
  </style>
</head>
<body class="landing">
<nav class="nav-landing">
  <div style="display:flex;align-items:center;gap:9px;font-family:var(--font-display);font-size:.95rem;font-weight:700">
    <div style="width:30px;height:30px;background:var(--primary-g);border-radius:8px;display:flex;align-items:center;justify-content:center">
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30" width="30" height="30"><defs><linearGradient id="gcl30" x1="0" y1="1" x2="1" y2="0"><stop offset="0%" stop-color="#ff4757"/><stop offset="100%" stop-color="#f59e0b"/></linearGradient></defs><rect width="30" height="30" rx="5" fill="#1e1a10"/><rect x="5" y="20" width="5" height="8" rx="1" fill="#f59e0b" opacity=".45"/><rect x="11" y="14" width="5" height="14" rx="1" fill="#ff6b35" opacity=".7"/><rect x="18" y="7" width="5" height="21" rx="1" fill="url(#gcl30)"/><polyline points="20,4 23,7 23,5" fill="none" stroke="url(#gcl30)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><line x1="17" y1="5" x2="20" y2="4" stroke="url(#gcl30)" stroke-width="1.5" stroke-linecap="round"/></svg>
    </div>
    <span style="white-space:nowrap">PlacementAI<span style="color:var(--primary-l)"> Pro</span></span>
  </div>
  <div style="display:flex;align-items:center;gap:10px">
    <button class="theme-toggle-btn" onclick="ThemeManager.toggle()" style="background:none;border:1px solid var(--border2);border-radius:8px;width:34px;height:34px;cursor:pointer;font-size:16px;">🌙</button>
    <a href="login.php" style="color:var(--text2);font-size:13.5px;font-weight:500;padding:7px 14px;border-radius:8px">Sign in</a>
    <a href="register.php" class="btn btn-primary btn-sm">Join Free</a>
  </div>
</nav>

<section class="stats-hero">
  <div style="display:inline-block;padding:5px 14px;background:rgba(124,106,255,.1);border:1px solid rgba(124,106,255,.25);border-radius:99px;font-size:12px;font-weight:700;color:var(--primary-l);margin-bottom:20px">📊 LIVE PLACEMENT DATA</div>
  <h1>Real Students.<br><span style="background:var(--primary-g);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text">Real Placements.</span></h1>
  <p style="color:var(--text2);font-size:16px;max-width:500px;margin:0 auto">Track placement outcomes from our college network — updated in real time.</p>
</section>

<div class="stats-grid" id="statsGrid">
  <div class="stat-box"><span class="num animated-num" style="background:var(--primary-g);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text" id="n_placed">—</span><span class="lbl">Students Placed</span></div>
  <div class="stat-box"><span class="num animated-num" style="color:var(--emerald)" id="n_students">—</span><span class="lbl">Registered Students</span></div>
  <div class="stat-box"><span class="num animated-num" style="color:var(--accent2)" id="n_companies">—</span><span class="lbl">Hiring Companies</span></div>
  <div class="stat-box"><span class="num animated-num" style="color:var(--cyan)" id="n_cgpa">—</span><span class="lbl">Average CGPA</span></div>
</div>

<section class="companies-section">
  <h2>Company-Wise Placements</h2>
  <div class="company-grid" id="companyGrid"><div style="text-align:center;color:var(--text3);padding:32px">Loading…</div></div>
</section>

<section class="recent-section">
  <h2 style="text-align:center;margin-bottom:24px">Recent Hires 🎉</h2>
  <div class="hire-grid" id="hireGrid"><div style="text-align:center;color:var(--text3);padding:32px">Loading…</div></div>
</section>

<section style="max-width:900px;margin:0 auto;padding:0 24px 80px">
  <h2 style="text-align:center;margin-bottom:24px">Placement by Branch</h2>
  <div id="branchGrid"></div>
</section>

<footer style="border-top:1px solid var(--border);padding:28px 40px;text-align:center">
  <span style="font-size:12px;color:var(--text3)">PlacementAI Pro — Empowering student careers with AI</span>
</footer>

<script src="js/app.js?v=5"></script>
<script>
ThemeManager.init();
async function loadStats() {
  try {
    const r = await fetch('php/placement_stats.php');
    const d = await r.json();
    if (!d.success) return;

    // Animate counters
    function animateCounter(el, target, suffix='') {
      let current = 0;
      const step = Math.max(1, Math.floor(target/60));
      const interval = setInterval(()=>{
        current = Math.min(current+step, target);
        el.textContent = current.toLocaleString('en-IN') + suffix;
        if (current >= target) clearInterval(interval);
      }, 30);
    }
    animateCounter(document.getElementById('n_placed'), d.total_placed);
    animateCounter(document.getElementById('n_students'), d.total_students);
    animateCounter(document.getElementById('n_companies'), d.total_companies);
    document.getElementById('n_cgpa').textContent = d.avg_cgpa;

    // Companies
    const cg = document.getElementById('companyGrid');
    if (d.companies?.length) {
      cg.innerHTML = d.companies.map(c=>`
        <div class="company-card">
          <div class="company-count">${c.placed_count}</div>
          <div class="company-name">${esc(c.company_name)}</div>
          <div style="font-size:11px;color:var(--text3);margin-top:2px">${esc(c.industry||'')}</div>
        </div>`).join('');
    } else {
      cg.innerHTML = '<div style="color:var(--text3);text-align:center;grid-column:1/-1;padding:24px">No placement data yet</div>';
    }

    // Recent hires
    const hg = document.getElementById('hireGrid');
    if (d.recent_hires?.length) {
      hg.innerHTML = d.recent_hires.map(h=>`
        <div class="hire-card">
          ${h.photo_url?`<img src="${esc(h.photo_url)}" class="student-photo-sm">`:
            `<div style="width:40px;height:40px;border-radius:50%;background:var(--primary-g);display:flex;align-items:center;justify-content:center;font-weight:700;color:#fff;flex-shrink:0">${esc(h.name).split(' ').map(w=>w[0]).join('').slice(0,2)}</div>`}
          <div>
            <div style="font-weight:700;font-size:13.5px">${esc(h.name)}</div>
            <div style="font-size:12px;color:var(--primary-l)">${esc(h.title)} @ ${esc(h.company_name)}</div>
            <div style="font-size:11px;color:var(--text3)">${esc(h.branch)}</div>
          </div>
          <div style="margin-left:auto;font-size:18px">🎊</div>
        </div>`).join('');
    } else {
      hg.innerHTML = '<div style="color:var(--text3);text-align:center;padding:24px">Placement journey just started!</div>';
    }

    // Branch stats
    const bg = document.getElementById('branchGrid');
    if (d.branch_stats?.length) {
      bg.innerHTML = d.branch_stats.map(b=>{
        const pct = b.total>0?Math.round((b.placed/b.total)*100):0;
        return `<div style="margin-bottom:14px">
          <div style="display:flex;justify-content:space-between;margin-bottom:5px">
            <span style="font-size:13px;font-weight:600">${esc(b.branch)}</span>
            <span style="font-size:13px;color:var(--emerald);font-weight:700">${b.placed}/${b.total} placed (${pct}%)</span>
          </div>
          <div style="height:6px;background:var(--surface3);border-radius:99px;overflow:hidden">
            <div style="height:100%;width:${pct}%;background:var(--primary-g);border-radius:99px;transition:width .8s ease"></div>
          </div>
        </div>`;
      }).join('');
    }
  } catch(e) {
    console.error(e);
  }
}
loadStats();
</script>
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">  <link rel="icon" type="image/svg+xml" href="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAzMiAzMiIgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIj4KICA8ZGVmcz4KICAgIDxsaW5lYXJHcmFkaWVudCBpZD0iZyIgeDE9IjAiIHkxPSIxIiB4Mj0iMSIgeTI9IjAiPgogICAgICA8c3RvcCBvZmZzZXQ9IjAlIiBzdG9wLWNvbG9yPSIjZmY0NzU3Ii8+CiAgICAgIDxzdG9wIG9mZnNldD0iMTAwJSIgc3RvcC1jb2xvcj0iI2Y1OWUwYiIvPgogICAgPC9saW5lYXJHcmFkaWVudD4KICA8L2RlZnM+CiAgPHJlY3Qgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIiByeD0iNyIgZmlsbD0iIzFlMWExMCIvPgogIDxyZWN0IHg9IjYiIHk9IjIxIiB3aWR0aD0iNSIgaGVpZ2h0PSI5IiByeD0iMS41IiBmaWxsPSIjZjU5ZTBiIiBvcGFjaXR5PSIuNSIvPgogIDxyZWN0IHg9IjEzIiB5PSIxNSIgd2lkdGg9IjUiIGhlaWdodD0iMTUiIHJ4PSIxLjUiIGZpbGw9IiNmZjZiMzUiIG9wYWNpdHk9Ii43NSIvPgogIDxyZWN0IHg9IjIwIiB5PSI4IiB3aWR0aD0iNSIgaGVpZ2h0PSIyMiIgcng9IjEuNSIgZmlsbD0idXJsKCNnKSIvPgogIDxwb2x5bGluZSBwb2ludHM9IjIzLDQgMjcsOCAyNyw1IiBmaWxsPSJub25lIiBzdHJva2U9InVybCgjZykiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIi8+CiAgPGxpbmUgeDE9IjE5IiB5MT0iNSIgeDI9IjI3IiB5Mj0iNCIgc3Ryb2tlPSJ1cmwoI2cpIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPgo8L3N2Zz4=">
  <link rel="icon" type="image/x-icon" href="data:image/x-icon;base64,AAABAAEAEBAAAAAAIACgAAAAFgAAAIlQTkcNChoKAAAADUlIRFIAAAAQAAAAEAgGAAAAH/P/YQAAAGdJREFUeJxjZIACLg6R/wwkgG8/3jAyMDAwMJGjGVkPIzmakQETJZoZGBgYWNAFvn5/jVMxN6co9V1AWwOwOZkkA/CFB1EGEAOoH43IgOIwIAZQnpRhuYoc8O3HG0YmGIMczQwMDAwA+P4aS3/n/2IAAAAASUVORK5CYII=">
  <link rel="icon" type="image/png" sizes="32x32" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAoElEQVR4nO2XvQ6AIAyES+Pgz6rv/4Cyimw6kWhDxID0HLixabyPozHUUERjPx+xeqmct0bWboVaxk8grG0uvVjbXEJwqrG2DOL0V8ET6FIN275mfXgalld98AQaABwgOYQxyQHLHVSiHyTQALJmoOTOpeAJNAA4wCc/ohLBE2gAcAD8ozS2LmnJeWvgV8CBRNs4eLIsaJoTie04SHM9PwGQNi1E3UY9bQAAAABJRU5ErkJggg==">
  <link rel="icon" type="image/png" sizes="192x192" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMAAAADACAYAAABS3GwHAAADvklEQVR4nO3dQVLjVgBFUZvqASFTsv8FhmkIMzJIdRc0YCxL8pd8z1kAaPCuvmy61MfDxjzcP76OvgbW8/zydBx9DW8NvRhj53AYG8XVf7HRc8q1Y7jaLzN8prhWCKv/EsNnjrVDWO2HGz5LWiuExX+o4bOmpUO4W/KHGT9rW3pji9Rk+IywxGkw+wQwfkZZYnuzAjB+Rpu7wYsDMH62Ys4WLwrA+NmaSzc5OQDjZ6su2eakAIyfrZu60bMDMH72YspWzwrA+Nmbczf7bQDGz16ds91F/ykE7M3JANz92bvvNvxlAMbPrTi1ZY9ApH0agLs/t+arTTsBSPsQgLs/t+qzbTsBSHsXgLs/t+73jTsBSPsVgLs/FW+37gQgTQCk3R0OHn/o+bl5JwBpAiBNAKQJgLSjD8CUOQFIEwBpAiBNAKQJgDQBkPZj9AXM9c+/f4++hF3584+/Rl/CpjgBSBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYC03b8VYi0j356w1psuvBHiIycAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANIEQJoASBMAaQIgTQCkCYA0AZAmANKOD/ePr6MvYo61XiV+q7wi/T0nAGkCIE0ApAmANAGQJgDSBECaAEgTAGkCIE0ApAmANAGQJgDSBECaAEgTAGkCIE0ApAmANAGQ9mP0BWyVtyc0OAFIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0gRAmgBIEwBpAiBNAKQJgDQBkCYA0o4P94+voy8CRnECkCYA0gRAmgBIEwBpd88vT8fRFwEjPL88HZ0ApAmANAGQJgDS7g6H/z8MjL4QuKafm3cCkCYA0n4F4DGIirdbdwKQ9i4ApwC37veNOwFI+xCAU4Bb9dm2nQCkfRqAU4Bb89WmnQCkfRmAU4BbcWrLJ08AEbB3323YIxBp3wbgFGCvztnuWSeACNibczd79iOQCNiLKVud9BlABGzd1I1O/hAsArbqkm1e9C2QCNiaSzd58degImAr5mxx1t8BRMBoczc4+w9hImCUJba36Hj9bzNcw5I33UX/KYTTgLUtvbHVBus0YElr3VxXv2MLgTnWfqq42iOLEJjiWo/TV39mFwKnXPtz5NAPrWLgcBj75cnmvrURxW3b2jeF/wGOq9fsu4f8UQAAAABJRU5ErkJggg==">
  <link rel="apple-touch-icon" sizes="180x180" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAAC0CAYAAAA9zQYyAAADX0lEQVR4nO3cOXJaQQBFUVA58JDa+1+glVpWZgceygOS/kh/rs5ZAOrg8tRAwfl0AO/ffvw2+gys9/B4fx59hiEHEPDrMCLwq/1BEb9u14p71z8iYi7ZM+5dHljITLFH2HdbP6CYmWqPVjZ7hgiZNbZa600WWsystVVDq54VQmYPa9Z68UKLmb2saWtR0GJmb0sbmx20mLmWJa3NClrMXNvc5iYHLWZGmdPepKDFzGhTG3wxaDFzFFNa3Pyjbxjp2aCtM0fzUpNPBi1mjuq5Nl05SLkYtHXm6J5q9L+gxcytuNSqKwcpfwVtnbk1/zZroUkRNCm/g3bd4Fb92a6FJkXQpNydTq4b3L5fDVtoUgRNiqBJObs/U2KhSRE0KYImRdCkCJoUQZPyZvQBlvjy9fPoIxzWh3efRh9hKAtNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiblJr8ku4cRXy71Zd/tWWhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCmCJkXQpAiaFEGTImhSBE2KoEkRNCl+rPEnP5zYYKFJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KQImhRBkyJoUgRNiqBJETQpgiZF0KT4kuxPH959Gn0ENmChSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJoUQZMiaFIETYqgSRE0KYImRdCkCJqU8/u3H7+NPgRsxUKTImhSBE2KoEkRNCl3D4/359GHgC08PN6fLTQpgiZF0KTcnU4/7h6jDwJr/GrYQpMiaFJ+B+3awa36s10LTYqgSfkraNcObs2/zVpoUv4L2kpzKy61enGhRc3RPdWoKwcpTwZtpTmq59p8dqFFzdG81KQrBykvBm2lOYopLU5aaFEz2tQGJ185RM0oc9qbdYcWNdc2t7nZLwpFzbUsaW3RuxyiZm9LG1v8tp2o2cuatjaJ0k/ysoUtRnKTD1asNWtt1dDmIVpr5th6DDf/6NtaM9Uerewan7Xmkj1H72prKu7X7Vr/uYdcD8T9Ooy4fh7ivivwhiO8fvoO2onGYhMioSEAAAAASUVORK5CYII=">
  <title>Register — PlacementAI Pro</title>
  <link rel="stylesheet" href="css/style.css?v=5">
  <style>
    body { background:#0a0a0a; }
    .reg-wrap { min-height:100vh; display:flex; align-items:center; justify-content:center; padding:32px 24px; }
    .reg-card { width:100%; max-width:480px; background:#111; border:1px solid rgba(255,255,255,.09); border-radius:18px; padding:40px; box-shadow:0 20px 60px rgba(0,0,0,.7); }
    .back-link { display:inline-flex; align-items:center; gap:6px; color:var(--text3); font-size:13px; text-decoration:none; margin-bottom:28px; transition:color .15s; }
    .back-link:hover { color:var(--text2); }
  </style>
  <style>
    @keyframes regFadeUp  { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
    @keyframes regScaleIn { from{opacity:0;transform:scale(.93)} to{opacity:1;transform:scale(1)} }
    @keyframes regOrb     { 0%,100%{transform:translate(0,0)} 50%{transform:translate(15px,-20px)} }

    body { overflow-x:hidden; }
    body::before {
      content:''; position:fixed; width:500px; height:500px; border-radius:50%;
      background:radial-gradient(circle, rgba(124,106,255,.09) 0%, transparent 70%);
      top:-100px; right:-100px; pointer-events:none; z-index:0;
      animation: regOrb 10s ease-in-out infinite;
    }
    body::after {
      content:''; position:fixed; width:300px; height:300px; border-radius:50%;
      background:radial-gradient(circle, rgba(0,229,180,.06) 0%, transparent 70%);
      bottom:-80px; left:-80px; pointer-events:none; z-index:0;
      animation: regOrb 12s ease-in-out 4s infinite reverse;
    }
    /* Card spring-in — safe, no opacity:0 on shared classes */
    .auth-card, .card { animation: regScaleIn .5s cubic-bezier(.34,1.56,.64,1) .1s both; position:relative; z-index:1; }
  </style>
</head>
<body>
<div class="reg-wrap">
  <div class="reg-card">
    <a href="login.php" class="back-link">← Back to sign in</a>
    <div style="display:flex;align-items:center;gap:9px;margin-bottom:6px">
      <div style="width:32px;height:32px;background:var(--primary-g);border-radius:9px;display:flex;align-items:center;justify-content:center">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18" width="18" height="18"><defs><linearGradient id="gcl18" x1="0" y1="1" x2="1" y2="0"><stop offset="0%" stop-color="#ff4757"/><stop offset="100%" stop-color="#f59e0b"/></linearGradient></defs><rect width="18" height="18" rx="4" fill="#1e1a10"/><rect x="3" y="12" width="3" height="5" rx="1" fill="#f59e0b" opacity=".45"/><rect x="7" y="8" width="3" height="9" rx="1" fill="#ff6b35" opacity=".7"/><rect x="11" y="5" width="3" height="12" rx="1" fill="url(#gcl18)"/><polyline points="12,3 14,5 14,4" fill="none" stroke="url(#gcl18)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><line x1="11" y1="4" x2="12" y2="3" stroke="url(#gcl18)" stroke-width="1.5" stroke-linecap="round"/></svg>
      </div>
      <span style="font-weight:700;font-size:.95rem;color:var(--text)">PlacementAI Pro</span>
    </div>
    <h2 style="font-size:1.35rem;font-weight:800;letter-spacing:-.03em;margin-bottom:5px">Create student account</h2>
    <p style="color:var(--text3);font-size:13.5px;margin-bottom:26px">Start your placement journey today</p>
    <div id="alertMsg"></div>
    <form id="regForm">
      <div class="form-group">
        <label class="form-label">Full Name</label>
        <input type="text" id="rname" class="form-input" placeholder="Your full name" required>
      </div>
      <div class="form-group">
        <label class="form-label">Email</label>
        <input type="email" id="remail" class="form-input" placeholder="you@college.edu" required>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Password</label>
          <input type="password" id="rpass" class="form-input" placeholder="Min 8 chars" required>
        </div>
        <div class="form-group">
          <label class="form-label">Branch</label>
          <select id="rbranch" class="form-select">
            <option value="CSE">CSE</option><option value="IT">IT</option>
            <option value="ECE">ECE</option><option value="EEE">EEE</option>
            <option value="MECH">Mechanical</option><option value="CIVIL">Civil</option>
            <option value="MBA">MBA</option><option value="Other">Other</option>
          </select>
        </div>
      </div>
      <button type="submit" id="regBtn" class="btn btn-primary w-full" style="margin-top:8px">Create Account</button>
    </form>
    <div style="text-align:center;margin-top:18px;font-size:13px;color:var(--text3)">
      Already have an account? <a href="login.php" style="color:var(--primary-l);font-weight:600">Sign in</a>
    </div>
    <div style="text-align:center;margin-top:8px;font-size:13px;color:var(--text3)">
      Registering a company? <a href="register-org.php" style="color:var(--primary-l);font-weight:600">Register organization</a>
    </div>
  </div>
</div>
<script src="js/app.js?v=5"></script>
<script>
document.getElementById('regForm').addEventListener('submit', async e => {
  e.preventDefault();
  const btn = document.getElementById('regBtn');
  const alertDiv = document.getElementById('alertMsg');
  alertDiv.innerHTML = '';
  loading(btn, true, 'Creating account…');
  try {
    const data = await API.post('auth_register.php', {
      name:     document.getElementById('rname').value.trim(),
      email:    document.getElementById('remail').value.trim(),
      password: document.getElementById('rpass').value,
      branch:   document.getElementById('rbranch').value
    });
    if (data.user) {
      Auth.setUser(data.user);
      alertDiv.innerHTML = '<div class="alert alert-success">✓ Account created! Redirecting…</div>';
      setTimeout(() => location.href = 'dashboard.php', 700);
    } else {
      alertDiv.innerHTML = '<div class="alert alert-success">✓ Account created! Please sign in.</div>';
      setTimeout(() => location.href = 'login.php', 1000);
    }
  } catch(err) {
    loading(btn, false);
    alertDiv.innerHTML = `<div class="alert alert-error">⚠ ${esc(err.message)}</div>`;
  }
});
</script>
</body>
</html>

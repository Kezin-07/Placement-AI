<?php
// Force show ALL errors immediately - no buffering
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$step = isset($_GET['step']) ? (int)$_GET['step'] : 0;
$msg = '';
$error = '';

if ($step === 1) {
    // Test MySQL connection
    try {
        $pdo = new PDO('mysql:host=localhost;charset=utf8mb4', 'root', '',
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        $msg = 'Connected to MySQL successfully!';
    } catch (Exception $e) {
        $error = 'Connection failed: ' . $e->getMessage();
    }
    header('Content-Type: application/json');
    echo json_encode(['msg' => $msg, 'error' => $error]);
    exit;
}

if ($step === 2) {
    // Create DB and tables
    $log = [];
    try {
        $pdo = new PDO('mysql:host=localhost;charset=utf8mb4', 'root', '',
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `placement_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $log[] = ['ok', 'Database placement_db created'];
        
        $pdo->exec("USE `placement_db`");
        
        // Run schema files
        foreach (['sql/schema_v3.sql', 'sql/schema_v4_features.sql'] as $file) {
            $path = __DIR__ . '/' . $file;
            if (!file_exists($path)) { $log[] = ['warn', "File not found: $file"]; continue; }
            
            $sql = file_get_contents($path);
            // Remove comments
            $sql = preg_replace('/--[^\n]*/', '', $sql);
            $sql = preg_replace('/\/\*.*?\*\//s', '', $sql);
            
            $stmts = array_filter(array_map('trim', explode(';', $sql)));
            $ok = 0; $skip = 0;
            foreach ($stmts as $s) {
                if (!$s) continue;
                try { $pdo->exec($s); $ok++; }
                catch (PDOException $e) {
                    $code = $e->getCode();
                    // Ignore: already exists (1050), duplicate entry (1062), duplicate col (1060), unknown DB in USE (1049 handled above)
                    if (in_array($code, ['1050','1060','1061','1062','42S01'])) { $skip++; }
                    else { $log[] = ['warn', basename($file).': '.$e->getMessage()]; }
                }
            }
            $log[] = ['ok', basename($file).": $ok statements ran, $skip skipped (already exist)"];
        }
        
        // Count results
        $users = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
        $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
        $log[] = ['ok', count($tables).' tables, '.$users.' users ready'];
        $log[] = ['done', 'Setup complete!'];
        
    } catch (Exception $e) {
        $log[] = ['error', $e->getMessage()];
    }
    header('Content-Type: application/json');
    echo json_encode(['log' => $log]);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="icon" type="image/svg+xml" href="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAzMiAzMiIgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIj4KICA8ZGVmcz4KICAgIDxsaW5lYXJHcmFkaWVudCBpZD0iZyIgeDE9IjAiIHkxPSIxIiB4Mj0iMSIgeTI9IjAiPgogICAgICA8c3RvcCBvZmZzZXQ9IjAlIiBzdG9wLWNvbG9yPSIjZmY0NzU3Ii8+CiAgICAgIDxzdG9wIG9mZnNldD0iMTAwJSIgc3RvcC1jb2xvcj0iI2Y1OWUwYiIvPgogICAgPC9saW5lYXJHcmFkaWVudD4KICA8L2RlZnM+CiAgPHJlY3Qgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIiByeD0iNyIgZmlsbD0iIzFlMWExMCIvPgogIDxyZWN0IHg9IjYiIHk9IjIxIiB3aWR0aD0iNSIgaGVpZ2h0PSI5IiByeD0iMS41IiBmaWxsPSIjZjU5ZTBiIiBvcGFjaXR5PSIuNSIvPgogIDxyZWN0IHg9IjEzIiB5PSIxNSIgd2lkdGg9IjUiIGhlaWdodD0iMTUiIHJ4PSIxLjUiIGZpbGw9IiNmZjZiMzUiIG9wYWNpdHk9Ii43NSIvPgogIDxyZWN0IHg9IjIwIiB5PSI4IiB3aWR0aD0iNSIgaGVpZ2h0PSIyMiIgcng9IjEuNSIgZmlsbD0idXJsKCNnKSIvPgogIDxwb2x5bGluZSBwb2ludHM9IjIzLDQgMjcsOCAyNyw1IiBmaWxsPSJub25lIiBzdHJva2U9InVybCgjZykiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIi8+CiAgPGxpbmUgeDE9IjE5IiB5MT0iNSIgeDI9IjI3IiB5Mj0iNCIgc3Ryb2tlPSJ1cmwoI2cpIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPgo8L3N2Zz4=">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>PlacementAI Pro — Setup</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#0a0a0a;color:#fafafa;font-family:-apple-system,'Inter',sans-serif;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px}
.card{background:#1a1a1a;border:1px solid rgba(255,255,255,.1);border-radius:16px;padding:36px;max-width:540px;width:100%}
h1{font-size:1.4rem;font-weight:800;margin-bottom:6px}
.sub{color:#a0a0a0;font-size:13px;margin-bottom:24px}
.btn{width:100%;padding:14px;background:linear-gradient(135deg,#7c6aff,#a78bfa);border:none;border-radius:10px;color:#fff;font-size:15px;font-weight:700;cursor:pointer;margin-bottom:12px}
.btn:disabled{opacity:.4;cursor:not-allowed}
.log{margin-top:20px;font-size:13px;font-family:monospace;display:flex;flex-direction:column;gap:6px}
.line{padding:8px 12px;border-radius:6px}
.line.ok{background:rgba(0,214,143,.1);color:#00d68f;border:1px solid rgba(0,214,143,.2)}
.line.warn{background:rgba(245,158,11,.1);color:#f59e0b;border:1px solid rgba(245,158,11,.2)}
.line.error{background:rgba(255,71,87,.1);color:#ff6b7a;border:1px solid rgba(255,71,87,.2)}
.line.info{background:rgba(124,106,255,.1);color:#a78bfa;border:1px solid rgba(124,106,255,.2)}
.line.done{background:rgba(0,214,143,.15);color:#00d68f;border:2px solid rgba(0,214,143,.4);font-weight:700;font-size:14px}
.creds{background:#111;border:1px solid rgba(255,255,255,.08);border-radius:8px;padding:14px;margin-top:16px;font-size:13px;line-height:2;display:none}
.creds strong{color:#a78bfa}
a.go{display:block;text-align:center;padding:13px;background:linear-gradient(135deg,#7c6aff,#a78bfa);border-radius:10px;color:#fff;font-weight:700;font-size:14px;text-decoration:none;margin-top:12px;display:none}
</style>
</head>
<body>
<div class="card">
  <h1>🚀 PlacementAI Pro — Database Setup</h1>
  <p class="sub">Creates <strong>placement_db</strong> and all tables on your XAMPP MySQL.</p>

  <button class="btn" id="btn" onclick="runSetup()">▶ Run Setup Now</button>

  <div class="log" id="log"></div>
  <div class="creds" id="creds">
    <strong>Demo credentials (password: password123)</strong><br>
    Student: rahul@student.com<br>
    Admin: admin@placementai.com<br>
    Org: hr@google.com
  </div>
  <a href="index.php" class="go" id="goBtn">→ Go to PlacementAI Pro</a>
</div>

<script>
function addLine(type, msg) {
  const d = document.createElement('div');
  d.className = 'line ' + type;
  d.textContent = msg;
  document.getElementById('log').appendChild(d);
}

async function runSetup() {
  const btn = document.getElementById('btn');
  btn.disabled = true;
  btn.textContent = '⏳ Running...';
  document.getElementById('log').innerHTML = '';

  // Step 1: test connection
  addLine('info', '→ Testing MySQL connection...');
  try {
    const r1 = await fetch('setup.php?step=1');
    const t1 = await r1.text();
    
    if (!t1.trim()) {
      addLine('error', '✗ Server returned empty response. Check XAMPP Apache & PHP are running.');
      btn.disabled = false; btn.textContent = '↺ Retry';
      return;
    }
    
    let d1;
    try { d1 = JSON.parse(t1); }
    catch(e) {
      addLine('error', '✗ PHP error: ' + t1.replace(/<[^>]+>/g,' ').trim().substring(0,300));
      btn.disabled = false; btn.textContent = '↺ Retry';
      return;
    }
    
    if (d1.error) { addLine('error', '✗ ' + d1.error); btn.disabled = false; btn.textContent = '↺ Retry'; return; }
    addLine('ok', '✓ ' + d1.msg);
  } catch(e) {
    addLine('error', '✗ Fetch failed: ' + e.message);
    btn.disabled = false; btn.textContent = '↺ Retry';
    return;
  }

  // Step 2: create DB & tables
  addLine('info', '→ Creating database and tables...');
  try {
    const r2 = await fetch('setup.php?step=2');
    const t2 = await r2.text();
    
    if (!t2.trim()) {
      addLine('error', '✗ Empty response on step 2. Check PHP error logs.');
      btn.disabled = false; btn.textContent = '↺ Retry';
      return;
    }
    
    let d2;
    try { d2 = JSON.parse(t2); }
    catch(e) {
      addLine('error', '✗ PHP error: ' + t2.replace(/<[^>]+>/g,' ').trim().substring(0,300));
      btn.disabled = false; btn.textContent = '↺ Retry';
      return;
    }

    for (const [type, msg] of (d2.log || [])) {
      addLine(type, msg);
    }

    const hasDone = (d2.log || []).some(l => l[0] === 'done');
    const hasError = (d2.log || []).some(l => l[0] === 'error');

    if (hasDone && !hasError) {
      document.getElementById('creds').style.display = 'block';
      document.getElementById('goBtn').style.display = 'block';
      btn.textContent = '✓ Done!';
    } else {
      btn.disabled = false;
      btn.textContent = '↺ Retry';
    }
  } catch(e) {
    addLine('error', '✗ ' + e.message);
    btn.disabled = false; btn.textContent = '↺ Retry';
  }
}
</script>
</body>
</html>
